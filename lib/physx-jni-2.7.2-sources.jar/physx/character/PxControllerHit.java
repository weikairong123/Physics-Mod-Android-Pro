package physx.character;

import physx.NativeObject;
import physx.common.PxVec3;

/**
 * Describes a generic CCT hit.
 */
public class PxControllerHit extends NativeObject {

    protected PxControllerHit() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxControllerHit wrapPointer(long address) {
        return address != 0L ? new PxControllerHit(address) : null;
    }
    
    public static PxControllerHit arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxControllerHit(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Current controller
     */
    public PxController getController() {
        checkNotNull();
        return PxController.wrapPointer(Raw.getController(address));
    }

    /**
     * Current controller
     */
    public void setController(PxController value) {
        checkNotNull();
        Raw.setController(address, value.getAddress());
    }

    /**
     * Contact position in world space
     */
    public PxExtendedVec3 getWorldPos() {
        checkNotNull();
        return PxExtendedVec3.wrapPointer(Raw.getWorldPos(address));
    }

    /**
     * Contact position in world space
     */
    public void setWorldPos(PxExtendedVec3 value) {
        checkNotNull();
        Raw.setWorldPos(address, value.getAddress());
    }

    /**
     * Contact normal in world space
     */
    public PxVec3 getWorldNormal() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getWorldNormal(address));
    }

    /**
     * Contact normal in world space
     */
    public void setWorldNormal(PxVec3 value) {
        checkNotNull();
        Raw.setWorldNormal(address, value.getAddress());
    }

    /**
     * Motion direction
     */
    public PxVec3 getDir() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getDir(address));
    }

    /**
     * Motion direction
     */
    public void setDir(PxVec3 value) {
        checkNotNull();
        Raw.setDir(address, value.getAddress());
    }

    /**
     * Motion length
     */
    public float getLength() {
        checkNotNull();
        return Raw.getLength(address);
    }

    /**
     * Motion length
     */
    public void setLength(float value) {
        checkNotNull();
        Raw.setLength(address, value);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getController(long address);
        public static native void setController(long address, long value);
        public static native long getWorldPos(long address);
        public static native void setWorldPos(long address, long value);
        public static native long getWorldNormal(long address);
        public static native void setWorldNormal(long address, long value);
        public static native long getDir(long address);
        public static native void setDir(long address, long value);
        public static native float getLength(long address);
        public static native void setLength(long address, float value);
    }
}
