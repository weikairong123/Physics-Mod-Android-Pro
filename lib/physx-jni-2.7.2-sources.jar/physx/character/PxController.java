package physx.character;

import physx.NativeObject;
import physx.common.PxVec3;
import physx.physics.PxRigidDynamic;
import physx.physics.PxScene;

/**
 * Base class for character controllers.
 * @see PxCapsuleController
 * @see PxBoxController
 */
public class PxController extends NativeObject {

    protected PxController() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxController wrapPointer(long address) {
        return address != 0L ? new PxController(address) : null;
    }
    
    public static PxController arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxController(long address) {
        super(address);
    }

    // Functions

    /**
     * Return the type of controller
     */
    public PxControllerShapeTypeEnum getType() {
        checkNotNull();
        return PxControllerShapeTypeEnum.forValue(Raw.getType(address));
    }

    /**
     * Releases the controller.
     */
    public void release() {
        checkNotNull();
        Raw.release(address);
    }

    /**
     * Moves the character using a "collide-and-slide" algorithm.
     * @param disp Displacement vector
     * @param minDist The minimum travelled distance to consider. If travelled distance is smaller, the character doesn't move.
     * This is used to stop the recursive motion algorithm when remaining distance to travel is small.
     * @param elapsedTime Time elapsed since last call
     * @param filters User-defined filters for this move
     * @return Collision flags, collection of ::PxControllerCollisionFlags
     */
    public PxControllerCollisionFlags move(PxVec3 disp, float minDist, float elapsedTime, PxControllerFilters filters) {
        checkNotNull();
        return PxControllerCollisionFlags.wrapPointer(Raw.move(address, disp.getAddress(), minDist, elapsedTime, filters.getAddress()));
    }

    /**
     * Moves the character using a "collide-and-slide" algorithm.
     * @param disp Displacement vector
     * @param minDist The minimum travelled distance to consider. If travelled distance is smaller, the character doesn't move.
     * This is used to stop the recursive motion algorithm when remaining distance to travel is small.
     * @param elapsedTime Time elapsed since last call
     * @param filters User-defined filters for this move
     * @param obstacles Potential additional obstacles the CCT should collide with.
     * @return Collision flags, collection of ::PxControllerCollisionFlags
     */
    public PxControllerCollisionFlags move(PxVec3 disp, float minDist, float elapsedTime, PxControllerFilters filters, PxObstacleContext obstacles) {
        checkNotNull();
        return PxControllerCollisionFlags.wrapPointer(Raw.move(address, disp.getAddress(), minDist, elapsedTime, filters.getAddress(), obstacles.getAddress()));
    }

    /**
     * Sets controller's position.
     * <p>
     * The position controlled by this function is the center of the collision shape.
     * <p>
     * \warning This is a 'teleport' function, it doesn't check for collisions.
     * \warning The character's position must be such that it does not overlap the static geometry.
     * <p>
     * To move the character under normal conditions use the #move() function.
     * @param position The new (center) positon for the controller.
     * @return Currently always returns true.
     * @see #getPosition
     * @see #getFootPosition
     * @see #setFootPosition
     * @see #move
     */
    public boolean setPosition(PxExtendedVec3 position) {
        checkNotNull();
        return Raw.setPosition(address, position.getAddress());
    }

    /**
     * Retrieve the raw position of the controller.
     * <p>
     * The position retrieved by this function is the center of the collision shape. To retrieve the bottom position of the shape,
     * a.k.a. the foot position, use the getFootPosition() function.
     * <p>
     * The position is updated by calls to move(). Calling this method without calling
     * move() will return the last position or the initial position of the controller.
     * @return The controller's center position
     * @see #setPosition
     * @see #getFootPosition
     * @see #setFootPosition
     * @see #move
     */
    public PxExtendedVec3 getPosition() {
        checkNotNull();
        return PxExtendedVec3.wrapPointer(Raw.getPosition(address));
    }

    /**
     * Set controller's foot position.
     * <p>
     * The position controlled by this function is the bottom of the collision shape, a.k.a. the foot position.
     * <p>
     * <b>Note:</b> The foot position takes the contact offset into account
     * <p>
     * \warning This is a 'teleport' function, it doesn't check for collisions.
     * <p>
     * To move the character under normal conditions use the #move() function.
     * @param position The new (bottom) positon for the controller.
     * @return Currently always returns true.
     * @see #setPosition
     * @see #getPosition
     * @see #getFootPosition
     * @see #move
     */
    public boolean setFootPosition(PxExtendedVec3 position) {
        checkNotNull();
        return Raw.setFootPosition(address, position.getAddress());
    }

    /**
     * Retrieve the "foot" position of the controller, i.e. the position of the bottom of the CCT's shape.
     * <p>
     * <b>Note:</b> The foot position takes the contact offset into account
     * @return The controller's foot position
     * @see #setPosition
     * @see #getPosition
     * @see #setFootPosition
     * @see #move
     */
    public PxExtendedVec3 getFootPosition() {
        checkNotNull();
        return PxExtendedVec3.wrapPointer(Raw.getFootPosition(address));
    }

    /**
     * Get the rigid body actor associated with this controller (see PhysX documentation). 
     * The behavior upon manually altering this actor is undefined, you should primarily 
     * use it for reading const properties.
     * @return the actor associated with the controller.
     */
    public PxRigidDynamic getActor() {
        checkNotNull();
        return PxRigidDynamic.wrapPointer(Raw.getActor(address));
    }

    /**
     * The step height.
     * @param offset The new step offset for the controller.
     */
    public void setStepOffset(float offset) {
        checkNotNull();
        Raw.setStepOffset(address, offset);
    }

    /**
     * Retrieve the step height.
     * @return The step offset for the controller.
     * @see #setStepOffset
     */
    public float getStepOffset() {
        checkNotNull();
        return Raw.getStepOffset(address);
    }

    /**
     * Sets the non-walkable mode for the CCT.
     * @param flag The new value of the non-walkable mode.
     */
    public void setNonWalkableMode(PxControllerNonWalkableModeEnum flag) {
        checkNotNull();
        Raw.setNonWalkableMode(address, flag.value);
    }

    /**
     * Retrieves the non-walkable mode for the CCT.
     * @return The current non-walkable mode.
     */
    public PxControllerNonWalkableModeEnum getNonWalkableMode() {
        checkNotNull();
        return PxControllerNonWalkableModeEnum.forValue(Raw.getNonWalkableMode(address));
    }

    /**
     * Retrieve the contact offset.
     * @return The contact offset for the controller.
     */
    public float getContactOffset() {
        checkNotNull();
        return Raw.getContactOffset(address);
    }

    /**
     * Sets the contact offset.
     * @param offset The contact offset for the controller.
     */
    public void setContactOffset(float offset) {
        checkNotNull();
        Raw.setContactOffset(address, offset);
    }

    /**
     * Retrieve the 'up' direction.
     * @return The up direction for the controller.
     */
    public PxVec3 getUpDirection() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getUpDirection(address));
    }

    /**
     * Sets the 'up' direction.
     * @param up The up direction for the controller.
     */
    public void setUpDirection(PxVec3 up) {
        checkNotNull();
        Raw.setUpDirection(address, up.getAddress());
    }

    /**
     * Retrieve the slope limit.
     * @return The slope limit for the controller.
     */
    public float getSlopeLimit() {
        checkNotNull();
        return Raw.getSlopeLimit(address);
    }

    /**
     * Sets the slope limit.
     * <p>
     * <b>Note:</b> This feature can not be enabled at runtime, i.e. if the slope limit is zero when creating the CCT
     * (which disables the feature) then changing the slope limit at runtime will not have any effect, and the call
     * will be ignored.
     * @param slopeLimit The slope limit for the controller.
     */
    public void setSlopeLimit(float slopeLimit) {
        checkNotNull();
        Raw.setSlopeLimit(address, slopeLimit);
    }

    /**
     * Flushes internal geometry cache.
     * <p>
     * The character controller uses caching in order to speed up collision testing. The cache is
     * automatically flushed when a change to static objects is detected in the scene. For example when a
     * static shape is added, updated, or removed from the scene, the cache is automatically invalidated.
     * <p>
     * However there may be situations that cannot be automatically detected, and those require manual
     * invalidation of the cache. Currently the user must call this when the filtering behavior changes (the
     * PxControllerFilters parameter of the PxController::move call).  While the controller in principle 
     * could detect a change in these parameters, it cannot detect a change in the behavior of the filtering 
     * function.
     * @see PxController#move
     */
    public void invalidateCache() {
        checkNotNull();
        Raw.invalidateCache(address);
    }

    /**
     * Retrieve the scene associated with the controller.
     * @return The physics scene
     */
    public PxScene getScene() {
        checkNotNull();
        return PxScene.wrapPointer(Raw.getScene(address));
    }

    /**
     * Returns the user data associated with this controller.
     * @return The user pointer associated with the controller.
     */
    public NativeObject getUserData() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.getUserData(address));
    }

    /**
     * Sets the user data associated with this controller.
     * @param userData The user pointer associated with the controller.
     */
    public void setUserData(NativeObject userData) {
        checkNotNull();
        Raw.setUserData(address, userData.getAddress());
    }

    /**
     * Returns information about the controller's internal state.
     * @param state The controller's internal state
     * @see PxControllerState
     */
    public void getState(PxControllerState state) {
        checkNotNull();
        Raw.getState(address, state.getAddress());
    }

    /**
     * Returns the controller's internal statistics.
     * @param stats The controller's internal statistics
     * @see PxControllerStats
     */
    public void getStats(PxControllerStats stats) {
        checkNotNull();
        Raw.getStats(address, stats.getAddress());
    }

    /**
     * Resizes the controller.
     * <p>
     * This function attempts to resize the controller to a given size, while making sure the bottom
     * position of the controller remains constant. In other words the function modifies both the
     * height and the (center) position of the controller. This is a helper function that can be used
     * to implement a 'crouch' functionality for example.
     * @param height Desired controller's height
     */
    public void resize(float height) {
        checkNotNull();
        Raw.resize(address, height);
    }

    public static class Raw {
        public static native int getType(long address);
        public static native void release(long address);
        public static native long move(long address, long disp, float minDist, float elapsedTime, long filters);
        public static native long move(long address, long disp, float minDist, float elapsedTime, long filters, long obstacles);
        public static native boolean setPosition(long address, long position);
        public static native long getPosition(long address);
        public static native boolean setFootPosition(long address, long position);
        public static native long getFootPosition(long address);
        public static native long getActor(long address);
        public static native void setStepOffset(long address, float offset);
        public static native float getStepOffset(long address);
        public static native void setNonWalkableMode(long address, int flag);
        public static native int getNonWalkableMode(long address);
        public static native float getContactOffset(long address);
        public static native void setContactOffset(long address, float offset);
        public static native long getUpDirection(long address);
        public static native void setUpDirection(long address, long up);
        public static native float getSlopeLimit(long address);
        public static native void setSlopeLimit(long address, float slopeLimit);
        public static native void invalidateCache(long address);
        public static native long getScene(long address);
        public static native long getUserData(long address);
        public static native void setUserData(long address, long userData);
        public static native void getState(long address, long state);
        public static native void getStats(long address, long stats);
        public static native void resize(long address, float height);
    }
}
