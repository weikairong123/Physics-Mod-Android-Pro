package physx.character;

import physx.NativeObject;
import physx.common.PxQuat;
import physx.geometry.PxGeometryTypeEnum;

/**
 * Base class for obstacles.
 * @see PxBoxObstacle
 * @see PxCapsuleObstacle
 * @see PxObstacleContext
 */
public class PxObstacle extends NativeObject {

    protected PxObstacle() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxObstacle wrapPointer(long address) {
        return address != 0L ? new PxObstacle(address) : null;
    }
    
    public static PxObstacle arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxObstacle(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    public NativeObject getMUserData() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.getMUserData(address));
    }

    public void setMUserData(NativeObject value) {
        checkNotNull();
        Raw.setMUserData(address, value.getAddress());
    }

    public PxExtendedVec3 getMPos() {
        checkNotNull();
        return PxExtendedVec3.wrapPointer(Raw.getMPos(address));
    }

    public void setMPos(PxExtendedVec3 value) {
        checkNotNull();
        Raw.setMPos(address, value.getAddress());
    }

    public PxQuat getMRot() {
        checkNotNull();
        return PxQuat.wrapPointer(Raw.getMRot(address));
    }

    public void setMRot(PxQuat value) {
        checkNotNull();
        Raw.setMRot(address, value.getAddress());
    }

    // Functions

    /**
     * @return WebIDL type: {@link PxGeometryTypeEnum} [enum]
     */
    public PxGeometryTypeEnum getType() {
        checkNotNull();
        return PxGeometryTypeEnum.forValue(Raw.getType(address));
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getMUserData(long address);
        public static native void setMUserData(long address, long value);
        public static native long getMPos(long address);
        public static native void setMPos(long address, long value);
        public static native long getMRot(long address);
        public static native void setMRot(long address, long value);
        public static native int getType(long address);
    }
}
