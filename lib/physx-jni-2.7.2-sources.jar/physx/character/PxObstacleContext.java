package physx.character;

import physx.NativeObject;

/**
 * Context class for obstacles.
 * <p>
 * An obstacle context class contains and manages a set of user-defined obstacles.
 * @see PxBoxObstacle
 * @see PxCapsuleObstacle
 * @see PxObstacle
 */
public class PxObstacleContext extends NativeObject {

    protected PxObstacleContext() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxObstacleContext wrapPointer(long address) {
        return address != 0L ? new PxObstacleContext(address) : null;
    }
    
    public static PxObstacleContext arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxObstacleContext(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * Releases the context.
     */
    public void release() {
        checkNotNull();
        Raw.release(address);
    }

    /**
     * Retrieves the controller manager associated with this context.
     * @return The associated controller manager
     */
    public PxControllerManager getControllerManager() {
        checkNotNull();
        return PxControllerManager.wrapPointer(Raw.getControllerManager(address));
    }

    /**
     * Adds an obstacle to the context.
     * @return Handle for newly-added obstacle
     */
    public int addObstacle(PxObstacle obstacle) {
        checkNotNull();
        return Raw.addObstacle(address, obstacle.getAddress());
    }

    /**
     * Removes an obstacle from the context.
     * @return True if success
     */
    public boolean removeObstacle(int handle) {
        checkNotNull();
        return Raw.removeObstacle(address, handle);
    }

    /**
     * Updates data for an existing obstacle.
     * @return True if success
     */
    public boolean updateObstacle(int handle, PxObstacle obstacle) {
        checkNotNull();
        return Raw.updateObstacle(address, handle, obstacle.getAddress());
    }

    /**
     * Retrieves number of obstacles in the context.
     * @return Number of obstacles in the context
     */
    public int getNbObstacles() {
        checkNotNull();
        return Raw.getNbObstacles(address);
    }

    /**
     * Retrieves desired obstacle.
     * @return Desired obstacle
     */
    public PxObstacle getObstacle(int i) {
        checkNotNull();
        return PxObstacle.wrapPointer(Raw.getObstacle(address, i));
    }

    /**
     * Retrieves desired obstacle by given handle.
     * @return Desired obstacle
     */
    public PxObstacle getObstacleByHandle(int handle) {
        checkNotNull();
        return PxObstacle.wrapPointer(Raw.getObstacleByHandle(address, handle));
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native void release(long address);
        public static native long getControllerManager(long address);
        public static native int addObstacle(long address, long obstacle);
        public static native boolean removeObstacle(long address, int handle);
        public static native boolean updateObstacle(long address, int handle, long obstacle);
        public static native int getNbObstacles(long address);
        public static native long getObstacle(long address, int i);
        public static native long getObstacleByHandle(long address, int handle);
    }
}
