package physx.character;

import physx.NativeObject;

public class PxControllerBehaviorFlags extends NativeObject {

    protected PxControllerBehaviorFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxControllerBehaviorFlags wrapPointer(long address) {
        return address != 0L ? new PxControllerBehaviorFlags(address) : null;
    }
    
    public static PxControllerBehaviorFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxControllerBehaviorFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: octet
     * @return Stack allocated object of PxControllerBehaviorFlags
     */
    public static PxControllerBehaviorFlags createAt(long address, byte flags) {
        Raw.PxControllerBehaviorFlags_placed(address, flags);
        PxControllerBehaviorFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: octet
     * @return Stack allocated object of PxControllerBehaviorFlags
     */
    public static <T> PxControllerBehaviorFlags createAt(T allocator, Allocator<T> allocate, byte flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxControllerBehaviorFlags_placed(address, flags);
        PxControllerBehaviorFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param flags WebIDL type: octet
     */
    public PxControllerBehaviorFlags(byte flags) {
        address = Raw.PxControllerBehaviorFlags(flags);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param flag WebIDL type: {@link PxControllerBehaviorFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxControllerBehaviorFlagEnum flag) {
        checkNotNull();
        return Raw.isSet(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxControllerBehaviorFlagEnum} [enum]
     */
    public void raise(PxControllerBehaviorFlagEnum flag) {
        checkNotNull();
        Raw.raise(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxControllerBehaviorFlagEnum} [enum]
     */
    public void clear(PxControllerBehaviorFlagEnum flag) {
        checkNotNull();
        Raw.clear(address, flag.value);
    }

    public static class Raw {
        public static native void PxControllerBehaviorFlags_placed(long address, byte flags);
        public static native long PxControllerBehaviorFlags(byte flags);
        public static native void destroy(long address);
        public static native boolean isSet(long address, int flag);
        public static native void raise(long address, int flag);
        public static native void clear(long address, int flag);
    }
}
