package physx.character;

import physx.physics.PxActor;
import physx.physics.PxShape;

public class SimpleControllerBehaviorCallback extends PxControllerBehaviorCallback {

    protected SimpleControllerBehaviorCallback() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static SimpleControllerBehaviorCallback wrapPointer(long address) {
        return address != 0L ? new SimpleControllerBehaviorCallback(address) : null;
    }
    
    public static SimpleControllerBehaviorCallback arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected SimpleControllerBehaviorCallback(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param shape WebIDL type: {@link PxShape} [Const, Ref]
     * @param actor WebIDL type: {@link PxActor} [Const, Ref]
     * @return WebIDL type: unsigned long
     */
    public int getShapeBehaviorFlags(PxShape shape, PxActor actor) {
        checkNotNull();
        return Raw.getShapeBehaviorFlags(address, shape.getAddress(), actor.getAddress());
    }

    /**
     * @param controller WebIDL type: {@link PxController} [Const, Ref]
     * @return WebIDL type: unsigned long
     */
    public int getControllerBehaviorFlags(PxController controller) {
        checkNotNull();
        return Raw.getControllerBehaviorFlags(address, controller.getAddress());
    }

    /**
     * @param obstacle WebIDL type: {@link PxObstacle} [Const, Ref]
     * @return WebIDL type: unsigned long
     */
    public int getObstacleBehaviorFlags(PxObstacle obstacle) {
        checkNotNull();
        return Raw.getObstacleBehaviorFlags(address, obstacle.getAddress());
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native int getShapeBehaviorFlags(long address, long shape, long actor);
        public static native int getControllerBehaviorFlags(long address, long controller);
        public static native int getObstacleBehaviorFlags(long address, long obstacle);
    }
}
