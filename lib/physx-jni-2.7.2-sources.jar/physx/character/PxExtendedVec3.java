package physx.character;

import physx.NativeObject;

public class PxExtendedVec3 extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxExtendedVec3 wrapPointer(long address) {
        return address != 0L ? new PxExtendedVec3(address) : null;
    }
    
    public static PxExtendedVec3 arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxExtendedVec3(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxExtendedVec3
     */
    public static PxExtendedVec3 createAt(long address) {
        Raw.PxExtendedVec3_placed(address);
        PxExtendedVec3 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxExtendedVec3
     */
    public static <T> PxExtendedVec3 createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxExtendedVec3_placed(address);
        PxExtendedVec3 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param x       WebIDL type: double
     * @param y       WebIDL type: double
     * @param z       WebIDL type: double
     * @return Stack allocated object of PxExtendedVec3
     */
    public static PxExtendedVec3 createAt(long address, double x, double y, double z) {
        Raw.PxExtendedVec3_placed(address, x, y, z);
        PxExtendedVec3 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param x         WebIDL type: double
     * @param y         WebIDL type: double
     * @param z         WebIDL type: double
     * @return Stack allocated object of PxExtendedVec3
     */
    public static <T> PxExtendedVec3 createAt(T allocator, Allocator<T> allocate, double x, double y, double z) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxExtendedVec3_placed(address, x, y, z);
        PxExtendedVec3 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxExtendedVec3() {
        address = Raw.PxExtendedVec3();
    }

    /**
     * @param x WebIDL type: double
     * @param y WebIDL type: double
     * @param z WebIDL type: double
     */
    public PxExtendedVec3(double x, double y, double z) {
        address = Raw.PxExtendedVec3(x, y, z);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: double
     */
    public double getX() {
        checkNotNull();
        return Raw.getX(address);
    }

    /**
     * @param value WebIDL type: double
     */
    public void setX(double value) {
        checkNotNull();
        Raw.setX(address, value);
    }

    /**
     * @return WebIDL type: double
     */
    public double getY() {
        checkNotNull();
        return Raw.getY(address);
    }

    /**
     * @param value WebIDL type: double
     */
    public void setY(double value) {
        checkNotNull();
        Raw.setY(address, value);
    }

    /**
     * @return WebIDL type: double
     */
    public double getZ() {
        checkNotNull();
        return Raw.getZ(address);
    }

    /**
     * @param value WebIDL type: double
     */
    public void setZ(double value) {
        checkNotNull();
        Raw.setZ(address, value);
    }

    public static class Raw {
        public static native void PxExtendedVec3_placed(long address);
        public static native void PxExtendedVec3_placed(long address, double x, double y, double z);
        public static native long PxExtendedVec3();
        public static native long PxExtendedVec3(double x, double y, double z);
        public static native void destroy(long address);
        public static native double getX(long address);
        public static native void setX(long address, double value);
        public static native double getY(long address);
        public static native void setY(long address, double value);
        public static native double getZ(long address);
        public static native void setZ(long address, double value);
    }
}
