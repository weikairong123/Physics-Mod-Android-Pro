package physx.geometry;

import physx.NativeObject;
import physx.PlatformChecks;
import physx.common.PxVec3;

public class PxContactBuffer extends NativeObject {

    protected PxContactBuffer() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxContactBuffer wrapPointer(long address) {
        return address != 0L ? new PxContactBuffer(address) : null;
    }
    
    public static PxContactBuffer arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxContactBuffer(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxContactPoint} [Value]
     */
    public PxContactPoint getContacts(int index) {
        checkNotNull();
        return PxContactPoint.wrapPointer(Raw.getContacts(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxContactPoint} [Value]
     */
    public void setContacts(int index, PxContactPoint value) {
        checkNotNull();
        Raw.setContacts(address, index, value.getAddress());
    }

    public int getCount() {
        checkNotNull();
        return Raw.getCount(address);
    }

    public void setCount(int value) {
        checkNotNull();
        Raw.setCount(address, value);
    }

    public int getPad() {
        checkNotNull();
        return Raw.getPad(address);
    }

    public void setPad(int value) {
        checkNotNull();
        Raw.setPad(address, value);
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public static int getMAX_CONTACTS() {
        return Raw.getMAX_CONTACTS();
    }

    // Functions

    public void reset() {
        checkNotNull();
        Raw.reset(address);
    }

    /**
     * @param worldPoint    WebIDL type: {@link PxVec3} [Const, Ref]
     * @param worldNormalIn WebIDL type: {@link PxVec3} [Const, Ref]
     * @param separation    WebIDL type: float
     * @return WebIDL type: boolean
     */
    public boolean contact(PxVec3 worldPoint, PxVec3 worldNormalIn, float separation) {
        checkNotNull();
        return Raw.contact(address, worldPoint.getAddress(), worldNormalIn.getAddress(), separation);
    }

    /**
     * @param worldPoint    WebIDL type: {@link PxVec3} [Const, Ref]
     * @param worldNormalIn WebIDL type: {@link PxVec3} [Const, Ref]
     * @param separation    WebIDL type: float
     * @param faceIndex1    WebIDL type: unsigned long
     * @return WebIDL type: boolean
     */
    public boolean contact(PxVec3 worldPoint, PxVec3 worldNormalIn, float separation, int faceIndex1) {
        checkNotNull();
        return Raw.contact(address, worldPoint.getAddress(), worldNormalIn.getAddress(), separation, faceIndex1);
    }

    /**
     * @param pt WebIDL type: {@link PxContactPoint} [Const, Ref]
     * @return WebIDL type: boolean
     */
    public boolean contact(PxContactPoint pt) {
        checkNotNull();
        return Raw.contact(address, pt.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxContactPoint} [Platforms=windows;linux;macos;android]
     */
    public PxContactPoint contact() {
        checkNotNull();
        PlatformChecks.requirePlatform(15, "physx.geometry.PxContactBuffer");
        return PxContactPoint.wrapPointer(Raw.contact(address));
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getContacts(long address, int index);
        public static native void setContacts(long address, int index, long value);
        public static native int getCount(long address);
        public static native void setCount(long address, int value);
        public static native int getPad(long address);
        public static native void setPad(long address, int value);
        public static native int getMAX_CONTACTS();
        public static native void reset(long address);
        public static native boolean contact(long address, long worldPoint, long worldNormalIn, float separation);
        public static native boolean contact(long address, long worldPoint, long worldNormalIn, float separation, int faceIndex1);
        public static native boolean contact(long address, long pt);
        public static native long contact(long address);
    }
}
