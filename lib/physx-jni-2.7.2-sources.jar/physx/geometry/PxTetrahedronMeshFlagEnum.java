package physx.geometry;

/**
 * The tetrahedron mesh has 16bits vertex indices
 */
public enum PxTetrahedronMeshFlagEnum {

    e16_BIT_INDICES(gete16_BIT_INDICES());
    public final int value;
    
    PxTetrahedronMeshFlagEnum(int value) {
        this.value = value;
    }

    private static native int _gete16_BIT_INDICES();
    private static int gete16_BIT_INDICES() {
        de.fabmax.physxjni.Loader.load();
        return _gete16_BIT_INDICES();
    }

    private static final int LUT_SIZE = 256;
    private static final PxTetrahedronMeshFlagEnum[] enumValues = values();
    private static final PxTetrahedronMeshFlagEnum[] enumLut = new PxTetrahedronMeshFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxTetrahedronMeshFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxTetrahedronMeshFlagEnum forValue(int value) {
        PxTetrahedronMeshFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxTetrahedronMeshFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxTetrahedronMeshFlagEnum: " + value);
        }
        return enumValue;
    }
}
