package physx.geometry;


/**
 * Triangle mesh geometry class.
 * <p>
 * This class unifies a mesh object with a scaling transform, and 
 * lets the combined object be used anywhere a PxGeometry is needed.
 * <p>
 * The scaling is a transform along arbitrary axes contained in the scale object.
 * The vertices of the mesh in geometry (or shape) space is the 
 * PxMeshScale::toMat33() transform, multiplied by the vertex space vertices 
 * in the PxTriangleMeshGeometry object.
 */
public class PxTriangleMeshGeometry extends PxGeometry {

    protected PxTriangleMeshGeometry() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxTriangleMeshGeometry wrapPointer(long address) {
        return address != 0L ? new PxTriangleMeshGeometry(address) : null;
    }
    
    public static PxTriangleMeshGeometry arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxTriangleMeshGeometry(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param mesh    WebIDL type: {@link PxTriangleMesh}
     * @return Stack allocated object of PxTriangleMeshGeometry
     */
    public static PxTriangleMeshGeometry createAt(long address, PxTriangleMesh mesh) {
        Raw.PxTriangleMeshGeometry_placed(address, mesh.getAddress());
        PxTriangleMeshGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param mesh      WebIDL type: {@link PxTriangleMesh}
     * @return Stack allocated object of PxTriangleMeshGeometry
     */
    public static <T> PxTriangleMeshGeometry createAt(T allocator, Allocator<T> allocate, PxTriangleMesh mesh) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxTriangleMeshGeometry_placed(address, mesh.getAddress());
        PxTriangleMeshGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param mesh    WebIDL type: {@link PxTriangleMesh}
     * @param scaling WebIDL type: {@link PxMeshScale} [Const, Ref]
     * @return Stack allocated object of PxTriangleMeshGeometry
     */
    public static PxTriangleMeshGeometry createAt(long address, PxTriangleMesh mesh, PxMeshScale scaling) {
        Raw.PxTriangleMeshGeometry_placed(address, mesh.getAddress(), scaling.getAddress());
        PxTriangleMeshGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param mesh      WebIDL type: {@link PxTriangleMesh}
     * @param scaling   WebIDL type: {@link PxMeshScale} [Const, Ref]
     * @return Stack allocated object of PxTriangleMeshGeometry
     */
    public static <T> PxTriangleMeshGeometry createAt(T allocator, Allocator<T> allocate, PxTriangleMesh mesh, PxMeshScale scaling) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxTriangleMeshGeometry_placed(address, mesh.getAddress(), scaling.getAddress());
        PxTriangleMeshGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param mesh    WebIDL type: {@link PxTriangleMesh}
     * @param scaling WebIDL type: {@link PxMeshScale} [Const, Ref]
     * @param flags   WebIDL type: {@link PxMeshGeometryFlags} [Ref]
     * @return Stack allocated object of PxTriangleMeshGeometry
     */
    public static PxTriangleMeshGeometry createAt(long address, PxTriangleMesh mesh, PxMeshScale scaling, PxMeshGeometryFlags flags) {
        Raw.PxTriangleMeshGeometry_placed(address, mesh.getAddress(), scaling.getAddress(), flags.getAddress());
        PxTriangleMeshGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param mesh      WebIDL type: {@link PxTriangleMesh}
     * @param scaling   WebIDL type: {@link PxMeshScale} [Const, Ref]
     * @param flags     WebIDL type: {@link PxMeshGeometryFlags} [Ref]
     * @return Stack allocated object of PxTriangleMeshGeometry
     */
    public static <T> PxTriangleMeshGeometry createAt(T allocator, Allocator<T> allocate, PxTriangleMesh mesh, PxMeshScale scaling, PxMeshGeometryFlags flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxTriangleMeshGeometry_placed(address, mesh.getAddress(), scaling.getAddress(), flags.getAddress());
        PxTriangleMeshGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * Constructor. By default creates an empty object with a NULL mesh and identity scale.
     * @param mesh  Mesh pointer. May be NULL, though this will not make the object valid for shape construction.
     */
    public PxTriangleMeshGeometry(PxTriangleMesh mesh) {
        address = Raw.PxTriangleMeshGeometry(mesh.getAddress());
    }

    /**
     * Constructor. By default creates an empty object with a NULL mesh and identity scale.
     * @param mesh  Mesh pointer. May be NULL, though this will not make the object valid for shape construction.
     * @param scaling Scale factor.
     */
    public PxTriangleMeshGeometry(PxTriangleMesh mesh, PxMeshScale scaling) {
        address = Raw.PxTriangleMeshGeometry(mesh.getAddress(), scaling.getAddress());
    }

    /**
     * Constructor. By default creates an empty object with a NULL mesh and identity scale.
     * @param mesh  Mesh pointer. May be NULL, though this will not make the object valid for shape construction.
     * @param scaling Scale factor.
     * @param flags Mesh flags.
     */
    public PxTriangleMeshGeometry(PxTriangleMesh mesh, PxMeshScale scaling, PxMeshGeometryFlags flags) {
        address = Raw.PxTriangleMeshGeometry(mesh.getAddress(), scaling.getAddress(), flags.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The scaling transformation.
     */
    public PxMeshScale getScale() {
        checkNotNull();
        return PxMeshScale.wrapPointer(Raw.getScale(address));
    }

    /**
     * The scaling transformation.
     */
    public void setScale(PxMeshScale value) {
        checkNotNull();
        Raw.setScale(address, value.getAddress());
    }

    /**
     * Mesh flags.
     */
    public PxMeshGeometryFlags getMeshFlags() {
        checkNotNull();
        return PxMeshGeometryFlags.wrapPointer(Raw.getMeshFlags(address));
    }

    /**
     * Mesh flags.
     */
    public void setMeshFlags(PxMeshGeometryFlags value) {
        checkNotNull();
        Raw.setMeshFlags(address, value.getAddress());
    }

    /**
     * A reference to the mesh object.
     */
    public PxTriangleMesh getTriangleMesh() {
        checkNotNull();
        return PxTriangleMesh.wrapPointer(Raw.getTriangleMesh(address));
    }

    /**
     * A reference to the mesh object.
     */
    public void setTriangleMesh(PxTriangleMesh value) {
        checkNotNull();
        Raw.setTriangleMesh(address, value.getAddress());
    }

    // Functions

    /**
     * Returns true if the geometry is valid.
     * @return  True if the current settings are valid for shape creation.
     * <p>
     * <b>Note:</b> A valid triangle mesh has a positive scale value in each direction (scale.scale.x &gt; 0, scale.scale.y &gt; 0, scale.scale.z &gt; 0).
     * It is illegal to call PxPhysics::createShape with a triangle mesh that has zero extents in any direction.
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native void PxTriangleMeshGeometry_placed(long address, long mesh);
        public static native void PxTriangleMeshGeometry_placed(long address, long mesh, long scaling);
        public static native void PxTriangleMeshGeometry_placed(long address, long mesh, long scaling, long flags);
        public static native long PxTriangleMeshGeometry(long mesh);
        public static native long PxTriangleMeshGeometry(long mesh, long scaling);
        public static native long PxTriangleMeshGeometry(long mesh, long scaling, long flags);
        public static native void destroy(long address);
        public static native long getScale(long address);
        public static native void setScale(long address, long value);
        public static native long getMeshFlags(long address);
        public static native void setMeshFlags(long address, long value);
        public static native long getTriangleMesh(long address);
        public static native void setTriangleMesh(long address, long value);
        public static native boolean isValid(long address);
    }
}
