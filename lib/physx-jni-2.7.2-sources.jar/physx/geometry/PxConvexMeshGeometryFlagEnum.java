package physx.geometry;

/**
 * Flags controlling the simulated behavior of the convex mesh geometry.
 * <p>
 * Used in ::PxConvexMeshGeometryFlags.
 */
public enum PxConvexMeshGeometryFlagEnum {

    eTIGHT_BOUNDS(geteTIGHT_BOUNDS());
    public final int value;
    
    PxConvexMeshGeometryFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteTIGHT_BOUNDS();
    private static int geteTIGHT_BOUNDS() {
        de.fabmax.physxjni.Loader.load();
        return _geteTIGHT_BOUNDS();
    }

    private static final int LUT_SIZE = 256;
    private static final PxConvexMeshGeometryFlagEnum[] enumValues = values();
    private static final PxConvexMeshGeometryFlagEnum[] enumLut = new PxConvexMeshGeometryFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxConvexMeshGeometryFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxConvexMeshGeometryFlagEnum forValue(int value) {
        PxConvexMeshGeometryFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxConvexMeshGeometryFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxConvexMeshGeometryFlagEnum: " + value);
        }
        return enumValue;
    }
}
