package physx.geometry;

import physx.NativeObject;

public class PxConvexCoreSegment extends NativeObject {

    protected PxConvexCoreSegment() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxConvexCoreSegment wrapPointer(long address) {
        return address != 0L ? new PxConvexCoreSegment(address) : null;
    }
    
    public static PxConvexCoreSegment arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxConvexCoreSegment(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param length  WebIDL type: float
     * @return Stack allocated object of PxConvexCoreSegment
     */
    public static PxConvexCoreSegment createAt(long address, float length) {
        Raw.PxConvexCoreSegment_placed(address, length);
        PxConvexCoreSegment createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param length    WebIDL type: float
     * @return Stack allocated object of PxConvexCoreSegment
     */
    public static <T> PxConvexCoreSegment createAt(T allocator, Allocator<T> allocate, float length) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxConvexCoreSegment_placed(address, length);
        PxConvexCoreSegment createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param length WebIDL type: float
     */
    public PxConvexCoreSegment(float length) {
        address = Raw.PxConvexCoreSegment(length);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: float
     */
    public float getLength() {
        checkNotNull();
        return Raw.getLength(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setLength(float value) {
        checkNotNull();
        Raw.setLength(address, value);
    }

    public static class Raw {
        public static native void PxConvexCoreSegment_placed(long address, float length);
        public static native long PxConvexCoreSegment(float length);
        public static native void destroy(long address);
        public static native float getLength(long address);
        public static native void setLength(long address, float value);
    }
}
