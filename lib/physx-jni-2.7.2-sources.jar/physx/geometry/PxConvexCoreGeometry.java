package physx.geometry;

import physx.NativeObject;

/**
 * Convex core geometry class.
 * <p>
 * This class allows users to create a variety of convex shapes. Each shape is defined by:
 * 1. A core, specified by one of the pre-authored GJK support functions.
 * 2. A margin, which is an arbitrary distance that extends the core.
 * <p>
 * The resulting convex shape includes both the core and the surrounding space within the margin.
 * <p>
 * Simple examples include:
 * - A sphere: created from a point core with a non-zero margin (radius).
 * - A capsule: created from a segment core with a non-zero margin.
 */
public class PxConvexCoreGeometry extends PxGeometry {

    protected PxConvexCoreGeometry() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxConvexCoreGeometry wrapPointer(long address) {
        return address != 0L ? new PxConvexCoreGeometry(address) : null;
    }
    
    public static PxConvexCoreGeometry arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxConvexCoreGeometry(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * Get the type of the core
     * @return The type of the core
     */
    public PxConvexCoreTypeEnum getCoreType() {
        checkNotNull();
        return PxConvexCoreTypeEnum.forValue(Raw.getCoreType(address));
    }

    /**
     * Get a pointer to the core data.
     * @return A pointer to the core data.
     */
    public NativeObject getCoreData() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.getCoreData(address));
    }

    /**
     * Get the margin of the convex core geometry.
     * @return The margin size.
     */
    public float getMargin() {
        checkNotNull();
        return Raw.getMargin(address);
    }

    /**
     * Check if the convex core geometry is valid.
     * @return True if the geometry is valid, false otherwise.
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native int getCoreType(long address);
        public static native long getCoreData(long address);
        public static native float getMargin(long address);
        public static native boolean isValid(long address);
    }
}
