package physx.geometry;

public enum PxTetrahedronMeshFormatEnum {

    eTET_MESH(geteTET_MESH()),
    eHEX_MESH(geteHEX_MESH());
    public final int value;
    
    PxTetrahedronMeshFormatEnum(int value) {
        this.value = value;
    }

    private static native int _geteTET_MESH();
    private static int geteTET_MESH() {
        de.fabmax.physxjni.Loader.load();
        return _geteTET_MESH();
    }

    private static native int _geteHEX_MESH();
    private static int geteHEX_MESH() {
        de.fabmax.physxjni.Loader.load();
        return _geteHEX_MESH();
    }

    private static final int LUT_SIZE = 256;
    private static final PxTetrahedronMeshFormatEnum[] enumValues = values();
    private static final PxTetrahedronMeshFormatEnum[] enumLut = new PxTetrahedronMeshFormatEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxTetrahedronMeshFormatEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxTetrahedronMeshFormatEnum forValue(int value) {
        PxTetrahedronMeshFormatEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxTetrahedronMeshFormatEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxTetrahedronMeshFormatEnum: " + value);
        }
        return enumValue;
    }
}
