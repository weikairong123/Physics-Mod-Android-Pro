package physx.geometry;

/**
 * Flags for the mesh geometry properties.
 * <p>
 * Used in ::PxTriangleMeshFlags.
 */
public enum PxTriangleMeshFlagEnum {

    /**
     * The triangle mesh has 16bits vertex indices.
     */
    e16_BIT_INDICES(gete16_BIT_INDICES()),
    /**
     * The triangle mesh has adjacency information build.
     */
    eADJACENCY_INFO(geteADJACENCY_INFO());
    public final int value;
    
    PxTriangleMeshFlagEnum(int value) {
        this.value = value;
    }

    private static native int _gete16_BIT_INDICES();
    private static int gete16_BIT_INDICES() {
        de.fabmax.physxjni.Loader.load();
        return _gete16_BIT_INDICES();
    }

    private static native int _geteADJACENCY_INFO();
    private static int geteADJACENCY_INFO() {
        de.fabmax.physxjni.Loader.load();
        return _geteADJACENCY_INFO();
    }

    private static final int LUT_SIZE = 256;
    private static final PxTriangleMeshFlagEnum[] enumValues = values();
    private static final PxTriangleMeshFlagEnum[] enumLut = new PxTriangleMeshFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxTriangleMeshFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxTriangleMeshFlagEnum forValue(int value) {
        PxTriangleMeshFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxTriangleMeshFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxTriangleMeshFlagEnum: " + value);
        }
        return enumValue;
    }
}
