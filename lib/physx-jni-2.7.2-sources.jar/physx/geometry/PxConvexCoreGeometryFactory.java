package physx.geometry;

import physx.NativeObject;

public class PxConvexCoreGeometryFactory extends NativeObject {

    protected PxConvexCoreGeometryFactory() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxConvexCoreGeometryFactory wrapPointer(long address) {
        return address != 0L ? new PxConvexCoreGeometryFactory(address) : null;
    }
    
    public static PxConvexCoreGeometryFactory arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxConvexCoreGeometryFactory(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param box    WebIDL type: {@link PxConvexCoreBox} [Const, Ref]
     * @param margin WebIDL type: float
     * @return WebIDL type: {@link PxConvexCoreGeometry}
     */
    public static PxConvexCoreGeometry createFromBox(PxConvexCoreBox box, float margin) {
        return PxConvexCoreGeometry.wrapPointer(Raw.createFromBox(box.getAddress(), margin));
    }

    /**
     * @param cone   WebIDL type: {@link PxConvexCoreCone} [Const, Ref]
     * @param margin WebIDL type: float
     * @return WebIDL type: {@link PxConvexCoreGeometry}
     */
    public static PxConvexCoreGeometry createFromCone(PxConvexCoreCone cone, float margin) {
        return PxConvexCoreGeometry.wrapPointer(Raw.createFromCone(cone.getAddress(), margin));
    }

    /**
     * @param cylinder WebIDL type: {@link PxConvexCoreCylinder} [Const, Ref]
     * @param margin   WebIDL type: float
     * @return WebIDL type: {@link PxConvexCoreGeometry}
     */
    public static PxConvexCoreGeometry createFromCylinder(PxConvexCoreCylinder cylinder, float margin) {
        return PxConvexCoreGeometry.wrapPointer(Raw.createFromCylinder(cylinder.getAddress(), margin));
    }

    /**
     * @param ellipsoid WebIDL type: {@link PxConvexCoreEllipsoid} [Const, Ref]
     * @param margin    WebIDL type: float
     * @return WebIDL type: {@link PxConvexCoreGeometry}
     */
    public static PxConvexCoreGeometry createFromEllipsoid(PxConvexCoreEllipsoid ellipsoid, float margin) {
        return PxConvexCoreGeometry.wrapPointer(Raw.createFromEllipsoid(ellipsoid.getAddress(), margin));
    }

    /**
     * @param point  WebIDL type: {@link PxConvexCorePoint} [Const, Ref]
     * @param margin WebIDL type: float
     * @return WebIDL type: {@link PxConvexCoreGeometry}
     */
    public static PxConvexCoreGeometry createFromPoint(PxConvexCorePoint point, float margin) {
        return PxConvexCoreGeometry.wrapPointer(Raw.createFromPoint(point.getAddress(), margin));
    }

    /**
     * @param segment WebIDL type: {@link PxConvexCoreSegment} [Const, Ref]
     * @param margin  WebIDL type: float
     * @return WebIDL type: {@link PxConvexCoreGeometry}
     */
    public static PxConvexCoreGeometry createFromSegment(PxConvexCoreSegment segment, float margin) {
        return PxConvexCoreGeometry.wrapPointer(Raw.createFromSegment(segment.getAddress(), margin));
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long createFromBox(long box, float margin);
        public static native long createFromCone(long cone, float margin);
        public static native long createFromCylinder(long cylinder, float margin);
        public static native long createFromEllipsoid(long ellipsoid, float margin);
        public static native long createFromPoint(long point, float margin);
        public static native long createFromSegment(long segment, float margin);
    }
}
