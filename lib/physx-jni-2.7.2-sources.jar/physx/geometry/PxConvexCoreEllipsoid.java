package physx.geometry;

import physx.NativeObject;
import physx.common.PxVec3;

public class PxConvexCoreEllipsoid extends NativeObject {

    protected PxConvexCoreEllipsoid() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxConvexCoreEllipsoid wrapPointer(long address) {
        return address != 0L ? new PxConvexCoreEllipsoid(address) : null;
    }
    
    public static PxConvexCoreEllipsoid arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxConvexCoreEllipsoid(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param rX      WebIDL type: float
     * @param rY      WebIDL type: float
     * @param rZ      WebIDL type: float
     * @return Stack allocated object of PxConvexCoreEllipsoid
     */
    public static PxConvexCoreEllipsoid createAt(long address, float rX, float rY, float rZ) {
        Raw.PxConvexCoreEllipsoid_placed(address, rX, rY, rZ);
        PxConvexCoreEllipsoid createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param rX        WebIDL type: float
     * @param rY        WebIDL type: float
     * @param rZ        WebIDL type: float
     * @return Stack allocated object of PxConvexCoreEllipsoid
     */
    public static <T> PxConvexCoreEllipsoid createAt(T allocator, Allocator<T> allocate, float rX, float rY, float rZ) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxConvexCoreEllipsoid_placed(address, rX, rY, rZ);
        PxConvexCoreEllipsoid createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param rX WebIDL type: float
     * @param rY WebIDL type: float
     * @param rZ WebIDL type: float
     */
    public PxConvexCoreEllipsoid(float rX, float rY, float rZ) {
        address = Raw.PxConvexCoreEllipsoid(rX, rY, rZ);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getRadii() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getRadii(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setRadii(PxVec3 value) {
        checkNotNull();
        Raw.setRadii(address, value.getAddress());
    }

    public static class Raw {
        public static native void PxConvexCoreEllipsoid_placed(long address, float rX, float rY, float rZ);
        public static native long PxConvexCoreEllipsoid(float rX, float rY, float rZ);
        public static native void destroy(long address);
        public static native long getRadii(long address);
        public static native void setRadii(long address, long value);
    }
}
