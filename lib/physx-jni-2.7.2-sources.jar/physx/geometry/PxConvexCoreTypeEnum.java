package physx.geometry;

public enum PxConvexCoreTypeEnum {

    ePOINT(getePOINT()),
    eSEGMENT(geteSEGMENT()),
    eBOX(geteBOX()),
    eELLIPSOID(geteELLIPSOID()),
    eCYLINDER(geteCYLINDER()),
    eCONE(geteCONE());
    public final int value;
    
    PxConvexCoreTypeEnum(int value) {
        this.value = value;
    }

    private static native int _getePOINT();
    private static int getePOINT() {
        de.fabmax.physxjni.Loader.load();
        return _getePOINT();
    }

    private static native int _geteSEGMENT();
    private static int geteSEGMENT() {
        de.fabmax.physxjni.Loader.load();
        return _geteSEGMENT();
    }

    private static native int _geteBOX();
    private static int geteBOX() {
        de.fabmax.physxjni.Loader.load();
        return _geteBOX();
    }

    private static native int _geteELLIPSOID();
    private static int geteELLIPSOID() {
        de.fabmax.physxjni.Loader.load();
        return _geteELLIPSOID();
    }

    private static native int _geteCYLINDER();
    private static int geteCYLINDER() {
        de.fabmax.physxjni.Loader.load();
        return _geteCYLINDER();
    }

    private static native int _geteCONE();
    private static int geteCONE() {
        de.fabmax.physxjni.Loader.load();
        return _geteCONE();
    }

    private static final int LUT_SIZE = 256;
    private static final PxConvexCoreTypeEnum[] enumValues = values();
    private static final PxConvexCoreTypeEnum[] enumLut = new PxConvexCoreTypeEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxConvexCoreTypeEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxConvexCoreTypeEnum forValue(int value) {
        PxConvexCoreTypeEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxConvexCoreTypeEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxConvexCoreTypeEnum: " + value);
        }
        return enumValue;
    }
}
