package physx.geometry;

import physx.NativeObject;
import physx.common.PxVec3;

public class PxConvexCoreBox extends NativeObject {

    protected PxConvexCoreBox() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxConvexCoreBox wrapPointer(long address) {
        return address != 0L ? new PxConvexCoreBox(address) : null;
    }
    
    public static PxConvexCoreBox arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxConvexCoreBox(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param eX      WebIDL type: float
     * @param eY      WebIDL type: float
     * @param eZ      WebIDL type: float
     * @return Stack allocated object of PxConvexCoreBox
     */
    public static PxConvexCoreBox createAt(long address, float eX, float eY, float eZ) {
        Raw.PxConvexCoreBox_placed(address, eX, eY, eZ);
        PxConvexCoreBox createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param eX        WebIDL type: float
     * @param eY        WebIDL type: float
     * @param eZ        WebIDL type: float
     * @return Stack allocated object of PxConvexCoreBox
     */
    public static <T> PxConvexCoreBox createAt(T allocator, Allocator<T> allocate, float eX, float eY, float eZ) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxConvexCoreBox_placed(address, eX, eY, eZ);
        PxConvexCoreBox createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param eX WebIDL type: float
     * @param eY WebIDL type: float
     * @param eZ WebIDL type: float
     */
    public PxConvexCoreBox(float eX, float eY, float eZ) {
        address = Raw.PxConvexCoreBox(eX, eY, eZ);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getExtents() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getExtents(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setExtents(PxVec3 value) {
        checkNotNull();
        Raw.setExtents(address, value.getAddress());
    }

    public static class Raw {
        public static native void PxConvexCoreBox_placed(long address, float eX, float eY, float eZ);
        public static native long PxConvexCoreBox(float eX, float eY, float eZ);
        public static native void destroy(long address);
        public static native long getExtents(long address);
        public static native void setExtents(long address, long value);
    }
}
