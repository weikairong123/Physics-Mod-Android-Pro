package physx.geometry;

import physx.NativeObject;

public class PxConvexCorePoint extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxConvexCorePoint wrapPointer(long address) {
        return address != 0L ? new PxConvexCorePoint(address) : null;
    }
    
    public static PxConvexCorePoint arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxConvexCorePoint(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxConvexCorePoint
     */
    public static PxConvexCorePoint createAt(long address) {
        Raw.PxConvexCorePoint_placed(address);
        PxConvexCorePoint createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxConvexCorePoint
     */
    public static <T> PxConvexCorePoint createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxConvexCorePoint_placed(address);
        PxConvexCorePoint createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxConvexCorePoint() {
        address = Raw.PxConvexCorePoint();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    public static class Raw {
        public static native void PxConvexCorePoint_placed(long address);
        public static native long PxConvexCorePoint();
        public static native void destroy(long address);
    }
}
