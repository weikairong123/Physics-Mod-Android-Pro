package physx.geometry;

import physx.NativeObject;
import physx.common.PxVec3;

/**
 * Triangle class.
 */
public class PxTriangle extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxTriangle wrapPointer(long address) {
        return address != 0L ? new PxTriangle(address) : null;
    }
    
    public static PxTriangle arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxTriangle(long address) {
        super(address);
    }

    // Constructors

    /**
     * Constructor
     */
    public PxTriangle() {
        address = Raw.PxTriangle();
    }

    /**
     * Constructor
     * @param p0 Point 0
     * @param p1 Point 1
     * @param p2 Point 2
     */
    public PxTriangle(PxVec3 p0, PxVec3 p1, PxVec3 p2) {
        address = Raw.PxTriangle(p0.getAddress(), p1.getAddress(), p2.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * Compute the normal of the Triangle.
     */
    public void normal(PxVec3 normal) {
        checkNotNull();
        Raw.normal(address, normal.getAddress());
    }

    /**
     * Compute the unnormalized normal of the triangle.
     */
    public void denormalizedNormal(PxVec3 normal) {
        checkNotNull();
        Raw.denormalizedNormal(address, normal.getAddress());
    }

    /**
     * Compute the area of the triangle.
     * @return Area of the triangle.
     */
    public float area() {
        checkNotNull();
        return Raw.area(address);
    }

    /**
     * @return Computes a point on the triangle from u and v barycentric coordinates.
     */
    public PxVec3 pointFromUV(float u, float v) {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.pointFromUV(address, u, v));
    }

    public static class Raw {
        public static native long PxTriangle();
        public static native long PxTriangle(long p0, long p1, long p2);
        public static native void destroy(long address);
        public static native void normal(long address, long normal);
        public static native void denormalizedNormal(long address, long normal);
        public static native float area(long address);
        public static native long pointFromUV(long address, float u, float v);
    }
}
