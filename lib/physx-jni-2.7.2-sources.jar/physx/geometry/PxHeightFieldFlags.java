package physx.geometry;

import physx.NativeObject;

public class PxHeightFieldFlags extends NativeObject {

    protected PxHeightFieldFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxHeightFieldFlags wrapPointer(long address) {
        return address != 0L ? new PxHeightFieldFlags(address) : null;
    }
    
    public static PxHeightFieldFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxHeightFieldFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: unsigned short
     * @return Stack allocated object of PxHeightFieldFlags
     */
    public static PxHeightFieldFlags createAt(long address, short flags) {
        Raw.PxHeightFieldFlags_placed(address, flags);
        PxHeightFieldFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: unsigned short
     * @return Stack allocated object of PxHeightFieldFlags
     */
    public static <T> PxHeightFieldFlags createAt(T allocator, Allocator<T> allocate, short flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxHeightFieldFlags_placed(address, flags);
        PxHeightFieldFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param flags WebIDL type: unsigned short
     */
    public PxHeightFieldFlags(short flags) {
        address = Raw.PxHeightFieldFlags(flags);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param flag WebIDL type: {@link PxHeightFieldFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxHeightFieldFlagEnum flag) {
        checkNotNull();
        return Raw.isSet(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxHeightFieldFlagEnum} [enum]
     */
    public void raise(PxHeightFieldFlagEnum flag) {
        checkNotNull();
        Raw.raise(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxHeightFieldFlagEnum} [enum]
     */
    public void clear(PxHeightFieldFlagEnum flag) {
        checkNotNull();
        Raw.clear(address, flag.value);
    }

    public static class Raw {
        public static native void PxHeightFieldFlags_placed(long address, short flags);
        public static native long PxHeightFieldFlags(short flags);
        public static native void destroy(long address);
        public static native boolean isSet(long address, int flag);
        public static native void raise(long address, int flag);
        public static native void clear(long address, int flag);
    }
}
