package physx.geometry;

import physx.NativeObject;

public class PxConvexCoreCone extends NativeObject {

    protected PxConvexCoreCone() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxConvexCoreCone wrapPointer(long address) {
        return address != 0L ? new PxConvexCoreCone(address) : null;
    }
    
    public static PxConvexCoreCone arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxConvexCoreCone(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param height  WebIDL type: float
     * @param radius  WebIDL type: float
     * @return Stack allocated object of PxConvexCoreCone
     */
    public static PxConvexCoreCone createAt(long address, float height, float radius) {
        Raw.PxConvexCoreCone_placed(address, height, radius);
        PxConvexCoreCone createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param height    WebIDL type: float
     * @param radius    WebIDL type: float
     * @return Stack allocated object of PxConvexCoreCone
     */
    public static <T> PxConvexCoreCone createAt(T allocator, Allocator<T> allocate, float height, float radius) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxConvexCoreCone_placed(address, height, radius);
        PxConvexCoreCone createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param height WebIDL type: float
     * @param radius WebIDL type: float
     */
    public PxConvexCoreCone(float height, float radius) {
        address = Raw.PxConvexCoreCone(height, radius);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: float
     */
    public float getHeight() {
        checkNotNull();
        return Raw.getHeight(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setHeight(float value) {
        checkNotNull();
        Raw.setHeight(address, value);
    }

    /**
     * @return WebIDL type: float
     */
    public float getRadius() {
        checkNotNull();
        return Raw.getRadius(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setRadius(float value) {
        checkNotNull();
        Raw.setRadius(address, value);
    }

    public static class Raw {
        public static native void PxConvexCoreCone_placed(long address, float height, float radius);
        public static native long PxConvexCoreCone(float height, float radius);
        public static native void destroy(long address);
        public static native float getHeight(long address);
        public static native void setHeight(long address, float value);
        public static native float getRadius(long address);
        public static native void setRadius(long address, float value);
    }
}
