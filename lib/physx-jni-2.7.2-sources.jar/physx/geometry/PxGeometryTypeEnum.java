package physx.geometry;

/**
 * A geometry type.
 * <p>
 * Used to distinguish the type of a ::PxGeometry object.
 */
public enum PxGeometryTypeEnum {

    eSPHERE(geteSPHERE()),
    ePLANE(getePLANE()),
    eCAPSULE(geteCAPSULE()),
    eBOX(geteBOX()),
    eCONVEXCORE(geteCONVEXCORE()),
    eCONVEXMESH(geteCONVEXMESH()),
    ePARTICLESYSTEM(getePARTICLESYSTEM()),
    eTETRAHEDRONMESH(geteTETRAHEDRONMESH()),
    eTRIANGLEMESH(geteTRIANGLEMESH()),
    eHEIGHTFIELD(geteHEIGHTFIELD()),
    eCUSTOM(geteCUSTOM());
    public final int value;
    
    PxGeometryTypeEnum(int value) {
        this.value = value;
    }

    private static native int _geteSPHERE();
    private static int geteSPHERE() {
        de.fabmax.physxjni.Loader.load();
        return _geteSPHERE();
    }

    private static native int _getePLANE();
    private static int getePLANE() {
        de.fabmax.physxjni.Loader.load();
        return _getePLANE();
    }

    private static native int _geteCAPSULE();
    private static int geteCAPSULE() {
        de.fabmax.physxjni.Loader.load();
        return _geteCAPSULE();
    }

    private static native int _geteBOX();
    private static int geteBOX() {
        de.fabmax.physxjni.Loader.load();
        return _geteBOX();
    }

    private static native int _geteCONVEXCORE();
    private static int geteCONVEXCORE() {
        de.fabmax.physxjni.Loader.load();
        return _geteCONVEXCORE();
    }

    private static native int _geteCONVEXMESH();
    private static int geteCONVEXMESH() {
        de.fabmax.physxjni.Loader.load();
        return _geteCONVEXMESH();
    }

    private static native int _getePARTICLESYSTEM();
    private static int getePARTICLESYSTEM() {
        de.fabmax.physxjni.Loader.load();
        return _getePARTICLESYSTEM();
    }

    private static native int _geteTETRAHEDRONMESH();
    private static int geteTETRAHEDRONMESH() {
        de.fabmax.physxjni.Loader.load();
        return _geteTETRAHEDRONMESH();
    }

    private static native int _geteTRIANGLEMESH();
    private static int geteTRIANGLEMESH() {
        de.fabmax.physxjni.Loader.load();
        return _geteTRIANGLEMESH();
    }

    private static native int _geteHEIGHTFIELD();
    private static int geteHEIGHTFIELD() {
        de.fabmax.physxjni.Loader.load();
        return _geteHEIGHTFIELD();
    }

    private static native int _geteCUSTOM();
    private static int geteCUSTOM() {
        de.fabmax.physxjni.Loader.load();
        return _geteCUSTOM();
    }

    private static final int LUT_SIZE = 256;
    private static final PxGeometryTypeEnum[] enumValues = values();
    private static final PxGeometryTypeEnum[] enumLut = new PxGeometryTypeEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxGeometryTypeEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxGeometryTypeEnum forValue(int value) {
        PxGeometryTypeEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxGeometryTypeEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxGeometryTypeEnum: " + value);
        }
        return enumValue;
    }
}
