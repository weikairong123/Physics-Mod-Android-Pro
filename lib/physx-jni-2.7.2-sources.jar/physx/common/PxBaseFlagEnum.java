package physx.common;

/**
 * Flags for PxBase.
 */
public enum PxBaseFlagEnum {

    eOWNS_MEMORY(geteOWNS_MEMORY()),
    eIS_RELEASABLE(geteIS_RELEASABLE());
    public final int value;
    
    PxBaseFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteOWNS_MEMORY();
    private static int geteOWNS_MEMORY() {
        de.fabmax.physxjni.Loader.load();
        return _geteOWNS_MEMORY();
    }

    private static native int _geteIS_RELEASABLE();
    private static int geteIS_RELEASABLE() {
        de.fabmax.physxjni.Loader.load();
        return _geteIS_RELEASABLE();
    }

    private static final int LUT_SIZE = 256;
    private static final PxBaseFlagEnum[] enumValues = values();
    private static final PxBaseFlagEnum[] enumLut = new PxBaseFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxBaseFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxBaseFlagEnum forValue(int value) {
        PxBaseFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxBaseFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxBaseFlagEnum: " + value);
        }
        return enumValue;
    }
}
