package physx.common;

import physx.NativeObject;

/**
 * Used to store a single line and colour for debug rendering.
 */
public class PxDebugLine extends NativeObject {

    protected PxDebugLine() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxDebugLine wrapPointer(long address) {
        return address != 0L ? new PxDebugLine(address) : null;
    }
    
    public static PxDebugLine arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxDebugLine(long address) {
        super(address);
    }

    // Attributes

    public PxVec3 getPos0() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getPos0(address));
    }

    public void setPos0(PxVec3 value) {
        checkNotNull();
        Raw.setPos0(address, value.getAddress());
    }

    public int getColor0() {
        checkNotNull();
        return Raw.getColor0(address);
    }

    public void setColor0(int value) {
        checkNotNull();
        Raw.setColor0(address, value);
    }

    public PxVec3 getPos1() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getPos1(address));
    }

    public void setPos1(PxVec3 value) {
        checkNotNull();
        Raw.setPos1(address, value.getAddress());
    }

    public int getColor1() {
        checkNotNull();
        return Raw.getColor1(address);
    }

    public void setColor1(int value) {
        checkNotNull();
        Raw.setColor1(address, value);
    }

    public static class Raw {
        public static native long getPos0(long address);
        public static native void setPos0(long address, long value);
        public static native int getColor0(long address);
        public static native void setColor0(long address, int value);
        public static native long getPos1(long address);
        public static native void setPos1(long address, long value);
        public static native int getColor1(long address);
        public static native void setColor1(long address, int value);
    }
}
