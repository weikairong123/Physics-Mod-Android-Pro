package physx.common;

import physx.NativeObject;
import physx.support.PxU16Ptr;

public class PxTypedBoundedData_PxU16 extends NativeObject {

    protected PxTypedBoundedData_PxU16() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxTypedBoundedData_PxU16 wrapPointer(long address) {
        return address != 0L ? new PxTypedBoundedData_PxU16(address) : null;
    }
    
    public static PxTypedBoundedData_PxU16 arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxTypedBoundedData_PxU16(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: unsigned long
     */
    public int getStride() {
        checkNotNull();
        return Raw.getStride(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setStride(int value) {
        checkNotNull();
        Raw.setStride(address, value);
    }

    /**
     * @return WebIDL type: {@link PxU16Ptr} [Value]
     */
    public PxU16Ptr getData() {
        checkNotNull();
        return PxU16Ptr.wrapPointer(Raw.getData(address));
    }

    /**
     * @param value WebIDL type: {@link PxU16Ptr} [Value]
     */
    public void setData(PxU16Ptr value) {
        checkNotNull();
        Raw.setData(address, value.getAddress());
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native int getStride(long address);
        public static native void setStride(long address, int value);
        public static native long getData(long address);
        public static native void setData(long address, long value);
    }
}
