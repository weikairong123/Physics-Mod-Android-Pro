package physx.common;

import physx.NativeObject;

/**
 * Output stream class for I/O.
 * <p>
 * The user needs to supply a PxOutputStream implementation to a number of methods to allow the SDK to write data.
 */
public class PxOutputStream extends NativeObject {

    protected PxOutputStream() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxOutputStream wrapPointer(long address) {
        return address != 0L ? new PxOutputStream(address) : null;
    }
    
    public static PxOutputStream arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxOutputStream(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    public static class Raw {
        public static native void destroy(long address);
    }
}
