package physx.common;

import physx.NativeObject;

/**
 * Input data class for I/O which provides random read access.
 * <p>
 * The user needs to supply a PxInputData implementation to a number of methods to allow the SDK to read data.
 */
public class PxInputData extends NativeObject {

    protected PxInputData() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxInputData wrapPointer(long address) {
        return address != 0L ? new PxInputData(address) : null;
    }
    
    public static PxInputData arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxInputData(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    public static class Raw {
        public static native void destroy(long address);
    }
}
