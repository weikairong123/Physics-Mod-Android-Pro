package physx.common;

/**
 * Error codes
 * <p>
 * These error codes are passed to #PxErrorCallback
 * <p>
 * <b>See also:</b> PxErrorCallback
 */
public enum PxErrorCodeEnum {

    eNO_ERROR(geteNO_ERROR()),
    /**
     * An informational message.
     */
    eDEBUG_INFO(geteDEBUG_INFO()),
    /**
     * a warning message for the user to help with debugging
     */
    eDEBUG_WARNING(geteDEBUG_WARNING()),
    /**
     * method called with invalid parameter(s)
     */
    eINVALID_PARAMETER(geteINVALID_PARAMETER()),
    /**
     * method was called at a time when an operation is not possible
     */
    eINVALID_OPERATION(geteINVALID_OPERATION()),
    /**
     * method failed to allocate some memory
     */
    eOUT_OF_MEMORY(geteOUT_OF_MEMORY()),
    /**
     * The library failed for some reason.
     *    Possibly you have passed invalid values like NaNs, which are not checked for.
     */
    eINTERNAL_ERROR(geteINTERNAL_ERROR()),
    /**
     * An unrecoverable error, execution should be halted and log output flushed
     */
    eABORT(geteABORT()),
    /**
     * The SDK has determined that an operation may result in poor performance.
     */
    ePERF_WARNING(getePERF_WARNING()),
    /**
     * A bit mask for including all errors
     */
    eMASK_ALL(geteMASK_ALL());
    public final int value;
    
    PxErrorCodeEnum(int value) {
        this.value = value;
    }

    private static native int _geteNO_ERROR();
    private static int geteNO_ERROR() {
        de.fabmax.physxjni.Loader.load();
        return _geteNO_ERROR();
    }

    private static native int _geteDEBUG_INFO();
    private static int geteDEBUG_INFO() {
        de.fabmax.physxjni.Loader.load();
        return _geteDEBUG_INFO();
    }

    private static native int _geteDEBUG_WARNING();
    private static int geteDEBUG_WARNING() {
        de.fabmax.physxjni.Loader.load();
        return _geteDEBUG_WARNING();
    }

    private static native int _geteINVALID_PARAMETER();
    private static int geteINVALID_PARAMETER() {
        de.fabmax.physxjni.Loader.load();
        return _geteINVALID_PARAMETER();
    }

    private static native int _geteINVALID_OPERATION();
    private static int geteINVALID_OPERATION() {
        de.fabmax.physxjni.Loader.load();
        return _geteINVALID_OPERATION();
    }

    private static native int _geteOUT_OF_MEMORY();
    private static int geteOUT_OF_MEMORY() {
        de.fabmax.physxjni.Loader.load();
        return _geteOUT_OF_MEMORY();
    }

    private static native int _geteINTERNAL_ERROR();
    private static int geteINTERNAL_ERROR() {
        de.fabmax.physxjni.Loader.load();
        return _geteINTERNAL_ERROR();
    }

    private static native int _geteABORT();
    private static int geteABORT() {
        de.fabmax.physxjni.Loader.load();
        return _geteABORT();
    }

    private static native int _getePERF_WARNING();
    private static int getePERF_WARNING() {
        de.fabmax.physxjni.Loader.load();
        return _getePERF_WARNING();
    }

    private static native int _geteMASK_ALL();
    private static int geteMASK_ALL() {
        de.fabmax.physxjni.Loader.load();
        return _geteMASK_ALL();
    }

    private static final int LUT_SIZE = 256;
    private static final PxErrorCodeEnum[] enumValues = values();
    private static final PxErrorCodeEnum[] enumLut = new PxErrorCodeEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxErrorCodeEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxErrorCodeEnum forValue(int value) {
        PxErrorCodeEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxErrorCodeEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxErrorCodeEnum: " + value);
        }
        return enumValue;
    }
}
