package physx.common;

import physx.NativeObject;
import physx.PlatformChecks;

public class PxMat33 extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxMat33 wrapPointer(long address) {
        return address != 0L ? new PxMat33(address) : null;
    }
    
    public static PxMat33 arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxMat33(long address) {
        super(address);
    }

    // Constructors

    public PxMat33() {
        address = Raw.PxMat33();
    }

    /**
     * @param r WebIDL type: {@link PxIDENTITYEnum} [enum]
     */
    public PxMat33(PxIDENTITYEnum r) {
        address = Raw.PxMat33(r.value);
    }

    /**
     * @param col0 WebIDL type: {@link PxVec3} [Const, Ref]
     * @param col1 WebIDL type: {@link PxVec3} [Const, Ref]
     * @param col2 WebIDL type: {@link PxVec3} [Const, Ref]
     */
    public PxMat33(PxVec3 col0, PxVec3 col1, PxVec3 col2) {
        address = Raw.PxMat33(col0.getAddress(), col1.getAddress(), col2.getAddress());
    }

    /**
     * @param r WebIDL type: float
     */
    public PxMat33(float r) {
        PlatformChecks.requirePlatform(15, "physx.common.PxMat33");
        address = Raw.PxMat33(r);
    }

    /**
     * @param q WebIDL type: {@link PxQuat} [Const, Ref]
     */
    public PxMat33(PxQuat q) {
        PlatformChecks.requirePlatform(15, "physx.common.PxMat33");
        address = Raw.PxMat33(q.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getColumn0() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getColumn0(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setColumn0(PxVec3 value) {
        checkNotNull();
        Raw.setColumn0(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getColumn1() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getColumn1(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setColumn1(PxVec3 value) {
        checkNotNull();
        Raw.setColumn1(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getColumn2() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getColumn2(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setColumn2(PxVec3 value) {
        checkNotNull();
        Raw.setColumn2(address, value.getAddress());
    }

    // Functions

    /**
     * @return WebIDL type: {@link PxMat33} [Value]
     */
    public PxMat33 getTranspose() {
        checkNotNull();
        return PxMat33.wrapPointer(Raw.getTranspose(address));
    }

    /**
     * @return WebIDL type: {@link PxMat33} [Value]
     */
    public PxMat33 getInverse() {
        checkNotNull();
        return PxMat33.wrapPointer(Raw.getInverse(address));
    }

    /**
     * @return WebIDL type: float
     */
    public float getDeterminant() {
        checkNotNull();
        return Raw.getDeterminant(address);
    }

    /**
     * @param other WebIDL type: {@link PxVec3} [Const, Ref]
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 transform(PxVec3 other) {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.transform(address, other.getAddress()));
    }

    /**
     * @param other WebIDL type: {@link PxVec3} [Const, Ref]
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 transformTranspose(PxVec3 other) {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.transformTranspose(address, other.getAddress()));
    }

    public static class Raw {
        public static native long PxMat33();
        public static native long PxMat33(int r);
        public static native long PxMat33(long col0, long col1, long col2);
        public static native long PxMat33(float r);
        public static native long PxMat33(long q);
        public static native void destroy(long address);
        public static native long getColumn0(long address);
        public static native void setColumn0(long address, long value);
        public static native long getColumn1(long address);
        public static native void setColumn1(long address, long value);
        public static native long getColumn2(long address);
        public static native void setColumn2(long address, long value);
        public static native long getTranspose(long address);
        public static native long getInverse(long address);
        public static native float getDeterminant(long address);
        public static native long transform(long address, long other);
        public static native long transformTranspose(long address, long other);
    }
}
