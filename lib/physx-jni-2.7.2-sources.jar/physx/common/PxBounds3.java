package physx.common;

import physx.NativeObject;

/**
 * Class representing 3D range or axis aligned bounding box.
 * <p>
 * Stored as minimum and maximum extent corners. Alternate representation
 * would be center and dimensions.
 * May be empty or nonempty. For nonempty bounds, minimum &lt;= maximum has to hold for all axes.
 * Empty bounds have to be represented as minimum = PX_MAX_BOUNDS_EXTENTS and maximum = -PX_MAX_BOUNDS_EXTENTS for all
 * axes.
 * All other representations are invalid and the behavior is undefined.
 */
public class PxBounds3 extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxBounds3 wrapPointer(long address) {
        return address != 0L ? new PxBounds3(address) : null;
    }
    
    public static PxBounds3 arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxBounds3(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxBounds3
     */
    public static PxBounds3 createAt(long address) {
        Raw.PxBounds3_placed(address);
        PxBounds3 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxBounds3
     */
    public static <T> PxBounds3 createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxBounds3_placed(address);
        PxBounds3 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param minimum WebIDL type: {@link PxVec3} [Const, Ref]
     * @param maximum WebIDL type: {@link PxVec3} [Const, Ref]
     * @return Stack allocated object of PxBounds3
     */
    public static PxBounds3 createAt(long address, PxVec3 minimum, PxVec3 maximum) {
        Raw.PxBounds3_placed(address, minimum.getAddress(), maximum.getAddress());
        PxBounds3 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param minimum   WebIDL type: {@link PxVec3} [Const, Ref]
     * @param maximum   WebIDL type: {@link PxVec3} [Const, Ref]
     * @return Stack allocated object of PxBounds3
     */
    public static <T> PxBounds3 createAt(T allocator, Allocator<T> allocate, PxVec3 minimum, PxVec3 maximum) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxBounds3_placed(address, minimum.getAddress(), maximum.getAddress());
        PxBounds3 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * Default constructor, not performing any initialization for performance reason.
     * \remark Use empty() function below to construct empty bounds.
     */
    public PxBounds3() {
        address = Raw.PxBounds3();
    }

    /**
     * Construct from two bounding points
     */
    public PxBounds3(PxVec3 minimum, PxVec3 maximum) {
        address = Raw.PxBounds3(minimum.getAddress(), maximum.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getMinimum() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getMinimum(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setMinimum(PxVec3 value) {
        checkNotNull();
        Raw.setMinimum(address, value.getAddress());
    }

    public PxVec3 getMaximum() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getMaximum(address));
    }

    public void setMaximum(PxVec3 value) {
        checkNotNull();
        Raw.setMaximum(address, value.getAddress());
    }

    // Functions

    /**
     * Sets empty to true
     */
    public void setEmpty() {
        checkNotNull();
        Raw.setEmpty(address);
    }

    /**
     * Sets the bounds to maximum size [-PX_MAX_BOUNDS_EXTENTS, PX_MAX_BOUNDS_EXTENTS].
     */
    public void setMaximal() {
        checkNotNull();
        Raw.setMaximal(address);
    }

    /**
     * expands the volume to include v
     * \param v Point to expand to.
     */
    public void include(PxVec3 v) {
        checkNotNull();
        Raw.include(address, v.getAddress());
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isEmpty() {
        checkNotNull();
        return Raw.isEmpty(address);
    }

    /**
     * indicates whether the intersection of this and b is empty or not.
     * \param b Bounds to test for intersection.
     */
    public boolean intersects(PxBounds3 b) {
        checkNotNull();
        return Raw.intersects(address, b.getAddress());
    }

    /**
     * computes the 1D-intersection between two AABBs, on a given axis.
     * \param axis the axis (0, 1, 2)
     */
    public boolean intersects1D(PxBounds3 b, int axis) {
        checkNotNull();
        return Raw.intersects1D(address, b.getAddress(), axis);
    }

    /**
     * indicates if these bounds contain v.
     * \param v Point to test against bounds.
     */
    public boolean contains(PxVec3 v) {
        checkNotNull();
        return Raw.contains(address, v.getAddress());
    }

    /**
     * checks a box is inside another box.
     * \param box  the other AABB
     */
    public boolean isInside(PxBounds3 box) {
        checkNotNull();
        return Raw.isInside(address, box.getAddress());
    }

    /**
     * returns the center of this axis aligned box.
     */
    public PxVec3 getCenter() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getCenter(address));
    }

    /**
     * returns the dimensions (width/height/depth) of this axis aligned box.
     */
    public PxVec3 getDimensions() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getDimensions(address));
    }

    /**
     * returns the extents, which are half of the width/height/depth.
     */
    public PxVec3 getExtents() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getExtents(address));
    }

    /**
     * scales the AABB.
     * <p>
     * This version is safe to call for empty bounds.
     * <p>
     * \param scale Factor to scale AABB by.
     */
    public void scaleSafe(float scale) {
        checkNotNull();
        Raw.scaleSafe(address, scale);
    }

    /**
     * scales the AABB.
     * <p>
     * Calling this method for empty bounds leads to undefined behavior. Use #scaleSafe() instead.
     * <p>
     * \param scale Factor to scale AABB by.
     */
    public void scaleFast(float scale) {
        checkNotNull();
        Raw.scaleFast(address, scale);
    }

    /**
     * fattens the AABB in all 3 dimensions by the given distance.
     * <p>
     * This version is safe to call for empty bounds.
     */
    public void fattenSafe(float distance) {
        checkNotNull();
        Raw.fattenSafe(address, distance);
    }

    /**
     * fattens the AABB in all 3 dimensions by the given distance.
     * <p>
     * Calling this method for empty bounds leads to undefined behavior. Use #fattenSafe() instead.
     */
    public void fattenFast(float distance) {
        checkNotNull();
        Raw.fattenFast(address, distance);
    }

    /**
     * checks that the AABB values are not NaN
     */
    public boolean isFinite() {
        checkNotNull();
        return Raw.isFinite(address);
    }

    /**
     * checks that the AABB values describe a valid configuration.
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native void PxBounds3_placed(long address);
        public static native void PxBounds3_placed(long address, long minimum, long maximum);
        public static native long PxBounds3();
        public static native long PxBounds3(long minimum, long maximum);
        public static native void destroy(long address);
        public static native long getMinimum(long address);
        public static native void setMinimum(long address, long value);
        public static native long getMaximum(long address);
        public static native void setMaximum(long address, long value);
        public static native void setEmpty(long address);
        public static native void setMaximal(long address);
        public static native void include(long address, long v);
        public static native boolean isEmpty(long address);
        public static native boolean intersects(long address, long b);
        public static native boolean intersects1D(long address, long b, int axis);
        public static native boolean contains(long address, long v);
        public static native boolean isInside(long address, long box);
        public static native long getCenter(long address);
        public static native long getDimensions(long address);
        public static native long getExtents(long address);
        public static native void scaleSafe(long address, float scale);
        public static native void scaleFast(long address, float scale);
        public static native void fattenSafe(long address, float distance);
        public static native void fattenFast(long address, float distance);
        public static native boolean isFinite(long address);
        public static native boolean isValid(long address);
    }
}
