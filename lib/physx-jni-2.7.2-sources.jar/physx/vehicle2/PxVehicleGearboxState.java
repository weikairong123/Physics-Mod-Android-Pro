package physx.vehicle2;

import physx.NativeObject;

public class PxVehicleGearboxState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleGearboxState wrapPointer(long address) {
        return address != 0L ? new PxVehicleGearboxState(address) : null;
    }
    
    public static PxVehicleGearboxState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleGearboxState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleGearboxState() {
        address = Raw.PxVehicleGearboxState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Current gear
     */
    public int getCurrentGear() {
        checkNotNull();
        return Raw.getCurrentGear(address);
    }

    /**
     * Current gear
     */
    public void setCurrentGear(int value) {
        checkNotNull();
        Raw.setCurrentGear(address, value);
    }

    /**
     * Target gear (different from current gear if a gear change is underway)
     */
    public int getTargetGear() {
        checkNotNull();
        return Raw.getTargetGear(address);
    }

    /**
     * Target gear (different from current gear if a gear change is underway)
     */
    public void setTargetGear(int value) {
        checkNotNull();
        Raw.setTargetGear(address, value);
    }

    /**
     * Reported time that has passed since gear change started.
     * <p>
     * The special value PX_VEHICLE_NO_GEAR_SWITCH_PENDING denotes that there is currently
     * no gear change underway.
     * <p>
     * If a gear switch was initiated, the special value PX_VEHICLE_GEAR_SWITCH_INITIATED
     * will be used temporarily but get translated to 0 in the gearbox update immediately.
     * This state might only get encountered, if the vehicle component update is split into
     * multiple sequences that do not run in one go.
     * <p>
     * <b>Unit:</b> time
     */
    public float getGearSwitchTime() {
        checkNotNull();
        return Raw.getGearSwitchTime(address);
    }

    /**
     * Reported time that has passed since gear change started.
     * <p>
     * The special value PX_VEHICLE_NO_GEAR_SWITCH_PENDING denotes that there is currently
     * no gear change underway.
     * <p>
     * If a gear switch was initiated, the special value PX_VEHICLE_GEAR_SWITCH_INITIATED
     * will be used temporarily but get translated to 0 in the gearbox update immediately.
     * This state might only get encountered, if the vehicle component update is split into
     * multiple sequences that do not run in one go.
     * <p>
     * <b>Unit:</b> time
     */
    public void setGearSwitchTime(float value) {
        checkNotNull();
        Raw.setGearSwitchTime(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleGearboxState();
        public static native void destroy(long address);
        public static native int getCurrentGear(long address);
        public static native void setCurrentGear(long address, int value);
        public static native int getTargetGear(long address);
        public static native void setTargetGear(long address, int value);
        public static native float getGearSwitchTime(long address);
        public static native void setGearSwitchTime(long address, float value);
        public static native void setToDefault(long address);
    }
}
