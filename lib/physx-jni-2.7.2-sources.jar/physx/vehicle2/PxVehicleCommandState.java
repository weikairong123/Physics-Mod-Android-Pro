package physx.vehicle2;

import physx.NativeObject;

/**
 * A description of the state of commands that are applied to the vehicle
 * <b>Note:</b> brakes[0] and brakes[1] may be used to distinguish brake and handbrake controls.
 */
public class PxVehicleCommandState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleCommandState wrapPointer(long address) {
        return address != 0L ? new PxVehicleCommandState(address) : null;
    }
    
    public static PxVehicleCommandState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleCommandState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleCommandState() {
        address = Raw.PxVehicleCommandState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getBrakes(int index) {
        checkNotNull();
        return Raw.getBrakes(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setBrakes(int index, float value) {
        checkNotNull();
        Raw.setBrakes(address, index, value);
    }

    public int getNbBrakes() {
        checkNotNull();
        return Raw.getNbBrakes(address);
    }

    public void setNbBrakes(int value) {
        checkNotNull();
        Raw.setNbBrakes(address, value);
    }

    /**
     * The instantaneous state of the throttle controller in range [0,1] with 1 denoting fully pressed and 0 fully depressed.
     */
    public float getThrottle() {
        checkNotNull();
        return Raw.getThrottle(address);
    }

    /**
     * The instantaneous state of the throttle controller in range [0,1] with 1 denoting fully pressed and 0 fully depressed.
     */
    public void setThrottle(float value) {
        checkNotNull();
        Raw.setThrottle(address, value);
    }

    /**
     * The instantaneous state of the steer controller in range [-1,1].
     */
    public float getSteer() {
        checkNotNull();
        return Raw.getSteer(address);
    }

    /**
     * The instantaneous state of the steer controller in range [-1,1].
     */
    public void setSteer(float value) {
        checkNotNull();
        Raw.setSteer(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleCommandState();
        public static native void destroy(long address);
        public static native float getBrakes(long address, int index);
        public static native void setBrakes(long address, int index, float value);
        public static native int getNbBrakes(long address);
        public static native void setNbBrakes(long address, int value);
        public static native float getThrottle(long address);
        public static native void setThrottle(long address, float value);
        public static native float getSteer(long address);
        public static native void setSteer(long address, float value);
        public static native void setToDefault(long address);
    }
}
