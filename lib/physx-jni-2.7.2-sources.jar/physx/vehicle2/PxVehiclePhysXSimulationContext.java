package physx.vehicle2;

import physx.geometry.PxConvexMesh;
import physx.physics.PxScene;

public class PxVehiclePhysXSimulationContext extends PxVehicleSimulationContext {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehiclePhysXSimulationContext wrapPointer(long address) {
        return address != 0L ? new PxVehiclePhysXSimulationContext(address) : null;
    }
    
    public static PxVehiclePhysXSimulationContext arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehiclePhysXSimulationContext(long address) {
        super(address);
    }

    // Constructors

    public PxVehiclePhysXSimulationContext() {
        address = Raw.PxVehiclePhysXSimulationContext();
    }

    // Attributes

    public PxConvexMesh getPhysxUnitCylinderSweepMesh() {
        checkNotNull();
        return PxConvexMesh.wrapPointer(Raw.getPhysxUnitCylinderSweepMesh(address));
    }

    public void setPhysxUnitCylinderSweepMesh(PxConvexMesh value) {
        checkNotNull();
        Raw.setPhysxUnitCylinderSweepMesh(address, value.getAddress());
    }

    public PxScene getPhysxScene() {
        checkNotNull();
        return PxScene.wrapPointer(Raw.getPhysxScene(address));
    }

    public void setPhysxScene(PxScene value) {
        checkNotNull();
        Raw.setPhysxScene(address, value.getAddress());
    }

    public PxVehiclePhysXActorUpdateModeEnum getPhysxActorUpdateMode() {
        checkNotNull();
        return PxVehiclePhysXActorUpdateModeEnum.forValue(Raw.getPhysxActorUpdateMode(address));
    }

    public void setPhysxActorUpdateMode(PxVehiclePhysXActorUpdateModeEnum value) {
        checkNotNull();
        Raw.setPhysxActorUpdateMode(address, value.value);
    }

    /**
     * Wake counter value to set on the physx actor if a reset is required.
     * <p>
     * Certain vehicle states should keep a physx actor of a vehicle awake. This
     * will be achieved by resetting the wake counter value if needed. The wake
     * counter value is the minimum simulation time that a physx actor will stay
     * awake.
     * <p>
     * <b>Unit:</b> time
     */
    public float getPhysxActorWakeCounterResetValue() {
        checkNotNull();
        return Raw.getPhysxActorWakeCounterResetValue(address);
    }

    /**
     * Wake counter value to set on the physx actor if a reset is required.
     * <p>
     * Certain vehicle states should keep a physx actor of a vehicle awake. This
     * will be achieved by resetting the wake counter value if needed. The wake
     * counter value is the minimum simulation time that a physx actor will stay
     * awake.
     * <p>
     * <b>Unit:</b> time
     */
    public void setPhysxActorWakeCounterResetValue(float value) {
        checkNotNull();
        Raw.setPhysxActorWakeCounterResetValue(address, value);
    }

    /**
     * Threshold below which to check whether the physx actor wake counter
     *        should get reset.
     * <p>
     * <b>Unit:</b> time
     */
    public float getPhysxActorWakeCounterThreshold() {
        checkNotNull();
        return Raw.getPhysxActorWakeCounterThreshold(address);
    }

    /**
     * Threshold below which to check whether the physx actor wake counter
     *        should get reset.
     * <p>
     * <b>Unit:</b> time
     */
    public void setPhysxActorWakeCounterThreshold(float value) {
        checkNotNull();
        Raw.setPhysxActorWakeCounterThreshold(address, value);
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehiclePhysXSimulationContext} [Value]
     */
    public PxVehiclePhysXSimulationContext transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehiclePhysXSimulationContext.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    public static class Raw {
        public static native long PxVehiclePhysXSimulationContext();
        public static native long getPhysxUnitCylinderSweepMesh(long address);
        public static native void setPhysxUnitCylinderSweepMesh(long address, long value);
        public static native long getPhysxScene(long address);
        public static native void setPhysxScene(long address, long value);
        public static native int getPhysxActorUpdateMode(long address);
        public static native void setPhysxActorUpdateMode(long address, int value);
        public static native float getPhysxActorWakeCounterResetValue(long address);
        public static native void setPhysxActorWakeCounterResetValue(long address, float value);
        public static native float getPhysxActorWakeCounterThreshold(long address);
        public static native void setPhysxActorWakeCounterThreshold(long address, float value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
    }
}
