package physx.vehicle2;

import physx.NativeObject;

public class PxVehicleEngineState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleEngineState wrapPointer(long address) {
        return address != 0L ? new PxVehicleEngineState(address) : null;
    }
    
    public static PxVehicleEngineState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleEngineState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleEngineState() {
        address = Raw.PxVehicleEngineState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The rotation speed of the engine (radians per second).
     * <p>
     * <b>Unit:</b> radians / time
     */
    public float getRotationSpeed() {
        checkNotNull();
        return Raw.getRotationSpeed(address);
    }

    /**
     * The rotation speed of the engine (radians per second).
     * <p>
     * <b>Unit:</b> radians / time
     */
    public void setRotationSpeed(float value) {
        checkNotNull();
        Raw.setRotationSpeed(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleEngineState();
        public static native void destroy(long address);
        public static native float getRotationSpeed(long address);
        public static native void setRotationSpeed(long address, float value);
        public static native void setToDefault(long address);
    }
}
