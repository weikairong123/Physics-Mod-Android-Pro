package physx.vehicle2;

/**
 * Maximum supported number of gears, including reverse and neutral.
 */
public enum PxVehicleGearboxParamsEnum {

    eMAX_NB_GEARS(geteMAX_NB_GEARS());
    public final int value;
    
    PxVehicleGearboxParamsEnum(int value) {
        this.value = value;
    }

    private static native int _geteMAX_NB_GEARS();
    private static int geteMAX_NB_GEARS() {
        de.fabmax.physxjni.Loader.load();
        return _geteMAX_NB_GEARS();
    }

    private static final int LUT_SIZE = 256;
    private static final PxVehicleGearboxParamsEnum[] enumValues = values();
    private static final PxVehicleGearboxParamsEnum[] enumLut = new PxVehicleGearboxParamsEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxVehicleGearboxParamsEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxVehicleGearboxParamsEnum forValue(int value) {
        PxVehicleGearboxParamsEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxVehicleGearboxParamsEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxVehicleGearboxParamsEnum: " + value);
        }
        return enumValue;
    }
}
