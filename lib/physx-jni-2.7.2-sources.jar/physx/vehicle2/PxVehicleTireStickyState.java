package physx.vehicle2;

import physx.NativeObject;

/**
 * Prolonged low speeds in the lateral and longitudinal directions may be handled with "sticky" velocity constraints that activate after
 * a speed below a threshold has been recorded for a threshold time.
 * @see PxVehicleTireStickyParams
 * @see PxVehicleTireSpeedState
 */
public class PxVehicleTireStickyState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleTireStickyState wrapPointer(long address) {
        return address != 0L ? new PxVehicleTireStickyState(address) : null;
    }
    
    public static PxVehicleTireStickyState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleTireStickyState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleTireStickyState() {
        address = Raw.PxVehicleTireStickyState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getLowSpeedTime(int index) {
        checkNotNull();
        return Raw.getLowSpeedTime(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setLowSpeedTime(int index, float value) {
        checkNotNull();
        Raw.setLowSpeedTime(address, index, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: boolean
     */
    public boolean getActiveStatus(int index) {
        checkNotNull();
        return Raw.getActiveStatus(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: boolean
     */
    public void setActiveStatus(int index, boolean value) {
        checkNotNull();
        Raw.setActiveStatus(address, index, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleTireStickyState();
        public static native void destroy(long address);
        public static native float getLowSpeedTime(long address, int index);
        public static native void setLowSpeedTime(long address, int index, float value);
        public static native boolean getActiveStatus(long address, int index);
        public static native void setActiveStatus(long address, int index, boolean value);
        public static native void setToDefault(long address);
    }
}
