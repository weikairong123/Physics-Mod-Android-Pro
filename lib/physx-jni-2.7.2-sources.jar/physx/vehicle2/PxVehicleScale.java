package physx.vehicle2;

import physx.NativeObject;

public class PxVehicleScale extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleScale wrapPointer(long address) {
        return address != 0L ? new PxVehicleScale(address) : null;
    }
    
    public static PxVehicleScale arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleScale(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleScale() {
        address = Raw.PxVehicleScale();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The length scale used for the vehicle. For example, if 1.0 is considered meters, then 100.0 would be for centimeters.
     */
    public float getScale() {
        checkNotNull();
        return Raw.getScale(address);
    }

    /**
     * The length scale used for the vehicle. For example, if 1.0 is considered meters, then 100.0 would be for centimeters.
     */
    public void setScale(float value) {
        checkNotNull();
        Raw.setScale(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native long PxVehicleScale();
        public static native void destroy(long address);
        public static native float getScale(long address);
        public static native void setScale(long address, float value);
        public static native void setToDefault(long address);
        public static native boolean isValid(long address);
    }
}
