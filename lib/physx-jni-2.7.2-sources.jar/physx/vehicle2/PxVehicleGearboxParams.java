package physx.vehicle2;

import physx.NativeObject;

public class PxVehicleGearboxParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleGearboxParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleGearboxParams(address) : null;
    }
    
    public static PxVehicleGearboxParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleGearboxParams(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxVehicleGearboxParams
     */
    public static PxVehicleGearboxParams createAt(long address) {
        Raw.PxVehicleGearboxParams_placed(address);
        PxVehicleGearboxParams createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxVehicleGearboxParams
     */
    public static <T> PxVehicleGearboxParams createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxVehicleGearboxParams_placed(address);
        PxVehicleGearboxParams createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxVehicleGearboxParams() {
        address = Raw.PxVehicleGearboxParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The gear that denotes neutral gear
     */
    public int getNeutralGear() {
        checkNotNull();
        return Raw.getNeutralGear(address);
    }

    /**
     * The gear that denotes neutral gear
     */
    public void setNeutralGear(int value) {
        checkNotNull();
        Raw.setNeutralGear(address, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getRatios(int index) {
        checkNotNull();
        return Raw.getRatios(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setRatios(int index, float value) {
        checkNotNull();
        Raw.setRatios(address, index, value);
    }

    /**
     * Gear ratio applied is #ratios[currentGear]*#finalRatio
     * <p>
     * <b>Range:</b> (0, inf)<br>
     */
    public float getFinalRatio() {
        checkNotNull();
        return Raw.getFinalRatio(address);
    }

    /**
     * Gear ratio applied is #ratios[currentGear]*#finalRatio
     * <p>
     * <b>Range:</b> (0, inf)<br>
     */
    public void setFinalRatio(float value) {
        checkNotNull();
        Raw.setFinalRatio(address, value);
    }

    /**
     * Number of gears (including reverse and neutral).
     * <p>
     * <b>Range:</b> [1, eMAX_NB_GEARS]<br>
     */
    public int getNbRatios() {
        checkNotNull();
        return Raw.getNbRatios(address);
    }

    /**
     * Number of gears (including reverse and neutral).
     * <p>
     * <b>Range:</b> [1, eMAX_NB_GEARS]<br>
     */
    public void setNbRatios(int value) {
        checkNotNull();
        Raw.setNbRatios(address, value);
    }

    /**
     * Time it takes to switch gear.
     * <p>
     * <b>Range:</b> [0, inf)<br>
     * <b>Unit:</b> time
     */
    public float getSwitchTime() {
        checkNotNull();
        return Raw.getSwitchTime(address);
    }

    /**
     * Time it takes to switch gear.
     * <p>
     * <b>Range:</b> [0, inf)<br>
     * <b>Unit:</b> time
     */
    public void setSwitchTime(float value) {
        checkNotNull();
        Raw.setSwitchTime(address, value);
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehicleGearboxParams} [Value]
     */
    public PxVehicleGearboxParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehicleGearboxParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native void PxVehicleGearboxParams_placed(long address);
        public static native long PxVehicleGearboxParams();
        public static native void destroy(long address);
        public static native int getNeutralGear(long address);
        public static native void setNeutralGear(long address, int value);
        public static native float getRatios(long address, int index);
        public static native void setRatios(long address, int index, float value);
        public static native float getFinalRatio(long address);
        public static native void setFinalRatio(long address, float value);
        public static native int getNbRatios(long address);
        public static native void setNbRatios(long address, int value);
        public static native float getSwitchTime(long address);
        public static native void setSwitchTime(long address, float value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address);
    }
}
