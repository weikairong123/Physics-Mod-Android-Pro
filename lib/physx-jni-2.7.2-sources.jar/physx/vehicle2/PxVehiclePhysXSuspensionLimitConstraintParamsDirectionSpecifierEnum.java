package physx.vehicle2;

public enum PxVehiclePhysXSuspensionLimitConstraintParamsDirectionSpecifierEnum {

    eSUSPENSION(geteSUSPENSION()),
    eROAD_GEOMETRY_NORMAL(geteROAD_GEOMETRY_NORMAL()),
    eNONE(geteNONE());
    public final int value;
    
    PxVehiclePhysXSuspensionLimitConstraintParamsDirectionSpecifierEnum(int value) {
        this.value = value;
    }

    private static native int _geteSUSPENSION();
    private static int geteSUSPENSION() {
        de.fabmax.physxjni.Loader.load();
        return _geteSUSPENSION();
    }

    private static native int _geteROAD_GEOMETRY_NORMAL();
    private static int geteROAD_GEOMETRY_NORMAL() {
        de.fabmax.physxjni.Loader.load();
        return _geteROAD_GEOMETRY_NORMAL();
    }

    private static native int _geteNONE();
    private static int geteNONE() {
        de.fabmax.physxjni.Loader.load();
        return _geteNONE();
    }

    private static final int LUT_SIZE = 256;
    private static final PxVehiclePhysXSuspensionLimitConstraintParamsDirectionSpecifierEnum[] enumValues = values();
    private static final PxVehiclePhysXSuspensionLimitConstraintParamsDirectionSpecifierEnum[] enumLut = new PxVehiclePhysXSuspensionLimitConstraintParamsDirectionSpecifierEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxVehiclePhysXSuspensionLimitConstraintParamsDirectionSpecifierEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxVehiclePhysXSuspensionLimitConstraintParamsDirectionSpecifierEnum forValue(int value) {
        PxVehiclePhysXSuspensionLimitConstraintParamsDirectionSpecifierEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxVehiclePhysXSuspensionLimitConstraintParamsDirectionSpecifierEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxVehiclePhysXSuspensionLimitConstraintParamsDirectionSpecifierEnum: " + value);
        }
        return enumValue;
    }
}
