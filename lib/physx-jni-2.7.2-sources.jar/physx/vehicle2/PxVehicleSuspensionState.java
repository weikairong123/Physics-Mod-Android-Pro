package physx.vehicle2;

import physx.NativeObject;

public class PxVehicleSuspensionState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleSuspensionState wrapPointer(long address) {
        return address != 0L ? new PxVehicleSuspensionState(address) : null;
    }
    
    public static PxVehicleSuspensionState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleSuspensionState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleSuspensionState() {
        address = Raw.PxVehicleSuspensionState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * jounce is the distance from maximum droop.
     * <b>Note:</b> jounce is positive semi-definite
     * <b>Note:</b> A value of 0.0 represents the suspension at maximum droop and zero suspension force.
     * <b>Note:</b> A value of suspensionTravelDist represents the suspension at maximum compression.
     * <b>Note:</b> jounce is clamped in range [0, suspensionTravelDist].
     */
    public float getJounce() {
        checkNotNull();
        return Raw.getJounce(address);
    }

    /**
     * jounce is the distance from maximum droop.
     * <b>Note:</b> jounce is positive semi-definite
     * <b>Note:</b> A value of 0.0 represents the suspension at maximum droop and zero suspension force.
     * <b>Note:</b> A value of suspensionTravelDist represents the suspension at maximum compression.
     * <b>Note:</b> jounce is clamped in range [0, suspensionTravelDist].
     */
    public void setJounce(float value) {
        checkNotNull();
        Raw.setJounce(address, value);
    }

    /**
     * jounceSpeed is the rate of change of jounce.
     */
    public float getJounceSpeed() {
        checkNotNull();
        return Raw.getJounceSpeed(address);
    }

    /**
     * jounceSpeed is the rate of change of jounce.
     */
    public void setJounceSpeed(float value) {
        checkNotNull();
        Raw.setJounceSpeed(address, value);
    }

    /**
     * separation holds extra information about the contact state of the wheel with the ground.
     * <p>
     * If the suspension travel range is enough to place the wheel on the ground, then separation will be 0.
     * If separation holds a negative value, then the wheel penetrates into the ground at maximum compression
     * as well as maximum droop. The suspension would need to go beyond maximum compression (ground normal
     * pointing in opposite direction of suspension) or beyond maximum droop (ground normal pointing in same
     * direction as suspension) to place the wheel on the ground. In that case the separation value defines
     * how much the wheel penetrates into the ground along the ground plane normal. This penetration may be
     * resolved by using a constraint that simulates the effect of a bump stop.
     * If separation holds a positive value, then the wheel does not penetrate the ground at maximum droop
     * but can not touch the ground because the suspension would need to expand beyond max droop to reach it
     * or because the suspension could not expand fast enough to reach the ground.
     */
    public float getSeparation() {
        checkNotNull();
        return Raw.getSeparation(address);
    }

    /**
     * separation holds extra information about the contact state of the wheel with the ground.
     * <p>
     * If the suspension travel range is enough to place the wheel on the ground, then separation will be 0.
     * If separation holds a negative value, then the wheel penetrates into the ground at maximum compression
     * as well as maximum droop. The suspension would need to go beyond maximum compression (ground normal
     * pointing in opposite direction of suspension) or beyond maximum droop (ground normal pointing in same
     * direction as suspension) to place the wheel on the ground. In that case the separation value defines
     * how much the wheel penetrates into the ground along the ground plane normal. This penetration may be
     * resolved by using a constraint that simulates the effect of a bump stop.
     * If separation holds a positive value, then the wheel does not penetrate the ground at maximum droop
     * but can not touch the ground because the suspension would need to expand beyond max droop to reach it
     * or because the suspension could not expand fast enough to reach the ground.
     */
    public void setSeparation(float value) {
        checkNotNull();
        Raw.setSeparation(address, value);
    }

    // Functions

    /**
     * @param _jounce     WebIDL type: float
     * @param _separation WebIDL type: float
     */
    public void setToDefault(float _jounce, float _separation) {
        checkNotNull();
        Raw.setToDefault(address, _jounce, _separation);
    }

    public static class Raw {
        public static native long PxVehicleSuspensionState();
        public static native void destroy(long address);
        public static native float getJounce(long address);
        public static native void setJounce(long address, float value);
        public static native float getJounceSpeed(long address);
        public static native void setJounceSpeed(long address, float value);
        public static native float getSeparation(long address);
        public static native void setSeparation(long address, float value);
        public static native void setToDefault(long address, float _jounce, float _separation);
    }
}
