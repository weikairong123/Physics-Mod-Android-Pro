package physx.vehicle2;

import physx.NativeObject;
import physx.physics.PxConstraint;

/**
 * A mapping between constraint state data and the associated PxConstraint instances.
 */
public class PxVehiclePhysXConstraints extends NativeObject {

    protected PxVehiclePhysXConstraints() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehiclePhysXConstraints wrapPointer(long address) {
        return address != 0L ? new PxVehiclePhysXConstraints(address) : null;
    }
    
    public static PxVehiclePhysXConstraints arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehiclePhysXConstraints(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehiclePhysXConstraintState} [Value]
     */
    public PxVehiclePhysXConstraintState getConstraintStates(int index) {
        checkNotNull();
        return PxVehiclePhysXConstraintState.wrapPointer(Raw.getConstraintStates(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehiclePhysXConstraintState} [Value]
     */
    public void setConstraintStates(int index, PxVehiclePhysXConstraintState value) {
        checkNotNull();
        Raw.setConstraintStates(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxConstraint}
     */
    public PxConstraint getConstraints(int index) {
        checkNotNull();
        return PxConstraint.wrapPointer(Raw.getConstraints(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxConstraint}
     */
    public void setConstraints(int index, PxConstraint value) {
        checkNotNull();
        Raw.setConstraints(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleConstraintConnector}
     */
    public PxVehicleConstraintConnector getConstraintConnectors(int index) {
        checkNotNull();
        return PxVehicleConstraintConnector.wrapPointer(Raw.getConstraintConnectors(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleConstraintConnector}
     */
    public void setConstraintConnectors(int index, PxVehicleConstraintConnector value) {
        checkNotNull();
        Raw.setConstraintConnectors(address, index, value.getAddress());
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getConstraintStates(long address, int index);
        public static native void setConstraintStates(long address, int index, long value);
        public static native long getConstraints(long address, int index);
        public static native void setConstraints(long address, int index, long value);
        public static native long getConstraintConnectors(long address, int index);
        public static native void setConstraintConnectors(long address, int index, long value);
        public static native void setToDefault(long address);
    }
}
