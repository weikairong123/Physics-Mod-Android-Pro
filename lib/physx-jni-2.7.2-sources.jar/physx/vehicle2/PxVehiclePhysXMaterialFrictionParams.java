package physx.vehicle2;

import physx.NativeObject;

/**
 * A mappping between PxMaterial instance and friction for multiple PxMaterial intances.
 */
public class PxVehiclePhysXMaterialFrictionParams extends NativeObject {

    protected PxVehiclePhysXMaterialFrictionParams() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehiclePhysXMaterialFrictionParams wrapPointer(long address) {
        return address != 0L ? new PxVehiclePhysXMaterialFrictionParams(address) : null;
    }
    
    public static PxVehiclePhysXMaterialFrictionParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehiclePhysXMaterialFrictionParams(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * An array of mappings between PxMaterial and friction.
     */
    public PxVehiclePhysXMaterialFriction getMaterialFrictions() {
        checkNotNull();
        return PxVehiclePhysXMaterialFriction.wrapPointer(Raw.getMaterialFrictions(address));
    }

    /**
     * An array of mappings between PxMaterial and friction.
     */
    public void setMaterialFrictions(PxVehiclePhysXMaterialFriction value) {
        checkNotNull();
        Raw.setMaterialFrictions(address, value.getAddress());
    }

    /**
     * The number of mappings between PxMaterial and friction.
     */
    public int getNbMaterialFrictions() {
        checkNotNull();
        return Raw.getNbMaterialFrictions(address);
    }

    /**
     * The number of mappings between PxMaterial and friction.
     */
    public void setNbMaterialFrictions(int value) {
        checkNotNull();
        Raw.setNbMaterialFrictions(address, value);
    }

    /**
     * A default friction value to be used in the event that the PxMaterial under the tire is not found in the array #materialFrictions.
     */
    public float getDefaultFriction() {
        checkNotNull();
        return Raw.getDefaultFriction(address);
    }

    /**
     * A default friction value to be used in the event that the PxMaterial under the tire is not found in the array #materialFrictions.
     */
    public void setDefaultFriction(float value) {
        checkNotNull();
        Raw.setDefaultFriction(address, value);
    }

    // Functions

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getMaterialFrictions(long address);
        public static native void setMaterialFrictions(long address, long value);
        public static native int getNbMaterialFrictions(long address);
        public static native void setNbMaterialFrictions(long address, int value);
        public static native float getDefaultFriction(long address);
        public static native void setDefaultFriction(long address, float value);
        public static native boolean isValid(long address);
    }
}
