package physx.vehicle2;

public enum PxVehicleSuspensionJounceCalculationTypeEnum {

    /**
     * The jounce is calculated using a raycast against the plane of the road geometry state
     */
    eRAYCAST(geteRAYCAST()),
    /**
     * The jounce is calculated by sweeping a cylinder against the plane of the road geometry state
     */
    eSWEEP(geteSWEEP());
    public final int value;
    
    PxVehicleSuspensionJounceCalculationTypeEnum(int value) {
        this.value = value;
    }

    private static native int _geteRAYCAST();
    private static int geteRAYCAST() {
        de.fabmax.physxjni.Loader.load();
        return _geteRAYCAST();
    }

    private static native int _geteSWEEP();
    private static int geteSWEEP() {
        de.fabmax.physxjni.Loader.load();
        return _geteSWEEP();
    }

    private static final int LUT_SIZE = 256;
    private static final PxVehicleSuspensionJounceCalculationTypeEnum[] enumValues = values();
    private static final PxVehicleSuspensionJounceCalculationTypeEnum[] enumLut = new PxVehicleSuspensionJounceCalculationTypeEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxVehicleSuspensionJounceCalculationTypeEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxVehicleSuspensionJounceCalculationTypeEnum forValue(int value) {
        PxVehicleSuspensionJounceCalculationTypeEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxVehicleSuspensionJounceCalculationTypeEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxVehicleSuspensionJounceCalculationTypeEnum: " + value);
        }
        return enumValue;
    }
}
