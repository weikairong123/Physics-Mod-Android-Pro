package physx.vehicle2;

import physx.NativeObject;

/**
 * Specify groups of wheels that are to be constrained to have pre-determined angular velocity relationship.
 */
public class PxVehicleWheelConstraintGroupState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleWheelConstraintGroupState wrapPointer(long address) {
        return address != 0L ? new PxVehicleWheelConstraintGroupState(address) : null;
    }
    
    public static PxVehicleWheelConstraintGroupState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleWheelConstraintGroupState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleWheelConstraintGroupState() {
        address = Raw.PxVehicleWheelConstraintGroupState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The number of constraint groups in the vehicle
     */
    public int getNbGroups() {
        checkNotNull();
        return Raw.getNbGroups(address);
    }

    /**
     * The number of constraint groups in the vehicle
     */
    public void setNbGroups(int value) {
        checkNotNull();
        Raw.setNbGroups(address, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: unsigned long
     */
    public int getNbWheelsPerGroup(int index) {
        checkNotNull();
        return Raw.getNbWheelsPerGroup(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: unsigned long
     */
    public void setNbWheelsPerGroup(int index, int value) {
        checkNotNull();
        Raw.setNbWheelsPerGroup(address, index, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: unsigned long
     */
    public int getGroupToWheelIds(int index) {
        checkNotNull();
        return Raw.getGroupToWheelIds(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: unsigned long
     */
    public void setGroupToWheelIds(int index, int value) {
        checkNotNull();
        Raw.setGroupToWheelIds(address, index, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: unsigned long
     */
    public int getWheelIdsInGroupOrder(int index) {
        checkNotNull();
        return Raw.getWheelIdsInGroupOrder(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: unsigned long
     */
    public void setWheelIdsInGroupOrder(int index, int value) {
        checkNotNull();
        Raw.setWheelIdsInGroupOrder(address, index, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getWheelMultipliersInGroupOrder(int index) {
        checkNotNull();
        return Raw.getWheelMultipliersInGroupOrder(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setWheelMultipliersInGroupOrder(int index, float value) {
        checkNotNull();
        Raw.setWheelMultipliersInGroupOrder(address, index, value);
    }

    /**
     * The number of wheels in a constraint group.
     */
    public int getNbWheelsInGroups() {
        checkNotNull();
        return Raw.getNbWheelsInGroups(address);
    }

    /**
     * The number of wheels in a constraint group.
     */
    public void setNbWheelsInGroups(int value) {
        checkNotNull();
        Raw.setNbWheelsInGroups(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    /**
     * Return the number of wheel constraint groups in the vehicle.
     * @return The number of wheel constraint groups.
     * @see #getNbWheelsInConstraintGroup
     */
    public int getNbConstraintGroups() {
        checkNotNull();
        return Raw.getNbConstraintGroups(address);
    }

    /**
     * Return the number of wheels in the ith constraint group.
     * @param i specifies the constraint group to be queried for its wheel count.
     * @return The number of wheels in the specified constraint group.
     * @see #getWheelInConstraintGroup
     */
    public int getNbWheelsInConstraintGroup(int i) {
        checkNotNull();
        return Raw.getNbWheelsInConstraintGroup(address, i);
    }

    /**
     * Return the wheel id of the jth wheel in the ith constraint group.
     * @param j specifies that the wheel id to be returned is the jth wheel in the list of wheels on the specified constraint group.
     * @param i specifies the constraint group to be queried.
     * @return The wheel id of the jth wheel in the ith constraint group.
     * @see #getNbWheelsInConstraintGroup
     */
    public int getWheelInConstraintGroup(int j, int i) {
        checkNotNull();
        return Raw.getWheelInConstraintGroup(address, j, i);
    }

    /**
     * Return the constraint multiplier of the jth wheel in the ith constraint group
     * @param j specifies that the wheel id to be returned is the jth wheel in the list of wheels on the specified constraint group.
     * @param i specifies the constraint group to be queried.
     * @return The constraint multiplier of the jth wheel in the ith constraint group.
     */
    public float getMultiplierInConstraintGroup(int j, int i) {
        checkNotNull();
        return Raw.getMultiplierInConstraintGroup(address, j, i);
    }

    public static class Raw {
        public static native long PxVehicleWheelConstraintGroupState();
        public static native void destroy(long address);
        public static native int getNbGroups(long address);
        public static native void setNbGroups(long address, int value);
        public static native int getNbWheelsPerGroup(long address, int index);
        public static native void setNbWheelsPerGroup(long address, int index, int value);
        public static native int getGroupToWheelIds(long address, int index);
        public static native void setGroupToWheelIds(long address, int index, int value);
        public static native int getWheelIdsInGroupOrder(long address, int index);
        public static native void setWheelIdsInGroupOrder(long address, int index, int value);
        public static native float getWheelMultipliersInGroupOrder(long address, int index);
        public static native void setWheelMultipliersInGroupOrder(long address, int index, float value);
        public static native int getNbWheelsInGroups(long address);
        public static native void setNbWheelsInGroups(long address, int value);
        public static native void setToDefault(long address);
        public static native int getNbConstraintGroups(long address);
        public static native int getNbWheelsInConstraintGroup(long address, int i);
        public static native int getWheelInConstraintGroup(long address, int j, int i);
        public static native float getMultiplierInConstraintGroup(long address, int j, int i);
    }
}
