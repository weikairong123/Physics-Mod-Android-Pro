package physx.vehicle2;

import physx.NativeObject;

/**
 * The low speed regime often presents numerical difficulties for the tire model due to the potential for divide-by-zero errors.
 * This particularly affects scenarios where the vehicle is slowing down due to damping and drag. In scenarios where there is no
 * significant brake or drive torque, numerical error begins to dominate and it can be difficult to bring the vehicle to rest. A solution
 * to this problem is to recognise that the vehicle is close to rest and to replace the tire forces with velocity constraints that will
 * bring the vehicle to rest. This regime is known as the "sticky tire" regime. PxVehicleTireAxisStickyParams describes velocity and time
 * thresholds that categorise the "sticky tire" regime. It also describes the rate at which the velocity constraints approach zero speed.
 */
public class PxVehicleTireAxisStickyParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleTireAxisStickyParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleTireAxisStickyParams(address) : null;
    }
    
    public static PxVehicleTireAxisStickyParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleTireAxisStickyParams(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxVehicleTireAxisStickyParams
     */
    public static PxVehicleTireAxisStickyParams createAt(long address) {
        Raw.PxVehicleTireAxisStickyParams_placed(address);
        PxVehicleTireAxisStickyParams createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxVehicleTireAxisStickyParams
     */
    public static <T> PxVehicleTireAxisStickyParams createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxVehicleTireAxisStickyParams_placed(address);
        PxVehicleTireAxisStickyParams createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxVehicleTireAxisStickyParams() {
        address = Raw.PxVehicleTireAxisStickyParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * A tire enters the "sticky tire" regime when it has been below a speed specified by #thresholdSpeed for a continuous time
     * specified by #thresholdTime.
     * <p>
     * <b>Range:</b> [0, inf)<br>
     * <b>Unit:</b> velocity = length / time
     */
    public float getThresholdSpeed() {
        checkNotNull();
        return Raw.getThresholdSpeed(address);
    }

    /**
     * A tire enters the "sticky tire" regime when it has been below a speed specified by #thresholdSpeed for a continuous time
     * specified by #thresholdTime.
     * <p>
     * <b>Range:</b> [0, inf)<br>
     * <b>Unit:</b> velocity = length / time
     */
    public void setThresholdSpeed(float value) {
        checkNotNull();
        Raw.setThresholdSpeed(address, value);
    }

    /**
     * A tire enters the "sticky tire" regime when it has been below a speed specified by #thresholdSpeed for a continuous time
     * specified by #thresholdTime.
     * <p>
     * <b>Range:</b> [0, inf)<br>
     * <b>Unit:</b> time
     */
    public float getThresholdTime() {
        checkNotNull();
        return Raw.getThresholdTime(address);
    }

    /**
     * A tire enters the "sticky tire" regime when it has been below a speed specified by #thresholdSpeed for a continuous time
     * specified by #thresholdTime.
     * <p>
     * <b>Range:</b> [0, inf)<br>
     * <b>Unit:</b> time
     */
    public void setThresholdTime(float value) {
        checkNotNull();
        Raw.setThresholdTime(address, value);
    }

    /**
     * The rate at which the velocity constraint approaches zero is controlled by the damping parameter.
     * <b>Note:</b> Larger values of damping lead to faster approaches to zero. Since the damping behaves like a
     *       stiffness with respect to the velocity, too large a value can lead to instabilities.
     * <p>
     * <b>Range:</b> [0, inf)<br>
     * <b>Unit:</b> 1 / time (acceleration instead of force based damping, thus not mass/time)
     */
    public float getDamping() {
        checkNotNull();
        return Raw.getDamping(address);
    }

    /**
     * The rate at which the velocity constraint approaches zero is controlled by the damping parameter.
     * <b>Note:</b> Larger values of damping lead to faster approaches to zero. Since the damping behaves like a
     *       stiffness with respect to the velocity, too large a value can lead to instabilities.
     * <p>
     * <b>Range:</b> [0, inf)<br>
     * <b>Unit:</b> 1 / time (acceleration instead of force based damping, thus not mass/time)
     */
    public void setDamping(float value) {
        checkNotNull();
        Raw.setDamping(address, value);
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehicleTireAxisStickyParams} [Value]
     */
    public PxVehicleTireAxisStickyParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehicleTireAxisStickyParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native void PxVehicleTireAxisStickyParams_placed(long address);
        public static native long PxVehicleTireAxisStickyParams();
        public static native void destroy(long address);
        public static native float getThresholdSpeed(long address);
        public static native void setThresholdSpeed(long address, float value);
        public static native float getThresholdTime(long address);
        public static native void setThresholdTime(long address, float value);
        public static native float getDamping(long address);
        public static native void setDamping(long address, float value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address);
    }
}
