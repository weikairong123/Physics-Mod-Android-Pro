package physx.vehicle2;

import physx.NativeObject;
import physx.common.PxVec3;

/**
 * The anti-roll torque of all anti-roll bars accumulates in a single torque to apply
 * to the vehicle's rigid body.
 */
public class PxVehicleAntiRollTorque extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleAntiRollTorque wrapPointer(long address) {
        return address != 0L ? new PxVehicleAntiRollTorque(address) : null;
    }
    
    public static PxVehicleAntiRollTorque arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleAntiRollTorque(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleAntiRollTorque() {
        address = Raw.PxVehicleAntiRollTorque();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The accumulated torque to apply to the rigid body.
     * <b>Note:</b> antiRollTorque is expressed in the world frame.
     * <p>
     * <b>Unit:</b> mass * (length^2) / (time^2)
     */
    public PxVec3 getAntiRollTorque() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getAntiRollTorque(address));
    }

    /**
     * The accumulated torque to apply to the rigid body.
     * <b>Note:</b> antiRollTorque is expressed in the world frame.
     * <p>
     * <b>Unit:</b> mass * (length^2) / (time^2)
     */
    public void setAntiRollTorque(PxVec3 value) {
        checkNotNull();
        Raw.setAntiRollTorque(address, value.getAddress());
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleAntiRollTorque();
        public static native void destroy(long address);
        public static native long getAntiRollTorque(long address);
        public static native void setAntiRollTorque(long address, long value);
        public static native void setToDefault(long address);
    }
}
