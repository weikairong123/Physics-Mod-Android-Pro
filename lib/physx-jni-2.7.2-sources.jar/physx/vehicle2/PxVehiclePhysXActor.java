package physx.vehicle2;

import physx.NativeObject;
import physx.physics.PxRigidBody;
import physx.physics.PxShape;

/**
 * A description of the PhysX actor and shapes that represent the vehicle in an associated PxScene.
 */
public class PxVehiclePhysXActor extends NativeObject {

    protected PxVehiclePhysXActor() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehiclePhysXActor wrapPointer(long address) {
        return address != 0L ? new PxVehiclePhysXActor(address) : null;
    }
    
    public static PxVehiclePhysXActor arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehiclePhysXActor(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The PhysX rigid body that represents the vehcle in the associated PhysX scene. 
     * <b>Note:</b> PxActorFlag::eDISABLE_GRAVITY must be set true on the PxRigidBody
     */
    public PxRigidBody getRigidBody() {
        checkNotNull();
        return PxRigidBody.wrapPointer(Raw.getRigidBody(address));
    }

    /**
     * The PhysX rigid body that represents the vehcle in the associated PhysX scene. 
     * <b>Note:</b> PxActorFlag::eDISABLE_GRAVITY must be set true on the PxRigidBody
     */
    public void setRigidBody(PxRigidBody value) {
        checkNotNull();
        Raw.setRigidBody(address, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxShape}
     */
    public PxShape getWheelShapes(int index) {
        checkNotNull();
        return PxShape.wrapPointer(Raw.getWheelShapes(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxShape}
     */
    public void setWheelShapes(int index, PxShape value) {
        checkNotNull();
        Raw.setWheelShapes(address, index, value.getAddress());
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getRigidBody(long address);
        public static native void setRigidBody(long address, long value);
        public static native long getWheelShapes(long address, int index);
        public static native void setWheelShapes(long address, int index, long value);
        public static native void setToDefault(long address);
    }
}
