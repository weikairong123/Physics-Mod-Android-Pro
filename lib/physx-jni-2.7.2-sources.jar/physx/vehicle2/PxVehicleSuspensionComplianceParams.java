package physx.vehicle2;

import physx.NativeObject;

/**
 * Compliance describes how toe and camber angle and force application points are affected by suspension compression.
 * <b>Note:</b> Each compliance term is in the form of a graph with up to 3 points. 
 * <b>Note:</b> Each point in the graph has form (jounce/suspensionTravelDist, complianceValue).
 * <b>Note:</b> The sequence of points must respresent monotonically increasing values of jounce.
 * <b>Note:</b> The compliance value can be computed by linear interpolation.
 * <b>Note:</b> If any graph has zero points in it, a value of 0.0 is used for the compliance value. 
 * <b>Note:</b> If any graph has 1 point in it, the compliance value of that point is used directly. 
 */
public class PxVehicleSuspensionComplianceParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleSuspensionComplianceParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleSuspensionComplianceParams(address) : null;
    }
    
    public static PxVehicleSuspensionComplianceParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleSuspensionComplianceParams(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleSuspensionComplianceParams() {
        address = Raw.PxVehicleSuspensionComplianceParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * A graph of toe angle against jounce/suspensionTravelDist with the toe angle expressed in radians.
     * <b>Note:</b> The toe angle is applied in the suspension frame.
     */
    public PxVehicleFixedSizeLookupTableFloat_3 getWheelToeAngle() {
        checkNotNull();
        return PxVehicleFixedSizeLookupTableFloat_3.wrapPointer(Raw.getWheelToeAngle(address));
    }

    /**
     * A graph of toe angle against jounce/suspensionTravelDist with the toe angle expressed in radians.
     * <b>Note:</b> The toe angle is applied in the suspension frame.
     */
    public void setWheelToeAngle(PxVehicleFixedSizeLookupTableFloat_3 value) {
        checkNotNull();
        Raw.setWheelToeAngle(address, value.getAddress());
    }

    /**
     * A graph of camber angle against jounce/suspensionTravelDist with the camber angle expressed in radians.
     * <b>Note:</b> The camber angle is applied in the suspension frame.
     */
    public PxVehicleFixedSizeLookupTableFloat_3 getWheelCamberAngle() {
        checkNotNull();
        return PxVehicleFixedSizeLookupTableFloat_3.wrapPointer(Raw.getWheelCamberAngle(address));
    }

    /**
     * A graph of camber angle against jounce/suspensionTravelDist with the camber angle expressed in radians.
     * <b>Note:</b> The camber angle is applied in the suspension frame.
     */
    public void setWheelCamberAngle(PxVehicleFixedSizeLookupTableFloat_3 value) {
        checkNotNull();
        Raw.setWheelCamberAngle(address, value.getAddress());
    }

    /**
     * Suspension forces are applied at an offset from the suspension frame. suspForceAppPoint
     * specifies the (X, Y, Z) components of that offset as a function of jounce/suspensionTravelDist.
     */
    public PxVehicleFixedSizeLookupTableVec3_3 getSuspForceAppPoint() {
        checkNotNull();
        return PxVehicleFixedSizeLookupTableVec3_3.wrapPointer(Raw.getSuspForceAppPoint(address));
    }

    /**
     * Suspension forces are applied at an offset from the suspension frame. suspForceAppPoint
     * specifies the (X, Y, Z) components of that offset as a function of jounce/suspensionTravelDist.
     */
    public void setSuspForceAppPoint(PxVehicleFixedSizeLookupTableVec3_3 value) {
        checkNotNull();
        Raw.setSuspForceAppPoint(address, value.getAddress());
    }

    /**
     * Tire forces are applied at an offset from the suspension frame. tireForceAppPoint
     * specifies the (X, Y, Z) components of that offset as a function of jounce/suspensionTravelDist.
     */
    public PxVehicleFixedSizeLookupTableVec3_3 getTireForceAppPoint() {
        checkNotNull();
        return PxVehicleFixedSizeLookupTableVec3_3.wrapPointer(Raw.getTireForceAppPoint(address));
    }

    /**
     * Tire forces are applied at an offset from the suspension frame. tireForceAppPoint
     * specifies the (X, Y, Z) components of that offset as a function of jounce/suspensionTravelDist.
     */
    public void setTireForceAppPoint(PxVehicleFixedSizeLookupTableVec3_3 value) {
        checkNotNull();
        Raw.setTireForceAppPoint(address, value.getAddress());
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehicleSuspensionComplianceParams} [Value]
     */
    public PxVehicleSuspensionComplianceParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehicleSuspensionComplianceParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native long PxVehicleSuspensionComplianceParams();
        public static native void destroy(long address);
        public static native long getWheelToeAngle(long address);
        public static native void setWheelToeAngle(long address, long value);
        public static native long getWheelCamberAngle(long address);
        public static native void setWheelCamberAngle(long address, long value);
        public static native long getSuspForceAppPoint(long address);
        public static native void setSuspForceAppPoint(long address, long value);
        public static native long getTireForceAppPoint(long address);
        public static native void setTireForceAppPoint(long address, long value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address);
    }
}
