package physx.vehicle2;

import physx.NativeObject;

public class PxVehicleEngineDriveThrottleCommandResponseState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleEngineDriveThrottleCommandResponseState wrapPointer(long address) {
        return address != 0L ? new PxVehicleEngineDriveThrottleCommandResponseState(address) : null;
    }
    
    public static PxVehicleEngineDriveThrottleCommandResponseState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleEngineDriveThrottleCommandResponseState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleEngineDriveThrottleCommandResponseState() {
        address = Raw.PxVehicleEngineDriveThrottleCommandResponseState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    public float getCommandResponse() {
        checkNotNull();
        return Raw.getCommandResponse(address);
    }

    public void setCommandResponse(float value) {
        checkNotNull();
        Raw.setCommandResponse(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleEngineDriveThrottleCommandResponseState();
        public static native void destroy(long address);
        public static native float getCommandResponse(long address);
        public static native void setCommandResponse(long address, float value);
        public static native void setToDefault(long address);
    }
}
