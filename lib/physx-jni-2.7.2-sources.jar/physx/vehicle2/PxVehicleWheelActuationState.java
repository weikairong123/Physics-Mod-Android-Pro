package physx.vehicle2;

import physx.NativeObject;

/**
 * It is useful to know if a brake or drive torque is to be applied to a wheel. 
 */
public class PxVehicleWheelActuationState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleWheelActuationState wrapPointer(long address) {
        return address != 0L ? new PxVehicleWheelActuationState(address) : null;
    }
    
    public static PxVehicleWheelActuationState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleWheelActuationState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleWheelActuationState() {
        address = Raw.PxVehicleWheelActuationState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * True if a brake torque is applied, false if not.
     */
    public boolean getIsBrakeApplied() {
        checkNotNull();
        return Raw.getIsBrakeApplied(address);
    }

    /**
     * True if a brake torque is applied, false if not.
     */
    public void setIsBrakeApplied(boolean value) {
        checkNotNull();
        Raw.setIsBrakeApplied(address, value);
    }

    /**
     * True if a drive torque is applied, false if not.
     */
    public boolean getIsDriveApplied() {
        checkNotNull();
        return Raw.getIsDriveApplied(address);
    }

    /**
     * True if a drive torque is applied, false if not.
     */
    public void setIsDriveApplied(boolean value) {
        checkNotNull();
        Raw.setIsDriveApplied(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleWheelActuationState();
        public static native void destroy(long address);
        public static native boolean getIsBrakeApplied(long address);
        public static native void setIsBrakeApplied(long address, boolean value);
        public static native boolean getIsDriveApplied(long address);
        public static native void setIsDriveApplied(long address, boolean value);
        public static native void setToDefault(long address);
    }
}
