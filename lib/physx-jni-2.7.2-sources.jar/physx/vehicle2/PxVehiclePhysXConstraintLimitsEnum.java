package physx.vehicle2;

/**
 * A description of the number of PxConstraintConnector instances per vehicle required to maintain suspension limit
 * and sticky tire instances.
 */
public enum PxVehiclePhysXConstraintLimitsEnum {

    eNB_DOFS_PER_PXCONSTRAINT(geteNB_DOFS_PER_PXCONSTRAINT()),
    eNB_DOFS_PER_WHEEL(geteNB_DOFS_PER_WHEEL()),
    eNB_WHEELS_PER_PXCONSTRAINT(geteNB_WHEELS_PER_PXCONSTRAINT()),
    eNB_CONSTRAINTS_PER_VEHICLE(geteNB_CONSTRAINTS_PER_VEHICLE());
    public final int value;
    
    PxVehiclePhysXConstraintLimitsEnum(int value) {
        this.value = value;
    }

    private static native int _geteNB_DOFS_PER_PXCONSTRAINT();
    private static int geteNB_DOFS_PER_PXCONSTRAINT() {
        de.fabmax.physxjni.Loader.load();
        return _geteNB_DOFS_PER_PXCONSTRAINT();
    }

    private static native int _geteNB_DOFS_PER_WHEEL();
    private static int geteNB_DOFS_PER_WHEEL() {
        de.fabmax.physxjni.Loader.load();
        return _geteNB_DOFS_PER_WHEEL();
    }

    private static native int _geteNB_WHEELS_PER_PXCONSTRAINT();
    private static int geteNB_WHEELS_PER_PXCONSTRAINT() {
        de.fabmax.physxjni.Loader.load();
        return _geteNB_WHEELS_PER_PXCONSTRAINT();
    }

    private static native int _geteNB_CONSTRAINTS_PER_VEHICLE();
    private static int geteNB_CONSTRAINTS_PER_VEHICLE() {
        de.fabmax.physxjni.Loader.load();
        return _geteNB_CONSTRAINTS_PER_VEHICLE();
    }

    private static final int LUT_SIZE = 256;
    private static final PxVehiclePhysXConstraintLimitsEnum[] enumValues = values();
    private static final PxVehiclePhysXConstraintLimitsEnum[] enumLut = new PxVehiclePhysXConstraintLimitsEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxVehiclePhysXConstraintLimitsEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxVehiclePhysXConstraintLimitsEnum forValue(int value) {
        PxVehiclePhysXConstraintLimitsEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxVehiclePhysXConstraintLimitsEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxVehiclePhysXConstraintLimitsEnum: " + value);
        }
        return enumValue;
    }
}
