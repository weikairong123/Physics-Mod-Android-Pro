package physx.vehicle2;

import physx.NativeObject;

public class PxVehicleAutoboxState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleAutoboxState wrapPointer(long address) {
        return address != 0L ? new PxVehicleAutoboxState(address) : null;
    }
    
    public static PxVehicleAutoboxState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleAutoboxState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleAutoboxState() {
        address = Raw.PxVehicleAutoboxState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Time that has lapsed since the last autobox gear shift.
     * <p>
     * <b>Unit:</b> time
     */
    public float getTimeSinceLastShift() {
        checkNotNull();
        return Raw.getTimeSinceLastShift(address);
    }

    /**
     * Time that has lapsed since the last autobox gear shift.
     * <p>
     * <b>Unit:</b> time
     */
    public void setTimeSinceLastShift(float value) {
        checkNotNull();
        Raw.setTimeSinceLastShift(address, value);
    }

    /**
     * Describes whether a gear shift triggered by the autobox is still in flight.
     */
    public boolean getActiveAutoboxGearShift() {
        checkNotNull();
        return Raw.getActiveAutoboxGearShift(address);
    }

    /**
     * Describes whether a gear shift triggered by the autobox is still in flight.
     */
    public void setActiveAutoboxGearShift(boolean value) {
        checkNotNull();
        Raw.setActiveAutoboxGearShift(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleAutoboxState();
        public static native void destroy(long address);
        public static native float getTimeSinceLastShift(long address);
        public static native void setTimeSinceLastShift(long address, float value);
        public static native boolean getActiveAutoboxGearShift(long address);
        public static native void setActiveAutoboxGearShift(long address, boolean value);
        public static native void setToDefault(long address);
    }
}
