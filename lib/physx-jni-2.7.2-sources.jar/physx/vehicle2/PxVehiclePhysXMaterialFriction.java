package physx.vehicle2;

import physx.NativeObject;
import physx.physics.PxMaterial;

/**
 * A mapping between PxMaterial and a friction value to be used by the tire model.
 * @see PxVehiclePhysXMaterialFrictionParams
 */
public class PxVehiclePhysXMaterialFriction extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehiclePhysXMaterialFriction wrapPointer(long address) {
        return address != 0L ? new PxVehiclePhysXMaterialFriction(address) : null;
    }
    
    public static PxVehiclePhysXMaterialFriction arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehiclePhysXMaterialFriction(long address) {
        super(address);
    }

    // Constructors

    public PxVehiclePhysXMaterialFriction() {
        address = Raw.PxVehiclePhysXMaterialFriction();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * A PxMaterial instance that is to be mapped to a friction value. 
     */
    public PxMaterial getMaterial() {
        checkNotNull();
        return PxMaterial.wrapPointer(Raw.getMaterial(address));
    }

    /**
     * A PxMaterial instance that is to be mapped to a friction value. 
     */
    public void setMaterial(PxMaterial value) {
        checkNotNull();
        Raw.setMaterial(address, value.getAddress());
    }

    /**
     * A friction value that is to be mapped to a PxMaterial instance.
     * <b>Note:</b> friction must have value greater than or equal to zero.
     * <p>
     * <b>Range:</b> [0, inf)<br>
     */
    public float getFriction() {
        checkNotNull();
        return Raw.getFriction(address);
    }

    /**
     * A friction value that is to be mapped to a PxMaterial instance.
     * <b>Note:</b> friction must have value greater than or equal to zero.
     * <p>
     * <b>Range:</b> [0, inf)<br>
     */
    public void setFriction(float value) {
        checkNotNull();
        Raw.setFriction(address, value);
    }

    // Functions

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native long PxVehiclePhysXMaterialFriction();
        public static native void destroy(long address);
        public static native long getMaterial(long address);
        public static native void setMaterial(long address, long value);
        public static native float getFriction(long address);
        public static native void setFriction(long address, float value);
        public static native boolean isValid(long address);
    }
}
