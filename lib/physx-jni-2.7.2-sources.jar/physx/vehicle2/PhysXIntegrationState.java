package physx.vehicle2;

import physx.NativeObject;
import physx.cooking.PxCookingParams;
import physx.physics.PxMaterial;
import physx.physics.PxPhysics;

public class PhysXIntegrationState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PhysXIntegrationState wrapPointer(long address) {
        return address != 0L ? new PhysXIntegrationState(address) : null;
    }
    
    public static PhysXIntegrationState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PhysXIntegrationState(long address) {
        super(address);
    }

    // Constructors

    public PhysXIntegrationState() {
        address = Raw.PhysXIntegrationState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxVehiclePhysXActor} [Value]
     */
    public PxVehiclePhysXActor getPhysxActor() {
        checkNotNull();
        return PxVehiclePhysXActor.wrapPointer(Raw.getPhysxActor(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehiclePhysXActor} [Value]
     */
    public void setPhysxActor(PxVehiclePhysXActor value) {
        checkNotNull();
        Raw.setPhysxActor(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehiclePhysXSteerState} [Value]
     */
    public PxVehiclePhysXSteerState getPhysxSteerState() {
        checkNotNull();
        return PxVehiclePhysXSteerState.wrapPointer(Raw.getPhysxSteerState(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehiclePhysXSteerState} [Value]
     */
    public void setPhysxSteerState(PxVehiclePhysXSteerState value) {
        checkNotNull();
        Raw.setPhysxSteerState(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehiclePhysXConstraints} [Value]
     */
    public PxVehiclePhysXConstraints getPhysxConstraints() {
        checkNotNull();
        return PxVehiclePhysXConstraints.wrapPointer(Raw.getPhysxConstraints(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehiclePhysXConstraints} [Value]
     */
    public void setPhysxConstraints(PxVehiclePhysXConstraints value) {
        checkNotNull();
        Raw.setPhysxConstraints(address, value.getAddress());
    }

    // Functions

    public void destroyState() {
        checkNotNull();
        Raw.destroyState(address);
    }

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    /**
     * @param baseParams      WebIDL type: {@link BaseVehicleParams} [Const, Ref]
     * @param physxParams     WebIDL type: {@link PhysXIntegrationParams} [Const, Ref]
     * @param physics         WebIDL type: {@link PxPhysics} [Ref]
     * @param params          WebIDL type: {@link PxCookingParams} [Const, Ref]
     * @param defaultMaterial WebIDL type: {@link PxMaterial} [Ref]
     */
    public void create(BaseVehicleParams baseParams, PhysXIntegrationParams physxParams, PxPhysics physics, PxCookingParams params, PxMaterial defaultMaterial) {
        checkNotNull();
        Raw.create(address, baseParams.getAddress(), physxParams.getAddress(), physics.getAddress(), params.getAddress(), defaultMaterial.getAddress());
    }

    public static class Raw {
        public static native long PhysXIntegrationState();
        public static native void destroy(long address);
        public static native long getPhysxActor(long address);
        public static native void setPhysxActor(long address, long value);
        public static native long getPhysxSteerState(long address);
        public static native void setPhysxSteerState(long address, long value);
        public static native long getPhysxConstraints(long address);
        public static native void setPhysxConstraints(long address, long value);
        public static native void destroyState(long address);
        public static native void setToDefault(long address);
        public static native void create(long address, long baseParams, long physxParams, long physics, long params, long defaultMaterial);
    }
}
