package physx.vehicle2;

public enum EngineDriveVehicleEnum {

    eDIFFTYPE_FOURWHEELDRIVE(geteDIFFTYPE_FOURWHEELDRIVE()),
    eDIFFTYPE_MULTIWHEELDRIVE(geteDIFFTYPE_MULTIWHEELDRIVE()),
    eDIFFTYPE_TANKDRIVE(geteDIFFTYPE_TANKDRIVE());
    public final int value;
    
    EngineDriveVehicleEnum(int value) {
        this.value = value;
    }

    private static native int _geteDIFFTYPE_FOURWHEELDRIVE();
    private static int geteDIFFTYPE_FOURWHEELDRIVE() {
        de.fabmax.physxjni.Loader.load();
        return _geteDIFFTYPE_FOURWHEELDRIVE();
    }

    private static native int _geteDIFFTYPE_MULTIWHEELDRIVE();
    private static int geteDIFFTYPE_MULTIWHEELDRIVE() {
        de.fabmax.physxjni.Loader.load();
        return _geteDIFFTYPE_MULTIWHEELDRIVE();
    }

    private static native int _geteDIFFTYPE_TANKDRIVE();
    private static int geteDIFFTYPE_TANKDRIVE() {
        de.fabmax.physxjni.Loader.load();
        return _geteDIFFTYPE_TANKDRIVE();
    }

    private static final int LUT_SIZE = 256;
    private static final EngineDriveVehicleEnum[] enumValues = values();
    private static final EngineDriveVehicleEnum[] enumLut = new EngineDriveVehicleEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final EngineDriveVehicleEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static EngineDriveVehicleEnum forValue(int value) {
        EngineDriveVehicleEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final EngineDriveVehicleEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum EngineDriveVehicleEnum: " + value);
        }
        return enumValue;
    }
}
