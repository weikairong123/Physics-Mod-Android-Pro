package physx.vehicle2;

import physx.physics.PxConstraintConnector;

public class PxVehicleConstraintConnector extends PxConstraintConnector {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleConstraintConnector wrapPointer(long address) {
        return address != 0L ? new PxVehicleConstraintConnector(address) : null;
    }
    
    public static PxVehicleConstraintConnector arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleConstraintConnector(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleConstraintConnector() {
        address = Raw.PxVehicleConstraintConnector();
    }

    /**
     * @param vehicleConstraintState WebIDL type: {@link PxVehiclePhysXConstraintState}
     */
    public PxVehicleConstraintConnector(PxVehiclePhysXConstraintState vehicleConstraintState) {
        address = Raw.PxVehicleConstraintConnector(vehicleConstraintState.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param constraintState WebIDL type: {@link PxVehiclePhysXConstraintState}
     */
    public void setConstraintState(PxVehiclePhysXConstraintState constraintState) {
        checkNotNull();
        Raw.setConstraintState(address, constraintState.getAddress());
    }

    public void getConstantBlock() {
        checkNotNull();
        Raw.getConstantBlock(address);
    }

    public static class Raw {
        public static native long PxVehicleConstraintConnector();
        public static native long PxVehicleConstraintConnector(long vehicleConstraintState);
        public static native void destroy(long address);
        public static native void setConstraintState(long address, long constraintState);
        public static native void getConstantBlock(long address);
    }
}
