package physx.vehicle2;

import physx.NativeObject;

/**
 * A description of the state of transmission-related commands that are applied to a vehicle with engine drive.
 */
public class PxVehicleEngineDriveTransmissionCommandState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleEngineDriveTransmissionCommandState wrapPointer(long address) {
        return address != 0L ? new PxVehicleEngineDriveTransmissionCommandState(address) : null;
    }
    
    public static PxVehicleEngineDriveTransmissionCommandState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleEngineDriveTransmissionCommandState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleEngineDriveTransmissionCommandState() {
        address = Raw.PxVehicleEngineDriveTransmissionCommandState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The instantaneous state of the clutch controller in range [0,1] with 1 denoting fully pressed and 0 fully depressed.
     */
    public float getClutch() {
        checkNotNull();
        return Raw.getClutch(address);
    }

    /**
     * The instantaneous state of the clutch controller in range [0,1] with 1 denoting fully pressed and 0 fully depressed.
     */
    public void setClutch(float value) {
        checkNotNull();
        Raw.setClutch(address, value);
    }

    /**
     * The desired gear of the input gear controller.
     */
    public int getTargetGear() {
        checkNotNull();
        return Raw.getTargetGear(address);
    }

    /**
     * The desired gear of the input gear controller.
     */
    public void setTargetGear(int value) {
        checkNotNull();
        Raw.setTargetGear(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleEngineDriveTransmissionCommandState();
        public static native void destroy(long address);
        public static native float getClutch(long address);
        public static native void setClutch(long address, float value);
        public static native int getTargetGear(long address);
        public static native void setTargetGear(long address, int value);
        public static native void setToDefault(long address);
    }
}
