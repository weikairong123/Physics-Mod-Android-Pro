package physx.vehicle2;

/**
 * Tires have two important directions for the purposes of tire force computation: longitudinal and lateral.
 */
public enum PxVehicleTireDirectionModesEnum {

    eLONGITUDINAL(geteLONGITUDINAL()),
    eLATERAL(geteLATERAL());
    public final int value;
    
    PxVehicleTireDirectionModesEnum(int value) {
        this.value = value;
    }

    private static native int _geteLONGITUDINAL();
    private static int geteLONGITUDINAL() {
        de.fabmax.physxjni.Loader.load();
        return _geteLONGITUDINAL();
    }

    private static native int _geteLATERAL();
    private static int geteLATERAL() {
        de.fabmax.physxjni.Loader.load();
        return _geteLATERAL();
    }

    private static final int LUT_SIZE = 256;
    private static final PxVehicleTireDirectionModesEnum[] enumValues = values();
    private static final PxVehicleTireDirectionModesEnum[] enumLut = new PxVehicleTireDirectionModesEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxVehicleTireDirectionModesEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxVehicleTireDirectionModesEnum forValue(int value) {
        PxVehicleTireDirectionModesEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxVehicleTireDirectionModesEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxVehicleTireDirectionModesEnum: " + value);
        }
        return enumValue;
    }
}
