package physx.vehicle2;

import physx.NativeObject;

public class PxVehicleWheelRigidBody1dState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleWheelRigidBody1dState wrapPointer(long address) {
        return address != 0L ? new PxVehicleWheelRigidBody1dState(address) : null;
    }
    
    public static PxVehicleWheelRigidBody1dState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleWheelRigidBody1dState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleWheelRigidBody1dState() {
        address = Raw.PxVehicleWheelRigidBody1dState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The rotation speed of the wheel around the lateral axis.
     * <p>
     * <b>Unit:</b> radians / time
     */
    public float getRotationSpeed() {
        checkNotNull();
        return Raw.getRotationSpeed(address);
    }

    /**
     * The rotation speed of the wheel around the lateral axis.
     * <p>
     * <b>Unit:</b> radians / time
     */
    public void setRotationSpeed(float value) {
        checkNotNull();
        Raw.setRotationSpeed(address, value);
    }

    /**
     * The corrected rotation speed of the wheel around the lateral axis in radians per second.
     * <p>
     * At low forward wheel speed, the wheel rotation speed can get unstable (depending on the tire 
     * model used) and, for example, oscillate. To integrate the wheel rotation angle, a (potentially)
     * blended rotation speed is used which gets stored in #correctedRotationSpeed.
     * <p>
     * <b>Unit:</b> radians / time
     */
    public float getCorrectedRotationSpeed() {
        checkNotNull();
        return Raw.getCorrectedRotationSpeed(address);
    }

    /**
     * The corrected rotation speed of the wheel around the lateral axis in radians per second.
     * <p>
     * At low forward wheel speed, the wheel rotation speed can get unstable (depending on the tire 
     * model used) and, for example, oscillate. To integrate the wheel rotation angle, a (potentially)
     * blended rotation speed is used which gets stored in #correctedRotationSpeed.
     * <p>
     * <b>Unit:</b> radians / time
     */
    public void setCorrectedRotationSpeed(float value) {
        checkNotNull();
        Raw.setCorrectedRotationSpeed(address, value);
    }

    /**
     * The accumulated angle of the wheel around the lateral axis in radians in range (-2*Pi,2*Pi)
     */
    public float getRotationAngle() {
        checkNotNull();
        return Raw.getRotationAngle(address);
    }

    /**
     * The accumulated angle of the wheel around the lateral axis in radians in range (-2*Pi,2*Pi)
     */
    public void setRotationAngle(float value) {
        checkNotNull();
        Raw.setRotationAngle(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleWheelRigidBody1dState();
        public static native void destroy(long address);
        public static native float getRotationSpeed(long address);
        public static native void setRotationSpeed(long address, float value);
        public static native float getCorrectedRotationSpeed(long address);
        public static native void setCorrectedRotationSpeed(long address, float value);
        public static native float getRotationAngle(long address);
        public static native void setRotationAngle(long address, float value);
        public static native void setToDefault(long address);
    }
}
