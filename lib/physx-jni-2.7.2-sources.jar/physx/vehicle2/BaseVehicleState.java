package physx.vehicle2;

import physx.NativeObject;

public class BaseVehicleState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static BaseVehicleState wrapPointer(long address) {
        return address != 0L ? new BaseVehicleState(address) : null;
    }
    
    public static BaseVehicleState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected BaseVehicleState(long address) {
        super(address);
    }

    // Constructors

    public BaseVehicleState() {
        address = Raw.BaseVehicleState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getBrakeCommandResponseStates(int index) {
        checkNotNull();
        return Raw.getBrakeCommandResponseStates(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setBrakeCommandResponseStates(int index, float value) {
        checkNotNull();
        Raw.setBrakeCommandResponseStates(address, index, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getSteerCommandResponseStates(int index) {
        checkNotNull();
        return Raw.getSteerCommandResponseStates(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setSteerCommandResponseStates(int index, float value) {
        checkNotNull();
        Raw.setSteerCommandResponseStates(address, index, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleWheelActuationState} [Value]
     */
    public PxVehicleWheelActuationState getActuationStates(int index) {
        checkNotNull();
        return PxVehicleWheelActuationState.wrapPointer(Raw.getActuationStates(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleWheelActuationState} [Value]
     */
    public void setActuationStates(int index, PxVehicleWheelActuationState value) {
        checkNotNull();
        Raw.setActuationStates(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleRoadGeometryState} [Value]
     */
    public PxVehicleRoadGeometryState getRoadGeomStates(int index) {
        checkNotNull();
        return PxVehicleRoadGeometryState.wrapPointer(Raw.getRoadGeomStates(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleRoadGeometryState} [Value]
     */
    public void setRoadGeomStates(int index, PxVehicleRoadGeometryState value) {
        checkNotNull();
        Raw.setRoadGeomStates(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleSuspensionState} [Value]
     */
    public PxVehicleSuspensionState getSuspensionStates(int index) {
        checkNotNull();
        return PxVehicleSuspensionState.wrapPointer(Raw.getSuspensionStates(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleSuspensionState} [Value]
     */
    public void setSuspensionStates(int index, PxVehicleSuspensionState value) {
        checkNotNull();
        Raw.setSuspensionStates(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleSuspensionComplianceState} [Value]
     */
    public PxVehicleSuspensionComplianceState getSuspensionComplianceStates(int index) {
        checkNotNull();
        return PxVehicleSuspensionComplianceState.wrapPointer(Raw.getSuspensionComplianceStates(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleSuspensionComplianceState} [Value]
     */
    public void setSuspensionComplianceStates(int index, PxVehicleSuspensionComplianceState value) {
        checkNotNull();
        Raw.setSuspensionComplianceStates(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleSuspensionForce} [Value]
     */
    public PxVehicleSuspensionForce getSuspensionForces(int index) {
        checkNotNull();
        return PxVehicleSuspensionForce.wrapPointer(Raw.getSuspensionForces(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleSuspensionForce} [Value]
     */
    public void setSuspensionForces(int index, PxVehicleSuspensionForce value) {
        checkNotNull();
        Raw.setSuspensionForces(address, index, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleAntiRollTorque} [Value]
     */
    public PxVehicleAntiRollTorque getAntiRollTorque() {
        checkNotNull();
        return PxVehicleAntiRollTorque.wrapPointer(Raw.getAntiRollTorque(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleAntiRollTorque} [Value]
     */
    public void setAntiRollTorque(PxVehicleAntiRollTorque value) {
        checkNotNull();
        Raw.setAntiRollTorque(address, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleTireGripState} [Value]
     */
    public PxVehicleTireGripState getTireGripStates(int index) {
        checkNotNull();
        return PxVehicleTireGripState.wrapPointer(Raw.getTireGripStates(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleTireGripState} [Value]
     */
    public void setTireGripStates(int index, PxVehicleTireGripState value) {
        checkNotNull();
        Raw.setTireGripStates(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleTireDirectionState} [Value]
     */
    public PxVehicleTireDirectionState getTireDirectionStates(int index) {
        checkNotNull();
        return PxVehicleTireDirectionState.wrapPointer(Raw.getTireDirectionStates(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleTireDirectionState} [Value]
     */
    public void setTireDirectionStates(int index, PxVehicleTireDirectionState value) {
        checkNotNull();
        Raw.setTireDirectionStates(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleTireSpeedState} [Value]
     */
    public PxVehicleTireSpeedState getTireSpeedStates(int index) {
        checkNotNull();
        return PxVehicleTireSpeedState.wrapPointer(Raw.getTireSpeedStates(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleTireSpeedState} [Value]
     */
    public void setTireSpeedStates(int index, PxVehicleTireSpeedState value) {
        checkNotNull();
        Raw.setTireSpeedStates(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleTireSlipState} [Value]
     */
    public PxVehicleTireSlipState getTireSlipStates(int index) {
        checkNotNull();
        return PxVehicleTireSlipState.wrapPointer(Raw.getTireSlipStates(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleTireSlipState} [Value]
     */
    public void setTireSlipStates(int index, PxVehicleTireSlipState value) {
        checkNotNull();
        Raw.setTireSlipStates(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleTireCamberAngleState} [Value]
     */
    public PxVehicleTireCamberAngleState getTireCamberAngleStates(int index) {
        checkNotNull();
        return PxVehicleTireCamberAngleState.wrapPointer(Raw.getTireCamberAngleStates(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleTireCamberAngleState} [Value]
     */
    public void setTireCamberAngleStates(int index, PxVehicleTireCamberAngleState value) {
        checkNotNull();
        Raw.setTireCamberAngleStates(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleTireStickyState} [Value]
     */
    public PxVehicleTireStickyState getTireStickyStates(int index) {
        checkNotNull();
        return PxVehicleTireStickyState.wrapPointer(Raw.getTireStickyStates(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleTireStickyState} [Value]
     */
    public void setTireStickyStates(int index, PxVehicleTireStickyState value) {
        checkNotNull();
        Raw.setTireStickyStates(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleTireForce} [Value]
     */
    public PxVehicleTireForce getTireForces(int index) {
        checkNotNull();
        return PxVehicleTireForce.wrapPointer(Raw.getTireForces(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleTireForce} [Value]
     */
    public void setTireForces(int index, PxVehicleTireForce value) {
        checkNotNull();
        Raw.setTireForces(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleWheelRigidBody1dState} [Value]
     */
    public PxVehicleWheelRigidBody1dState getWheelRigidBody1dStates(int index) {
        checkNotNull();
        return PxVehicleWheelRigidBody1dState.wrapPointer(Raw.getWheelRigidBody1dStates(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleWheelRigidBody1dState} [Value]
     */
    public void setWheelRigidBody1dStates(int index, PxVehicleWheelRigidBody1dState value) {
        checkNotNull();
        Raw.setWheelRigidBody1dStates(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleWheelLocalPose} [Value]
     */
    public PxVehicleWheelLocalPose getWheelLocalPoses(int index) {
        checkNotNull();
        return PxVehicleWheelLocalPose.wrapPointer(Raw.getWheelLocalPoses(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleWheelLocalPose} [Value]
     */
    public void setWheelLocalPoses(int index, PxVehicleWheelLocalPose value) {
        checkNotNull();
        Raw.setWheelLocalPoses(address, index, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleRigidBodyState} [Value]
     */
    public PxVehicleRigidBodyState getRigidBodyState() {
        checkNotNull();
        return PxVehicleRigidBodyState.wrapPointer(Raw.getRigidBodyState(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleRigidBodyState} [Value]
     */
    public void setRigidBodyState(PxVehicleRigidBodyState value) {
        checkNotNull();
        Raw.setRigidBodyState(address, value.getAddress());
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long BaseVehicleState();
        public static native void destroy(long address);
        public static native float getBrakeCommandResponseStates(long address, int index);
        public static native void setBrakeCommandResponseStates(long address, int index, float value);
        public static native float getSteerCommandResponseStates(long address, int index);
        public static native void setSteerCommandResponseStates(long address, int index, float value);
        public static native long getActuationStates(long address, int index);
        public static native void setActuationStates(long address, int index, long value);
        public static native long getRoadGeomStates(long address, int index);
        public static native void setRoadGeomStates(long address, int index, long value);
        public static native long getSuspensionStates(long address, int index);
        public static native void setSuspensionStates(long address, int index, long value);
        public static native long getSuspensionComplianceStates(long address, int index);
        public static native void setSuspensionComplianceStates(long address, int index, long value);
        public static native long getSuspensionForces(long address, int index);
        public static native void setSuspensionForces(long address, int index, long value);
        public static native long getAntiRollTorque(long address);
        public static native void setAntiRollTorque(long address, long value);
        public static native long getTireGripStates(long address, int index);
        public static native void setTireGripStates(long address, int index, long value);
        public static native long getTireDirectionStates(long address, int index);
        public static native void setTireDirectionStates(long address, int index, long value);
        public static native long getTireSpeedStates(long address, int index);
        public static native void setTireSpeedStates(long address, int index, long value);
        public static native long getTireSlipStates(long address, int index);
        public static native void setTireSlipStates(long address, int index, long value);
        public static native long getTireCamberAngleStates(long address, int index);
        public static native void setTireCamberAngleStates(long address, int index, long value);
        public static native long getTireStickyStates(long address, int index);
        public static native void setTireStickyStates(long address, int index, long value);
        public static native long getTireForces(long address, int index);
        public static native void setTireForces(long address, int index, long value);
        public static native long getWheelRigidBody1dStates(long address, int index);
        public static native void setWheelRigidBody1dStates(long address, int index, long value);
        public static native long getWheelLocalPoses(long address, int index);
        public static native void setWheelLocalPoses(long address, int index, long value);
        public static native long getRigidBodyState(long address);
        public static native void setRigidBodyState(long address, long value);
        public static native void setToDefault(long address);
    }
}
