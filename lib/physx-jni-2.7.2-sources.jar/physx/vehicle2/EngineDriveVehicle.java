package physx.vehicle2;

import physx.cooking.PxCookingParams;
import physx.physics.PxMaterial;
import physx.physics.PxPhysics;

public class EngineDriveVehicle extends PhysXActorVehicle {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static EngineDriveVehicle wrapPointer(long address) {
        return address != 0L ? new EngineDriveVehicle(address) : null;
    }
    
    public static EngineDriveVehicle arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected EngineDriveVehicle(long address) {
        super(address);
    }

    // Constructors

    public EngineDriveVehicle() {
        address = Raw.EngineDriveVehicle();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link EngineDrivetrainParams} [Value]
     */
    public EngineDrivetrainParams getEngineDriveParams() {
        checkNotNull();
        return EngineDrivetrainParams.wrapPointer(Raw.getEngineDriveParams(address));
    }

    /**
     * @param value WebIDL type: {@link EngineDrivetrainParams} [Value]
     */
    public void setEngineDriveParams(EngineDrivetrainParams value) {
        checkNotNull();
        Raw.setEngineDriveParams(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link EngineDrivetrainState} [Value]
     */
    public EngineDrivetrainState getEngineDriveState() {
        checkNotNull();
        return EngineDrivetrainState.wrapPointer(Raw.getEngineDriveState(address));
    }

    /**
     * @param value WebIDL type: {@link EngineDrivetrainState} [Value]
     */
    public void setEngineDriveState(EngineDrivetrainState value) {
        checkNotNull();
        Raw.setEngineDriveState(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleEngineDriveTransmissionCommandState} [Value]
     */
    public PxVehicleEngineDriveTransmissionCommandState getTransmissionCommandState() {
        checkNotNull();
        return PxVehicleEngineDriveTransmissionCommandState.wrapPointer(Raw.getTransmissionCommandState(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleEngineDriveTransmissionCommandState} [Value]
     */
    public void setTransmissionCommandState(PxVehicleEngineDriveTransmissionCommandState value) {
        checkNotNull();
        Raw.setTransmissionCommandState(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleTankDriveTransmissionCommandState} [Value]
     */
    public PxVehicleTankDriveTransmissionCommandState getTankDriveTransmissionCommandState() {
        checkNotNull();
        return PxVehicleTankDriveTransmissionCommandState.wrapPointer(Raw.getTankDriveTransmissionCommandState(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleTankDriveTransmissionCommandState} [Value]
     */
    public void setTankDriveTransmissionCommandState(PxVehicleTankDriveTransmissionCommandState value) {
        checkNotNull();
        Raw.setTankDriveTransmissionCommandState(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link EngineDriveVehicleEnum} [enum]
     */
    public EngineDriveVehicleEnum getDifferentialType() {
        checkNotNull();
        return EngineDriveVehicleEnum.forValue(Raw.getDifferentialType(address));
    }

    /**
     * @param value WebIDL type: {@link EngineDriveVehicleEnum} [enum]
     */
    public void setDifferentialType(EngineDriveVehicleEnum value) {
        checkNotNull();
        Raw.setDifferentialType(address, value.value);
    }

    // Functions

    /**
     * @param physics          WebIDL type: {@link PxPhysics} [Ref]
     * @param params           WebIDL type: {@link PxCookingParams} [Const, Ref]
     * @param defaultMaterial  WebIDL type: {@link PxMaterial} [Ref]
     * @param differentialType WebIDL type: {@link EngineDriveVehicleEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean initialize(PxPhysics physics, PxCookingParams params, PxMaterial defaultMaterial, EngineDriveVehicleEnum differentialType) {
        checkNotNull();
        return Raw.initialize(address, physics.getAddress(), params.getAddress(), defaultMaterial.getAddress(), differentialType.value);
    }

    /**
     * @param physics                    WebIDL type: {@link PxPhysics} [Ref]
     * @param params                     WebIDL type: {@link PxCookingParams} [Const, Ref]
     * @param defaultMaterial            WebIDL type: {@link PxMaterial} [Ref]
     * @param differentialType           WebIDL type: {@link EngineDriveVehicleEnum} [enum]
     * @param addPhysXBeginEndComponents WebIDL type: boolean
     * @return WebIDL type: boolean
     */
    public boolean initialize(PxPhysics physics, PxCookingParams params, PxMaterial defaultMaterial, EngineDriveVehicleEnum differentialType, boolean addPhysXBeginEndComponents) {
        checkNotNull();
        return Raw.initialize(address, physics.getAddress(), params.getAddress(), defaultMaterial.getAddress(), differentialType.value, addPhysXBeginEndComponents);
    }

    /**
     * @param addPhysXBeginEndComponents WebIDL type: boolean
     */
    public void initComponentSequence(boolean addPhysXBeginEndComponents) {
        checkNotNull();
        Raw.initComponentSequence(address, addPhysXBeginEndComponents);
    }

    public static class Raw {
        public static native long EngineDriveVehicle();
        public static native void destroy(long address);
        public static native long getEngineDriveParams(long address);
        public static native void setEngineDriveParams(long address, long value);
        public static native long getEngineDriveState(long address);
        public static native void setEngineDriveState(long address, long value);
        public static native long getTransmissionCommandState(long address);
        public static native void setTransmissionCommandState(long address, long value);
        public static native long getTankDriveTransmissionCommandState(long address);
        public static native void setTankDriveTransmissionCommandState(long address, long value);
        public static native int getDifferentialType(long address);
        public static native void setDifferentialType(long address, int value);
        public static native boolean initialize(long address, long physics, long params, long defaultMaterial, int differentialType);
        public static native boolean initialize(long address, long physics, long params, long defaultMaterial, int differentialType, boolean addPhysXBeginEndComponents);
        public static native void initComponentSequence(long address, boolean addPhysXBeginEndComponents);
    }
}
