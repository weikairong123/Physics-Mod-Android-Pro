package physx.vehicle2;

import physx.NativeObject;

/**
 * A description of the previous steer command applied to the vehicle.
 */
public class PxVehiclePhysXSteerState extends NativeObject {

    protected PxVehiclePhysXSteerState() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehiclePhysXSteerState wrapPointer(long address) {
        return address != 0L ? new PxVehiclePhysXSteerState(address) : null;
    }
    
    public static PxVehiclePhysXSteerState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehiclePhysXSteerState(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The steer command that was most previously applied to the vehicle.
     */
    public float getPreviousSteerCommand() {
        checkNotNull();
        return Raw.getPreviousSteerCommand(address);
    }

    /**
     * The steer command that was most previously applied to the vehicle.
     */
    public void setPreviousSteerCommand(float value) {
        checkNotNull();
        Raw.setPreviousSteerCommand(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native float getPreviousSteerCommand(long address);
        public static native void setPreviousSteerCommand(long address, float value);
        public static native void setToDefault(long address);
    }
}
