package physx.vehicle2;

import physx.NativeObject;
import physx.common.PxPlane;
import physx.common.PxVec3;

public class PxVehicleRoadGeometryState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleRoadGeometryState wrapPointer(long address) {
        return address != 0L ? new PxVehicleRoadGeometryState(address) : null;
    }
    
    public static PxVehicleRoadGeometryState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleRoadGeometryState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleRoadGeometryState() {
        address = Raw.PxVehicleRoadGeometryState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * the plane under the wheel
     */
    public PxPlane getPlane() {
        checkNotNull();
        return PxPlane.wrapPointer(Raw.getPlane(address));
    }

    /**
     * the plane under the wheel
     */
    public void setPlane(PxPlane value) {
        checkNotNull();
        Raw.setPlane(address, value.getAddress());
    }

    /**
     * the friction to be used by the tire model
     */
    public float getFriction() {
        checkNotNull();
        return Raw.getFriction(address);
    }

    /**
     * the friction to be used by the tire model
     */
    public void setFriction(float value) {
        checkNotNull();
        Raw.setFriction(address, value);
    }

    /**
     * the velocity of the road geometry
     */
    public PxVec3 getVelocity() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getVelocity(address));
    }

    /**
     * the velocity of the road geometry
     */
    public void setVelocity(PxVec3 value) {
        checkNotNull();
        Raw.setVelocity(address, value.getAddress());
    }

    /**
     * true if a plane is found, false if there is no plane.
     */
    public boolean getHitState() {
        checkNotNull();
        return Raw.getHitState(address);
    }

    /**
     * true if a plane is found, false if there is no plane.
     */
    public void setHitState(boolean value) {
        checkNotNull();
        Raw.setHitState(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleRoadGeometryState();
        public static native void destroy(long address);
        public static native long getPlane(long address);
        public static native void setPlane(long address, long value);
        public static native float getFriction(long address);
        public static native void setFriction(long address, float value);
        public static native long getVelocity(long address);
        public static native void setVelocity(long address, long value);
        public static native boolean getHitState(long address);
        public static native void setHitState(long address, boolean value);
        public static native void setToDefault(long address);
    }
}
