package physx.vehicle2;

import physx.NativeObject;

/**
 * A description of the per wheel response to an input command.
 */
public class PxVehicleCommandResponseParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleCommandResponseParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleCommandResponseParams(address) : null;
    }
    
    public static PxVehicleCommandResponseParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleCommandResponseParams(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleCommandResponseParams() {
        address = Raw.PxVehicleCommandResponseParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * A nonlinear response to command value expressed as a lookup table of normalized response as a function of command value and longitudinal speed.
     * <b>Note:</b> The effect of the default state of nonlinearResponse is a linear response to command value that is independent of longitudinal speed.
     */
    public PxVehicleCommandNonLinearResponseParams getNonlinearResponse() {
        checkNotNull();
        return PxVehicleCommandNonLinearResponseParams.wrapPointer(Raw.getNonlinearResponse(address));
    }

    /**
     * A nonlinear response to command value expressed as a lookup table of normalized response as a function of command value and longitudinal speed.
     * <b>Note:</b> The effect of the default state of nonlinearResponse is a linear response to command value that is independent of longitudinal speed.
     */
    public void setNonlinearResponse(PxVehicleCommandNonLinearResponseParams value) {
        checkNotNull();
        Raw.setNonlinearResponse(address, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getWheelResponseMultipliers(int index) {
        checkNotNull();
        return Raw.getWheelResponseMultipliers(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setWheelResponseMultipliers(int index, float value) {
        checkNotNull();
        Raw.setWheelResponseMultipliers(address, index, value);
    }

    /**
     * The maximum response that occurs when the wheel response multiplier has value 1.0 and nonlinearResponse is in the default state of linear response.
     */
    public float getMaxResponse() {
        checkNotNull();
        return Raw.getMaxResponse(address);
    }

    /**
     * The maximum response that occurs when the wheel response multiplier has value 1.0 and nonlinearResponse is in the default state of linear response.
     */
    public void setMaxResponse(float value) {
        checkNotNull();
        Raw.setMaxResponse(address, value);
    }

    public static class Raw {
        public static native long PxVehicleCommandResponseParams();
        public static native void destroy(long address);
        public static native long getNonlinearResponse(long address);
        public static native void setNonlinearResponse(long address, long value);
        public static native float getWheelResponseMultipliers(long address, int index);
        public static native void setWheelResponseMultipliers(long address, int index, float value);
        public static native float getMaxResponse(long address);
        public static native void setMaxResponse(long address, float value);
    }
}
