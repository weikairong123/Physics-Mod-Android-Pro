package physx.vehicle2;

public enum PxVehicleSimulationContextTypeEnum {

    /**
     * The simulation context inherits from PxVehicleSimulationContext
     */
    eDEFAULT(geteDEFAULT()),
    ePHYSX(getePHYSX());
    public final int value;
    
    PxVehicleSimulationContextTypeEnum(int value) {
        this.value = value;
    }

    private static native int _geteDEFAULT();
    private static int geteDEFAULT() {
        de.fabmax.physxjni.Loader.load();
        return _geteDEFAULT();
    }

    private static native int _getePHYSX();
    private static int getePHYSX() {
        de.fabmax.physxjni.Loader.load();
        return _getePHYSX();
    }

    private static final int LUT_SIZE = 256;
    private static final PxVehicleSimulationContextTypeEnum[] enumValues = values();
    private static final PxVehicleSimulationContextTypeEnum[] enumLut = new PxVehicleSimulationContextTypeEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxVehicleSimulationContextTypeEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxVehicleSimulationContextTypeEnum forValue(int value) {
        PxVehicleSimulationContextTypeEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxVehicleSimulationContextTypeEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxVehicleSimulationContextTypeEnum: " + value);
        }
        return enumValue;
    }
}
