package physx.vehicle2;

import physx.NativeObject;
import physx.common.PxMat33;

public class PxVehicleFrame extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleFrame wrapPointer(long address) {
        return address != 0L ? new PxVehicleFrame(address) : null;
    }
    
    public static PxVehicleFrame arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleFrame(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleFrame() {
        address = Raw.PxVehicleFrame();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The axis defining the longitudinal (forward) direction of the vehicle.
     */
    public PxVehicleAxesEnum getLngAxis() {
        checkNotNull();
        return PxVehicleAxesEnum.forValue(Raw.getLngAxis(address));
    }

    /**
     * The axis defining the longitudinal (forward) direction of the vehicle.
     */
    public void setLngAxis(PxVehicleAxesEnum value) {
        checkNotNull();
        Raw.setLngAxis(address, value.value);
    }

    /**
     * The axis defining the lateral (side) direction of the vehicle.
     */
    public PxVehicleAxesEnum getLatAxis() {
        checkNotNull();
        return PxVehicleAxesEnum.forValue(Raw.getLatAxis(address));
    }

    /**
     * The axis defining the lateral (side) direction of the vehicle.
     */
    public void setLatAxis(PxVehicleAxesEnum value) {
        checkNotNull();
        Raw.setLatAxis(address, value.value);
    }

    /**
     * The axis defining the vertical (up) direction of the vehicle.
     */
    public PxVehicleAxesEnum getVrtAxis() {
        checkNotNull();
        return PxVehicleAxesEnum.forValue(Raw.getVrtAxis(address));
    }

    /**
     * The axis defining the vertical (up) direction of the vehicle.
     */
    public void setVrtAxis(PxVehicleAxesEnum value) {
        checkNotNull();
        Raw.setVrtAxis(address, value.value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    /**
     * @return WebIDL type: {@link PxMat33} [Value]
     */
    public PxMat33 getFrame() {
        checkNotNull();
        return PxMat33.wrapPointer(Raw.getFrame(address));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native long PxVehicleFrame();
        public static native void destroy(long address);
        public static native int getLngAxis(long address);
        public static native void setLngAxis(long address, int value);
        public static native int getLatAxis(long address);
        public static native void setLatAxis(long address, int value);
        public static native int getVrtAxis(long address);
        public static native void setVrtAxis(long address, int value);
        public static native void setToDefault(long address);
        public static native long getFrame(long address);
        public static native boolean isValid(long address);
    }
}
