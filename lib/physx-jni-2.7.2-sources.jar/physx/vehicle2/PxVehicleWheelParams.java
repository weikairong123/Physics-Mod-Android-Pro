package physx.vehicle2;

import physx.NativeObject;

public class PxVehicleWheelParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleWheelParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleWheelParams(address) : null;
    }
    
    public static PxVehicleWheelParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleWheelParams(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleWheelParams() {
        address = Raw.PxVehicleWheelParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Radius of unit that includes metal wheel plus rubber tire.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> length
     */
    public float getRadius() {
        checkNotNull();
        return Raw.getRadius(address);
    }

    /**
     * Radius of unit that includes metal wheel plus rubber tire.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> length
     */
    public void setRadius(float value) {
        checkNotNull();
        Raw.setRadius(address, value);
    }

    /**
     * Half-width of unit that includes wheel plus tire.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> length
     */
    public float getHalfWidth() {
        checkNotNull();
        return Raw.getHalfWidth(address);
    }

    /**
     * Half-width of unit that includes wheel plus tire.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> length
     */
    public void setHalfWidth(float value) {
        checkNotNull();
        Raw.setHalfWidth(address, value);
    }

    /**
     * Mass of unit that includes wheel plus tire.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> mass
     */
    public float getMass() {
        checkNotNull();
        return Raw.getMass(address);
    }

    /**
     * Mass of unit that includes wheel plus tire.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> mass
     */
    public void setMass(float value) {
        checkNotNull();
        Raw.setMass(address, value);
    }

    /**
     * Moment of inertia of unit that includes wheel plus tire about the rolling axis.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> mass * (length^2)
     */
    public float getMoi() {
        checkNotNull();
        return Raw.getMoi(address);
    }

    /**
     * Moment of inertia of unit that includes wheel plus tire about the rolling axis.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> mass * (length^2)
     */
    public void setMoi(float value) {
        checkNotNull();
        Raw.setMoi(address, value);
    }

    /**
     * Damping rate applied to wheel.
     * <p>
     * <b>Range:</b> [0, inf)<br>
     * <b>Unit:</b> torque * time = mass * (length^2) / time
     */
    public float getDampingRate() {
        checkNotNull();
        return Raw.getDampingRate(address);
    }

    /**
     * Damping rate applied to wheel.
     * <p>
     * <b>Range:</b> [0, inf)<br>
     * <b>Unit:</b> torque * time = mass * (length^2) / time
     */
    public void setDampingRate(float value) {
        checkNotNull();
        Raw.setDampingRate(address, value);
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehicleWheelParams} [Value]
     */
    public PxVehicleWheelParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehicleWheelParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native long PxVehicleWheelParams();
        public static native void destroy(long address);
        public static native float getRadius(long address);
        public static native void setRadius(long address, float value);
        public static native float getHalfWidth(long address);
        public static native void setHalfWidth(long address, float value);
        public static native float getMass(long address);
        public static native void setMass(long address, float value);
        public static native float getMoi(long address);
        public static native void setMoi(long address, float value);
        public static native float getDampingRate(long address);
        public static native void setDampingRate(long address, float value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address);
    }
}
