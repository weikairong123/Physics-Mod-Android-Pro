package physx.vehicle2;

import physx.NativeObject;

public class DirectDrivetrainState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static DirectDrivetrainState wrapPointer(long address) {
        return address != 0L ? new DirectDrivetrainState(address) : null;
    }
    
    public static DirectDrivetrainState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected DirectDrivetrainState(long address) {
        super(address);
    }

    // Constructors

    public DirectDrivetrainState() {
        address = Raw.DirectDrivetrainState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getDirectDriveThrottleResponseStates(int index) {
        checkNotNull();
        return Raw.getDirectDriveThrottleResponseStates(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setDirectDriveThrottleResponseStates(int index, float value) {
        checkNotNull();
        Raw.setDirectDriveThrottleResponseStates(address, index, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long DirectDrivetrainState();
        public static native void destroy(long address);
        public static native float getDirectDriveThrottleResponseStates(long address, int index);
        public static native void setDirectDriveThrottleResponseStates(long address, int index, float value);
        public static native void setToDefault(long address);
    }
}
