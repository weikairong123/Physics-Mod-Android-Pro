package physx.vehicle2;

import physx.NativeObject;

public class PxVehicleEngineParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleEngineParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleEngineParams(address) : null;
    }
    
    public static PxVehicleEngineParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleEngineParams(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxVehicleEngineParams
     */
    public static PxVehicleEngineParams createAt(long address) {
        Raw.PxVehicleEngineParams_placed(address);
        PxVehicleEngineParams createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxVehicleEngineParams
     */
    public static <T> PxVehicleEngineParams createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxVehicleEngineParams_placed(address);
        PxVehicleEngineParams createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxVehicleEngineParams() {
        address = Raw.PxVehicleEngineParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxVehicleTorqueCurveLookupTable} [Value]
     */
    public PxVehicleTorqueCurveLookupTable getTorqueCurve() {
        checkNotNull();
        return PxVehicleTorqueCurveLookupTable.wrapPointer(Raw.getTorqueCurve(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleTorqueCurveLookupTable} [Value]
     */
    public void setTorqueCurve(PxVehicleTorqueCurveLookupTable value) {
        checkNotNull();
        Raw.setTorqueCurve(address, value.getAddress());
    }

    /**
     * @return WebIDL type: float
     */
    public float getMoi() {
        checkNotNull();
        return Raw.getMoi(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setMoi(float value) {
        checkNotNull();
        Raw.setMoi(address, value);
    }

    /**
     * @return WebIDL type: float
     */
    public float getPeakTorque() {
        checkNotNull();
        return Raw.getPeakTorque(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setPeakTorque(float value) {
        checkNotNull();
        Raw.setPeakTorque(address, value);
    }

    /**
     * @return WebIDL type: float
     */
    public float getIdleOmega() {
        checkNotNull();
        return Raw.getIdleOmega(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setIdleOmega(float value) {
        checkNotNull();
        Raw.setIdleOmega(address, value);
    }

    /**
     * @return WebIDL type: float
     */
    public float getMaxOmega() {
        checkNotNull();
        return Raw.getMaxOmega(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setMaxOmega(float value) {
        checkNotNull();
        Raw.setMaxOmega(address, value);
    }

    /**
     * @return WebIDL type: float
     */
    public float getDampingRateFullThrottle() {
        checkNotNull();
        return Raw.getDampingRateFullThrottle(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setDampingRateFullThrottle(float value) {
        checkNotNull();
        Raw.setDampingRateFullThrottle(address, value);
    }

    /**
     * @return WebIDL type: float
     */
    public float getDampingRateZeroThrottleClutchEngaged() {
        checkNotNull();
        return Raw.getDampingRateZeroThrottleClutchEngaged(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setDampingRateZeroThrottleClutchEngaged(float value) {
        checkNotNull();
        Raw.setDampingRateZeroThrottleClutchEngaged(address, value);
    }

    /**
     * @return WebIDL type: float
     */
    public float getDampingRateZeroThrottleClutchDisengaged() {
        checkNotNull();
        return Raw.getDampingRateZeroThrottleClutchDisengaged(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setDampingRateZeroThrottleClutchDisengaged(float value) {
        checkNotNull();
        Raw.setDampingRateZeroThrottleClutchDisengaged(address, value);
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehicleEngineParams} [Value]
     */
    public PxVehicleEngineParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehicleEngineParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native void PxVehicleEngineParams_placed(long address);
        public static native long PxVehicleEngineParams();
        public static native void destroy(long address);
        public static native long getTorqueCurve(long address);
        public static native void setTorqueCurve(long address, long value);
        public static native float getMoi(long address);
        public static native void setMoi(long address, float value);
        public static native float getPeakTorque(long address);
        public static native void setPeakTorque(long address, float value);
        public static native float getIdleOmega(long address);
        public static native void setIdleOmega(long address, float value);
        public static native float getMaxOmega(long address);
        public static native void setMaxOmega(long address, float value);
        public static native float getDampingRateFullThrottle(long address);
        public static native void setDampingRateFullThrottle(long address, float value);
        public static native float getDampingRateZeroThrottleClutchEngaged(long address);
        public static native void setDampingRateZeroThrottleClutchEngaged(long address, float value);
        public static native float getDampingRateZeroThrottleClutchDisengaged(long address);
        public static native void setDampingRateZeroThrottleClutchDisengaged(long address, float value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address);
    }
}
