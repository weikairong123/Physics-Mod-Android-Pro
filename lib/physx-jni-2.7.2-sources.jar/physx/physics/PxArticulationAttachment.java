package physx.physics;

import physx.NativeObject;
import physx.common.PxVec3;

/**
 * Defines a spatial tendon attachment point on a link.
 */
public class PxArticulationAttachment extends NativeObject {

    protected PxArticulationAttachment() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxArticulationAttachment wrapPointer(long address) {
        return address != 0L ? new PxArticulationAttachment(address) : null;
    }
    
    public static PxArticulationAttachment arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxArticulationAttachment(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * user can assign this to whatever, usually to create a 1:1 relationship with a user object.
     */
    public NativeObject getUserData() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.getUserData(address));
    }

    /**
     * user can assign this to whatever, usually to create a 1:1 relationship with a user object.
     */
    public void setUserData(NativeObject value) {
        checkNotNull();
        Raw.setUserData(address, value.getAddress());
    }

    // Functions

    /**
     * Sets the spring rest length for the sub-tendon from the root to this leaf attachment.
     * <p>
     * Setting this on non-leaf attachments has no effect.
     * @param restLength The rest length of the spring.
     * <b>Default:</b> 0
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #isLeaf
     */
    public void setRestLength(float restLength) {
        checkNotNull();
        Raw.setRestLength(address, restLength);
    }

    /**
     * Gets the spring rest length for the sub-tendon from the root to this leaf attachment.
     * @return The rest length.
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #setRestLength
     */
    public float getRestLength() {
        checkNotNull();
        return Raw.getRestLength(address);
    }

    /**
     * Sets the low and high limit on the length of the sub-tendon from the root to this leaf attachment.
     * <p>
     * Setting this on non-leaf attachments has no effect.
     * @param parameters Struct with the low and high limit.
     * <b>Default:</b> (PX_MAX_F32, -PX_MAX_F32) (i.e. an invalid configuration that can only work if stiffness is zero)
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #isLeaf
     */
    public void setLimitParameters(PxArticulationTendonLimit parameters) {
        checkNotNull();
        Raw.setLimitParameters(address, parameters.getAddress());
    }

    /**
     * Gets the low and high limit on the length of the sub-tendon from the root to this leaf attachment.
     * @return Struct with the low and high limit.
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #setLimitParameters
     */
    public PxArticulationTendonLimit getLimitParameters() {
        checkNotNull();
        return PxArticulationTendonLimit.wrapPointer(Raw.getLimitParameters(address));
    }

    /**
     * Sets the attachment's relative offset in the link actor frame.
     * @param offset The relative offset in the link actor frame.
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #getRelativeOffset
     */
    public void setRelativeOffset(PxVec3 offset) {
        checkNotNull();
        Raw.setRelativeOffset(address, offset.getAddress());
    }

    /**
     * Gets the attachment's relative offset in the link actor frame.
     * @return The relative offset in the link actor frame.
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #setRelativeOffset
     */
    public PxVec3 getRelativeOffset() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getRelativeOffset(address));
    }

    /**
     * Sets the attachment coefficient.
     * @param coefficient The scale that the distance between this attachment and its parent is multiplied by when summing up the spatial tendon's length.
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #getCoefficient
     */
    public void setCoefficient(float coefficient) {
        checkNotNull();
        Raw.setCoefficient(address, coefficient);
    }

    /**
     * Gets the attachment coefficient.
     * @return The scale that the distance between this attachment and its parent is multiplied by when summing up the spatial tendon's length.
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #setCoefficient
     */
    public float getCoefficient() {
        checkNotNull();
        return Raw.getCoefficient(address);
    }

    /**
     * Gets the articulation link.
     * @return The articulation link that this attachment is attached to.
     */
    public PxArticulationLink getLink() {
        checkNotNull();
        return PxArticulationLink.wrapPointer(Raw.getLink(address));
    }

    /**
     * Gets the parent attachment.
     * @return The parent attachment.
     */
    public PxArticulationAttachment getParent() {
        checkNotNull();
        return PxArticulationAttachment.wrapPointer(Raw.getParent(address));
    }

    /**
     * Indicates that this attachment is a leaf, and thus defines a sub-tendon from the root to this attachment.
     * @return True: This attachment is a leaf and has zero children; False: Not a leaf.
     */
    public boolean isLeaf() {
        checkNotNull();
        return Raw.isLeaf(address);
    }

    /**
     * Gets the spatial tendon that the attachment is a part of.
     * @return The tendon.
     * @see PxArticulationSpatialTendon
     */
    public PxArticulationSpatialTendon getTendon() {
        checkNotNull();
        return PxArticulationSpatialTendon.wrapPointer(Raw.getTendon(address));
    }

    /**
     * Releases the attachment.
     * <p>
     * <b>Note:</b> Releasing the attachment is not allowed while the articulation is in a scene. In order to
     * release the attachment, remove and then re-add the articulation to the scene.
     */
    public void release() {
        checkNotNull();
        Raw.release(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getUserData(long address);
        public static native void setUserData(long address, long value);
        public static native void setRestLength(long address, float restLength);
        public static native float getRestLength(long address);
        public static native void setLimitParameters(long address, long parameters);
        public static native long getLimitParameters(long address);
        public static native void setRelativeOffset(long address, long offset);
        public static native long getRelativeOffset(long address);
        public static native void setCoefficient(long address, float coefficient);
        public static native float getCoefficient(long address);
        public static native long getLink(long address);
        public static native long getParent(long address);
        public static native boolean isLeaf(long address);
        public static native long getTendon(long address);
        public static native void release(long address);
    }
}
