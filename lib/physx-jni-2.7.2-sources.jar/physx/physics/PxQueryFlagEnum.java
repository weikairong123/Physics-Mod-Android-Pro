package physx.physics;

/**
 * Filtering flags for scene queries.
 * <p>
 * <b>See also:</b> PxQueryFilterData.flags
 */
public enum PxQueryFlagEnum {

    /**
     * Traverse static shapes
     */
    eSTATIC(geteSTATIC()),
    /**
     * Traverse dynamic shapes
     */
    eDYNAMIC(geteDYNAMIC()),
    /**
     * Run the pre-intersection-test filter (see #PxQueryFilterCallback::preFilter())
     */
    ePREFILTER(getePREFILTER()),
    /**
     * Run the post-intersection-test filter (see #PxQueryFilterCallback::postFilter())
     */
    ePOSTFILTER(getePOSTFILTER()),
    /**
     * Abort traversal as soon as any hit is found and return it via callback.block.
     */
    eANY_HIT(geteANY_HIT()),
    /**
     * All hits are reported as touching. Overrides eBLOCK returned from user filters with eTOUCH.
     */
    eNO_BLOCK(geteNO_BLOCK());
    public final int value;
    
    PxQueryFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteSTATIC();
    private static int geteSTATIC() {
        de.fabmax.physxjni.Loader.load();
        return _geteSTATIC();
    }

    private static native int _geteDYNAMIC();
    private static int geteDYNAMIC() {
        de.fabmax.physxjni.Loader.load();
        return _geteDYNAMIC();
    }

    private static native int _getePREFILTER();
    private static int getePREFILTER() {
        de.fabmax.physxjni.Loader.load();
        return _getePREFILTER();
    }

    private static native int _getePOSTFILTER();
    private static int getePOSTFILTER() {
        de.fabmax.physxjni.Loader.load();
        return _getePOSTFILTER();
    }

    private static native int _geteANY_HIT();
    private static int geteANY_HIT() {
        de.fabmax.physxjni.Loader.load();
        return _geteANY_HIT();
    }

    private static native int _geteNO_BLOCK();
    private static int geteNO_BLOCK() {
        de.fabmax.physxjni.Loader.load();
        return _geteNO_BLOCK();
    }

    private static final int LUT_SIZE = 256;
    private static final PxQueryFlagEnum[] enumValues = values();
    private static final PxQueryFlagEnum[] enumLut = new PxQueryFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxQueryFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxQueryFlagEnum forValue(int value) {
        PxQueryFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxQueryFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxQueryFlagEnum: " + value);
        }
        return enumValue;
    }
}
