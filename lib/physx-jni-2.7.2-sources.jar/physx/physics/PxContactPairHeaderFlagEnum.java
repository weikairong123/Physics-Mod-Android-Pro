package physx.physics;

/**
 * Collection of flags providing information on contact report pairs.
 * <p>
 * <b>See also:</b> PxContactPairHeader
 */
public enum PxContactPairHeaderFlagEnum {

    /**
     * The actor with index 0 has been removed from the scene.
     */
    eREMOVED_ACTOR_0(geteREMOVED_ACTOR_0()),
    eREMOVED_ACTOR_1(geteREMOVED_ACTOR_1());
    public final int value;
    
    PxContactPairHeaderFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteREMOVED_ACTOR_0();
    private static int geteREMOVED_ACTOR_0() {
        de.fabmax.physxjni.Loader.load();
        return _geteREMOVED_ACTOR_0();
    }

    private static native int _geteREMOVED_ACTOR_1();
    private static int geteREMOVED_ACTOR_1() {
        de.fabmax.physxjni.Loader.load();
        return _geteREMOVED_ACTOR_1();
    }

    private static final int LUT_SIZE = 256;
    private static final PxContactPairHeaderFlagEnum[] enumValues = values();
    private static final PxContactPairHeaderFlagEnum[] enumLut = new PxContactPairHeaderFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxContactPairHeaderFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxContactPairHeaderFlagEnum forValue(int value) {
        PxContactPairHeaderFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxContactPairHeaderFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxContactPairHeaderFlagEnum: " + value);
        }
        return enumValue;
    }
}
