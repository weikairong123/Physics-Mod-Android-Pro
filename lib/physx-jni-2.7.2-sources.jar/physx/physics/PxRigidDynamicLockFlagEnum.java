package physx.physics;

/**
 * Collection of flags providing a mechanism to lock motion along/around a specific axis.
 * <p>
 * <b>See also:</b> PxRigidDynamic.setRigidDynamicLockFlag(), PxRigidBody.getRigidDynamicLockFlags()
 */
public enum PxRigidDynamicLockFlagEnum {

    eLOCK_LINEAR_X(geteLOCK_LINEAR_X()),
    eLOCK_LINEAR_Y(geteLOCK_LINEAR_Y()),
    eLOCK_LINEAR_Z(geteLOCK_LINEAR_Z()),
    eLOCK_ANGULAR_X(geteLOCK_ANGULAR_X()),
    eLOCK_ANGULAR_Y(geteLOCK_ANGULAR_Y()),
    eLOCK_ANGULAR_Z(geteLOCK_ANGULAR_Z());
    public final int value;
    
    PxRigidDynamicLockFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteLOCK_LINEAR_X();
    private static int geteLOCK_LINEAR_X() {
        de.fabmax.physxjni.Loader.load();
        return _geteLOCK_LINEAR_X();
    }

    private static native int _geteLOCK_LINEAR_Y();
    private static int geteLOCK_LINEAR_Y() {
        de.fabmax.physxjni.Loader.load();
        return _geteLOCK_LINEAR_Y();
    }

    private static native int _geteLOCK_LINEAR_Z();
    private static int geteLOCK_LINEAR_Z() {
        de.fabmax.physxjni.Loader.load();
        return _geteLOCK_LINEAR_Z();
    }

    private static native int _geteLOCK_ANGULAR_X();
    private static int geteLOCK_ANGULAR_X() {
        de.fabmax.physxjni.Loader.load();
        return _geteLOCK_ANGULAR_X();
    }

    private static native int _geteLOCK_ANGULAR_Y();
    private static int geteLOCK_ANGULAR_Y() {
        de.fabmax.physxjni.Loader.load();
        return _geteLOCK_ANGULAR_Y();
    }

    private static native int _geteLOCK_ANGULAR_Z();
    private static int geteLOCK_ANGULAR_Z() {
        de.fabmax.physxjni.Loader.load();
        return _geteLOCK_ANGULAR_Z();
    }

    private static final int LUT_SIZE = 256;
    private static final PxRigidDynamicLockFlagEnum[] enumValues = values();
    private static final PxRigidDynamicLockFlagEnum[] enumLut = new PxRigidDynamicLockFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxRigidDynamicLockFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxRigidDynamicLockFlagEnum forValue(int value) {
        PxRigidDynamicLockFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxRigidDynamicLockFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxRigidDynamicLockFlagEnum: " + value);
        }
        return enumValue;
    }
}
