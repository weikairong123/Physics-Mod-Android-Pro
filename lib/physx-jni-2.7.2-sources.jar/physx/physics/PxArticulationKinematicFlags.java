package physx.physics;

import physx.NativeObject;

public class PxArticulationKinematicFlags extends NativeObject {

    protected PxArticulationKinematicFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxArticulationKinematicFlags wrapPointer(long address) {
        return address != 0L ? new PxArticulationKinematicFlags(address) : null;
    }
    
    public static PxArticulationKinematicFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxArticulationKinematicFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: octet
     * @return Stack allocated object of PxArticulationKinematicFlags
     */
    public static PxArticulationKinematicFlags createAt(long address, byte flags) {
        Raw.PxArticulationKinematicFlags_placed(address, flags);
        PxArticulationKinematicFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: octet
     * @return Stack allocated object of PxArticulationKinematicFlags
     */
    public static <T> PxArticulationKinematicFlags createAt(T allocator, Allocator<T> allocate, byte flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxArticulationKinematicFlags_placed(address, flags);
        PxArticulationKinematicFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param flags WebIDL type: octet
     */
    public PxArticulationKinematicFlags(byte flags) {
        address = Raw.PxArticulationKinematicFlags(flags);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param flag WebIDL type: {@link PxArticulationKinematicFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxArticulationKinematicFlagEnum flag) {
        checkNotNull();
        return Raw.isSet(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxArticulationKinematicFlagEnum} [enum]
     */
    public void raise(PxArticulationKinematicFlagEnum flag) {
        checkNotNull();
        Raw.raise(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxArticulationKinematicFlagEnum} [enum]
     */
    public void clear(PxArticulationKinematicFlagEnum flag) {
        checkNotNull();
        Raw.clear(address, flag.value);
    }

    public static class Raw {
        public static native void PxArticulationKinematicFlags_placed(long address, byte flags);
        public static native long PxArticulationKinematicFlags(byte flags);
        public static native void destroy(long address);
        public static native boolean isSet(long address, int flag);
        public static native void raise(long address, int flag);
        public static native void clear(long address, int flag);
    }
}
