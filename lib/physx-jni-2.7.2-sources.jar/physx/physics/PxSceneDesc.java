package physx.physics;

import physx.NativeObject;
import physx.common.PxBounds3;
import physx.common.PxCpuDispatcher;
import physx.common.PxTolerancesScale;
import physx.common.PxVec3;

/**
 * Descriptor class for scenes. See #PxScene.
 * <p>
 * This struct must be initialized with the same PxTolerancesScale values used to initialize PxPhysics.
 * @see PxScene
 * @see PxPhysics#createScene
 * @see physx.common.PxTolerancesScale
 */
public class PxSceneDesc extends NativeObject {

    protected PxSceneDesc() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxSceneDesc wrapPointer(long address) {
        return address != 0L ? new PxSceneDesc(address) : null;
    }
    
    public static PxSceneDesc arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxSceneDesc(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param scale   WebIDL type: {@link PxTolerancesScale} [Const, Ref]
     * @return Stack allocated object of PxSceneDesc
     */
    public static PxSceneDesc createAt(long address, PxTolerancesScale scale) {
        Raw.PxSceneDesc_placed(address, scale.getAddress());
        PxSceneDesc createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param scale     WebIDL type: {@link PxTolerancesScale} [Const, Ref]
     * @return Stack allocated object of PxSceneDesc
     */
    public static <T> PxSceneDesc createAt(T allocator, Allocator<T> allocate, PxTolerancesScale scale) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxSceneDesc_placed(address, scale.getAddress());
        PxSceneDesc createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * constructor sets to default.
     * @param scale scale values for the tolerances in the scene, these must be the same values passed into
     * PxCreatePhysics(). The affected tolerances are bounceThresholdVelocity and frictionOffsetThreshold.
     * @see physx.common.PxTolerancesScale
     */
    public PxSceneDesc(PxTolerancesScale scale) {
        address = Raw.PxSceneDesc(scale.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Gravity vector.
     * <p>
     * <b>Range:</b> force vector<br>
     * <b>Default:</b> Zero
     * @see PxScene#setGravity
     * @see PxScene#getGravity
     * <p>
     * When setting gravity, you should probably also set bounce threshold.
     */
    public PxVec3 getGravity() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getGravity(address));
    }

    /**
     * Gravity vector.
     * <p>
     * <b>Range:</b> force vector<br>
     * <b>Default:</b> Zero
     * @see PxScene#setGravity
     * @see PxScene#getGravity
     * <p>
     * When setting gravity, you should probably also set bounce threshold.
     */
    public void setGravity(PxVec3 value) {
        checkNotNull();
        Raw.setGravity(address, value.getAddress());
    }

    /**
     * Possible notification callback.
     * <p>
     * <b>Default:</b> NULL
     * @see PxSimulationEventCallback
     * @see PxScene#setSimulationEventCallback
     * @see PxScene#getSimulationEventCallback
     */
    public PxSimulationEventCallback getSimulationEventCallback() {
        checkNotNull();
        return PxSimulationEventCallback.wrapPointer(Raw.getSimulationEventCallback(address));
    }

    /**
     * Possible notification callback.
     * <p>
     * <b>Default:</b> NULL
     * @see PxSimulationEventCallback
     * @see PxScene#setSimulationEventCallback
     * @see PxScene#getSimulationEventCallback
     */
    public void setSimulationEventCallback(PxSimulationEventCallback value) {
        checkNotNull();
        Raw.setSimulationEventCallback(address, value.getAddress());
    }

    /**
     * Shared global filter data which will get passed into the filter shader.
     * <p>
     * <b>Note:</b> The provided data will get copied to internal buffers and this copy will be used for filtering calls.
     * <p>
     * <b>Default:</b> NULL
     * @see PxSimulationFilterShader
     * @see PxScene#setFilterShaderData
     * @see PxScene#getFilterShaderData
     */
    public NativeObject getFilterShaderData() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.getFilterShaderData(address));
    }

    /**
     * Shared global filter data which will get passed into the filter shader.
     * <p>
     * <b>Note:</b> The provided data will get copied to internal buffers and this copy will be used for filtering calls.
     * <p>
     * <b>Default:</b> NULL
     * @see PxSimulationFilterShader
     * @see PxScene#setFilterShaderData
     * @see PxScene#getFilterShaderData
     */
    public void setFilterShaderData(NativeObject value) {
        checkNotNull();
        Raw.setFilterShaderData(address, value.getAddress());
    }

    /**
     * Size (in bytes) of the shared global filter data #filterShaderData.
     * <p>
     * <b>Default:</b> 0
     * @see PxSimulationFilterShader
     * @see PxScene#getFilterShaderDataSize
     */
    public int getFilterShaderDataSize() {
        checkNotNull();
        return Raw.getFilterShaderDataSize(address);
    }

    /**
     * Size (in bytes) of the shared global filter data #filterShaderData.
     * <p>
     * <b>Default:</b> 0
     * @see PxSimulationFilterShader
     * @see PxScene#getFilterShaderDataSize
     */
    public void setFilterShaderDataSize(int value) {
        checkNotNull();
        Raw.setFilterShaderDataSize(address, value);
    }

    /**
     * The custom filter shader to use for collision filtering.
     * <p>
     * <b>Note:</b> This parameter is compulsory. If you don't want to define your own filter shader you can
     * use the default shader #PxDefaultSimulationFilterShader which can be found in the PhysX extensions 
     * library.
     * @see PxSimulationFilterShader
     * @see PxScene#getFilterShader
     */
    public PxSimulationFilterShader getFilterShader() {
        checkNotNull();
        return PxSimulationFilterShader.wrapPointer(Raw.getFilterShader(address));
    }

    /**
     * The custom filter shader to use for collision filtering.
     * <p>
     * <b>Note:</b> This parameter is compulsory. If you don't want to define your own filter shader you can
     * use the default shader #PxDefaultSimulationFilterShader which can be found in the PhysX extensions 
     * library.
     * @see PxSimulationFilterShader
     * @see PxScene#getFilterShader
     */
    public void setFilterShader(PxSimulationFilterShader value) {
        checkNotNull();
        Raw.setFilterShader(address, value.getAddress());
    }

    /**
     * Filtering mode for kinematic-kinematic pairs in the broadphase.
     * <p>
     * <b>Default:</b> PxPairFilteringMode::eDEFAULT
     * @see PxScene#getKinematicKinematicFilteringMode
     */
    public PxPairFilteringModeEnum getKineKineFilteringMode() {
        checkNotNull();
        return PxPairFilteringModeEnum.forValue(Raw.getKineKineFilteringMode(address));
    }

    /**
     * Filtering mode for kinematic-kinematic pairs in the broadphase.
     * <p>
     * <b>Default:</b> PxPairFilteringMode::eDEFAULT
     * @see PxScene#getKinematicKinematicFilteringMode
     */
    public void setKineKineFilteringMode(PxPairFilteringModeEnum value) {
        checkNotNull();
        Raw.setKineKineFilteringMode(address, value.value);
    }

    /**
     * Filtering mode for static-kinematic pairs in the broadphase.
     * <p>
     * <b>Default:</b> PxPairFilteringMode::eDEFAULT
     * @see PxScene#getStaticKinematicFilteringMode
     */
    public PxPairFilteringModeEnum getStaticKineFilteringMode() {
        checkNotNull();
        return PxPairFilteringModeEnum.forValue(Raw.getStaticKineFilteringMode(address));
    }

    /**
     * Filtering mode for static-kinematic pairs in the broadphase.
     * <p>
     * <b>Default:</b> PxPairFilteringMode::eDEFAULT
     * @see PxScene#getStaticKinematicFilteringMode
     */
    public void setStaticKineFilteringMode(PxPairFilteringModeEnum value) {
        checkNotNull();
        Raw.setStaticKineFilteringMode(address, value.value);
    }

    /**
     * Selects the broad-phase algorithm to use.
     * <p>
     * <b>Default:</b> PxBroadPhaseType::ePABP
     * @see PxScene#getBroadPhaseType
     */
    public PxBroadPhaseTypeEnum getBroadPhaseType() {
        checkNotNull();
        return PxBroadPhaseTypeEnum.forValue(Raw.getBroadPhaseType(address));
    }

    /**
     * Selects the broad-phase algorithm to use.
     * <p>
     * <b>Default:</b> PxBroadPhaseType::ePABP
     * @see PxScene#getBroadPhaseType
     */
    public void setBroadPhaseType(PxBroadPhaseTypeEnum value) {
        checkNotNull();
        Raw.setBroadPhaseType(address, value.value);
    }

    /**
     * Expected scene limits.
     * @see PxSceneLimits
     * @see PxScene#getLimits
     */
    public PxSceneLimits getLimits() {
        checkNotNull();
        return PxSceneLimits.wrapPointer(Raw.getLimits(address));
    }

    /**
     * Expected scene limits.
     * @see PxSceneLimits
     * @see PxScene#getLimits
     */
    public void setLimits(PxSceneLimits value) {
        checkNotNull();
        Raw.setLimits(address, value.getAddress());
    }

    /**
     * Selects the friction algorithm to use for simulation.
     * @deprecated  Since only the patch friction model is supported now, the frictionType parameter is obsolete.
     * <p>
     * <b>Default:</b> PxFrictionType::ePATCH
     * @see PxScene#getFrictionType
     */
    @Deprecated
    public PxFrictionTypeEnum getFrictionType() {
        checkNotNull();
        return PxFrictionTypeEnum.forValue(Raw.getFrictionType(address));
    }

    /**
     * Selects the friction algorithm to use for simulation.
     * @deprecated  Since only the patch friction model is supported now, the frictionType parameter is obsolete.
     * <p>
     * <b>Default:</b> PxFrictionType::ePATCH
     * @see PxScene#getFrictionType
     */
    @Deprecated
    public void setFrictionType(PxFrictionTypeEnum value) {
        checkNotNull();
        Raw.setFrictionType(address, value.value);
    }

    /**
     * Selects the solver algorithm to use.
     * <p>
     * <b>Default:</b> PxSolverType::ePGS
     * @see PxScene#getSolverType
     */
    public PxSolverTypeEnum getSolverType() {
        checkNotNull();
        return PxSolverTypeEnum.forValue(Raw.getSolverType(address));
    }

    /**
     * Selects the solver algorithm to use.
     * <p>
     * <b>Default:</b> PxSolverType::ePGS
     * @see PxScene#getSolverType
     */
    public void setSolverType(PxSolverTypeEnum value) {
        checkNotNull();
        Raw.setSolverType(address, value.value);
    }

    /**
     * A contact with a relative velocity below this will not bounce. A typical value for simulation.
     * stability is about 0.2 * gravity.
     * <p>
     * <b>Range:</b> (0, PX_MAX_F32)<br>
     * <b>Default:</b> 0.2 * PxTolerancesScale::speed
     * @see PxMaterial
     * @see PxScene#setBounceThresholdVelocity
     * @see PxScene#getBounceThresholdVelocity
     */
    public float getBounceThresholdVelocity() {
        checkNotNull();
        return Raw.getBounceThresholdVelocity(address);
    }

    /**
     * A contact with a relative velocity below this will not bounce. A typical value for simulation.
     * stability is about 0.2 * gravity.
     * <p>
     * <b>Range:</b> (0, PX_MAX_F32)<br>
     * <b>Default:</b> 0.2 * PxTolerancesScale::speed
     * @see PxMaterial
     * @see PxScene#setBounceThresholdVelocity
     * @see PxScene#getBounceThresholdVelocity
     */
    public void setBounceThresholdVelocity(float value) {
        checkNotNull();
        Raw.setBounceThresholdVelocity(address, value);
    }

    /**
     * A threshold of contact separation distance used to decide if a contact point will experience friction forces.
     * <p>
     * <b>Note:</b> If the separation distance of a contact point is greater than the threshold then the contact point will not experience friction forces. 
     * <p>
     * <b>Note:</b> If the aggregated contact offset of a pair of shapes is large it might be desirable to neglect friction
     * for contact points whose separation distance is sufficiently large that the shape surfaces are clearly separated. 
     * <p>
     * <b>Note:</b> This parameter can be used to tune the separation distance of contact points at which friction starts to have an effect.  
     * <p>
     * <b>Range:</b> [0, PX_MAX_F32)<br>
     * <b>Default:</b> 0.04 * PxTolerancesScale::length
     * @see PxScene#setFrictionOffsetThreshold
     * @see PxScene#getFrictionOffsetThreshold
     */
    public float getFrictionOffsetThreshold() {
        checkNotNull();
        return Raw.getFrictionOffsetThreshold(address);
    }

    /**
     * A threshold of contact separation distance used to decide if a contact point will experience friction forces.
     * <p>
     * <b>Note:</b> If the separation distance of a contact point is greater than the threshold then the contact point will not experience friction forces. 
     * <p>
     * <b>Note:</b> If the aggregated contact offset of a pair of shapes is large it might be desirable to neglect friction
     * for contact points whose separation distance is sufficiently large that the shape surfaces are clearly separated. 
     * <p>
     * <b>Note:</b> This parameter can be used to tune the separation distance of contact points at which friction starts to have an effect.  
     * <p>
     * <b>Range:</b> [0, PX_MAX_F32)<br>
     * <b>Default:</b> 0.04 * PxTolerancesScale::length
     * @see PxScene#setFrictionOffsetThreshold
     * @see PxScene#getFrictionOffsetThreshold
     */
    public void setFrictionOffsetThreshold(float value) {
        checkNotNull();
        Raw.setFrictionOffsetThreshold(address, value);
    }

    /**
     * Friction correlation distance used to decide whether contacts are close enough to be merged into a single friction anchor point or not.
     * <p>
     * <b>Note:</b> If the correlation distance is larger than the distance between contact points generated between a pair of shapes, some of the contacts may not experience frictional forces.
     * <p>
     * <b>Note:</b> This parameter can be used to tune the correlation distance used in the solver. Contact points can be merged into a single friction anchor if the distance between the contacts is smaller than correlation distance.
     * <p>
     * <b>Range:</b> [0, PX_MAX_F32)<br>
     * <b>Default:</b> 0.025f * PxTolerancesScale::length
     * @see PxScene#setFrictionCorrelationDistance
     * @see PxScene#getFrictionCorrelationDistance
     */
    public float getFrictionCorrelationDistance() {
        checkNotNull();
        return Raw.getFrictionCorrelationDistance(address);
    }

    /**
     * Friction correlation distance used to decide whether contacts are close enough to be merged into a single friction anchor point or not.
     * <p>
     * <b>Note:</b> If the correlation distance is larger than the distance between contact points generated between a pair of shapes, some of the contacts may not experience frictional forces.
     * <p>
     * <b>Note:</b> This parameter can be used to tune the correlation distance used in the solver. Contact points can be merged into a single friction anchor if the distance between the contacts is smaller than correlation distance.
     * <p>
     * <b>Range:</b> [0, PX_MAX_F32)<br>
     * <b>Default:</b> 0.025f * PxTolerancesScale::length
     * @see PxScene#setFrictionCorrelationDistance
     * @see PxScene#getFrictionCorrelationDistance
     */
    public void setFrictionCorrelationDistance(float value) {
        checkNotNull();
        Raw.setFrictionCorrelationDistance(address, value);
    }

    /**
     * Flags used to select scene options.
     * <p>
     * <b>Default:</b> PxSceneFlag::eENABLE_PCM
     * @see PxSceneFlags
     * @see PxScene#getFlags
     * @see PxScene#setFlag
     */
    public PxSceneFlags getFlags() {
        checkNotNull();
        return PxSceneFlags.wrapPointer(Raw.getFlags(address));
    }

    /**
     * Flags used to select scene options.
     * <p>
     * <b>Default:</b> PxSceneFlag::eENABLE_PCM
     * @see PxSceneFlags
     * @see PxScene#getFlags
     * @see PxScene#setFlag
     */
    public void setFlags(PxSceneFlags value) {
        checkNotNull();
        Raw.setFlags(address, value.getAddress());
    }

    /**
     * The CPU task dispatcher for the scene.
     */
    public PxCpuDispatcher getCpuDispatcher() {
        checkNotNull();
        return PxCpuDispatcher.wrapPointer(Raw.getCpuDispatcher(address));
    }

    /**
     * The CPU task dispatcher for the scene.
     */
    public void setCpuDispatcher(PxCpuDispatcher value) {
        checkNotNull();
        Raw.setCpuDispatcher(address, value.getAddress());
    }

    /**
     * Will be copied to PxScene::userData.
     * <p>
     * <b>Default:</b> NULL
     */
    public NativeObject getUserData() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.getUserData(address));
    }

    /**
     * Will be copied to PxScene::userData.
     * <p>
     * <b>Default:</b> NULL
     */
    public void setUserData(NativeObject value) {
        checkNotNull();
        Raw.setUserData(address, value.getAddress());
    }

    /**
     * Defines the number of actors required to spawn a separate rigid body solver island task chain.
     * <p>
     * This parameter defines the minimum number of actors required to spawn a separate rigid body solver task chain. Setting a low value 
     * will potentially cause more task chains to be generated. This may result in the overhead of spawning tasks can become a limiting performance factor. 
     * Setting a high value will potentially cause fewer islands to be generated. This may reduce thread scaling (fewer task chains spawned) and may 
     * detrimentally affect performance if some bodies in the scene have large solver iteration counts because all constraints in a given island are solved by the 
     * maximum number of solver iterations requested by any body in the island.
     * <p>
     * Note that a rigid body solver task chain is spawned as soon as either a sufficient number of rigid bodies or articulations are batched together.
     * <p>
     * <b>Default:</b> 128
     * @see PxScene#setSolverBatchSize
     * @see PxScene#getSolverBatchSize
     */
    public int getSolverBatchSize() {
        checkNotNull();
        return Raw.getSolverBatchSize(address);
    }

    /**
     * Defines the number of actors required to spawn a separate rigid body solver island task chain.
     * <p>
     * This parameter defines the minimum number of actors required to spawn a separate rigid body solver task chain. Setting a low value 
     * will potentially cause more task chains to be generated. This may result in the overhead of spawning tasks can become a limiting performance factor. 
     * Setting a high value will potentially cause fewer islands to be generated. This may reduce thread scaling (fewer task chains spawned) and may 
     * detrimentally affect performance if some bodies in the scene have large solver iteration counts because all constraints in a given island are solved by the 
     * maximum number of solver iterations requested by any body in the island.
     * <p>
     * Note that a rigid body solver task chain is spawned as soon as either a sufficient number of rigid bodies or articulations are batched together.
     * <p>
     * <b>Default:</b> 128
     * @see PxScene#setSolverBatchSize
     * @see PxScene#getSolverBatchSize
     */
    public void setSolverBatchSize(int value) {
        checkNotNull();
        Raw.setSolverBatchSize(address, value);
    }

    /**
     * Defines the number of articulations required to spawn a separate rigid body solver island task chain.
     * <p>
     * This parameter defines the minimum number of articulations required to spawn a separate rigid body solver task chain. Setting a low value
     * will potentially cause more task chains to be generated. This may result in the overhead of spawning tasks can become a limiting performance factor.
     * Setting a high value will potentially cause fewer islands to be generated. This may reduce thread scaling (fewer task chains spawned) and may
     * detrimentally affect performance if some bodies in the scene have large solver iteration counts because all constraints in a given island are solved by the
     * maximum number of solver iterations requested by any body in the island.
     * <p>
     * Note that a rigid body solver task chain is spawned as soon as either a sufficient number of rigid bodies or articulations are batched together. 
     * <p>
     * <b>Default:</b> 16
     * @see PxScene#setSolverArticulationBatchSize
     * @see PxScene#getSolverArticulationBatchSize
     */
    public int getSolverArticulationBatchSize() {
        checkNotNull();
        return Raw.getSolverArticulationBatchSize(address);
    }

    /**
     * Defines the number of articulations required to spawn a separate rigid body solver island task chain.
     * <p>
     * This parameter defines the minimum number of articulations required to spawn a separate rigid body solver task chain. Setting a low value
     * will potentially cause more task chains to be generated. This may result in the overhead of spawning tasks can become a limiting performance factor.
     * Setting a high value will potentially cause fewer islands to be generated. This may reduce thread scaling (fewer task chains spawned) and may
     * detrimentally affect performance if some bodies in the scene have large solver iteration counts because all constraints in a given island are solved by the
     * maximum number of solver iterations requested by any body in the island.
     * <p>
     * Note that a rigid body solver task chain is spawned as soon as either a sufficient number of rigid bodies or articulations are batched together. 
     * <p>
     * <b>Default:</b> 16
     * @see PxScene#setSolverArticulationBatchSize
     * @see PxScene#getSolverArticulationBatchSize
     */
    public void setSolverArticulationBatchSize(int value) {
        checkNotNull();
        Raw.setSolverArticulationBatchSize(address, value);
    }

    /**
     * Setting to define the number of 16K blocks that will be initially reserved to store contact, friction, and contact cache data.
     * This is the number of 16K memory blocks that will be automatically allocated from the user allocator when the scene is instantiated. Further 16k
     * memory blocks may be allocated during the simulation up to maxNbContactDataBlocks.
     * <p>
     * <b>Note:</b> This value cannot be larger than maxNbContactDataBlocks because that defines the maximum number of 16k blocks that can be allocated by the SDK.
     * <p>
     * <b>Default:</b> 0
     * <p>
     * <b>Range:</b> [0, PX_MAX_U32]<br>
     */
    public int getNbContactDataBlocks() {
        checkNotNull();
        return Raw.getNbContactDataBlocks(address);
    }

    /**
     * Setting to define the number of 16K blocks that will be initially reserved to store contact, friction, and contact cache data.
     * This is the number of 16K memory blocks that will be automatically allocated from the user allocator when the scene is instantiated. Further 16k
     * memory blocks may be allocated during the simulation up to maxNbContactDataBlocks.
     * <p>
     * <b>Note:</b> This value cannot be larger than maxNbContactDataBlocks because that defines the maximum number of 16k blocks that can be allocated by the SDK.
     * <p>
     * <b>Default:</b> 0
     * <p>
     * <b>Range:</b> [0, PX_MAX_U32]<br>
     */
    public void setNbContactDataBlocks(int value) {
        checkNotNull();
        Raw.setNbContactDataBlocks(address, value);
    }

    /**
     * Setting to define the maximum number of 16K blocks that can be allocated to store contact, friction, and contact cache data.
     * As the complexity of a scene increases, the SDK may require to allocate new 16k blocks in addition to the blocks it has already 
     * allocated. This variable controls the maximum number of blocks that the SDK can allocate.
     * <p>
     * In the case that the scene is sufficiently complex that all the permitted 16K blocks are used, contacts will be dropped and 
     * a warning passed to the error stream.
     * <p>
     * If a warning is reported to the error stream to indicate the number of 16K blocks is insufficient for the scene complexity 
     * then the choices are either (i) re-tune the number of 16K data blocks until a number is found that is sufficient for the scene complexity,
     * (ii) to simplify the scene or (iii) to opt to not increase the memory requirements of physx and accept some dropped contacts.
     * <p>
     * <b>Default:</b> 65536
     * <p>
     * <b>Range:</b> [0, PX_MAX_U32]<br>
     * @see PxScene#setNbContactDataBlocks
     */
    public int getMaxNbContactDataBlocks() {
        checkNotNull();
        return Raw.getMaxNbContactDataBlocks(address);
    }

    /**
     * Setting to define the maximum number of 16K blocks that can be allocated to store contact, friction, and contact cache data.
     * As the complexity of a scene increases, the SDK may require to allocate new 16k blocks in addition to the blocks it has already 
     * allocated. This variable controls the maximum number of blocks that the SDK can allocate.
     * <p>
     * In the case that the scene is sufficiently complex that all the permitted 16K blocks are used, contacts will be dropped and 
     * a warning passed to the error stream.
     * <p>
     * If a warning is reported to the error stream to indicate the number of 16K blocks is insufficient for the scene complexity 
     * then the choices are either (i) re-tune the number of 16K data blocks until a number is found that is sufficient for the scene complexity,
     * (ii) to simplify the scene or (iii) to opt to not increase the memory requirements of physx and accept some dropped contacts.
     * <p>
     * <b>Default:</b> 65536
     * <p>
     * <b>Range:</b> [0, PX_MAX_U32]<br>
     * @see PxScene#setNbContactDataBlocks
     */
    public void setMaxNbContactDataBlocks(int value) {
        checkNotNull();
        Raw.setMaxNbContactDataBlocks(address, value);
    }

    /**
     * The maximum bias coefficient used in the constraint solver
     * <p>
     * When geometric errors are found in the constraint solver, either as a result of shapes penetrating
     * or joints becoming separated or violating limits, a bias is introduced in the solver position iterations
     * to correct these errors. This bias is proportional to 1/dt, meaning that the bias becomes increasingly 
     * strong as the time-step passed to PxScene::simulate(...) becomes smaller. This coefficient allows the
     * application to restrict how large the bias coefficient is, to reduce how violent error corrections are.
     * This can improve simulation quality in cases where either variable time-steps or extremely small time-steps
     * are used.
     * <p>
     * <b>Default:</b> PX_MAX_F32
     * <p>
     * <b> Range</b> [0, PX_MAX_F32] <br>
     * @see PxScene#setMaxBiasCoefficient
     * @see PxScene#getMaxBiasCoefficient
     */
    public float getMaxBiasCoefficient() {
        checkNotNull();
        return Raw.getMaxBiasCoefficient(address);
    }

    /**
     * The maximum bias coefficient used in the constraint solver
     * <p>
     * When geometric errors are found in the constraint solver, either as a result of shapes penetrating
     * or joints becoming separated or violating limits, a bias is introduced in the solver position iterations
     * to correct these errors. This bias is proportional to 1/dt, meaning that the bias becomes increasingly 
     * strong as the time-step passed to PxScene::simulate(...) becomes smaller. This coefficient allows the
     * application to restrict how large the bias coefficient is, to reduce how violent error corrections are.
     * This can improve simulation quality in cases where either variable time-steps or extremely small time-steps
     * are used.
     * <p>
     * <b>Default:</b> PX_MAX_F32
     * <p>
     * <b> Range</b> [0, PX_MAX_F32] <br>
     * @see PxScene#setMaxBiasCoefficient
     * @see PxScene#getMaxBiasCoefficient
     */
    public void setMaxBiasCoefficient(float value) {
        checkNotNull();
        Raw.setMaxBiasCoefficient(address, value);
    }

    /**
     * Size of the contact report stream (in bytes).
     * <p>
     * The contact report stream buffer is used during the simulation to store all the contact reports. 
     * If the size is not sufficient, the buffer will grow by a factor of two.
     * It is possible to disable the buffer growth by setting the flag PxSceneFlag::eDISABLE_CONTACT_REPORT_BUFFER_RESIZE.
     * In that case the buffer will not grow but contact reports not stored in the buffer will not get sent in the contact report callbacks.
     * <p>
     * <b>Default:</b> 8192
     * <p>
     * <b>Range:</b> (0, PX_MAX_U32]<br>
     * @see PxScene#getContactReportStreamBufferSize
     */
    public int getContactReportStreamBufferSize() {
        checkNotNull();
        return Raw.getContactReportStreamBufferSize(address);
    }

    /**
     * Size of the contact report stream (in bytes).
     * <p>
     * The contact report stream buffer is used during the simulation to store all the contact reports. 
     * If the size is not sufficient, the buffer will grow by a factor of two.
     * It is possible to disable the buffer growth by setting the flag PxSceneFlag::eDISABLE_CONTACT_REPORT_BUFFER_RESIZE.
     * In that case the buffer will not grow but contact reports not stored in the buffer will not get sent in the contact report callbacks.
     * <p>
     * <b>Default:</b> 8192
     * <p>
     * <b>Range:</b> (0, PX_MAX_U32]<br>
     * @see PxScene#getContactReportStreamBufferSize
     */
    public void setContactReportStreamBufferSize(int value) {
        checkNotNull();
        Raw.setContactReportStreamBufferSize(address, value);
    }

    /**
     * Maximum number of CCD passes 
     * <p>
     * The CCD performs multiple passes, where each pass every object advances to its time of first impact. This value defines how many passes the CCD system should perform.
     * <p>
     * <b>Note:</b> The CCD system is a multi-pass best-effort conservative advancement approach. After the defined number of passes has been completed, any remaining time is dropped.
     * <b>Note:</b> This defines the maximum number of passes the CCD can perform. It may perform fewer if additional passes are not necessary.
     * <p>
     * <b>Default:</b> 1
     * <b>Range:</b> [1, PX_MAX_U32]<br>
     * @see PxScene#setCCDMaxPasses
     * @see PxScene#getCCDMaxPasses
     */
    public int getCcdMaxPasses() {
        checkNotNull();
        return Raw.getCcdMaxPasses(address);
    }

    /**
     * Maximum number of CCD passes 
     * <p>
     * The CCD performs multiple passes, where each pass every object advances to its time of first impact. This value defines how many passes the CCD system should perform.
     * <p>
     * <b>Note:</b> The CCD system is a multi-pass best-effort conservative advancement approach. After the defined number of passes has been completed, any remaining time is dropped.
     * <b>Note:</b> This defines the maximum number of passes the CCD can perform. It may perform fewer if additional passes are not necessary.
     * <p>
     * <b>Default:</b> 1
     * <b>Range:</b> [1, PX_MAX_U32]<br>
     * @see PxScene#setCCDMaxPasses
     * @see PxScene#getCCDMaxPasses
     */
    public void setCcdMaxPasses(int value) {
        checkNotNull();
        Raw.setCcdMaxPasses(address, value);
    }

    /**
     * CCD threshold
     * <p>
     * CCD performs sweeps against shapes if and only if the relative motion of the shapes is fast-enough that a collision would be missed
     * by the discrete contact generation. However, in some circumstances, e.g. when the environment is constructed from large convex shapes, this 
     * approach may produce undesired simulation artefacts. This parameter defines the minimum relative motion that would be required to force CCD between shapes.
     * The smaller of this value and the sum of the thresholds calculated for the shapes involved will be used.
     * <p>
     * <b>Note:</b> It is not advisable to set this to a very small value as this may lead to CCD "jamming" and detrimentally effect performance. This value should be at least larger than the translation caused by a single frame's gravitational effect
     * <p>
     * <b>Default:</b> PX_MAX_F32
     * <b>Range:</b> [Eps, PX_MAX_F32]<br>
     * @see PxScene#setCCDThreshold
     * @see PxScene#getCCDThreshold
     */
    public float getCcdThreshold() {
        checkNotNull();
        return Raw.getCcdThreshold(address);
    }

    /**
     * CCD threshold
     * <p>
     * CCD performs sweeps against shapes if and only if the relative motion of the shapes is fast-enough that a collision would be missed
     * by the discrete contact generation. However, in some circumstances, e.g. when the environment is constructed from large convex shapes, this 
     * approach may produce undesired simulation artefacts. This parameter defines the minimum relative motion that would be required to force CCD between shapes.
     * The smaller of this value and the sum of the thresholds calculated for the shapes involved will be used.
     * <p>
     * <b>Note:</b> It is not advisable to set this to a very small value as this may lead to CCD "jamming" and detrimentally effect performance. This value should be at least larger than the translation caused by a single frame's gravitational effect
     * <p>
     * <b>Default:</b> PX_MAX_F32
     * <b>Range:</b> [Eps, PX_MAX_F32]<br>
     * @see PxScene#setCCDThreshold
     * @see PxScene#getCCDThreshold
     */
    public void setCcdThreshold(float value) {
        checkNotNull();
        Raw.setCcdThreshold(address, value);
    }

    /**
     * A threshold for speculative CCD. Used to control whether bias, restitution or a combination of the two are used to resolve the contacts.
     * <p>
     * <b>Note:</b> This only has any effect on contacting pairs where one of the bodies has PxRigidBodyFlag::eENABLE_SPECULATIVE_CCD raised.
     * <p>
     * <b>Range:</b> [0, PX_MAX_F32)<br>
     * <b>Default:</b> 0.04 * PxTolerancesScale::length
     * @see PxScene#setCCDMaxSeparation
     * @see PxScene#getCCDMaxSeparation
     */
    public float getCcdMaxSeparation() {
        checkNotNull();
        return Raw.getCcdMaxSeparation(address);
    }

    /**
     * A threshold for speculative CCD. Used to control whether bias, restitution or a combination of the two are used to resolve the contacts.
     * <p>
     * <b>Note:</b> This only has any effect on contacting pairs where one of the bodies has PxRigidBodyFlag::eENABLE_SPECULATIVE_CCD raised.
     * <p>
     * <b>Range:</b> [0, PX_MAX_F32)<br>
     * <b>Default:</b> 0.04 * PxTolerancesScale::length
     * @see PxScene#setCCDMaxSeparation
     * @see PxScene#getCCDMaxSeparation
     */
    public void setCcdMaxSeparation(float value) {
        checkNotNull();
        Raw.setCcdMaxSeparation(address, value);
    }

    /**
     * The wake counter reset value
     * <p>
     * Calling wakeUp() on objects which support sleeping will set their wake counter value to the specified reset value.
     * <p>
     * <b>Range:</b> (0, PX_MAX_F32)<br>
     * <b>Default:</b> 0.4 (which corresponds to 20 frames for a time step of 0.02)
     * @see PxScene#getWakeCounterResetValue
     */
    public float getWakeCounterResetValue() {
        checkNotNull();
        return Raw.getWakeCounterResetValue(address);
    }

    /**
     * The wake counter reset value
     * <p>
     * Calling wakeUp() on objects which support sleeping will set their wake counter value to the specified reset value.
     * <p>
     * <b>Range:</b> (0, PX_MAX_F32)<br>
     * <b>Default:</b> 0.4 (which corresponds to 20 frames for a time step of 0.02)
     * @see PxScene#getWakeCounterResetValue
     */
    public void setWakeCounterResetValue(float value) {
        checkNotNull();
        Raw.setWakeCounterResetValue(address, value);
    }

    /**
     * The bounds used to sanity check user-set positions of actors and articulation links
     * <p>
     * These bounds are used to check the position values of rigid actors inserted into the scene, and positions set for rigid actors
     * already within the scene.
     * <p>
     * <b>Range:</b> any valid PxBounds3 <br> 
     * <b>Default:</b> (-PX_MAX_BOUNDS_EXTENTS, PX_MAX_BOUNDS_EXTENTS) on each axis
     */
    public PxBounds3 getSanityBounds() {
        checkNotNull();
        return PxBounds3.wrapPointer(Raw.getSanityBounds(address));
    }

    /**
     * The bounds used to sanity check user-set positions of actors and articulation links
     * <p>
     * These bounds are used to check the position values of rigid actors inserted into the scene, and positions set for rigid actors
     * already within the scene.
     * <p>
     * <b>Range:</b> any valid PxBounds3 <br> 
     * <b>Default:</b> (-PX_MAX_BOUNDS_EXTENTS, PX_MAX_BOUNDS_EXTENTS) on each axis
     */
    public void setSanityBounds(PxBounds3 value) {
        checkNotNull();
        Raw.setSanityBounds(address, value.getAddress());
    }

    /**
     * Limitation for the partitions in the GPU dynamics pipeline.
     * This variable must be power of 2.
     * A value greater than 32 is currently not supported.
     * <b>Range:</b> (1, 32)<br>
     */
    public int getGpuMaxNumPartitions() {
        checkNotNull();
        return Raw.getGpuMaxNumPartitions(address);
    }

    /**
     * Limitation for the partitions in the GPU dynamics pipeline.
     * This variable must be power of 2.
     * A value greater than 32 is currently not supported.
     * <b>Range:</b> (1, 32)<br>
     */
    public void setGpuMaxNumPartitions(int value) {
        checkNotNull();
        Raw.setGpuMaxNumPartitions(address, value);
    }

    /**
     * Limitation for the number of static rigid body partitions in the GPU dynamics pipeline.
     * <b>Range:</b> (1, 255)<br>
     * <b>Default:</b> 16
     */
    public int getGpuMaxNumStaticPartitions() {
        checkNotNull();
        return Raw.getGpuMaxNumStaticPartitions(address);
    }

    /**
     * Limitation for the number of static rigid body partitions in the GPU dynamics pipeline.
     * <b>Range:</b> (1, 255)<br>
     * <b>Default:</b> 16
     */
    public void setGpuMaxNumStaticPartitions(int value) {
        checkNotNull();
        Raw.setGpuMaxNumStaticPartitions(address, value);
    }

    /**
     * Defines which compute version the GPU dynamics should target. DO NOT MODIFY
     */
    public int getGpuComputeVersion() {
        checkNotNull();
        return Raw.getGpuComputeVersion(address);
    }

    /**
     * Defines which compute version the GPU dynamics should target. DO NOT MODIFY
     */
    public void setGpuComputeVersion(int value) {
        checkNotNull();
        Raw.setGpuComputeVersion(address, value);
    }

    /**
     * Defines the size of a contact pool slab.
     * Contact pairs and associated data are allocated using a pool allocator. Increasing the slab size can trade
     * off some performance spikes when a large number of new contacts are found for an increase in overall memory 
     * usage.
     * <p>
     * <b>Range:</b>(1, PX_MAX_U32)<br>
     * <b>Default:</b> 256
     */
    public int getContactPairSlabSize() {
        checkNotNull();
        return Raw.getContactPairSlabSize(address);
    }

    /**
     * Defines the size of a contact pool slab.
     * Contact pairs and associated data are allocated using a pool allocator. Increasing the slab size can trade
     * off some performance spikes when a large number of new contacts are found for an increase in overall memory 
     * usage.
     * <p>
     * <b>Range:</b>(1, PX_MAX_U32)<br>
     * <b>Default:</b> 256
     */
    public void setContactPairSlabSize(int value) {
        checkNotNull();
        Raw.setContactPairSlabSize(address, value);
    }

    /**
     * @return WebIDL type: {@link PxPruningStructureTypeEnum} [enum]
     */
    public PxPruningStructureTypeEnum getStaticStructure() {
        checkNotNull();
        return PxPruningStructureTypeEnum.forValue(Raw.getStaticStructure(address));
    }

    /**
     * @param value WebIDL type: {@link PxPruningStructureTypeEnum} [enum]
     */
    public void setStaticStructure(PxPruningStructureTypeEnum value) {
        checkNotNull();
        Raw.setStaticStructure(address, value.value);
    }

    /**
     * @return WebIDL type: {@link PxPruningStructureTypeEnum} [enum]
     */
    public PxPruningStructureTypeEnum getDynamicStructure() {
        checkNotNull();
        return PxPruningStructureTypeEnum.forValue(Raw.getDynamicStructure(address));
    }

    /**
     * @param value WebIDL type: {@link PxPruningStructureTypeEnum} [enum]
     */
    public void setDynamicStructure(PxPruningStructureTypeEnum value) {
        checkNotNull();
        Raw.setDynamicStructure(address, value.value);
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getDynamicTreeRebuildRateHint() {
        checkNotNull();
        return Raw.getDynamicTreeRebuildRateHint(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setDynamicTreeRebuildRateHint(int value) {
        checkNotNull();
        Raw.setDynamicTreeRebuildRateHint(address, value);
    }

    /**
     * @return WebIDL type: {@link PxDynamicTreeSecondaryPrunerEnum} [enum]
     */
    public PxDynamicTreeSecondaryPrunerEnum getDynamicTreeSecondaryPruner() {
        checkNotNull();
        return PxDynamicTreeSecondaryPrunerEnum.forValue(Raw.getDynamicTreeSecondaryPruner(address));
    }

    /**
     * @param value WebIDL type: {@link PxDynamicTreeSecondaryPrunerEnum} [enum]
     */
    public void setDynamicTreeSecondaryPruner(PxDynamicTreeSecondaryPrunerEnum value) {
        checkNotNull();
        Raw.setDynamicTreeSecondaryPruner(address, value.value);
    }

    /**
     * @return WebIDL type: {@link PxBVHBuildStrategyEnum} [enum]
     */
    public PxBVHBuildStrategyEnum getStaticBVHBuildStrategy() {
        checkNotNull();
        return PxBVHBuildStrategyEnum.forValue(Raw.getStaticBVHBuildStrategy(address));
    }

    /**
     * @param value WebIDL type: {@link PxBVHBuildStrategyEnum} [enum]
     */
    public void setStaticBVHBuildStrategy(PxBVHBuildStrategyEnum value) {
        checkNotNull();
        Raw.setStaticBVHBuildStrategy(address, value.value);
    }

    /**
     * @return WebIDL type: {@link PxBVHBuildStrategyEnum} [enum]
     */
    public PxBVHBuildStrategyEnum getDynamicBVHBuildStrategy() {
        checkNotNull();
        return PxBVHBuildStrategyEnum.forValue(Raw.getDynamicBVHBuildStrategy(address));
    }

    /**
     * @param value WebIDL type: {@link PxBVHBuildStrategyEnum} [enum]
     */
    public void setDynamicBVHBuildStrategy(PxBVHBuildStrategyEnum value) {
        checkNotNull();
        Raw.setDynamicBVHBuildStrategy(address, value.value);
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getStaticNbObjectsPerNode() {
        checkNotNull();
        return Raw.getStaticNbObjectsPerNode(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setStaticNbObjectsPerNode(int value) {
        checkNotNull();
        Raw.setStaticNbObjectsPerNode(address, value);
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getDynamicNbObjectsPerNode() {
        checkNotNull();
        return Raw.getDynamicNbObjectsPerNode(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setDynamicNbObjectsPerNode(int value) {
        checkNotNull();
        Raw.setDynamicNbObjectsPerNode(address, value);
    }

    /**
     * @return WebIDL type: {@link PxSceneQueryUpdateModeEnum} [enum]
     */
    public PxSceneQueryUpdateModeEnum getSceneQueryUpdateMode() {
        checkNotNull();
        return PxSceneQueryUpdateModeEnum.forValue(Raw.getSceneQueryUpdateMode(address));
    }

    /**
     * @param value WebIDL type: {@link PxSceneQueryUpdateModeEnum} [enum]
     */
    public void setSceneQueryUpdateMode(PxSceneQueryUpdateModeEnum value) {
        checkNotNull();
        Raw.setSceneQueryUpdateMode(address, value.value);
    }

    // Functions

    /**
     * (re)sets the structure to the default.
     * @param scale scale values for the tolerances in the scene, these must be the same values passed into
     * PxCreatePhysics(). The affected tolerances are bounceThresholdVelocity and frictionOffsetThreshold.
     * @see physx.common.PxTolerancesScale
     */
    public void setToDefault(PxTolerancesScale scale) {
        checkNotNull();
        Raw.setToDefault(address, scale.getAddress());
    }

    /**
     * Returns true if the descriptor is valid.
     * @return true if the current settings are valid.
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native void PxSceneDesc_placed(long address, long scale);
        public static native long PxSceneDesc(long scale);
        public static native void destroy(long address);
        public static native long getGravity(long address);
        public static native void setGravity(long address, long value);
        public static native long getSimulationEventCallback(long address);
        public static native void setSimulationEventCallback(long address, long value);
        public static native long getFilterShaderData(long address);
        public static native void setFilterShaderData(long address, long value);
        public static native int getFilterShaderDataSize(long address);
        public static native void setFilterShaderDataSize(long address, int value);
        public static native long getFilterShader(long address);
        public static native void setFilterShader(long address, long value);
        public static native int getKineKineFilteringMode(long address);
        public static native void setKineKineFilteringMode(long address, int value);
        public static native int getStaticKineFilteringMode(long address);
        public static native void setStaticKineFilteringMode(long address, int value);
        public static native int getBroadPhaseType(long address);
        public static native void setBroadPhaseType(long address, int value);
        public static native long getLimits(long address);
        public static native void setLimits(long address, long value);
        public static native int getFrictionType(long address);
        public static native void setFrictionType(long address, int value);
        public static native int getSolverType(long address);
        public static native void setSolverType(long address, int value);
        public static native float getBounceThresholdVelocity(long address);
        public static native void setBounceThresholdVelocity(long address, float value);
        public static native float getFrictionOffsetThreshold(long address);
        public static native void setFrictionOffsetThreshold(long address, float value);
        public static native float getFrictionCorrelationDistance(long address);
        public static native void setFrictionCorrelationDistance(long address, float value);
        public static native long getFlags(long address);
        public static native void setFlags(long address, long value);
        public static native long getCpuDispatcher(long address);
        public static native void setCpuDispatcher(long address, long value);
        public static native long getUserData(long address);
        public static native void setUserData(long address, long value);
        public static native int getSolverBatchSize(long address);
        public static native void setSolverBatchSize(long address, int value);
        public static native int getSolverArticulationBatchSize(long address);
        public static native void setSolverArticulationBatchSize(long address, int value);
        public static native int getNbContactDataBlocks(long address);
        public static native void setNbContactDataBlocks(long address, int value);
        public static native int getMaxNbContactDataBlocks(long address);
        public static native void setMaxNbContactDataBlocks(long address, int value);
        public static native float getMaxBiasCoefficient(long address);
        public static native void setMaxBiasCoefficient(long address, float value);
        public static native int getContactReportStreamBufferSize(long address);
        public static native void setContactReportStreamBufferSize(long address, int value);
        public static native int getCcdMaxPasses(long address);
        public static native void setCcdMaxPasses(long address, int value);
        public static native float getCcdThreshold(long address);
        public static native void setCcdThreshold(long address, float value);
        public static native float getCcdMaxSeparation(long address);
        public static native void setCcdMaxSeparation(long address, float value);
        public static native float getWakeCounterResetValue(long address);
        public static native void setWakeCounterResetValue(long address, float value);
        public static native long getSanityBounds(long address);
        public static native void setSanityBounds(long address, long value);
        public static native int getGpuMaxNumPartitions(long address);
        public static native void setGpuMaxNumPartitions(long address, int value);
        public static native int getGpuMaxNumStaticPartitions(long address);
        public static native void setGpuMaxNumStaticPartitions(long address, int value);
        public static native int getGpuComputeVersion(long address);
        public static native void setGpuComputeVersion(long address, int value);
        public static native int getContactPairSlabSize(long address);
        public static native void setContactPairSlabSize(long address, int value);
        public static native int getStaticStructure(long address);
        public static native void setStaticStructure(long address, int value);
        public static native int getDynamicStructure(long address);
        public static native void setDynamicStructure(long address, int value);
        public static native int getDynamicTreeRebuildRateHint(long address);
        public static native void setDynamicTreeRebuildRateHint(long address, int value);
        public static native int getDynamicTreeSecondaryPruner(long address);
        public static native void setDynamicTreeSecondaryPruner(long address, int value);
        public static native int getStaticBVHBuildStrategy(long address);
        public static native void setStaticBVHBuildStrategy(long address, int value);
        public static native int getDynamicBVHBuildStrategy(long address);
        public static native void setDynamicBVHBuildStrategy(long address, int value);
        public static native int getStaticNbObjectsPerNode(long address);
        public static native void setStaticNbObjectsPerNode(long address, int value);
        public static native int getDynamicNbObjectsPerNode(long address);
        public static native void setDynamicNbObjectsPerNode(long address, int value);
        public static native int getSceneQueryUpdateMode(long address);
        public static native void setSceneQueryUpdateMode(long address, int value);
        public static native void setToDefault(long address, long scale);
        public static native boolean isValid(long address);
    }
}
