package physx.physics;


public class PxRaycastHit extends PxGeomRaycastHit {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxRaycastHit wrapPointer(long address) {
        return address != 0L ? new PxRaycastHit(address) : null;
    }
    
    public static PxRaycastHit arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxRaycastHit(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxRaycastHit
     */
    public static PxRaycastHit createAt(long address) {
        Raw.PxRaycastHit_placed(address);
        PxRaycastHit createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxRaycastHit
     */
    public static <T> PxRaycastHit createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxRaycastHit_placed(address);
        PxRaycastHit createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxRaycastHit() {
        address = Raw.PxRaycastHit();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxRigidActor}
     */
    public PxRigidActor getActor() {
        checkNotNull();
        return PxRigidActor.wrapPointer(Raw.getActor(address));
    }

    /**
     * @param value WebIDL type: {@link PxRigidActor}
     */
    public void setActor(PxRigidActor value) {
        checkNotNull();
        Raw.setActor(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxShape}
     */
    public PxShape getShape() {
        checkNotNull();
        return PxShape.wrapPointer(Raw.getShape(address));
    }

    /**
     * @param value WebIDL type: {@link PxShape}
     */
    public void setShape(PxShape value) {
        checkNotNull();
        Raw.setShape(address, value.getAddress());
    }

    public static class Raw {
        public static native void PxRaycastHit_placed(long address);
        public static native long PxRaycastHit();
        public static native void destroy(long address);
        public static native long getActor(long address);
        public static native void setActor(long address, long value);
        public static native long getShape(long address);
        public static native void setShape(long address, long value);
    }
}
