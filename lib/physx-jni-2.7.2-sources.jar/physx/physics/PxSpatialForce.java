package physx.physics;

import physx.NativeObject;
import physx.common.PxVec3;

/**
 * Data structure to represent spatial forces.
 */
public class PxSpatialForce extends NativeObject {

    protected PxSpatialForce() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxSpatialForce wrapPointer(long address) {
        return address != 0L ? new PxSpatialForce(address) : null;
    }
    
    public static PxSpatialForce arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxSpatialForce(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    public PxVec3 getForce() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getForce(address));
    }

    public void setForce(PxVec3 value) {
        checkNotNull();
        Raw.setForce(address, value.getAddress());
    }

    public PxVec3 getTorque() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getTorque(address));
    }

    public void setTorque(PxVec3 value) {
        checkNotNull();
        Raw.setTorque(address, value.getAddress());
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getForce(long address);
        public static native void setForce(long address, long value);
        public static native long getTorque(long address);
        public static native void setTorque(long address, long value);
    }
}
