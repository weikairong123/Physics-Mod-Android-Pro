package physx.physics;

public enum PxQueryHitType {

    eNONE(geteNONE()),
    eBLOCK(geteBLOCK()),
    eTOUCH(geteTOUCH());
    public final int value;
    
    PxQueryHitType(int value) {
        this.value = value;
    }

    private static native int _geteNONE();
    private static int geteNONE() {
        de.fabmax.physxjni.Loader.load();
        return _geteNONE();
    }

    private static native int _geteBLOCK();
    private static int geteBLOCK() {
        de.fabmax.physxjni.Loader.load();
        return _geteBLOCK();
    }

    private static native int _geteTOUCH();
    private static int geteTOUCH() {
        de.fabmax.physxjni.Loader.load();
        return _geteTOUCH();
    }

    private static final int LUT_SIZE = 256;
    private static final PxQueryHitType[] enumValues = values();
    private static final PxQueryHitType[] enumLut = new PxQueryHitType[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxQueryHitType it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxQueryHitType forValue(int value) {
        PxQueryHitType enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxQueryHitType it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxQueryHitType: " + value);
        }
        return enumValue;
    }
}
