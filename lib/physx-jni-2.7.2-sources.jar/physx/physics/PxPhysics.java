package physx.physics;

import physx.NativeObject;
import physx.common.PxFoundation;
import physx.common.PxInputData;
import physx.common.PxInsertionCallback;
import physx.common.PxTolerancesScale;
import physx.common.PxTransform;
import physx.geometry.PxConvexMesh;
import physx.geometry.PxGeometry;
import physx.geometry.PxTriangleMesh;

/**
 * Abstract singleton factory class used for instancing objects in the Physics SDK.
 * <p>
 * In addition you can use PxPhysics to set global parameters which will effect all scenes and create
 * objects that can be shared across multiple scenes.
 * <p>
 * You can get an instance of this class by calling PxCreatePhysics().
 * @see PxScene
 */
public class PxPhysics extends NativeObject {

    protected PxPhysics() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxPhysics wrapPointer(long address) {
        return address != 0L ? new PxPhysics(address) : null;
    }
    
    public static PxPhysics arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxPhysics(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * Destroys the instance it is called on.
     * <p>
     * Use this release method to destroy an instance of this class. Be sure
     * to not keep a reference to this object after calling release.
     * Avoid release calls while a scene is simulating (in between simulate() and fetchResults() calls).
     * <p>
     * Note that this must be called once for each prior call to PxCreatePhysics, as
     * there is a reference counter. Also note that you mustn't destroy the PxFoundation instance (holding the allocator, error callback etc.)
     * until after the reference count reaches 0 and the SDK is actually removed.
     * <p>
     * Releasing an SDK will also release any objects created through it (scenes, triangle meshes, convex meshes, heightfields, shapes etc.),
     * provided the user hasn't already done so.
     * <p>
     * <b>Note:</b> Releasing the PxPhysics instance is a prerequisite to releasing the PxFoundation instance.
     * @see physx.common.PxFoundation
     */
    public void release() {
        checkNotNull();
        Raw.release(address);
    }

    /**
     * Retrieves the Foundation instance.
     * @return A reference to the Foundation object.
     */
    public PxFoundation getFoundation() {
        checkNotNull();
        return PxFoundation.wrapPointer(Raw.getFoundation(address));
    }

    /**
     * Creates an aggregate with the specified maximum size and filtering hint.
     * <p>
     * The previous API used "bool enableSelfCollision" which should now silently evaluates
     * to a PxAggregateType::eGENERIC aggregate with its self-collision bit.
     * <p>
     * Use PxAggregateType::eSTATIC or PxAggregateType::eKINEMATIC for aggregates that will
     * only contain static or kinematic actors. This provides faster filtering when used in
     * combination with PxPairFilteringMode.
     * @return The new aggregate.
     * @see PxAggregate
     */
    public PxAggregate createAggregate(int maxActor, int maxShape, boolean enableSelfCollision) {
        checkNotNull();
        return PxAggregate.wrapPointer(Raw.createAggregate(address, maxActor, maxShape, enableSelfCollision));
    }

    /**
     * Returns the simulation tolerance parameters.
     * @return The current simulation tolerance parameters.
     */
    public PxTolerancesScale getTolerancesScale() {
        checkNotNull();
        return PxTolerancesScale.wrapPointer(Raw.getTolerancesScale(address));
    }

    /**
     * Creates a scene.
     * <p>
     * <b>Note:</b> Every scene uses a Thread Local Storage slot. This imposes a platform specific limit on the
     * number of scenes that can be created.
     * @return The new scene object.
     * @see PxScene
     * @see PxScene#release
     * @see PxSceneDesc
     */
    public PxScene createScene(PxSceneDesc sceneDesc) {
        checkNotNull();
        return PxScene.wrapPointer(Raw.createScene(address, sceneDesc.getAddress()));
    }

    /**
     * Creates a static rigid actor with the specified pose and all other fields initialized
     * to their default values.
     * @see PxRigidStatic
     */
    public PxRigidStatic createRigidStatic(PxTransform pose) {
        checkNotNull();
        return PxRigidStatic.wrapPointer(Raw.createRigidStatic(address, pose.getAddress()));
    }

    /**
     * Creates a dynamic rigid actor with the specified pose and all other fields initialized
     * to their default values.
     * @see PxRigidDynamic
     */
    public PxRigidDynamic createRigidDynamic(PxTransform pose) {
        checkNotNull();
        return PxRigidDynamic.wrapPointer(Raw.createRigidDynamic(address, pose.getAddress()));
    }

    /**
     * Creates a shape which may be attached to multiple actors
     * <p>
     * The shape will be created with a reference count of 1.
     * @return The shape
     * <p>
     * <b>Note:</b> Shared shapes are not mutable when they are attached to an actor
     * @see PxShape
     */
    public PxShape createShape(PxGeometry geometry, PxMaterial material) {
        checkNotNull();
        return PxShape.wrapPointer(Raw.createShape(address, geometry.getAddress(), material.getAddress()));
    }

    /**
     * Creates a shape which may be attached to multiple actors
     * <p>
     * The shape will be created with a reference count of 1.
     * @return The shape
     * <p>
     * <b>Note:</b> Shared shapes are not mutable when they are attached to an actor
     * @see PxShape
     */
    public PxShape createShape(PxGeometry geometry, PxMaterial material, boolean isExclusive) {
        checkNotNull();
        return PxShape.wrapPointer(Raw.createShape(address, geometry.getAddress(), material.getAddress(), isExclusive));
    }

    /**
     * Creates a shape which may be attached to multiple actors
     * <p>
     * The shape will be created with a reference count of 1.
     * @return The shape
     * <p>
     * <b>Note:</b> Shared shapes are not mutable when they are attached to an actor
     * @see PxShape
     */
    public PxShape createShape(PxGeometry geometry, PxMaterial material, boolean isExclusive, PxShapeFlags shapeFlags) {
        checkNotNull();
        return PxShape.wrapPointer(Raw.createShape(address, geometry.getAddress(), material.getAddress(), isExclusive, shapeFlags.getAddress()));
    }

    /**
     * Creates a triangle mesh object.
     * <p>
     * This can then be instanced into #PxShape objects.
     * @return The new triangle mesh.
     * @see physx.geometry.PxTriangleMesh
     */
    public PxTriangleMesh createTriangleMesh(PxInputData stream) {
        checkNotNull();
        return PxTriangleMesh.wrapPointer(Raw.createTriangleMesh(address, stream.getAddress()));
    }

    /**
     * Creates a convex mesh object.
     * <p>
     * This can then be instanced into #PxShape objects.
     * @return The new convex mesh.
     * @see physx.geometry.PxConvexMesh
     * @see #createTriangleMesh
     * @see physx.geometry.PxConvexMeshGeometry
     * @see PxShape
     */
    public PxConvexMesh createConvexMesh(PxInputData stream) {
        checkNotNull();
        return PxConvexMesh.wrapPointer(Raw.createConvexMesh(address, stream.getAddress()));
    }

    /**
     * Return the number of shapes that currently exist.
     * @return Number of shapes.
     */
    public int getNbShapes() {
        checkNotNull();
        return Raw.getNbShapes(address);
    }

    /**
     * Creates a reduced-coordinate articulation with all fields initialized to their default values.
     * @return the new articulation
     * @see PxArticulationReducedCoordinate
     */
    public PxArticulationReducedCoordinate createArticulationReducedCoordinate() {
        checkNotNull();
        return PxArticulationReducedCoordinate.wrapPointer(Raw.createArticulationReducedCoordinate(address));
    }

    /**
     * Creates a new rigid body material with certain default properties.
     * @return The new rigid body material.
     * @see PxMaterial
     */
    public PxMaterial createMaterial(float staticFriction, float dynamicFriction, float restitution) {
        checkNotNull();
        return PxMaterial.wrapPointer(Raw.createMaterial(address, staticFriction, dynamicFriction, restitution));
    }

    /**
     * Gets PxPhysics object insertion interface.
     * <p>
     * The insertion interface is needed for PxCreateTriangleMesh, PxCooking::createTriangleMesh etc., this allows runtime mesh creation.
     * <p>
     *      PxCooking::createTriangleMesh PxCooking::createHeightfield PxCooking::createTetrahedronMesh PxCooking::createBVH
     */
    public PxInsertionCallback getPhysicsInsertionCallback() {
        checkNotNull();
        return PxInsertionCallback.wrapPointer(Raw.getPhysicsInsertionCallback(address));
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native void release(long address);
        public static native long getFoundation(long address);
        public static native long createAggregate(long address, int maxActor, int maxShape, boolean enableSelfCollision);
        public static native long getTolerancesScale(long address);
        public static native long createScene(long address, long sceneDesc);
        public static native long createRigidStatic(long address, long pose);
        public static native long createRigidDynamic(long address, long pose);
        public static native long createShape(long address, long geometry, long material);
        public static native long createShape(long address, long geometry, long material, boolean isExclusive);
        public static native long createShape(long address, long geometry, long material, boolean isExclusive, long shapeFlags);
        public static native long createTriangleMesh(long address, long stream);
        public static native long createConvexMesh(long address, long stream);
        public static native int getNbShapes(long address);
        public static native long createArticulationReducedCoordinate(long address);
        public static native long createMaterial(long address, float staticFriction, float dynamicFriction, float restitution);
        public static native long getPhysicsInsertionCallback(long address);
    }
}
