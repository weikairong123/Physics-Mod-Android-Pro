package physx.physics;

public enum PxFilterObjectFlagEnum {

    eKINEMATIC(geteKINEMATIC()),
    eTRIGGER(geteTRIGGER());
    public final int value;
    
    PxFilterObjectFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteKINEMATIC();
    private static int geteKINEMATIC() {
        de.fabmax.physxjni.Loader.load();
        return _geteKINEMATIC();
    }

    private static native int _geteTRIGGER();
    private static int geteTRIGGER() {
        de.fabmax.physxjni.Loader.load();
        return _geteTRIGGER();
    }

    private static final int LUT_SIZE = 256;
    private static final PxFilterObjectFlagEnum[] enumValues = values();
    private static final PxFilterObjectFlagEnum[] enumLut = new PxFilterObjectFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxFilterObjectFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxFilterObjectFlagEnum forValue(int value) {
        PxFilterObjectFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxFilterObjectFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxFilterObjectFlagEnum: " + value);
        }
        return enumValue;
    }
}
