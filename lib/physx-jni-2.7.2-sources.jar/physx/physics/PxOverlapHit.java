package physx.physics;


public class PxOverlapHit extends PxQueryHit {

    protected PxOverlapHit() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxOverlapHit wrapPointer(long address) {
        return address != 0L ? new PxOverlapHit(address) : null;
    }
    
    public static PxOverlapHit arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxOverlapHit(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxRigidActor}
     */
    public PxRigidActor getActor() {
        checkNotNull();
        return PxRigidActor.wrapPointer(Raw.getActor(address));
    }

    /**
     * @param value WebIDL type: {@link PxRigidActor}
     */
    public void setActor(PxRigidActor value) {
        checkNotNull();
        Raw.setActor(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxShape}
     */
    public PxShape getShape() {
        checkNotNull();
        return PxShape.wrapPointer(Raw.getShape(address));
    }

    /**
     * @param value WebIDL type: {@link PxShape}
     */
    public void setShape(PxShape value) {
        checkNotNull();
        Raw.setShape(address, value.getAddress());
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getActor(long address);
        public static native void setActor(long address, long value);
        public static native long getShape(long address);
        public static native void setShape(long address, long value);
    }
}
