package physx.physics;

import physx.NativeObject;

/**
 * Scene query hit information.
 */
public class PxQueryHit extends NativeObject {

    protected PxQueryHit() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxQueryHit wrapPointer(long address) {
        return address != 0L ? new PxQueryHit(address) : null;
    }
    
    public static PxQueryHit arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxQueryHit(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Face index of touched triangle, for triangle meshes, convex meshes and height fields.
     * <p>
     * <b>Note:</b> This index will default to 0xFFFFffff value for overlap queries.
     * <b>Note:</b> Please refer to the user guide for more details for sweep queries.
     * <b>Note:</b> This index is remapped by mesh cooking. Use #PxTriangleMesh::getTrianglesRemap() to convert to original mesh index.
     * <b>Note:</b> For convex meshes use #PxConvexMesh::getPolygonData() to retrieve touched polygon data.
     */
    public int getFaceIndex() {
        checkNotNull();
        return Raw.getFaceIndex(address);
    }

    /**
     * Face index of touched triangle, for triangle meshes, convex meshes and height fields.
     * <p>
     * <b>Note:</b> This index will default to 0xFFFFffff value for overlap queries.
     * <b>Note:</b> Please refer to the user guide for more details for sweep queries.
     * <b>Note:</b> This index is remapped by mesh cooking. Use #PxTriangleMesh::getTrianglesRemap() to convert to original mesh index.
     * <b>Note:</b> For convex meshes use #PxConvexMesh::getPolygonData() to retrieve touched polygon data.
     */
    public void setFaceIndex(int value) {
        checkNotNull();
        Raw.setFaceIndex(address, value);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native int getFaceIndex(long address);
        public static native void setFaceIndex(long address, int value);
    }
}
