package physx.physics;

public enum PxArticulationMotionEnum {

    /**
     * Locked axis, i.e. degree of freedom (DOF)
     */
    eLOCKED(geteLOCKED()),
    /**
     * Limited DOF - set limits of joint DOF together with this flag, see PxArticulationJointReducedCoordinate::setLimitParams
     */
    eLIMITED(geteLIMITED()),
    eFREE(geteFREE());
    public final int value;
    
    PxArticulationMotionEnum(int value) {
        this.value = value;
    }

    private static native int _geteLOCKED();
    private static int geteLOCKED() {
        de.fabmax.physxjni.Loader.load();
        return _geteLOCKED();
    }

    private static native int _geteLIMITED();
    private static int geteLIMITED() {
        de.fabmax.physxjni.Loader.load();
        return _geteLIMITED();
    }

    private static native int _geteFREE();
    private static int geteFREE() {
        de.fabmax.physxjni.Loader.load();
        return _geteFREE();
    }

    private static final int LUT_SIZE = 256;
    private static final PxArticulationMotionEnum[] enumValues = values();
    private static final PxArticulationMotionEnum[] enumLut = new PxArticulationMotionEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxArticulationMotionEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxArticulationMotionEnum forValue(int value) {
        PxArticulationMotionEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxArticulationMotionEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxArticulationMotionEnum: " + value);
        }
        return enumValue;
    }
}
