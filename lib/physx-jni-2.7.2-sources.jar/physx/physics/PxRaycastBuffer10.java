package physx.physics;


public class PxRaycastBuffer10 extends PxRaycastCallback {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxRaycastBuffer10 wrapPointer(long address) {
        return address != 0L ? new PxRaycastBuffer10(address) : null;
    }
    
    public static PxRaycastBuffer10 arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxRaycastBuffer10(long address) {
        super(address);
    }

    // Constructors

    public PxRaycastBuffer10() {
        address = Raw.PxRaycastBuffer10();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxRaycastHit} [Value]
     */
    public PxRaycastHit getBlock() {
        checkNotNull();
        return PxRaycastHit.wrapPointer(Raw.getBlock(address));
    }

    /**
     * @param value WebIDL type: {@link PxRaycastHit} [Value]
     */
    public void setBlock(PxRaycastHit value) {
        checkNotNull();
        Raw.setBlock(address, value.getAddress());
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean getHasBlock() {
        checkNotNull();
        return Raw.getHasBlock(address);
    }

    /**
     * @param value WebIDL type: boolean
     */
    public void setHasBlock(boolean value) {
        checkNotNull();
        Raw.setHasBlock(address, value);
    }

    // Functions

    /**
     * @return WebIDL type: unsigned long
     */
    public int getNbAnyHits() {
        checkNotNull();
        return Raw.getNbAnyHits(address);
    }

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxRaycastHit} [Const, Ref]
     */
    public PxRaycastHit getAnyHit(int index) {
        checkNotNull();
        return PxRaycastHit.wrapPointer(Raw.getAnyHit(address, index));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getNbTouches() {
        checkNotNull();
        return Raw.getNbTouches(address);
    }

    /**
     * @return WebIDL type: {@link PxRaycastHit} [Const]
     */
    public PxRaycastHit getTouches() {
        checkNotNull();
        return PxRaycastHit.wrapPointer(Raw.getTouches(address));
    }

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxRaycastHit} [Const, Ref]
     */
    public PxRaycastHit getTouch(int index) {
        checkNotNull();
        return PxRaycastHit.wrapPointer(Raw.getTouch(address, index));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getMaxNbTouches() {
        checkNotNull();
        return Raw.getMaxNbTouches(address);
    }

    public static class Raw {
        public static native long PxRaycastBuffer10();
        public static native void destroy(long address);
        public static native long getBlock(long address);
        public static native void setBlock(long address, long value);
        public static native boolean getHasBlock(long address);
        public static native void setHasBlock(long address, boolean value);
        public static native int getNbAnyHits(long address);
        public static native long getAnyHit(long address, int index);
        public static native int getNbTouches(long address);
        public static native long getTouches(long address);
        public static native long getTouch(long address, int index);
        public static native int getMaxNbTouches(long address);
    }
}
