package physx.physics;

import physx.NativeObject;

/**
 * Scene query filtering data.
 * <p>
 * Whenever the scene query intersects a shape, filtering is performed in the following order:
 * <p>
 * \li For non-batched queries only:<br>If the data field is non-zero, and the bitwise-AND value of data AND the shape's
 * queryFilterData is zero, the shape is skipped
 * \li If filter callbacks are enabled in flags field (see #PxQueryFlags) they will get invoked accordingly.
 * \li If neither #PxQueryFlag::ePREFILTER or #PxQueryFlag::ePOSTFILTER is set, the hit defaults
 * to type #PxQueryHitType::eBLOCK when the value of PxHitCallback::nbTouches provided with the query is zero and to type
 * #PxQueryHitType::eTOUCH when PxHitCallback::nbTouches is positive.
 */
public class PxQueryFilterData extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxQueryFilterData wrapPointer(long address) {
        return address != 0L ? new PxQueryFilterData(address) : null;
    }
    
    public static PxQueryFilterData arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxQueryFilterData(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxQueryFilterData
     */
    public static PxQueryFilterData createAt(long address) {
        Raw.PxQueryFilterData_placed(address);
        PxQueryFilterData createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxQueryFilterData
     */
    public static <T> PxQueryFilterData createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxQueryFilterData_placed(address);
        PxQueryFilterData createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param fd      WebIDL type: {@link PxFilterData} [Const, Ref]
     * @param f       WebIDL type: {@link PxQueryFlags} [Ref]
     * @return Stack allocated object of PxQueryFilterData
     */
    public static PxQueryFilterData createAt(long address, PxFilterData fd, PxQueryFlags f) {
        Raw.PxQueryFilterData_placed(address, fd.getAddress(), f.getAddress());
        PxQueryFilterData createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param fd        WebIDL type: {@link PxFilterData} [Const, Ref]
     * @param f         WebIDL type: {@link PxQueryFlags} [Ref]
     * @return Stack allocated object of PxQueryFilterData
     */
    public static <T> PxQueryFilterData createAt(T allocator, Allocator<T> allocate, PxFilterData fd, PxQueryFlags f) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxQueryFilterData_placed(address, fd.getAddress(), f.getAddress());
        PxQueryFilterData createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param f       WebIDL type: {@link PxQueryFlags} [Ref]
     * @return Stack allocated object of PxQueryFilterData
     */
    public static PxQueryFilterData createAt(long address, PxQueryFlags f) {
        Raw.PxQueryFilterData_placed(address, f.getAddress());
        PxQueryFilterData createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param f         WebIDL type: {@link PxQueryFlags} [Ref]
     * @return Stack allocated object of PxQueryFilterData
     */
    public static <T> PxQueryFilterData createAt(T allocator, Allocator<T> allocate, PxQueryFlags f) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxQueryFilterData_placed(address, f.getAddress());
        PxQueryFilterData createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * default constructor 
     */
    public PxQueryFilterData() {
        address = Raw.PxQueryFilterData();
    }

    /**
     * constructor to set both filter data and filter flags 
     */
    public PxQueryFilterData(PxFilterData fd, PxQueryFlags f) {
        address = Raw.PxQueryFilterData(fd.getAddress(), f.getAddress());
    }

    /**
     * constructor to set filter flags only 
     */
    public PxQueryFilterData(PxQueryFlags f) {
        address = Raw.PxQueryFilterData(f.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Filter data associated with the scene query
     */
    public PxFilterData getData() {
        checkNotNull();
        return PxFilterData.wrapPointer(Raw.getData(address));
    }

    /**
     * Filter data associated with the scene query
     */
    public void setData(PxFilterData value) {
        checkNotNull();
        Raw.setData(address, value.getAddress());
    }

    /**
     * Filter flags (see #PxQueryFlags)
     */
    public PxQueryFlags getFlags() {
        checkNotNull();
        return PxQueryFlags.wrapPointer(Raw.getFlags(address));
    }

    /**
     * Filter flags (see #PxQueryFlags)
     */
    public void setFlags(PxQueryFlags value) {
        checkNotNull();
        Raw.setFlags(address, value.getAddress());
    }

    public static class Raw {
        public static native void PxQueryFilterData_placed(long address);
        public static native void PxQueryFilterData_placed(long address, long fd, long f);
        public static native void PxQueryFilterData_placed(long address, long f);
        public static native long PxQueryFilterData();
        public static native long PxQueryFilterData(long fd, long f);
        public static native long PxQueryFilterData(long f);
        public static native void destroy(long address);
        public static native long getData(long address);
        public static native void setData(long address, long value);
        public static native long getFlags(long address);
        public static native void setFlags(long address, long value);
    }
}
