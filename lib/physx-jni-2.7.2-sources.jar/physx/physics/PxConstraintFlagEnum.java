package physx.physics;

/**
 * constraint flags
 * <p>
 * <b>Note:</b> eBROKEN is a read only flag
 */
public enum PxConstraintFlagEnum {

    /**
     * whether the constraint is broken
     */
    eBROKEN(geteBROKEN()),
    /**
     * whether contacts should be generated between the objects this constraint constrains
     */
    eCOLLISION_ENABLED(geteCOLLISION_ENABLED()),
    /**
     * whether this constraint should be visualized, if constraint visualization is turned on
     */
    eVISUALIZATION(geteVISUALIZATION()),
    /**
     * @deprecated  Will be removed in a future version and the limits will always be forces. limits for drive strength are forces rather than impulses
     */
    @Deprecated
    eDRIVE_LIMITS_ARE_FORCES(geteDRIVE_LIMITS_ARE_FORCES()),
    /**
     * perform preprocessing for improved accuracy on D6 Slerp Drive (this flag will be removed in a future release when preprocessing is no longer required)
     */
    eIMPROVED_SLERP(geteIMPROVED_SLERP()),
    /**
     * suppress constraint preprocessing, intended for use with rowResponseThreshold. May result in worse solver accuracy for ill-conditioned constraints.
     */
    eDISABLE_PREPROCESSING(geteDISABLE_PREPROCESSING()),
    /**
     * enables extended limit ranges for angular limits (e.g., limit values &gt; PxPi or &lt; -PxPi)
     */
    eENABLE_EXTENDED_LIMITS(geteENABLE_EXTENDED_LIMITS()),
    /**
     * please do not raise this flag as it is for internal use only
     */
    eGPU_COMPATIBLE(geteGPU_COMPATIBLE()),
    /**
     * updates the constraint each frame
     */
    eALWAYS_UPDATE(geteALWAYS_UPDATE()),
    eDISABLE_CONSTRAINT(geteDISABLE_CONSTRAINT());
    public final int value;
    
    PxConstraintFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteBROKEN();
    private static int geteBROKEN() {
        de.fabmax.physxjni.Loader.load();
        return _geteBROKEN();
    }

    private static native int _geteCOLLISION_ENABLED();
    private static int geteCOLLISION_ENABLED() {
        de.fabmax.physxjni.Loader.load();
        return _geteCOLLISION_ENABLED();
    }

    private static native int _geteVISUALIZATION();
    private static int geteVISUALIZATION() {
        de.fabmax.physxjni.Loader.load();
        return _geteVISUALIZATION();
    }

    private static native int _geteDRIVE_LIMITS_ARE_FORCES();
    private static int geteDRIVE_LIMITS_ARE_FORCES() {
        de.fabmax.physxjni.Loader.load();
        return _geteDRIVE_LIMITS_ARE_FORCES();
    }

    private static native int _geteIMPROVED_SLERP();
    private static int geteIMPROVED_SLERP() {
        de.fabmax.physxjni.Loader.load();
        return _geteIMPROVED_SLERP();
    }

    private static native int _geteDISABLE_PREPROCESSING();
    private static int geteDISABLE_PREPROCESSING() {
        de.fabmax.physxjni.Loader.load();
        return _geteDISABLE_PREPROCESSING();
    }

    private static native int _geteENABLE_EXTENDED_LIMITS();
    private static int geteENABLE_EXTENDED_LIMITS() {
        de.fabmax.physxjni.Loader.load();
        return _geteENABLE_EXTENDED_LIMITS();
    }

    private static native int _geteGPU_COMPATIBLE();
    private static int geteGPU_COMPATIBLE() {
        de.fabmax.physxjni.Loader.load();
        return _geteGPU_COMPATIBLE();
    }

    private static native int _geteALWAYS_UPDATE();
    private static int geteALWAYS_UPDATE() {
        de.fabmax.physxjni.Loader.load();
        return _geteALWAYS_UPDATE();
    }

    private static native int _geteDISABLE_CONSTRAINT();
    private static int geteDISABLE_CONSTRAINT() {
        de.fabmax.physxjni.Loader.load();
        return _geteDISABLE_CONSTRAINT();
    }

    private static final int LUT_SIZE = 256;
    private static final PxConstraintFlagEnum[] enumValues = values();
    private static final PxConstraintFlagEnum[] enumLut = new PxConstraintFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxConstraintFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxConstraintFlagEnum forValue(int value) {
        PxConstraintFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxConstraintFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxConstraintFlagEnum: " + value);
        }
        return enumValue;
    }
}
