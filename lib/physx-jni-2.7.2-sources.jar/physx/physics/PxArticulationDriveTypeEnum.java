package physx.physics;

public enum PxArticulationDriveTypeEnum {

    /**
     * The output of the implicit spring drive controller is a force/torque.
     */
    eFORCE(geteFORCE()),
    /**
     * The output of the implicit spring drive controller is a joint acceleration (use this to get (spatial)-inertia-invariant behavior of the drive).
     */
    eACCELERATION(geteACCELERATION()),
    eNONE(geteNONE());
    public final int value;
    
    PxArticulationDriveTypeEnum(int value) {
        this.value = value;
    }

    private static native int _geteFORCE();
    private static int geteFORCE() {
        de.fabmax.physxjni.Loader.load();
        return _geteFORCE();
    }

    private static native int _geteACCELERATION();
    private static int geteACCELERATION() {
        de.fabmax.physxjni.Loader.load();
        return _geteACCELERATION();
    }

    private static native int _geteNONE();
    private static int geteNONE() {
        de.fabmax.physxjni.Loader.load();
        return _geteNONE();
    }

    private static final int LUT_SIZE = 256;
    private static final PxArticulationDriveTypeEnum[] enumValues = values();
    private static final PxArticulationDriveTypeEnum[] enumLut = new PxArticulationDriveTypeEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxArticulationDriveTypeEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxArticulationDriveTypeEnum forValue(int value) {
        PxArticulationDriveTypeEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxArticulationDriveTypeEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxArticulationDriveTypeEnum: " + value);
        }
        return enumValue;
    }
}
