package physx.physics;

import physx.NativeObject;

/**
 * Descriptor for a trigger pair.
 * <p>
 * An array of these structs gets passed to the PxSimulationEventCallback::onTrigger() report.
 * <p>
 * <b>Note:</b> The shape pointers might reference deleted shapes. This will be the case if #PxPairFlag::eNOTIFY_TOUCH_LOST
 *       events were requested for the pair and one of the involved shapes gets deleted. Check the #flags member to see
 *    whether that is the case. Do not dereference a pointer to a deleted shape. The pointer to a deleted shape is 
 *    only provided such that user data structures which might depend on the pointer value can be updated.
 */
public class PxTriggerPair extends NativeObject {

    protected PxTriggerPair() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxTriggerPair wrapPointer(long address) {
        return address != 0L ? new PxTriggerPair(address) : null;
    }
    
    public static PxTriggerPair arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxTriggerPair(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The shape that has been marked as a trigger.
     */
    public PxShape getTriggerShape() {
        checkNotNull();
        return PxShape.wrapPointer(Raw.getTriggerShape(address));
    }

    /**
     * The shape that has been marked as a trigger.
     */
    public void setTriggerShape(PxShape value) {
        checkNotNull();
        Raw.setTriggerShape(address, value.getAddress());
    }

    /**
     * The actor to which triggerShape is attached
     */
    public PxActor getTriggerActor() {
        checkNotNull();
        return PxActor.wrapPointer(Raw.getTriggerActor(address));
    }

    /**
     * The actor to which triggerShape is attached
     */
    public void setTriggerActor(PxActor value) {
        checkNotNull();
        Raw.setTriggerActor(address, value.getAddress());
    }

    /**
     * The shape causing the trigger event. @deprecated  (see #PxSimulationEventCallback::onTrigger()) If collision between trigger shapes is enabled, then this member might point to a trigger shape as well.
     */
    @Deprecated
    public PxShape getOtherShape() {
        checkNotNull();
        return PxShape.wrapPointer(Raw.getOtherShape(address));
    }

    /**
     * The shape causing the trigger event. @deprecated  (see #PxSimulationEventCallback::onTrigger()) If collision between trigger shapes is enabled, then this member might point to a trigger shape as well.
     */
    @Deprecated
    public void setOtherShape(PxShape value) {
        checkNotNull();
        Raw.setOtherShape(address, value.getAddress());
    }

    /**
     * The actor to which otherShape is attached
     */
    public PxActor getOtherActor() {
        checkNotNull();
        return PxActor.wrapPointer(Raw.getOtherActor(address));
    }

    /**
     * The actor to which otherShape is attached
     */
    public void setOtherActor(PxActor value) {
        checkNotNull();
        Raw.setOtherActor(address, value.getAddress());
    }

    /**
     * Type of trigger event (eNOTIFY_TOUCH_FOUND or eNOTIFY_TOUCH_LOST). eNOTIFY_TOUCH_PERSISTS events are not supported.
     */
    public PxPairFlagEnum getStatus() {
        checkNotNull();
        return PxPairFlagEnum.forValue(Raw.getStatus(address));
    }

    /**
     * Type of trigger event (eNOTIFY_TOUCH_FOUND or eNOTIFY_TOUCH_LOST). eNOTIFY_TOUCH_PERSISTS events are not supported.
     */
    public void setStatus(PxPairFlagEnum value) {
        checkNotNull();
        Raw.setStatus(address, value.value);
    }

    /**
     * Additional information on the pair (see #PxTriggerPairFlag)
     */
    public PxTriggerPairFlags getFlags() {
        checkNotNull();
        return PxTriggerPairFlags.wrapPointer(Raw.getFlags(address));
    }

    /**
     * Additional information on the pair (see #PxTriggerPairFlag)
     */
    public void setFlags(PxTriggerPairFlags value) {
        checkNotNull();
        Raw.setFlags(address, value.getAddress());
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getTriggerShape(long address);
        public static native void setTriggerShape(long address, long value);
        public static native long getTriggerActor(long address);
        public static native void setTriggerActor(long address, long value);
        public static native long getOtherShape(long address);
        public static native void setOtherShape(long address, long value);
        public static native long getOtherActor(long address);
        public static native void setOtherActor(long address, long value);
        public static native int getStatus(long address);
        public static native void setStatus(long address, int value);
        public static native long getFlags(long address);
        public static native void setFlags(long address, long value);
    }
}
