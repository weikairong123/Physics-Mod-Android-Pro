package physx.physics;

import physx.common.PxBase;

/**
 * Common API base class shared by PxArticulationSpatialTendon and PxArticulationFixedTendon.
 */
public class PxArticulationTendon extends PxBase {

    protected PxArticulationTendon() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxArticulationTendon wrapPointer(long address) {
        return address != 0L ? new PxArticulationTendon(address) : null;
    }
    
    public static PxArticulationTendon arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxArticulationTendon(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * Sets the spring stiffness term acting on the tendon length.
     * @param stiffness The spring stiffness.
     * <b>Default:</b> 0
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #getStiffness
     */
    public void setStiffness(float stiffness) {
        checkNotNull();
        Raw.setStiffness(address, stiffness);
    }

    /**
     * Gets the spring stiffness of the tendon.
     * @return The spring stiffness.
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #setStiffness
     */
    public float getStiffness() {
        checkNotNull();
        return Raw.getStiffness(address);
    }

    /**
     * Sets the damping term acting both on the tendon length and tendon-length limits.
     * @param damping The damping term.
     * <b>Default:</b> 0
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #getDamping
     */
    public void setDamping(float damping) {
        checkNotNull();
        Raw.setDamping(address, damping);
    }

    /**
     * Gets the damping term acting both on the tendon length and tendon-length limits.
     * @return The damping term.
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #setDamping
     */
    public float getDamping() {
        checkNotNull();
        return Raw.getDamping(address);
    }

    /**
     * Sets the limit stiffness term acting on the tendon's length limits.
     * <p>
     * For spatial tendons, this parameter applies to all its leaf attachments / sub-tendons.
     * @param stiffness The limit stiffness term.
     * <b>Default:</b> 0
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #getLimitStiffness
     */
    public void setLimitStiffness(float stiffness) {
        checkNotNull();
        Raw.setLimitStiffness(address, stiffness);
    }

    /**
     * Gets the limit stiffness term acting on the tendon's length limits.
     * <p>
     * For spatial tendons, this parameter applies to all its leaf attachments / sub-tendons.
     * @return The limit stiffness term.
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #setLimitStiffness
     */
    public float getLimitStiffness() {
        checkNotNull();
        return Raw.getLimitStiffness(address);
    }

    /**
     * Sets the length offset term for the tendon.
     * <p>
     * An offset defines an amount to be added to the accumulated length computed for the tendon. It allows the
     * application to actuate the tendon by shortening or lengthening it.
     * @param offset The offset term. <b>Default:</b> 0
     * to #PxSceneDesc::wakeCounterResetValue if the counter value is below the reset value.
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #getOffset
     */
    public void setOffset(float offset) {
        checkNotNull();
        Raw.setOffset(address, offset);
    }

    /**
     * Sets the length offset term for the tendon.
     * <p>
     * An offset defines an amount to be added to the accumulated length computed for the tendon. It allows the
     * application to actuate the tendon by shortening or lengthening it.
     * @param offset The offset term. <b>Default:</b> 0
     * @param autowake If true and the articulation is in a scene, the call wakes up the articulation and increases the wake counter
     * to #PxSceneDesc::wakeCounterResetValue if the counter value is below the reset value.
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #getOffset
     */
    public void setOffset(float offset, boolean autowake) {
        checkNotNull();
        Raw.setOffset(address, offset, autowake);
    }

    /**
     * Gets the length offset term for the tendon.
     * @return The offset term.
     * <p>
     * <b>Note:</b> This method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @see #setOffset
     */
    public float getOffset() {
        checkNotNull();
        return Raw.getOffset(address);
    }

    /**
     * Gets the articulation that the tendon is a part of.
     * @return The articulation.
     * @see PxArticulationReducedCoordinate
     */
    public PxArticulationReducedCoordinate getArticulation() {
        checkNotNull();
        return PxArticulationReducedCoordinate.wrapPointer(Raw.getArticulation(address));
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native void setStiffness(long address, float stiffness);
        public static native float getStiffness(long address);
        public static native void setDamping(long address, float damping);
        public static native float getDamping(long address);
        public static native void setLimitStiffness(long address, float stiffness);
        public static native float getLimitStiffness(long address);
        public static native void setOffset(long address, float offset);
        public static native void setOffset(long address, float offset, boolean autowake);
        public static native float getOffset(long address);
        public static native long getArticulation(long address);
    }
}
