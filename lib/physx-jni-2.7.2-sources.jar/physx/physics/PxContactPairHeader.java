package physx.physics;

import physx.NativeObject;

/**
 * An Instance of this class is passed to PxSimulationEventCallback.onContact().
 */
public class PxContactPairHeader extends NativeObject {

    protected PxContactPairHeader() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxContactPairHeader wrapPointer(long address) {
        return address != 0L ? new PxContactPairHeader(address) : null;
    }
    
    public static PxContactPairHeader arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxContactPairHeader(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxActor}
     */
    public PxActor getActors(int index) {
        checkNotNull();
        return PxActor.wrapPointer(Raw.getActors(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxActor}
     */
    public void setActors(int index, PxActor value) {
        checkNotNull();
        Raw.setActors(address, index, value.getAddress());
    }

    /**
     * Additional information on the contact report pair.
     */
    public PxContactPairHeaderFlags getFlags() {
        checkNotNull();
        return PxContactPairHeaderFlags.wrapPointer(Raw.getFlags(address));
    }

    /**
     * Additional information on the contact report pair.
     */
    public void setFlags(PxContactPairHeaderFlags value) {
        checkNotNull();
        Raw.setFlags(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxContactPair} [Const]
     */
    public PxContactPair getPairs() {
        checkNotNull();
        return PxContactPair.wrapPointer(Raw.getPairs(address));
    }

    /**
     * @param value WebIDL type: {@link PxContactPair} [Const]
     */
    public void setPairs(PxContactPair value) {
        checkNotNull();
        Raw.setPairs(address, value.getAddress());
    }

    /**
     * number of contact pairs
     */
    public int getNbPairs() {
        checkNotNull();
        return Raw.getNbPairs(address);
    }

    /**
     * number of contact pairs
     */
    public void setNbPairs(int value) {
        checkNotNull();
        Raw.setNbPairs(address, value);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getActors(long address, int index);
        public static native void setActors(long address, int index, long value);
        public static native long getFlags(long address);
        public static native void setFlags(long address, long value);
        public static native long getPairs(long address);
        public static native void setPairs(long address, long value);
        public static native int getNbPairs(long address);
        public static native void setNbPairs(long address, int value);
    }
}
