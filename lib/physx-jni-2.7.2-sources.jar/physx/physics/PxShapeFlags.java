package physx.physics;

import physx.NativeObject;

public class PxShapeFlags extends NativeObject {

    protected PxShapeFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxShapeFlags wrapPointer(long address) {
        return address != 0L ? new PxShapeFlags(address) : null;
    }
    
    public static PxShapeFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxShapeFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: octet
     * @return Stack allocated object of PxShapeFlags
     */
    public static PxShapeFlags createAt(long address, byte flags) {
        Raw.PxShapeFlags_placed(address, flags);
        PxShapeFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: octet
     * @return Stack allocated object of PxShapeFlags
     */
    public static <T> PxShapeFlags createAt(T allocator, Allocator<T> allocate, byte flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxShapeFlags_placed(address, flags);
        PxShapeFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param flags WebIDL type: octet
     */
    public PxShapeFlags(byte flags) {
        address = Raw.PxShapeFlags(flags);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param flag WebIDL type: {@link PxShapeFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxShapeFlagEnum flag) {
        checkNotNull();
        return Raw.isSet(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxShapeFlagEnum} [enum]
     */
    public void raise(PxShapeFlagEnum flag) {
        checkNotNull();
        Raw.raise(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxShapeFlagEnum} [enum]
     */
    public void clear(PxShapeFlagEnum flag) {
        checkNotNull();
        Raw.clear(address, flag.value);
    }

    public static class Raw {
        public static native void PxShapeFlags_placed(long address, byte flags);
        public static native long PxShapeFlags(byte flags);
        public static native void destroy(long address);
        public static native boolean isSet(long address, int flag);
        public static native void raise(long address, int flag);
        public static native void clear(long address, int flag);
    }
}
