package physx.physics;

import physx.NativeObject;
import physx.common.PxVec3;

/**
 * A contact point as used by contact notification
 */
public class PxContactPairPoint extends NativeObject {

    protected PxContactPairPoint() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxContactPairPoint wrapPointer(long address) {
        return address != 0L ? new PxContactPairPoint(address) : null;
    }
    
    public static PxContactPairPoint arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxContactPairPoint(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The position of the contact point between the shapes, in world space. 
     */
    public PxVec3 getPosition() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getPosition(address));
    }

    /**
     * The position of the contact point between the shapes, in world space. 
     */
    public void setPosition(PxVec3 value) {
        checkNotNull();
        Raw.setPosition(address, value.getAddress());
    }

    /**
     * The separation of the shapes at the contact point.  A negative separation denotes a penetration.
     */
    public float getSeparation() {
        checkNotNull();
        return Raw.getSeparation(address);
    }

    /**
     * The separation of the shapes at the contact point.  A negative separation denotes a penetration.
     */
    public void setSeparation(float value) {
        checkNotNull();
        Raw.setSeparation(address, value);
    }

    /**
     * The normal of the contacting surfaces at the contact point. The normal direction points from the second shape to the first shape.
     */
    public PxVec3 getNormal() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getNormal(address));
    }

    /**
     * The normal of the contacting surfaces at the contact point. The normal direction points from the second shape to the first shape.
     */
    public void setNormal(PxVec3 value) {
        checkNotNull();
        Raw.setNormal(address, value.getAddress());
    }

    /**
     * The surface index of shape 0 at the contact point.  This is used to identify the surface material.
     */
    public int getInternalFaceIndex0() {
        checkNotNull();
        return Raw.getInternalFaceIndex0(address);
    }

    /**
     * The surface index of shape 0 at the contact point.  This is used to identify the surface material.
     */
    public void setInternalFaceIndex0(int value) {
        checkNotNull();
        Raw.setInternalFaceIndex0(address, value);
    }

    /**
     * The impulse applied at the contact point, in world space. Divide by the simulation time step to get a force value.
     */
    public PxVec3 getImpulse() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getImpulse(address));
    }

    /**
     * The impulse applied at the contact point, in world space. Divide by the simulation time step to get a force value.
     */
    public void setImpulse(PxVec3 value) {
        checkNotNull();
        Raw.setImpulse(address, value.getAddress());
    }

    /**
     * The surface index of shape 1 at the contact point.  This is used to identify the surface material.
     */
    public int getInternalFaceIndex1() {
        checkNotNull();
        return Raw.getInternalFaceIndex1(address);
    }

    /**
     * The surface index of shape 1 at the contact point.  This is used to identify the surface material.
     */
    public void setInternalFaceIndex1(int value) {
        checkNotNull();
        Raw.setInternalFaceIndex1(address, value);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getPosition(long address);
        public static native void setPosition(long address, long value);
        public static native float getSeparation(long address);
        public static native void setSeparation(long address, float value);
        public static native long getNormal(long address);
        public static native void setNormal(long address, long value);
        public static native int getInternalFaceIndex0(long address);
        public static native void setInternalFaceIndex0(long address, int value);
        public static native long getImpulse(long address);
        public static native void setImpulse(long address, long value);
        public static native int getInternalFaceIndex1(long address);
        public static native void setInternalFaceIndex1(long address, int value);
    }
}
