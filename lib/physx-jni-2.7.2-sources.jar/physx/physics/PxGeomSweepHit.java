package physx.physics;


/**
 * Stores results of sweep queries.
 */
public class PxGeomSweepHit extends PxLocationHit {

    protected PxGeomSweepHit() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxGeomSweepHit wrapPointer(long address) {
        return address != 0L ? new PxGeomSweepHit(address) : null;
    }
    
    public static PxGeomSweepHit arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxGeomSweepHit(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @return WebIDL type: boolean
     */
    public boolean hadInitialOverlap() {
        checkNotNull();
        return Raw.hadInitialOverlap(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native boolean hadInitialOverlap(long address);
    }
}
