package physx.physics;

import physx.support.PxActorPtr;

public class SimpleSimulationEventCallback extends PxSimulationEventCallback {

    protected SimpleSimulationEventCallback() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static SimpleSimulationEventCallback wrapPointer(long address) {
        return address != 0L ? new SimpleSimulationEventCallback(address) : null;
    }
    
    public static SimpleSimulationEventCallback arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected SimpleSimulationEventCallback(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param constraints WebIDL type: {@link PxConstraintInfo}
     * @param count       WebIDL type: unsigned long
     */
    public void onConstraintBreak(PxConstraintInfo constraints, int count) {
        checkNotNull();
        Raw.onConstraintBreak(address, constraints.getAddress(), count);
    }

    /**
     * @param actors WebIDL type: {@link PxActorPtr}
     * @param count  WebIDL type: unsigned long
     */
    public void onWake(PxActorPtr actors, int count) {
        checkNotNull();
        Raw.onWake(address, actors.getAddress(), count);
    }

    /**
     * @param actors WebIDL type: {@link PxActorPtr}
     * @param count  WebIDL type: unsigned long
     */
    public void onSleep(PxActorPtr actors, int count) {
        checkNotNull();
        Raw.onSleep(address, actors.getAddress(), count);
    }

    /**
     * @param pairHeader WebIDL type: {@link PxContactPairHeader} [Const, Ref]
     * @param pairs      WebIDL type: {@link PxContactPair} [Const]
     * @param nbPairs    WebIDL type: unsigned long
     */
    public void onContact(PxContactPairHeader pairHeader, PxContactPair pairs, int nbPairs) {
        checkNotNull();
        Raw.onContact(address, pairHeader.getAddress(), pairs.getAddress(), nbPairs);
    }

    /**
     * @param pairs WebIDL type: {@link PxTriggerPair}
     * @param count WebIDL type: unsigned long
     */
    public void onTrigger(PxTriggerPair pairs, int count) {
        checkNotNull();
        Raw.onTrigger(address, pairs.getAddress(), count);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native void onConstraintBreak(long address, long constraints, int count);
        public static native void onWake(long address, long actors, int count);
        public static native void onSleep(long address, long actors, int count);
        public static native void onContact(long address, long pairHeader, long pairs, int nbPairs);
        public static native void onTrigger(long address, long pairs, int count);
    }
}
