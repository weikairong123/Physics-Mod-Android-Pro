package physx.physics;

import physx.support.PxActorPtr;

public class PxSimulationEventCallbackImpl extends SimpleSimulationEventCallback {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxSimulationEventCallbackImpl wrapPointer(long address) {
        return address != 0L ? new PxSimulationEventCallbackImpl(address) : null;
    }
    
    public static PxSimulationEventCallbackImpl arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxSimulationEventCallbackImpl(long address) {
        super(address);
    }

    protected PxSimulationEventCallbackImpl() {
        address = _PxSimulationEventCallbackImpl();
    }
    private native long _PxSimulationEventCallbackImpl();
    
    // Destructor
    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _destroy(address);
        address = 0L;
    }
    private static native void _destroy(long address);

    // Functions

    /*
     * Called from native code
     */
    private void _onConstraintBreak(long constraints, int count) {
        onConstraintBreak(PxConstraintInfo.wrapPointer(constraints), count);
    }

    /**
     * @param constraints WebIDL type: {@link PxConstraintInfo}
     * @param count       WebIDL type: unsigned long
     */
    public void onConstraintBreak(PxConstraintInfo constraints, int count) { }

    /*
     * Called from native code
     */
    private void _onWake(long actors, int count) {
        onWake(PxActorPtr.wrapPointer(actors), count);
    }

    /**
     * @param actors WebIDL type: {@link PxActorPtr}
     * @param count  WebIDL type: unsigned long
     */
    public void onWake(PxActorPtr actors, int count) { }

    /*
     * Called from native code
     */
    private void _onSleep(long actors, int count) {
        onSleep(PxActorPtr.wrapPointer(actors), count);
    }

    /**
     * @param actors WebIDL type: {@link PxActorPtr}
     * @param count  WebIDL type: unsigned long
     */
    public void onSleep(PxActorPtr actors, int count) { }

    /*
     * Called from native code
     */
    private void _onContact(long pairHeader, long pairs, int nbPairs) {
        onContact(PxContactPairHeader.wrapPointer(pairHeader), PxContactPair.wrapPointer(pairs), nbPairs);
    }

    /**
     * @param pairHeader WebIDL type: {@link PxContactPairHeader} [Const, Ref]
     * @param pairs      WebIDL type: {@link PxContactPair} [Const]
     * @param nbPairs    WebIDL type: unsigned long
     */
    public void onContact(PxContactPairHeader pairHeader, PxContactPair pairs, int nbPairs) { }

    /*
     * Called from native code
     */
    private void _onTrigger(long pairs, int count) {
        onTrigger(PxTriggerPair.wrapPointer(pairs), count);
    }

    /**
     * @param pairs WebIDL type: {@link PxTriggerPair}
     * @param count WebIDL type: unsigned long
     */
    public void onTrigger(PxTriggerPair pairs, int count) { }

}
