package physx.physics;

/**
 * Flags which control the behavior of an actor.
 * <p>
 * <b>See also:</b> PxActorFlags PxActor PxActor.setActorFlag() PxActor.getActorFlags()
 */
public enum PxActorFlagEnum {

    /**
     * Enable debug renderer for this actor
     * <p>
     * <b>See also:</b> PxScene.getRenderBuffer() PxRenderBuffer PxVisualizationParameter
     */
    eVISUALIZATION(geteVISUALIZATION()),
    /**
     * Disables scene gravity for this actor
     */
    eDISABLE_GRAVITY(geteDISABLE_GRAVITY()),
    /**
     * Enables the sending of PxSimulationEventCallback::onWake() and PxSimulationEventCallback::onSleep() notify events
     * <p>
     * <b>See also:</b> PxSimulationEventCallback::onWake() PxSimulationEventCallback::onSleep()
     */
    eSEND_SLEEP_NOTIFIES(geteSEND_SLEEP_NOTIFIES()),
    /**
     * Disables simulation for the actor.
     * <p>
     * <b>Note:</b> This is only supported by PxRigidStatic and PxRigidDynamic actors and can be used to reduce the memory footprint when rigid actors are
     * used for scene queries only.
     * <p>
     * <b>Note:</b> Setting this flag will remove all constraints attached to the actor from the scene.
     * <p>
     * <b>Note:</b> If this flag is set, the following calls are forbidden:
     * \li PxRigidBody: setLinearVelocity(), setAngularVelocity(), addForce(), addTorque(), clearForce(), clearTorque(), setForceAndTorque()
     * \li PxRigidDynamic: setKinematicTarget(), setWakeCounter(), wakeUp(), putToSleep()
     * <p>
     * \par <b>Sleeping:</b>
     * Raising this flag will set all velocities and the wake counter to 0, clear all forces, clear the kinematic target, put the actor
     * to sleep and wake up all touching actors from the previous frame.
     */
    eDISABLE_SIMULATION(geteDISABLE_SIMULATION());
    public final int value;
    
    PxActorFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteVISUALIZATION();
    private static int geteVISUALIZATION() {
        de.fabmax.physxjni.Loader.load();
        return _geteVISUALIZATION();
    }

    private static native int _geteDISABLE_GRAVITY();
    private static int geteDISABLE_GRAVITY() {
        de.fabmax.physxjni.Loader.load();
        return _geteDISABLE_GRAVITY();
    }

    private static native int _geteSEND_SLEEP_NOTIFIES();
    private static int geteSEND_SLEEP_NOTIFIES() {
        de.fabmax.physxjni.Loader.load();
        return _geteSEND_SLEEP_NOTIFIES();
    }

    private static native int _geteDISABLE_SIMULATION();
    private static int geteDISABLE_SIMULATION() {
        de.fabmax.physxjni.Loader.load();
        return _geteDISABLE_SIMULATION();
    }

    private static final int LUT_SIZE = 256;
    private static final PxActorFlagEnum[] enumValues = values();
    private static final PxActorFlagEnum[] enumLut = new PxActorFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxActorFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxActorFlagEnum forValue(int value) {
        PxActorFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxActorFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxActorFlagEnum: " + value);
        }
        return enumValue;
    }
}
