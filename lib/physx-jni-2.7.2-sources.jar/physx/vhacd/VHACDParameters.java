package physx.vhacd;

import physx.NativeObject;
import physx.PlatformChecks;

public class VHACDParameters extends NativeObject {

    static {
        PlatformChecks.requirePlatform(15, "physx.vhacd.VHACDParameters");
    }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static VHACDParameters wrapPointer(long address) {
        return address != 0L ? new VHACDParameters(address) : null;
    }
    
    public static VHACDParameters arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected VHACDParameters(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of VHACDParameters
     */
    public static VHACDParameters createAt(long address) {
        Raw.VHACDParameters_placed(address);
        VHACDParameters createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of VHACDParameters
     */
    public static <T> VHACDParameters createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.VHACDParameters_placed(address);
        VHACDParameters createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public VHACDParameters() {
        address = Raw.VHACDParameters();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: unsigned long
     */
    public int getM_maxConvexHulls() {
        checkNotNull();
        return Raw.getM_maxConvexHulls(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setM_maxConvexHulls(int value) {
        checkNotNull();
        Raw.setM_maxConvexHulls(address, value);
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getM_resolution() {
        checkNotNull();
        return Raw.getM_resolution(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setM_resolution(int value) {
        checkNotNull();
        Raw.setM_resolution(address, value);
    }

    /**
     * @return WebIDL type: double
     */
    public double getM_minimumVolumePercentErrorAllowed() {
        checkNotNull();
        return Raw.getM_minimumVolumePercentErrorAllowed(address);
    }

    /**
     * @param value WebIDL type: double
     */
    public void setM_minimumVolumePercentErrorAllowed(double value) {
        checkNotNull();
        Raw.setM_minimumVolumePercentErrorAllowed(address, value);
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getM_maxRecursionDepth() {
        checkNotNull();
        return Raw.getM_maxRecursionDepth(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setM_maxRecursionDepth(int value) {
        checkNotNull();
        Raw.setM_maxRecursionDepth(address, value);
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean getM_shrinkWrap() {
        checkNotNull();
        return Raw.getM_shrinkWrap(address);
    }

    /**
     * @param value WebIDL type: boolean
     */
    public void setM_shrinkWrap(boolean value) {
        checkNotNull();
        Raw.setM_shrinkWrap(address, value);
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getM_maxNumVerticesPerCH() {
        checkNotNull();
        return Raw.getM_maxNumVerticesPerCH(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setM_maxNumVerticesPerCH(int value) {
        checkNotNull();
        Raw.setM_maxNumVerticesPerCH(address, value);
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean getM_asyncACD() {
        checkNotNull();
        return Raw.getM_asyncACD(address);
    }

    /**
     * @param value WebIDL type: boolean
     */
    public void setM_asyncACD(boolean value) {
        checkNotNull();
        Raw.setM_asyncACD(address, value);
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getM_minEdgeLength() {
        checkNotNull();
        return Raw.getM_minEdgeLength(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setM_minEdgeLength(int value) {
        checkNotNull();
        Raw.setM_minEdgeLength(address, value);
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean getM_findBestPlane() {
        checkNotNull();
        return Raw.getM_findBestPlane(address);
    }

    /**
     * @param value WebIDL type: boolean
     */
    public void setM_findBestPlane(boolean value) {
        checkNotNull();
        Raw.setM_findBestPlane(address, value);
    }

    public static class Raw {
        public static native void VHACDParameters_placed(long address);
        public static native long VHACDParameters();
        public static native void destroy(long address);
        public static native int getM_maxConvexHulls(long address);
        public static native void setM_maxConvexHulls(long address, int value);
        public static native int getM_resolution(long address);
        public static native void setM_resolution(long address, int value);
        public static native double getM_minimumVolumePercentErrorAllowed(long address);
        public static native void setM_minimumVolumePercentErrorAllowed(long address, double value);
        public static native int getM_maxRecursionDepth(long address);
        public static native void setM_maxRecursionDepth(long address, int value);
        public static native boolean getM_shrinkWrap(long address);
        public static native void setM_shrinkWrap(long address, boolean value);
        public static native int getM_maxNumVerticesPerCH(long address);
        public static native void setM_maxNumVerticesPerCH(long address, int value);
        public static native boolean getM_asyncACD(long address);
        public static native void setM_asyncACD(long address, boolean value);
        public static native int getM_minEdgeLength(long address);
        public static native void setM_minEdgeLength(long address, int value);
        public static native boolean getM_findBestPlane(long address);
        public static native void setM_findBestPlane(long address, boolean value);
    }
}
