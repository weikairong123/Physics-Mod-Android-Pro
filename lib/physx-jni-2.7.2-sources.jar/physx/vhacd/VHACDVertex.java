package physx.vhacd;

import physx.NativeObject;
import physx.PlatformChecks;

public class VHACDVertex extends NativeObject {

    static {
        PlatformChecks.requirePlatform(15, "physx.vhacd.VHACDVertex");
    }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static VHACDVertex wrapPointer(long address) {
        return address != 0L ? new VHACDVertex(address) : null;
    }
    
    public static VHACDVertex arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected VHACDVertex(long address) {
        super(address);
    }

    // Constructors

    public VHACDVertex() {
        address = Raw.VHACDVertex();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: double
     */
    public double getMX() {
        checkNotNull();
        return Raw.getMX(address);
    }

    /**
     * @param value WebIDL type: double
     */
    public void setMX(double value) {
        checkNotNull();
        Raw.setMX(address, value);
    }

    /**
     * @return WebIDL type: double
     */
    public double getMY() {
        checkNotNull();
        return Raw.getMY(address);
    }

    /**
     * @param value WebIDL type: double
     */
    public void setMY(double value) {
        checkNotNull();
        Raw.setMY(address, value);
    }

    /**
     * @return WebIDL type: double
     */
    public double getMZ() {
        checkNotNull();
        return Raw.getMZ(address);
    }

    /**
     * @param value WebIDL type: double
     */
    public void setMZ(double value) {
        checkNotNull();
        Raw.setMZ(address, value);
    }

    public static class Raw {
        public static native long VHACDVertex();
        public static native void destroy(long address);
        public static native double getMX(long address);
        public static native void setMX(long address, double value);
        public static native double getMY(long address);
        public static native void setMY(long address, double value);
        public static native double getMZ(long address);
        public static native void setMZ(long address, double value);
    }
}
