package physx.vhacd;

import physx.NativeObject;
import physx.PlatformChecks;

public class Vector_VHACDVertex extends NativeObject {

    static {
        PlatformChecks.requirePlatform(15, "physx.vhacd.Vector_VHACDVertex");
    }

    protected Vector_VHACDVertex() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static Vector_VHACDVertex wrapPointer(long address) {
        return address != 0L ? new Vector_VHACDVertex(address) : null;
    }
    
    public static Vector_VHACDVertex arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected Vector_VHACDVertex(long address) {
        super(address);
    }

    // Placed Constructors

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link VHACDVertex} [Ref]
     */
    public VHACDVertex at(int index) {
        checkNotNull();
        return VHACDVertex.wrapPointer(Raw.at(address, index));
    }

    /**
     * @return WebIDL type: {@link VHACDVertex}
     */
    public VHACDVertex data() {
        checkNotNull();
        return VHACDVertex.wrapPointer(Raw.data(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: {@link VHACDVertex} [Ref]
     */
    public void push_back(VHACDVertex value) {
        checkNotNull();
        Raw.push_back(address, value.getAddress());
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long at(long address, int index);
        public static native long data(long address);
        public static native int size(long address);
        public static native void push_back(long address, long value);
        public static native void clear(long address);
    }
}
