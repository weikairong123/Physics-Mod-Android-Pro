package physx.vhacd;

import physx.NativeObject;
import physx.PlatformChecks;

public class Vector_VHACDTriangle extends NativeObject {

    static {
        PlatformChecks.requirePlatform(15, "physx.vhacd.Vector_VHACDTriangle");
    }

    protected Vector_VHACDTriangle() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static Vector_VHACDTriangle wrapPointer(long address) {
        return address != 0L ? new Vector_VHACDTriangle(address) : null;
    }
    
    public static Vector_VHACDTriangle arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected Vector_VHACDTriangle(long address) {
        super(address);
    }

    // Placed Constructors

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link VHACDTriangle} [Ref]
     */
    public VHACDTriangle at(int index) {
        checkNotNull();
        return VHACDTriangle.wrapPointer(Raw.at(address, index));
    }

    /**
     * @return WebIDL type: {@link VHACDTriangle}
     */
    public VHACDTriangle data() {
        checkNotNull();
        return VHACDTriangle.wrapPointer(Raw.data(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: {@link VHACDTriangle} [Ref]
     */
    public void push_back(VHACDTriangle value) {
        checkNotNull();
        Raw.push_back(address, value.getAddress());
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long at(long address, int index);
        public static native long data(long address);
        public static native int size(long address);
        public static native void push_back(long address, long value);
        public static native void clear(long address);
    }
}
