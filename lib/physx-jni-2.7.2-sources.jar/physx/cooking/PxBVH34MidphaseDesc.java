package physx.cooking;

import physx.NativeObject;

/**
 * Structure describing parameters affecting BVH34 midphase mesh structure.
 * @see PxMidphaseDesc
 */
public class PxBVH34MidphaseDesc extends NativeObject {

    protected PxBVH34MidphaseDesc() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxBVH34MidphaseDesc wrapPointer(long address) {
        return address != 0L ? new PxBVH34MidphaseDesc(address) : null;
    }
    
    public static PxBVH34MidphaseDesc arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxBVH34MidphaseDesc(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Mesh cooking hint for max primitives per leaf limit. 
     * Less primitives per leaf produces larger meshes with better runtime performance 
     * and worse cooking performance. More triangles per leaf results in faster cooking speed and
     * smaller mesh sizes, but with worse runtime performance.
     * <p>
     * <b>Default value:</b> 4
     * <b>Range:</b> &lt;2, 15&gt;
     */
    public int getNumPrimsPerLeaf() {
        checkNotNull();
        return Raw.getNumPrimsPerLeaf(address);
    }

    /**
     * Mesh cooking hint for max primitives per leaf limit. 
     * Less primitives per leaf produces larger meshes with better runtime performance 
     * and worse cooking performance. More triangles per leaf results in faster cooking speed and
     * smaller mesh sizes, but with worse runtime performance.
     * <p>
     * <b>Default value:</b> 4
     * <b>Range:</b> &lt;2, 15&gt;
     */
    public void setNumPrimsPerLeaf(int value) {
        checkNotNull();
        Raw.setNumPrimsPerLeaf(address, value);
    }

    // Functions

    /**
     * Desc initialization to default value.
     */
    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    /**
     * Returns true if the descriptor is valid.
     * @return true if the current settings are valid.
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native int getNumPrimsPerLeaf(long address);
        public static native void setNumPrimsPerLeaf(long address, int value);
        public static native void setToDefault(long address);
        public static native boolean isValid(long address);
    }
}
