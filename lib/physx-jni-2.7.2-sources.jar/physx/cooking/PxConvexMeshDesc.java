package physx.cooking;

import physx.NativeObject;
import physx.common.PxBoundedData;

/**
 * Descriptor class for #PxConvexMesh.
 * <b>Note:</b> The number of vertices and the number of convex polygons in a cooked convex mesh is limited to 256.
 * <b>Note:</b> The number of vertices and the number of convex polygons in a GPU compatible convex mesh is limited to 64,
 * and the number of faces per vertex is limited to 32.
 * @see physx.geometry.PxConvexMesh
 * @see physx.geometry.PxConvexMeshGeometry
 * @see physx.physics.PxShape
 * @see physx.physics.PxPhysics#createConvexMesh
 */
public class PxConvexMeshDesc extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxConvexMeshDesc wrapPointer(long address) {
        return address != 0L ? new PxConvexMeshDesc(address) : null;
    }
    
    public static PxConvexMeshDesc arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxConvexMeshDesc(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxConvexMeshDesc
     */
    public static PxConvexMeshDesc createAt(long address) {
        Raw.PxConvexMeshDesc_placed(address);
        PxConvexMeshDesc createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxConvexMeshDesc
     */
    public static <T> PxConvexMeshDesc createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxConvexMeshDesc_placed(address);
        PxConvexMeshDesc createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * constructor sets to default.
     */
    public PxConvexMeshDesc() {
        address = Raw.PxConvexMeshDesc();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Vertex positions data in PxBoundedData format.
     * <p>
     * <b>Default:</b> NULL
     */
    public PxBoundedData getPoints() {
        checkNotNull();
        return PxBoundedData.wrapPointer(Raw.getPoints(address));
    }

    /**
     * Vertex positions data in PxBoundedData format.
     * <p>
     * <b>Default:</b> NULL
     */
    public void setPoints(PxBoundedData value) {
        checkNotNull();
        Raw.setPoints(address, value.getAddress());
    }

    /**
     * Flags bits, combined from values of the enum ::PxConvexFlag
     * <p>
     * <b>Default:</b> 0
     */
    public PxConvexFlags getFlags() {
        checkNotNull();
        return PxConvexFlags.wrapPointer(Raw.getFlags(address));
    }

    /**
     * Flags bits, combined from values of the enum ::PxConvexFlag
     * <p>
     * <b>Default:</b> 0
     */
    public void setFlags(PxConvexFlags value) {
        checkNotNull();
        Raw.setFlags(address, value.getAddress());
    }

    public static class Raw {
        public static native void PxConvexMeshDesc_placed(long address);
        public static native long PxConvexMeshDesc();
        public static native void destroy(long address);
        public static native long getPoints(long address);
        public static native void setPoints(long address, long value);
        public static native long getFlags(long address);
        public static native void setFlags(long address, long value);
    }
}
