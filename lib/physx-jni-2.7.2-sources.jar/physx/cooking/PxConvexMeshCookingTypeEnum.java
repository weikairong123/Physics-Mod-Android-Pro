package physx.cooking;

/**
 * Enumeration for convex mesh cooking algorithms. 
 */
public enum PxConvexMeshCookingTypeEnum {

    /**
     * The Quickhull algorithm constructs the hull from the given input points. The resulting hull
     * will only contain a subset of the input points. 
     */
    eQUICKHULL(geteQUICKHULL());
    public final int value;
    
    PxConvexMeshCookingTypeEnum(int value) {
        this.value = value;
    }

    private static native int _geteQUICKHULL();
    private static int geteQUICKHULL() {
        de.fabmax.physxjni.Loader.load();
        return _geteQUICKHULL();
    }

    private static final int LUT_SIZE = 256;
    private static final PxConvexMeshCookingTypeEnum[] enumValues = values();
    private static final PxConvexMeshCookingTypeEnum[] enumLut = new PxConvexMeshCookingTypeEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxConvexMeshCookingTypeEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxConvexMeshCookingTypeEnum forValue(int value) {
        PxConvexMeshCookingTypeEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxConvexMeshCookingTypeEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxConvexMeshCookingTypeEnum: " + value);
        }
        return enumValue;
    }
}
