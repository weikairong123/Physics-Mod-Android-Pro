package physx.cooking;

/**
 * Mesh midphase structure. This enum is used to select the desired acceleration structure for midphase queries
 *  (i.e. raycasts, overlaps, sweeps vs triangle meshes).
 * <p>
 *  The PxMeshMidPhase::eBVH33 structure is the one used in recent PhysX versions (up to PhysX 3.3). It has great performance and is
 *  supported on all platforms. It is deprecated since PhysX 5.x.
 * <p>
 *  The PxMeshMidPhase::eBVH34 structure is a revisited implementation introduced in PhysX 3.4. It can be significantly faster both
 *  in terms of cooking performance and runtime performance.
 */
public enum PxMeshMidPhaseEnum {

    /**
     * @deprecated  Use eBVH34 instead. Used to be default midphase mesh structure up to PhysX 3.3
     */
    @Deprecated
    eBVH33(geteBVH33()),
    /**
     * New midphase mesh structure, introduced in PhysX 3.4
     */
    eBVH34(geteBVH34());
    public final int value;
    
    PxMeshMidPhaseEnum(int value) {
        this.value = value;
    }

    private static native int _geteBVH33();
    private static int geteBVH33() {
        de.fabmax.physxjni.Loader.load();
        return _geteBVH33();
    }

    private static native int _geteBVH34();
    private static int geteBVH34() {
        de.fabmax.physxjni.Loader.load();
        return _geteBVH34();
    }

    private static final int LUT_SIZE = 256;
    private static final PxMeshMidPhaseEnum[] enumValues = values();
    private static final PxMeshMidPhaseEnum[] enumLut = new PxMeshMidPhaseEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxMeshMidPhaseEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxMeshMidPhaseEnum forValue(int value) {
        PxMeshMidPhaseEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxMeshMidPhaseEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxMeshMidPhaseEnum: " + value);
        }
        return enumValue;
    }
}
