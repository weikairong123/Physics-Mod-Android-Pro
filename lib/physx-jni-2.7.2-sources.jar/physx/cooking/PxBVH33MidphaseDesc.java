package physx.cooking;

import physx.NativeObject;

public class PxBVH33MidphaseDesc extends NativeObject {

    protected PxBVH33MidphaseDesc() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxBVH33MidphaseDesc wrapPointer(long address) {
        return address != 0L ? new PxBVH33MidphaseDesc(address) : null;
    }
    
    public static PxBVH33MidphaseDesc arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxBVH33MidphaseDesc(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: float
     */
    public float getMeshSizePerformanceTradeOff() {
        checkNotNull();
        return Raw.getMeshSizePerformanceTradeOff(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setMeshSizePerformanceTradeOff(float value) {
        checkNotNull();
        Raw.setMeshSizePerformanceTradeOff(address, value);
    }

    /**
     * @return WebIDL type: {@link PxMeshCookingHintEnum} [enum]
     */
    public PxMeshCookingHintEnum getMeshCookingHint() {
        checkNotNull();
        return PxMeshCookingHintEnum.forValue(Raw.getMeshCookingHint(address));
    }

    /**
     * @param value WebIDL type: {@link PxMeshCookingHintEnum} [enum]
     */
    public void setMeshCookingHint(PxMeshCookingHintEnum value) {
        checkNotNull();
        Raw.setMeshCookingHint(address, value.value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native float getMeshSizePerformanceTradeOff(long address);
        public static native void setMeshSizePerformanceTradeOff(long address, float value);
        public static native int getMeshCookingHint(long address);
        public static native void setMeshCookingHint(long address, int value);
        public static native void setToDefault(long address);
        public static native boolean isValid(long address);
    }
}
