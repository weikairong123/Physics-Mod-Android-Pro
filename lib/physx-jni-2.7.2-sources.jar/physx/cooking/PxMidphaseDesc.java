package physx.cooking;

import physx.NativeObject;

/**
 * Structure describing parameters affecting midphase mesh structure.
 * @see PxBVH34MidphaseDesc
 */
public class PxMidphaseDesc extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxMidphaseDesc wrapPointer(long address) {
        return address != 0L ? new PxMidphaseDesc(address) : null;
    }
    
    public static PxMidphaseDesc arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxMidphaseDesc(long address) {
        super(address);
    }

    // Constructors

    public PxMidphaseDesc() {
        address = Raw.PxMidphaseDesc();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxBVH33MidphaseDesc} [Value]
     */
    public PxBVH33MidphaseDesc getMBVH33Desc() {
        checkNotNull();
        return PxBVH33MidphaseDesc.wrapPointer(Raw.getMBVH33Desc(address));
    }

    /**
     * @param value WebIDL type: {@link PxBVH33MidphaseDesc} [Value]
     */
    public void setMBVH33Desc(PxBVH33MidphaseDesc value) {
        checkNotNull();
        Raw.setMBVH33Desc(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxBVH34MidphaseDesc} [Value]
     */
    public PxBVH34MidphaseDesc getMBVH34Desc() {
        checkNotNull();
        return PxBVH34MidphaseDesc.wrapPointer(Raw.getMBVH34Desc(address));
    }

    /**
     * @param value WebIDL type: {@link PxBVH34MidphaseDesc} [Value]
     */
    public void setMBVH34Desc(PxBVH34MidphaseDesc value) {
        checkNotNull();
        Raw.setMBVH34Desc(address, value.getAddress());
    }

    // Functions

    /**
     * Returns type of midphase mesh structure.
     * @return PxMeshMidPhase::Enum 
     */
    public PxMeshMidPhaseEnum getType() {
        checkNotNull();
        return PxMeshMidPhaseEnum.forValue(Raw.getType(address));
    }

    /**
     * Initialize the midphase mesh structure descriptor
     * @param type Midphase mesh structure descriptor
     */
    public void setToDefault(PxMeshMidPhaseEnum type) {
        checkNotNull();
        Raw.setToDefault(address, type.value);
    }

    /**
     * Returns true if the descriptor is valid.
     * @return true if the current settings are valid.
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native long PxMidphaseDesc();
        public static native void destroy(long address);
        public static native long getMBVH33Desc(long address);
        public static native void setMBVH33Desc(long address, long value);
        public static native long getMBVH34Desc(long address);
        public static native void setMBVH34Desc(long address, long value);
        public static native int getType(long address);
        public static native void setToDefault(long address, int type);
        public static native boolean isValid(long address);
    }
}
