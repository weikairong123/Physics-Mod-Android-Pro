package physx.support;

import physx.NativeObject;
import physx.common.PxVec3;

/**
 * Special client for PxScene.
 * It provides access to the PxPvdSceneFlag.
 * It also provides simple user debug services that associated scene position such as immediate rendering and camera updates.
 */
public class PxPvdSceneClient extends NativeObject {

    protected PxPvdSceneClient() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxPvdSceneClient wrapPointer(long address) {
        return address != 0L ? new PxPvdSceneClient(address) : null;
    }
    
    public static PxPvdSceneClient arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxPvdSceneClient(long address) {
        super(address);
    }

    // Functions

    /**
     * Sets the PVD flag. See PxPvdSceneFlag.
     * \param flag Flag to set.
     * \param value value the flag gets set to.
     */
    public void setScenePvdFlag(PxPvdSceneFlagEnum flag, boolean value) {
        checkNotNull();
        Raw.setScenePvdFlag(address, flag.value, value);
    }

    /**
     * Sets the PVD flags. See PxPvdSceneFlags.
     * \param flags Flags to set.
     */
    public void setScenePvdFlags(PxPvdSceneFlags flags) {
        checkNotNull();
        Raw.setScenePvdFlags(address, flags.getAddress());
    }

    /**
     * Retrieves the PVD flags. See PxPvdSceneFlags.
     */
    public PxPvdSceneFlags getScenePvdFlags() {
        checkNotNull();
        return PxPvdSceneFlags.wrapPointer(Raw.getScenePvdFlags(address));
    }

    /**
     * update camera on PVD application's render window
     */
    public void updateCamera(String name, PxVec3 origin, PxVec3 up, PxVec3 target) {
        checkNotNull();
        Raw.updateCamera(address, name, origin.getAddress(), up.getAddress(), target.getAddress());
    }

    public static class Raw {
        public static native void setScenePvdFlag(long address, int flag, boolean value);
        public static native void setScenePvdFlags(long address, long flags);
        public static native long getScenePvdFlags(long address);
        public static native void updateCamera(long address, String name, long origin, long up, long target);
    }
}
