package physx.support;

/**
 * PVD scene Flags. They are disabled by default, and only works if PxPvdInstrumentationFlag::eDEBUG is set.
 */
public enum PxPvdSceneFlagEnum {

    eTRANSMIT_CONTACTS(geteTRANSMIT_CONTACTS()),
    /**
     * Transmits contact stream to PVD.
     */
    eTRANSMIT_SCENEQUERIES(geteTRANSMIT_SCENEQUERIES()),
    eTRANSMIT_CONSTRAINTS(geteTRANSMIT_CONSTRAINTS());
    public final int value;
    
    PxPvdSceneFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteTRANSMIT_CONTACTS();
    private static int geteTRANSMIT_CONTACTS() {
        de.fabmax.physxjni.Loader.load();
        return _geteTRANSMIT_CONTACTS();
    }

    private static native int _geteTRANSMIT_SCENEQUERIES();
    private static int geteTRANSMIT_SCENEQUERIES() {
        de.fabmax.physxjni.Loader.load();
        return _geteTRANSMIT_SCENEQUERIES();
    }

    private static native int _geteTRANSMIT_CONSTRAINTS();
    private static int geteTRANSMIT_CONSTRAINTS() {
        de.fabmax.physxjni.Loader.load();
        return _geteTRANSMIT_CONSTRAINTS();
    }

    private static final int LUT_SIZE = 256;
    private static final PxPvdSceneFlagEnum[] enumValues = values();
    private static final PxPvdSceneFlagEnum[] enumLut = new PxPvdSceneFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxPvdSceneFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxPvdSceneFlagEnum forValue(int value) {
        PxPvdSceneFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxPvdSceneFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxPvdSceneFlagEnum: " + value);
        }
        return enumValue;
    }
}
