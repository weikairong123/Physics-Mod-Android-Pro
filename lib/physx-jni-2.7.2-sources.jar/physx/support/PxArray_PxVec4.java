package physx.support;

import physx.NativeObject;
import physx.common.PxVec4;

public class PxArray_PxVec4 extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxArray_PxVec4 wrapPointer(long address) {
        return address != 0L ? new PxArray_PxVec4(address) : null;
    }
    
    public static PxArray_PxVec4 arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxArray_PxVec4(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxArray_PxVec4
     */
    public static PxArray_PxVec4 createAt(long address) {
        Raw.PxArray_PxVec4_placed(address);
        PxArray_PxVec4 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxArray_PxVec4
     */
    public static <T> PxArray_PxVec4 createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxArray_PxVec4_placed(address);
        PxArray_PxVec4 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param size    WebIDL type: unsigned long
     * @return Stack allocated object of PxArray_PxVec4
     */
    public static PxArray_PxVec4 createAt(long address, int size) {
        Raw.PxArray_PxVec4_placed(address, size);
        PxArray_PxVec4 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param size      WebIDL type: unsigned long
     * @return Stack allocated object of PxArray_PxVec4
     */
    public static <T> PxArray_PxVec4 createAt(T allocator, Allocator<T> allocate, int size) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxArray_PxVec4_placed(address, size);
        PxArray_PxVec4 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxArray_PxVec4() {
        address = Raw.PxArray_PxVec4();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public PxArray_PxVec4(int size) {
        address = Raw.PxArray_PxVec4(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxVec4} [Ref]
     */
    public PxVec4 get(int index) {
        checkNotNull();
        return PxVec4.wrapPointer(Raw.get(address, index));
    }

    /**
     * @param index WebIDL type: unsigned long
     * @param value WebIDL type: {@link PxVec4} [Const, Ref]
     */
    public void set(int index, PxVec4 value) {
        checkNotNull();
        Raw.set(address, index, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVec4}
     */
    public PxVec4 begin() {
        checkNotNull();
        return PxVec4.wrapPointer(Raw.begin(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: {@link PxVec4} [Ref]
     */
    public void pushBack(PxVec4 value) {
        checkNotNull();
        Raw.pushBack(address, value.getAddress());
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native void PxArray_PxVec4_placed(long address);
        public static native void PxArray_PxVec4_placed(long address, int size);
        public static native long PxArray_PxVec4();
        public static native long PxArray_PxVec4(int size);
        public static native void destroy(long address);
        public static native long get(long address, int index);
        public static native void set(long address, int index, long value);
        public static native long begin(long address);
        public static native int size(long address);
        public static native void pushBack(long address, long value);
        public static native void clear(long address);
    }
}
