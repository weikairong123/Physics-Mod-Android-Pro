package physx.support;

import physx.physics.PxSimulationFilterShader;

public class PassThroughFilterShader extends PxSimulationFilterShader {

    protected PassThroughFilterShader() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PassThroughFilterShader wrapPointer(long address) {
        return address != 0L ? new PassThroughFilterShader(address) : null;
    }
    
    public static PassThroughFilterShader arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PassThroughFilterShader(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: unsigned long
     */
    public int getOutputPairFlags() {
        checkNotNull();
        return Raw.getOutputPairFlags(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setOutputPairFlags(int value) {
        checkNotNull();
        Raw.setOutputPairFlags(address, value);
    }

    // Functions

    /**
     * @param attributes0   WebIDL type: unsigned long
     * @param filterData0w0 WebIDL type: unsigned long
     * @param filterData0w1 WebIDL type: unsigned long
     * @param filterData0w2 WebIDL type: unsigned long
     * @param filterData0w3 WebIDL type: unsigned long
     * @param attributes1   WebIDL type: unsigned long
     * @param filterData1w0 WebIDL type: unsigned long
     * @param filterData1w1 WebIDL type: unsigned long
     * @param filterData1w2 WebIDL type: unsigned long
     * @param filterData1w3 WebIDL type: unsigned long
     * @return WebIDL type: unsigned long
     */
    public int filterShader(int attributes0, int filterData0w0, int filterData0w1, int filterData0w2, int filterData0w3, int attributes1, int filterData1w0, int filterData1w1, int filterData1w2, int filterData1w3) {
        checkNotNull();
        return Raw.filterShader(address, attributes0, filterData0w0, filterData0w1, filterData0w2, filterData0w3, attributes1, filterData1w0, filterData1w1, filterData1w2, filterData1w3);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native int getOutputPairFlags(long address);
        public static native void setOutputPairFlags(long address, int value);
        public static native int filterShader(long address, int attributes0, int filterData0w0, int filterData0w1, int filterData0w2, int filterData0w3, int attributes1, int filterData1w0, int filterData1w1, int filterData1w2, int filterData1w3);
    }
}
