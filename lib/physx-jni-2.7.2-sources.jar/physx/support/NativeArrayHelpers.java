package physx.support;

import physx.NativeObject;
import physx.character.PxController;
import physx.character.PxControllerObstacleHit;
import physx.character.PxControllerShapeHit;
import physx.character.PxControllersHit;
import physx.character.PxObstacle;
import physx.common.PxBounds3;
import physx.common.PxDebugLine;
import physx.common.PxDebugPoint;
import physx.common.PxDebugTriangle;
import physx.common.PxVec3;
import physx.physics.PxActor;
import physx.physics.PxContactPair;
import physx.physics.PxContactPairHeader;
import physx.physics.PxShape;
import physx.physics.PxTriggerPair;

public class NativeArrayHelpers extends NativeObject {

    protected NativeArrayHelpers() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static NativeArrayHelpers wrapPointer(long address) {
        return address != 0L ? new NativeArrayHelpers(address) : null;
    }
    
    public static NativeArrayHelpers arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected NativeArrayHelpers(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param base  WebIDL type: {@link PxU8ConstPtr} [Ref]
     * @param index WebIDL type: long
     * @return WebIDL type: octet
     */
    public static byte getU8At(PxU8ConstPtr base, int index) {
        return Raw.getU8At(base.getAddress(), index);
    }

    /**
     * @param base  WebIDL type: {@link PxU16ConstPtr} [Ref]
     * @param index WebIDL type: long
     * @return WebIDL type: unsigned short
     */
    public static short getU16At(PxU16ConstPtr base, int index) {
        return Raw.getU16At(base.getAddress(), index);
    }

    /**
     * @param base  WebIDL type: {@link PxU32ConstPtr} [Ref]
     * @param index WebIDL type: long
     * @return WebIDL type: unsigned long
     */
    public static int getU32At(PxU32ConstPtr base, int index) {
        return Raw.getU32At(base.getAddress(), index);
    }

    /**
     * @param base  WebIDL type: {@link PxRealPtr} [Ref]
     * @param index WebIDL type: long
     * @return WebIDL type: float
     */
    public static float getRealAt(PxRealPtr base, int index) {
        return Raw.getRealAt(base.getAddress(), index);
    }

    /**
     * @param base  WebIDL type: VoidPtr
     * @param index WebIDL type: long
     * @param value WebIDL type: octet
     */
    public static void setU8At(NativeObject base, int index, byte value) {
        Raw.setU8At(base.getAddress(), index, value);
    }

    /**
     * @param base  WebIDL type: VoidPtr
     * @param index WebIDL type: long
     * @param value WebIDL type: unsigned short
     */
    public static void setU16At(NativeObject base, int index, short value) {
        Raw.setU16At(base.getAddress(), index, value);
    }

    /**
     * @param base  WebIDL type: VoidPtr
     * @param index WebIDL type: long
     * @param value WebIDL type: unsigned long
     */
    public static void setU32At(NativeObject base, int index, int value) {
        Raw.setU32At(base.getAddress(), index, value);
    }

    /**
     * @param base  WebIDL type: VoidPtr
     * @param index WebIDL type: long
     * @param value WebIDL type: float
     */
    public static void setRealAt(NativeObject base, int index, float value) {
        Raw.setRealAt(base.getAddress(), index, value);
    }

    /**
     * @param voidPtr WebIDL type: VoidPtr
     * @return WebIDL type: {@link PxU8Ptr} [Value]
     */
    public static PxU8Ptr voidToU8Ptr(NativeObject voidPtr) {
        return PxU8Ptr.wrapPointer(Raw.voidToU8Ptr(voidPtr.getAddress()));
    }

    /**
     * @param voidPtr WebIDL type: VoidPtr
     * @return WebIDL type: {@link PxU16Ptr} [Value]
     */
    public static PxU16Ptr voidToU16Ptr(NativeObject voidPtr) {
        return PxU16Ptr.wrapPointer(Raw.voidToU16Ptr(voidPtr.getAddress()));
    }

    /**
     * @param voidPtr WebIDL type: VoidPtr
     * @return WebIDL type: {@link PxU32Ptr} [Value]
     */
    public static PxU32Ptr voidToU32Ptr(NativeObject voidPtr) {
        return PxU32Ptr.wrapPointer(Raw.voidToU32Ptr(voidPtr.getAddress()));
    }

    /**
     * @param voidPtr WebIDL type: VoidPtr
     * @return WebIDL type: {@link PxI32Ptr} [Value]
     */
    public static PxI32Ptr voidToI32Ptr(NativeObject voidPtr) {
        return PxI32Ptr.wrapPointer(Raw.voidToI32Ptr(voidPtr.getAddress()));
    }

    /**
     * @param voidPtr WebIDL type: VoidPtr
     * @return WebIDL type: {@link PxRealPtr} [Value]
     */
    public static PxRealPtr voidToRealPtr(NativeObject voidPtr) {
        return PxRealPtr.wrapPointer(Raw.voidToRealPtr(voidPtr.getAddress()));
    }

    /**
     * @param base  WebIDL type: {@link PxActor}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxActor}
     */
    public static PxActor getActorAt(PxActor base, int index) {
        return PxActor.wrapPointer(Raw.getActorAt(base.getAddress(), index));
    }

    /**
     * @param base  WebIDL type: {@link PxBounds3}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxBounds3}
     */
    public static PxBounds3 getBounds3At(PxBounds3 base, int index) {
        return PxBounds3.wrapPointer(Raw.getBounds3At(base.getAddress(), index));
    }

    /**
     * @param base  WebIDL type: {@link PxContactPair}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxContactPair}
     */
    public static PxContactPair getContactPairAt(PxContactPair base, int index) {
        return PxContactPair.wrapPointer(Raw.getContactPairAt(base.getAddress(), index));
    }

    /**
     * @param base  WebIDL type: {@link PxContactPairHeader}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxContactPairHeader}
     */
    public static PxContactPairHeader getContactPairHeaderAt(PxContactPairHeader base, int index) {
        return PxContactPairHeader.wrapPointer(Raw.getContactPairHeaderAt(base.getAddress(), index));
    }

    /**
     * @param base  WebIDL type: {@link PxController}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxController}
     */
    public static PxController getControllerAt(PxController base, int index) {
        return PxController.wrapPointer(Raw.getControllerAt(base.getAddress(), index));
    }

    /**
     * @param base  WebIDL type: {@link PxControllerShapeHit}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxControllerShapeHit}
     */
    public static PxControllerShapeHit getControllerShapeHitAt(PxControllerShapeHit base, int index) {
        return PxControllerShapeHit.wrapPointer(Raw.getControllerShapeHitAt(base.getAddress(), index));
    }

    /**
     * @param base  WebIDL type: {@link PxControllersHit}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxControllersHit}
     */
    public static PxControllersHit getControllersHitAt(PxControllersHit base, int index) {
        return PxControllersHit.wrapPointer(Raw.getControllersHitAt(base.getAddress(), index));
    }

    /**
     * @param base  WebIDL type: {@link PxControllerObstacleHit}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxControllerObstacleHit}
     */
    public static PxControllerObstacleHit getControllerObstacleHitAt(PxControllerObstacleHit base, int index) {
        return PxControllerObstacleHit.wrapPointer(Raw.getControllerObstacleHitAt(base.getAddress(), index));
    }

    /**
     * @param base  WebIDL type: {@link PxDebugPoint}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxDebugPoint}
     */
    public static PxDebugPoint getDebugPointAt(PxDebugPoint base, int index) {
        return PxDebugPoint.wrapPointer(Raw.getDebugPointAt(base.getAddress(), index));
    }

    /**
     * @param base  WebIDL type: {@link PxDebugLine}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxDebugLine}
     */
    public static PxDebugLine getDebugLineAt(PxDebugLine base, int index) {
        return PxDebugLine.wrapPointer(Raw.getDebugLineAt(base.getAddress(), index));
    }

    /**
     * @param base  WebIDL type: {@link PxDebugTriangle}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxDebugTriangle}
     */
    public static PxDebugTriangle getDebugTriangleAt(PxDebugTriangle base, int index) {
        return PxDebugTriangle.wrapPointer(Raw.getDebugTriangleAt(base.getAddress(), index));
    }

    /**
     * @param base  WebIDL type: {@link PxObstacle}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxObstacle}
     */
    public static PxObstacle getObstacleAt(PxObstacle base, int index) {
        return PxObstacle.wrapPointer(Raw.getObstacleAt(base.getAddress(), index));
    }

    /**
     * @param base  WebIDL type: {@link PxShape}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxShape}
     */
    public static PxShape getShapeAt(PxShape base, int index) {
        return PxShape.wrapPointer(Raw.getShapeAt(base.getAddress(), index));
    }

    /**
     * @param base  WebIDL type: {@link PxTriggerPair}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxTriggerPair}
     */
    public static PxTriggerPair getTriggerPairAt(PxTriggerPair base, int index) {
        return PxTriggerPair.wrapPointer(Raw.getTriggerPairAt(base.getAddress(), index));
    }

    /**
     * @param base  WebIDL type: {@link PxVec3}
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxVec3}
     */
    public static PxVec3 getVec3At(PxVec3 base, int index) {
        return PxVec3.wrapPointer(Raw.getVec3At(base.getAddress(), index));
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native byte getU8At(long base, int index);
        public static native short getU16At(long base, int index);
        public static native int getU32At(long base, int index);
        public static native float getRealAt(long base, int index);
        public static native void setU8At(long base, int index, byte value);
        public static native void setU16At(long base, int index, short value);
        public static native void setU32At(long base, int index, int value);
        public static native void setRealAt(long base, int index, float value);
        public static native long voidToU8Ptr(long voidPtr);
        public static native long voidToU16Ptr(long voidPtr);
        public static native long voidToU32Ptr(long voidPtr);
        public static native long voidToI32Ptr(long voidPtr);
        public static native long voidToRealPtr(long voidPtr);
        public static native long getActorAt(long base, int index);
        public static native long getBounds3At(long base, int index);
        public static native long getContactPairAt(long base, int index);
        public static native long getContactPairHeaderAt(long base, int index);
        public static native long getControllerAt(long base, int index);
        public static native long getControllerShapeHitAt(long base, int index);
        public static native long getControllersHitAt(long base, int index);
        public static native long getControllerObstacleHitAt(long base, int index);
        public static native long getDebugPointAt(long base, int index);
        public static native long getDebugLineAt(long base, int index);
        public static native long getDebugTriangleAt(long base, int index);
        public static native long getObstacleAt(long base, int index);
        public static native long getShapeAt(long base, int index);
        public static native long getTriggerPairAt(long base, int index);
        public static native long getVec3At(long base, int index);
    }
}
