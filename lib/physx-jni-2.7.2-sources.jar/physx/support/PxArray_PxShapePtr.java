package physx.support;

import physx.NativeObject;
import physx.physics.PxShape;

public class PxArray_PxShapePtr extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxArray_PxShapePtr wrapPointer(long address) {
        return address != 0L ? new PxArray_PxShapePtr(address) : null;
    }
    
    public static PxArray_PxShapePtr arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxArray_PxShapePtr(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxArray_PxShapePtr
     */
    public static PxArray_PxShapePtr createAt(long address) {
        Raw.PxArray_PxShapePtr_placed(address);
        PxArray_PxShapePtr createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxArray_PxShapePtr
     */
    public static <T> PxArray_PxShapePtr createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxArray_PxShapePtr_placed(address);
        PxArray_PxShapePtr createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param size    WebIDL type: unsigned long
     * @return Stack allocated object of PxArray_PxShapePtr
     */
    public static PxArray_PxShapePtr createAt(long address, int size) {
        Raw.PxArray_PxShapePtr_placed(address, size);
        PxArray_PxShapePtr createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param size      WebIDL type: unsigned long
     * @return Stack allocated object of PxArray_PxShapePtr
     */
    public static <T> PxArray_PxShapePtr createAt(T allocator, Allocator<T> allocate, int size) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxArray_PxShapePtr_placed(address, size);
        PxArray_PxShapePtr createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxArray_PxShapePtr() {
        address = Raw.PxArray_PxShapePtr();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public PxArray_PxShapePtr(int size) {
        address = Raw.PxArray_PxShapePtr(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxShape}
     */
    public PxShape get(int index) {
        checkNotNull();
        return PxShape.wrapPointer(Raw.get(address, index));
    }

    /**
     * @param index WebIDL type: unsigned long
     * @param value WebIDL type: {@link PxShapePtr} [Const, Ref]
     */
    public void set(int index, PxShapePtr value) {
        checkNotNull();
        Raw.set(address, index, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxShapePtr}
     */
    public PxShapePtr begin() {
        checkNotNull();
        return PxShapePtr.wrapPointer(Raw.begin(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: {@link PxShape}
     */
    public void pushBack(PxShape value) {
        checkNotNull();
        Raw.pushBack(address, value.getAddress());
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native void PxArray_PxShapePtr_placed(long address);
        public static native void PxArray_PxShapePtr_placed(long address, int size);
        public static native long PxArray_PxShapePtr();
        public static native long PxArray_PxShapePtr(int size);
        public static native void destroy(long address);
        public static native long get(long address, int index);
        public static native void set(long address, int index, long value);
        public static native long begin(long address);
        public static native int size(long address);
        public static native void pushBack(long address, long value);
        public static native void clear(long address);
    }
}
