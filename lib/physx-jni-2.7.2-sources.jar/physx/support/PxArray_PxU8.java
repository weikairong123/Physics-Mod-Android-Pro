package physx.support;

import physx.NativeObject;

public class PxArray_PxU8 extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxArray_PxU8 wrapPointer(long address) {
        return address != 0L ? new PxArray_PxU8(address) : null;
    }
    
    public static PxArray_PxU8 arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxArray_PxU8(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxArray_PxU8
     */
    public static PxArray_PxU8 createAt(long address) {
        Raw.PxArray_PxU8_placed(address);
        PxArray_PxU8 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxArray_PxU8
     */
    public static <T> PxArray_PxU8 createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxArray_PxU8_placed(address);
        PxArray_PxU8 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param size    WebIDL type: unsigned long
     * @return Stack allocated object of PxArray_PxU8
     */
    public static PxArray_PxU8 createAt(long address, int size) {
        Raw.PxArray_PxU8_placed(address, size);
        PxArray_PxU8 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param size      WebIDL type: unsigned long
     * @return Stack allocated object of PxArray_PxU8
     */
    public static <T> PxArray_PxU8 createAt(T allocator, Allocator<T> allocate, int size) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxArray_PxU8_placed(address, size);
        PxArray_PxU8 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxArray_PxU8() {
        address = Raw.PxArray_PxU8();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public PxArray_PxU8(int size) {
        address = Raw.PxArray_PxU8(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: octet
     */
    public byte get(int index) {
        checkNotNull();
        return Raw.get(address, index);
    }

    /**
     * @param index WebIDL type: unsigned long
     * @param value WebIDL type: octet
     */
    public void set(int index, byte value) {
        checkNotNull();
        Raw.set(address, index, value);
    }

    /**
     * @return WebIDL type: VoidPtr
     */
    public NativeObject begin() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.begin(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: octet
     */
    public void pushBack(byte value) {
        checkNotNull();
        Raw.pushBack(address, value);
    }

    /**
     * @param buffer WebIDL type: VoidPtr
     * @param size   WebIDL type: unsigned long
     */
    public void setFromBuffer(NativeObject buffer, int size) {
        checkNotNull();
        Raw.setFromBuffer(address, buffer.getAddress(), size);
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native void PxArray_PxU8_placed(long address);
        public static native void PxArray_PxU8_placed(long address, int size);
        public static native long PxArray_PxU8();
        public static native long PxArray_PxU8(int size);
        public static native void destroy(long address);
        public static native byte get(long address, int index);
        public static native void set(long address, int index, byte value);
        public static native long begin(long address);
        public static native int size(long address);
        public static native void pushBack(long address, byte value);
        public static native void setFromBuffer(long address, long buffer, int size);
        public static native void clear(long address);
    }
}
