package physx.support;

import physx.NativeObject;

@Deprecated
public class Vector_PxU8 extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static Vector_PxU8 wrapPointer(long address) {
        return address != 0L ? new Vector_PxU8(address) : null;
    }
    
    public static Vector_PxU8 arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected Vector_PxU8(long address) {
        super(address);
    }

    // Constructors

    public Vector_PxU8() {
        address = Raw.Vector_PxU8();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public Vector_PxU8(int size) {
        address = Raw.Vector_PxU8(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: octet
     */
    public byte at(int index) {
        checkNotNull();
        return Raw.at(address, index);
    }

    /**
     * @return WebIDL type: VoidPtr
     */
    public NativeObject data() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.data(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: octet
     */
    public void push_back(byte value) {
        checkNotNull();
        Raw.push_back(address, value);
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native long Vector_PxU8();
        public static native long Vector_PxU8(int size);
        public static native void destroy(long address);
        public static native byte at(long address, int index);
        public static native long data(long address);
        public static native int size(long address);
        public static native void push_back(long address, byte value);
        public static native void clear(long address);
    }
}
