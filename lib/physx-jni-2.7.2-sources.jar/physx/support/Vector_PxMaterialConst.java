package physx.support;

import physx.NativeObject;
import physx.physics.PxMaterial;

@Deprecated
public class Vector_PxMaterialConst extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static Vector_PxMaterialConst wrapPointer(long address) {
        return address != 0L ? new Vector_PxMaterialConst(address) : null;
    }
    
    public static Vector_PxMaterialConst arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected Vector_PxMaterialConst(long address) {
        super(address);
    }

    // Constructors

    public Vector_PxMaterialConst() {
        address = Raw.Vector_PxMaterialConst();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public Vector_PxMaterialConst(int size) {
        address = Raw.Vector_PxMaterialConst(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxMaterial} [Const]
     */
    public PxMaterial at(int index) {
        checkNotNull();
        return PxMaterial.wrapPointer(Raw.at(address, index));
    }

    /**
     * @return WebIDL type: {@link PxMaterialConstPtr}
     */
    public PxMaterialConstPtr data() {
        checkNotNull();
        return PxMaterialConstPtr.wrapPointer(Raw.data(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: {@link PxMaterial} [Const]
     */
    public void push_back(PxMaterial value) {
        checkNotNull();
        Raw.push_back(address, value.getAddress());
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native long Vector_PxMaterialConst();
        public static native long Vector_PxMaterialConst(int size);
        public static native void destroy(long address);
        public static native long at(long address, int index);
        public static native long data(long address);
        public static native int size(long address);
        public static native void push_back(long address, long value);
        public static native void clear(long address);
    }
}
