package physx.support;

import physx.NativeObject;
import physx.geometry.PxHeightFieldSample;

@Deprecated
public class Vector_PxHeightFieldSample extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static Vector_PxHeightFieldSample wrapPointer(long address) {
        return address != 0L ? new Vector_PxHeightFieldSample(address) : null;
    }
    
    public static Vector_PxHeightFieldSample arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected Vector_PxHeightFieldSample(long address) {
        super(address);
    }

    // Constructors

    public Vector_PxHeightFieldSample() {
        address = Raw.Vector_PxHeightFieldSample();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public Vector_PxHeightFieldSample(int size) {
        address = Raw.Vector_PxHeightFieldSample(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxHeightFieldSample} [Ref]
     */
    public PxHeightFieldSample at(int index) {
        checkNotNull();
        return PxHeightFieldSample.wrapPointer(Raw.at(address, index));
    }

    /**
     * @return WebIDL type: {@link PxHeightFieldSample}
     */
    public PxHeightFieldSample data() {
        checkNotNull();
        return PxHeightFieldSample.wrapPointer(Raw.data(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: {@link PxHeightFieldSample} [Ref]
     */
    public void push_back(PxHeightFieldSample value) {
        checkNotNull();
        Raw.push_back(address, value.getAddress());
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native long Vector_PxHeightFieldSample();
        public static native long Vector_PxHeightFieldSample(int size);
        public static native void destroy(long address);
        public static native long at(long address, int index);
        public static native long data(long address);
        public static native int size(long address);
        public static native void push_back(long address, long value);
        public static native void clear(long address);
    }
}
