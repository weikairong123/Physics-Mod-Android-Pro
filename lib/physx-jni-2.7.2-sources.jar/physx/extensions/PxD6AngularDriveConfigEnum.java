package physx.extensions;

/**
 * The configuration to use for driving to the angular component of a target pose or velocity.
 * <p>
 * <b>See also:</b> PxD6Joint::setAngularDriveConfig() PxD6Drive PxD6Joint::setDrive()
 */
public enum PxD6AngularDriveConfigEnum {

    /**
     * The joint tries to reach the angular drive target by separately driving along each angular degree of freedom.
     * <p>
     * Each angular degree of freedom can have its own set of drive parameters. The degrees of freedom are covered by a twist and two swing axes.
     * As a consequence, only the following options are available when setting the drive parameters: PxD6Drive::eSWING1, PxD6Drive::eSWING2, 
     * PxD6Drive::eTWIST (see #PxD6Joint::setDrive()).
     */
    eSWING_TWIST(geteSWING_TWIST()),
    /**
     * The joint tries to reach the angular drive target by following a spherical linear interpolation (SLERP) based path.
     * <p>
     * A single set of drive parameters will be used for all angular degrees of freedom and PxD6Drive::eSLERP is the only valid option to set
     * those parameters (see #PxD6Joint::setDrive()).
     */
    eSLERP(geteSLERP()),
    eLEGACY(geteLEGACY());
    public final int value;
    
    PxD6AngularDriveConfigEnum(int value) {
        this.value = value;
    }

    private static native int _geteSWING_TWIST();
    private static int geteSWING_TWIST() {
        de.fabmax.physxjni.Loader.load();
        return _geteSWING_TWIST();
    }

    private static native int _geteSLERP();
    private static int geteSLERP() {
        de.fabmax.physxjni.Loader.load();
        return _geteSLERP();
    }

    private static native int _geteLEGACY();
    private static int geteLEGACY() {
        de.fabmax.physxjni.Loader.load();
        return _geteLEGACY();
    }

    private static final int LUT_SIZE = 256;
    private static final PxD6AngularDriveConfigEnum[] enumValues = values();
    private static final PxD6AngularDriveConfigEnum[] enumLut = new PxD6AngularDriveConfigEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxD6AngularDriveConfigEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxD6AngularDriveConfigEnum forValue(int value) {
        PxD6AngularDriveConfigEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxD6AngularDriveConfigEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxD6AngularDriveConfigEnum: " + value);
        }
        return enumValue;
    }
}
