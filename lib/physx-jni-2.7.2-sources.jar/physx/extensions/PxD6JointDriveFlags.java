package physx.extensions;

import physx.NativeObject;

public class PxD6JointDriveFlags extends NativeObject {

    protected PxD6JointDriveFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxD6JointDriveFlags wrapPointer(long address) {
        return address != 0L ? new PxD6JointDriveFlags(address) : null;
    }
    
    public static PxD6JointDriveFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxD6JointDriveFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: unsigned long
     * @return Stack allocated object of PxD6JointDriveFlags
     */
    public static PxD6JointDriveFlags createAt(long address, int flags) {
        Raw.PxD6JointDriveFlags_placed(address, flags);
        PxD6JointDriveFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: unsigned long
     * @return Stack allocated object of PxD6JointDriveFlags
     */
    public static <T> PxD6JointDriveFlags createAt(T allocator, Allocator<T> allocate, int flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxD6JointDriveFlags_placed(address, flags);
        PxD6JointDriveFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param flags WebIDL type: unsigned long
     */
    public PxD6JointDriveFlags(int flags) {
        address = Raw.PxD6JointDriveFlags(flags);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param flag WebIDL type: {@link PxD6JointDriveFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxD6JointDriveFlagEnum flag) {
        checkNotNull();
        return Raw.isSet(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxD6JointDriveFlagEnum} [enum]
     */
    public void raise(PxD6JointDriveFlagEnum flag) {
        checkNotNull();
        Raw.raise(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxD6JointDriveFlagEnum} [enum]
     */
    public void clear(PxD6JointDriveFlagEnum flag) {
        checkNotNull();
        Raw.clear(address, flag.value);
    }

    public static class Raw {
        public static native void PxD6JointDriveFlags_placed(long address, int flags);
        public static native long PxD6JointDriveFlags(int flags);
        public static native void destroy(long address);
        public static native boolean isSet(long address, int flag);
        public static native void raise(long address, int flag);
        public static native void clear(long address, int flag);
    }
}
