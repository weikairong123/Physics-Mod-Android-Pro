package physx.extensions;


public class PxJointAngularLimitPair extends PxJointLimitParameters {

    protected PxJointAngularLimitPair() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxJointAngularLimitPair wrapPointer(long address) {
        return address != 0L ? new PxJointAngularLimitPair(address) : null;
    }
    
    public static PxJointAngularLimitPair arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxJointAngularLimitPair(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address    Pre-allocated memory, where the object is created.
     * @param lowerLimit WebIDL type: float
     * @param upperLimit WebIDL type: float
     * @return Stack allocated object of PxJointAngularLimitPair
     */
    public static PxJointAngularLimitPair createAt(long address, float lowerLimit, float upperLimit) {
        Raw.PxJointAngularLimitPair_placed(address, lowerLimit, upperLimit);
        PxJointAngularLimitPair createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>        Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator  Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate   Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param lowerLimit WebIDL type: float
     * @param upperLimit WebIDL type: float
     * @return Stack allocated object of PxJointAngularLimitPair
     */
    public static <T> PxJointAngularLimitPair createAt(T allocator, Allocator<T> allocate, float lowerLimit, float upperLimit) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxJointAngularLimitPair_placed(address, lowerLimit, upperLimit);
        PxJointAngularLimitPair createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address    Pre-allocated memory, where the object is created.
     * @param lowerLimit WebIDL type: float
     * @param upperLimit WebIDL type: float
     * @param spring     WebIDL type: {@link PxSpring} [Const, Ref]
     * @return Stack allocated object of PxJointAngularLimitPair
     */
    public static PxJointAngularLimitPair createAt(long address, float lowerLimit, float upperLimit, PxSpring spring) {
        Raw.PxJointAngularLimitPair_placed(address, lowerLimit, upperLimit, spring.getAddress());
        PxJointAngularLimitPair createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>        Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator  Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate   Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param lowerLimit WebIDL type: float
     * @param upperLimit WebIDL type: float
     * @param spring     WebIDL type: {@link PxSpring} [Const, Ref]
     * @return Stack allocated object of PxJointAngularLimitPair
     */
    public static <T> PxJointAngularLimitPair createAt(T allocator, Allocator<T> allocate, float lowerLimit, float upperLimit, PxSpring spring) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxJointAngularLimitPair_placed(address, lowerLimit, upperLimit, spring.getAddress());
        PxJointAngularLimitPair createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * construct an angular hard limit pair. 
     * <p>
     * The lower value must be less than the upper value. 
     * @param lowerLimit The lower angle of the limit
     * @param upperLimit The upper angle of the limit
     * @see PxJointLimitParameters
     */
    public PxJointAngularLimitPair(float lowerLimit, float upperLimit) {
        address = Raw.PxJointAngularLimitPair(lowerLimit, upperLimit);
    }

    /**
     * construct an angular soft limit pair. 
     * <p>
     * The lower value must be less than the upper value. 
     * @param lowerLimit The lower angle of the limit
     * @param upperLimit The upper angle of the limit
     * @param spring  The stiffness and damping of the limit spring
     * @see PxJointLimitParameters
     */
    public PxJointAngularLimitPair(float lowerLimit, float upperLimit, PxSpring spring) {
        address = Raw.PxJointAngularLimitPair(lowerLimit, upperLimit, spring.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: float
     */
    public float getUpper() {
        checkNotNull();
        return Raw.getUpper(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setUpper(float value) {
        checkNotNull();
        Raw.setUpper(address, value);
    }

    /**
     * the range of the limit. The upper limit must be no lower than the lower limit.
     * <p>
     * <b>Unit:</b> Angular: Radians
     * <b>Range:</b> See the joint on which the limit is used for details<br>
     * <b>Default:</b> lower = -PI/2, upper = PI/2
     */
    public float getLower() {
        checkNotNull();
        return Raw.getLower(address);
    }

    /**
     * the range of the limit. The upper limit must be no lower than the lower limit.
     * <p>
     * <b>Unit:</b> Angular: Radians
     * <b>Range:</b> See the joint on which the limit is used for details<br>
     * <b>Default:</b> lower = -PI/2, upper = PI/2
     */
    public void setLower(float value) {
        checkNotNull();
        Raw.setLower(address, value);
    }

    public static class Raw {
        public static native void PxJointAngularLimitPair_placed(long address, float lowerLimit, float upperLimit);
        public static native void PxJointAngularLimitPair_placed(long address, float lowerLimit, float upperLimit, long spring);
        public static native long PxJointAngularLimitPair(float lowerLimit, float upperLimit);
        public static native long PxJointAngularLimitPair(float lowerLimit, float upperLimit, long spring);
        public static native void destroy(long address);
        public static native float getUpper(long address);
        public static native void setUpper(long address, float value);
        public static native float getLower(long address);
        public static native void setLower(long address, float value);
    }
}
