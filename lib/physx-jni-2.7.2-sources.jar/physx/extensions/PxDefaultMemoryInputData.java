package physx.extensions;

import physx.NativeObject;
import physx.common.PxInputData;
import physx.support.PxU8Ptr;

/**
 * default implementation of a memory read stream
 * @see physx.common.PxInputData
 */
public class PxDefaultMemoryInputData extends PxInputData {

    protected PxDefaultMemoryInputData() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxDefaultMemoryInputData wrapPointer(long address) {
        return address != 0L ? new PxDefaultMemoryInputData(address) : null;
    }
    
    public static PxDefaultMemoryInputData arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxDefaultMemoryInputData(long address) {
        super(address);
    }

    // Constructors

    /**
     * @param data   WebIDL type: {@link PxU8Ptr} [Ref]
     * @param length WebIDL type: unsigned long
     */
    public PxDefaultMemoryInputData(PxU8Ptr data, int length) {
        address = Raw.PxDefaultMemoryInputData(data.getAddress(), length);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param dest  WebIDL type: VoidPtr
     * @param count WebIDL type: unsigned long
     * @return WebIDL type: unsigned long
     */
    public int read(NativeObject dest, int count) {
        checkNotNull();
        return Raw.read(address, dest.getAddress(), count);
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getLength() {
        checkNotNull();
        return Raw.getLength(address);
    }

    /**
     * @param pos WebIDL type: unsigned long
     */
    public void seek(int pos) {
        checkNotNull();
        Raw.seek(address, pos);
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int tell() {
        checkNotNull();
        return Raw.tell(address);
    }

    public static class Raw {
        public static native long PxDefaultMemoryInputData(long data, int length);
        public static native void destroy(long address);
        public static native int read(long address, long dest, int count);
        public static native int getLength(long address);
        public static native void seek(long address, int pos);
        public static native int tell(long address);
    }
}
