package physx.extensions;

/**
 * Flags specific to the spherical joint.
 * <p>
 * <b>See also:</b> PxSphericalJoint
 */
public enum PxSphericalJointFlagEnum {

    eLIMIT_ENABLED(geteLIMIT_ENABLED());
    public final int value;
    
    PxSphericalJointFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteLIMIT_ENABLED();
    private static int geteLIMIT_ENABLED() {
        de.fabmax.physxjni.Loader.load();
        return _geteLIMIT_ENABLED();
    }

    private static final int LUT_SIZE = 256;
    private static final PxSphericalJointFlagEnum[] enumValues = values();
    private static final PxSphericalJointFlagEnum[] enumLut = new PxSphericalJointFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxSphericalJointFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxSphericalJointFlagEnum forValue(int value) {
        PxSphericalJointFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxSphericalJointFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxSphericalJointFlagEnum: " + value);
        }
        return enumValue;
    }
}
