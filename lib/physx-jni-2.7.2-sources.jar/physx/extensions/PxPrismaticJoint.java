package physx.extensions;


/**
 * A prismatic joint permits relative translational movement between two bodies along
 * an axis, but no relative rotational movement.
 * <p>
 * The axis on each body is defined as the line containing the origin of the joint frame and
 * extending along the x-axis of that frame.
 * <p>
 * \image html prismJoint.png
 * @see PxJoint
 */
public class PxPrismaticJoint extends PxJoint {

    protected PxPrismaticJoint() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxPrismaticJoint wrapPointer(long address) {
        return address != 0L ? new PxPrismaticJoint(address) : null;
    }
    
    public static PxPrismaticJoint arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxPrismaticJoint(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * returns the displacement of the joint along its axis.
     */
    public float getPosition() {
        checkNotNull();
        return Raw.getPosition(address);
    }

    /**
     * returns the velocity of the joint along its axis
     */
    public float getVelocity() {
        checkNotNull();
        return Raw.getVelocity(address);
    }

    /**
     * sets the joint limit  parameters.
     * <p>
     * The limit range is [-PX_MAX_F32, PX_MAX_F32], but note that the width of the limit (upper-lower) must also be
     * a valid float.
     * @see PxJointLinearLimitPair
     */
    public void setLimit(PxJointLinearLimitPair limit) {
        checkNotNull();
        Raw.setLimit(address, limit.getAddress());
    }

    /**
     * Set the flags specific to the Prismatic Joint.
     * <p>
     * <b>Default</b> PxPrismaticJointFlags(0)
     * @param flags The joint flags.
     */
    public void setPrismaticJointFlags(PxPrismaticJointFlags flags) {
        checkNotNull();
        Raw.setPrismaticJointFlags(address, flags.getAddress());
    }

    /**
     * Set a single flag specific to a Prismatic Joint to true or false.
     * @param flag  The flag to set or clear.
     * @param value The value to which to set the flag
     */
    public void setPrismaticJointFlag(PxPrismaticJointFlagEnum flag, boolean value) {
        checkNotNull();
        Raw.setPrismaticJointFlag(address, flag.value, value);
    }

    /**
     * Get the flags specific to the Prismatic Joint.
     * @return the joint flags
     */
    public PxPrismaticJointFlags getPrismaticJointFlags() {
        checkNotNull();
        return PxPrismaticJointFlags.wrapPointer(Raw.getPrismaticJointFlags(address));
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native float getPosition(long address);
        public static native float getVelocity(long address);
        public static native void setLimit(long address, long limit);
        public static native void setPrismaticJointFlags(long address, long flags);
        public static native void setPrismaticJointFlag(long address, int flag, boolean value);
        public static native long getPrismaticJointFlags(long address);
    }
}
