package physx.extensions;

/**
 * Used to specify one of the degrees of freedom of  a D6 joint.
 * <p>
 * <b>See also:</b> PxD6Joint
 */
public enum PxD6AxisEnum {

    /**
     * motion along the X axis
     */
    eX(geteX()),
    /**
     * motion along the Y axis
     */
    eY(geteY()),
    /**
     * motion along the Z axis
     */
    eZ(geteZ()),
    /**
     * motion around the X axis
     */
    eTWIST(geteTWIST()),
    /**
     * motion around the Y axis
     */
    eSWING1(geteSWING1()),
    /**
     * motion around the Z axis
     */
    eSWING2(geteSWING2());
    public final int value;
    
    PxD6AxisEnum(int value) {
        this.value = value;
    }

    private static native int _geteX();
    private static int geteX() {
        de.fabmax.physxjni.Loader.load();
        return _geteX();
    }

    private static native int _geteY();
    private static int geteY() {
        de.fabmax.physxjni.Loader.load();
        return _geteY();
    }

    private static native int _geteZ();
    private static int geteZ() {
        de.fabmax.physxjni.Loader.load();
        return _geteZ();
    }

    private static native int _geteTWIST();
    private static int geteTWIST() {
        de.fabmax.physxjni.Loader.load();
        return _geteTWIST();
    }

    private static native int _geteSWING1();
    private static int geteSWING1() {
        de.fabmax.physxjni.Loader.load();
        return _geteSWING1();
    }

    private static native int _geteSWING2();
    private static int geteSWING2() {
        de.fabmax.physxjni.Loader.load();
        return _geteSWING2();
    }

    private static final int LUT_SIZE = 256;
    private static final PxD6AxisEnum[] enumValues = values();
    private static final PxD6AxisEnum[] enumLut = new PxD6AxisEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxD6AxisEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxD6AxisEnum forValue(int value) {
        PxD6AxisEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxD6AxisEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxD6AxisEnum: " + value);
        }
        return enumValue;
    }
}
