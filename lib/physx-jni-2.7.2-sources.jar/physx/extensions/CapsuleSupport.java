package physx.extensions;


/**
 * Pre-made support mapping for a capsule
 */
public class CapsuleSupport extends Support {

    protected CapsuleSupport() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static CapsuleSupport wrapPointer(long address) {
        return address != 0L ? new CapsuleSupport(address) : null;
    }
    
    public static CapsuleSupport arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected CapsuleSupport(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address    Pre-allocated memory, where the object is created.
     * @param radius     WebIDL type: float
     * @param halfHeight WebIDL type: float
     * @return Stack allocated object of CapsuleSupport
     */
    public static CapsuleSupport createAt(long address, float radius, float halfHeight) {
        Raw.CapsuleSupport_placed(address, radius, halfHeight);
        CapsuleSupport createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>        Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator  Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate   Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param radius     WebIDL type: float
     * @param halfHeight WebIDL type: float
     * @return Stack allocated object of CapsuleSupport
     */
    public static <T> CapsuleSupport createAt(T allocator, Allocator<T> allocate, float radius, float halfHeight) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.CapsuleSupport_placed(address, radius, halfHeight);
        CapsuleSupport createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * Constructs a CapsuleSupport for capsule radius and halfHeight
     */
    public CapsuleSupport(float radius, float halfHeight) {
        address = Raw.CapsuleSupport(radius, halfHeight);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: float
     */
    public float getRadius() {
        checkNotNull();
        return Raw.getRadius(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setRadius(float value) {
        checkNotNull();
        Raw.setRadius(address, value);
    }

    public float getHalfHeight() {
        checkNotNull();
        return Raw.getHalfHeight(address);
    }

    public void setHalfHeight(float value) {
        checkNotNull();
        Raw.setHalfHeight(address, value);
    }

    public static class Raw {
        public static native void CapsuleSupport_placed(long address, float radius, float halfHeight);
        public static native long CapsuleSupport(float radius, float halfHeight);
        public static native void destroy(long address);
        public static native float getRadius(long address);
        public static native void setRadius(long address, float value);
        public static native float getHalfHeight(long address);
        public static native void setHalfHeight(long address, float value);
    }
}
