package physx.extensions;

import physx.common.PxTransform;
import physx.common.PxVec3;

/**
 *  A D6 joint is a general constraint between two actors.
 * <p>
 *  It allows the application to individually define the linear and rotational degrees of freedom, 
 *  and also to configure a variety of limits and driven degrees of freedom.
 * <p>
 *  By default all degrees of freedom are locked. So to create a prismatic joint with free motion 
 *  along the x-axis:
 * <p>
 *  \code 
 *     ...
 *     joint-&gt;setMotion(PxD6Axis::eX, PxD6JointMotion::eFREE);
 *      ...
 *  \endcode
 * <p>
 *  Or a Revolute joint with motion free allowed around the x-axis:
 * <p>
 *  \code
 *     ... 
 *  joint-&gt;setMotion(PxD6Axis::eTWIST, PxD6JointMotion::eFREE);
 *     ...
 *  \endcode
 * <p>
 *  Degrees of freedom may also be set to limited instead of locked.
 * <p>
 *  There are two different kinds of linear limits available. The first kind is a single limit value
 *  for all linear degrees of freedom, which may act as a linear, circular, or spherical limit depending
 *  on which degrees of freedom are limited. This is similar to a distance limit. Then, the second kind
 *  supports a pair of limit values for each linear axis, which can be used to implement a traditional
 *  prismatic joint for example.
 * <p>
 *  If the twist degree of freedom is limited, is supports upper and lower limits. The two swing degrees
 *  of freedom are limited with a cone limit.
 * @see PxJoint
 */
public class PxD6Joint extends PxJoint {

    protected PxD6Joint() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxD6Joint wrapPointer(long address) {
        return address != 0L ? new PxD6Joint(address) : null;
    }
    
    public static PxD6Joint arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxD6Joint(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * Set the motion type around the specified axis.
     * <p>
     * Each axis may independently specify that the degree of freedom is locked (blocking relative movement
     * along or around this axis), limited by the corresponding limit, or free.
     * @param axis the axis around which motion is specified
     * @param type the motion type around the specified axis
     * <p>
     * <b>Default:</b> all degrees of freedom are locked
     * @see #getMotion
     */
    public void setMotion(PxD6AxisEnum axis, PxD6MotionEnum type) {
        checkNotNull();
        Raw.setMotion(address, axis.value, type.value);
    }

    /**
     * Get the motion type around the specified axis.
     * @see #setMotion
     * @param axis the degree of freedom around which the motion type is specified
     * @return the motion type around the specified axis
     */
    public PxD6MotionEnum getMotion(PxD6AxisEnum axis) {
        checkNotNull();
        return PxD6MotionEnum.forValue(Raw.getMotion(address, axis.value));
    }

    /**
     * get the twist angle of the joint, in the range (-2*Pi, 2*Pi]
     */
    public float getTwistAngle() {
        checkNotNull();
        return Raw.getTwistAngle(address);
    }

    /**
     * get the swing angle of the joint from the Y axis
     */
    public float getSwingYAngle() {
        checkNotNull();
        return Raw.getSwingYAngle(address);
    }

    /**
     * get the swing angle of the joint from the Z axis
     */
    public float getSwingZAngle() {
        checkNotNull();
        return Raw.getSwingZAngle(address);
    }

    /**
     * Set the distance limit for the joint. 
     * <p>
     * A single limit constraints all linear limited degrees of freedom, forming a linear, circular 
     * or spherical constraint on motion depending on the number of limited degrees. This is similar
     * to a distance limit.
     * @param limit the distance limit structure
     * @see PxJointLinearLimit
     */
    public void setDistanceLimit(PxJointLinearLimit limit) {
        checkNotNull();
        Raw.setDistanceLimit(address, limit.getAddress());
    }

    /**
     * Set the linear limit for a given linear axis. 
     * <p>
     * This function extends the previous setDistanceLimit call with the following features:
     * - there can be a different limit for each linear axis
     * - each limit is defined by two values, i.e. it can now be asymmetric
     * <p>
     * This can be used to create prismatic joints similar to PxPrismaticJoint, or point-in-quad joints,
     * or point-in-box joints.
     * @param axis  The limited linear axis (must be PxD6Axis::eX, PxD6Axis::eY or PxD6Axis::eZ)
     * @param limit The linear limit pair structure
     */
    public void setLinearLimit(PxD6AxisEnum axis, PxJointLinearLimitPair limit) {
        checkNotNull();
        Raw.setLinearLimit(address, axis.value, limit.getAddress());
    }

    /**
     * Set the twist limit for the joint. 
     * <p>
     * The twist limit controls the range of motion around the twist axis. 
     * <p>
     * The limit angle range is (-2*Pi, 2*Pi).
     * @param limit the twist limit structure
     * @see PxJointAngularLimitPair
     */
    public void setTwistLimit(PxJointAngularLimitPair limit) {
        checkNotNull();
        Raw.setTwistLimit(address, limit.getAddress());
    }

    /**
     * Set the swing cone limit for the joint. 
     * <p>
     * The cone limit is used if either or both swing axes are limited. The extents are 
     * symmetrical and measured in the frame of the parent. If only one swing degree of freedom 
     * is limited, the corresponding value from the cone limit defines the limit range.
     * @param limit the cone limit structure
     * @see PxJointLimitCone
     */
    public void setSwingLimit(PxJointLimitCone limit) {
        checkNotNull();
        Raw.setSwingLimit(address, limit.getAddress());
    }

    /**
     * Set a pyramidal swing limit for the joint. 
     * <p>
     * The pyramid limits will only be used in the following cases:
     * - both swing Y and Z are limited. The limit shape is then a pyramid.
     * - Y is limited and Z is locked, or vice versa. The limit shape is an asymmetric angular section, similar to
     * what is supported for the twist axis.
     * The remaining cases (Y limited and Z is free, or vice versa) are not supported.
     * @param limit the cone limit structure
     * @see PxJointLimitPyramid
     */
    public void setPyramidSwingLimit(PxJointLimitPyramid limit) {
        checkNotNull();
        Raw.setPyramidSwingLimit(address, limit.getAddress());
    }

    /**
     * Set the drive parameters for the specified drive type.
     * <p>
     * <b>Note:</b> The angular drive configuration (see #PxD6AngularDriveConfig) defines what type of
     *       angular drives will be accepted.
     * @param index the type of drive being specified
     * @param drive the drive parameters
     * @see #getDrive
     * @see PxD6JointDrive
     * <p>
     * <b>Default</b> The default drive spring and damping values are zero, the force limit is PX_MAX_F32, and no flags are set.
     */
    public void setDrive(PxD6DriveEnum index, PxD6JointDrive drive) {
        checkNotNull();
        Raw.setDrive(address, index.value, drive.getAddress());
    }

    /**
     * Get the drive parameters for the specified drive type. 
     * <p>
     * <b>Note:</b> The angular drive configuration (see #PxD6AngularDriveConfig) defines what type of
     *       angular drives will be accepted.
     * @param index the specified drive type
     * @see #setDrive
     * @see PxD6JointDrive
     */
    public PxD6JointDrive getDrive(PxD6DriveEnum index) {
        checkNotNull();
        return PxD6JointDrive.wrapPointer(Raw.getDrive(address, index.value));
    }

    /**
     * Set the drive goal pose 
     * <p>
     * The goal is relative to the constraint frame of actor[0]
     * <p>
     * <b>Default</b> the identity transform
     * @param pose The goal drive pose if positional drive is in use. 
     * wake counters to #PxSceneDesc::wakeCounterResetValue if the counter value is below the reset value.
     * @see #setDrivePosition
     */
    public void setDrivePosition(PxTransform pose) {
        checkNotNull();
        Raw.setDrivePosition(address, pose.getAddress());
    }

    /**
     * Set the drive goal pose 
     * <p>
     * The goal is relative to the constraint frame of actor[0]
     * <p>
     * <b>Default</b> the identity transform
     * @param pose The goal drive pose if positional drive is in use. 
     * @param autowake If true and the attached actors are in a scene, this call wakes them up and increases their
     * wake counters to #PxSceneDesc::wakeCounterResetValue if the counter value is below the reset value.
     * @see #setDrivePosition
     */
    public void setDrivePosition(PxTransform pose, boolean autowake) {
        checkNotNull();
        Raw.setDrivePosition(address, pose.getAddress(), autowake);
    }

    /**
     * Get the drive goal pose.
     * @see #getDrivePosition
     */
    public PxTransform getDrivePosition() {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getDrivePosition(address));
    }

    /**
     * Set the target goal velocity for drive.
     * <p>
     * The velocity is measured in the constraint frame of actor[0]
     * @param linear The goal velocity for linear drive
     * @param angular The goal velocity for angular drive
     * wake counters to #PxSceneDesc::wakeCounterResetValue if the counter value is below the reset value.
     * @see #getDriveVelocity
     */
    public void setDriveVelocity(PxVec3 linear, PxVec3 angular) {
        checkNotNull();
        Raw.setDriveVelocity(address, linear.getAddress(), angular.getAddress());
    }

    /**
     * Get the target goal velocity for joint drive.
     * @param linear The goal velocity for linear drive
     * @param angular The goal velocity for angular drive
     * @see #setDriveVelocity
     */
    public void getDriveVelocity(PxVec3 linear, PxVec3 angular) {
        checkNotNull();
        Raw.getDriveVelocity(address, linear.getAddress(), angular.getAddress());
    }

    /**
     * Set the angular drive model to apply.
     * <p>
     * <b>Note:</b> The configuration will limit the allowed set of angular drive types (see #PxD6Drive) to use
     *       when calling #PxD6Joint::setDrive().
     * <p>
     * <b>Note:</b> Changing the angular drive model, will reset all the parameters for the angular drives to
     *       their default values (see #PxD6Joint::setDrive() for information on the default values).
     * @param config The angular drive model to apply.
     * @see #getAngularDriveConfig
     * <p>
     * <b>Default</b> PxD6AngularDriveConfig::eLEGACY but will soon change to PxD6AngularDriveConfig::eSWING_TWIST
     */
    public void setAngularDriveConfig(PxD6AngularDriveConfigEnum config) {
        checkNotNull();
        Raw.setAngularDriveConfig(address, config.value);
    }

    /**
     * Get the angular drive model to apply.
     * @return The angular drive model to apply.
     * @see #setAngularDriveConfig
     */
    public PxD6AngularDriveConfigEnum getAngularDriveConfig() {
        checkNotNull();
        return PxD6AngularDriveConfigEnum.forValue(Raw.getAngularDriveConfig(address));
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native void setMotion(long address, int axis, int type);
        public static native int getMotion(long address, int axis);
        public static native float getTwistAngle(long address);
        public static native float getSwingYAngle(long address);
        public static native float getSwingZAngle(long address);
        public static native void setDistanceLimit(long address, long limit);
        public static native void setLinearLimit(long address, int axis, long limit);
        public static native void setTwistLimit(long address, long limit);
        public static native void setSwingLimit(long address, long limit);
        public static native void setPyramidSwingLimit(long address, long limit);
        public static native void setDrive(long address, int index, long drive);
        public static native long getDrive(long address, int index);
        public static native void setDrivePosition(long address, long pose);
        public static native void setDrivePosition(long address, long pose, boolean autowake);
        public static native long getDrivePosition(long address);
        public static native void setDriveVelocity(long address, long linear, long angular);
        public static native void getDriveVelocity(long address, long linear, long angular);
        public static native void setAngularDriveConfig(long address, int config);
        public static native int getAngularDriveConfig(long address);
    }
}
