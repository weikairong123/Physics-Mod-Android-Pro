package physx.extensions;

import physx.NativeObject;
import physx.common.PxVec3;

public class PxGjkQueryProximityInfoResult extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxGjkQueryProximityInfoResult wrapPointer(long address) {
        return address != 0L ? new PxGjkQueryProximityInfoResult(address) : null;
    }
    
    public static PxGjkQueryProximityInfoResult arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxGjkQueryProximityInfoResult(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxGjkQueryProximityInfoResult
     */
    public static PxGjkQueryProximityInfoResult createAt(long address) {
        Raw.PxGjkQueryProximityInfoResult_placed(address);
        PxGjkQueryProximityInfoResult createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxGjkQueryProximityInfoResult
     */
    public static <T> PxGjkQueryProximityInfoResult createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxGjkQueryProximityInfoResult_placed(address);
        PxGjkQueryProximityInfoResult createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxGjkQueryProximityInfoResult() {
        address = Raw.PxGjkQueryProximityInfoResult();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: boolean
     */
    public boolean getSuccess() {
        checkNotNull();
        return Raw.getSuccess(address);
    }

    /**
     * @param value WebIDL type: boolean
     */
    public void setSuccess(boolean value) {
        checkNotNull();
        Raw.setSuccess(address, value);
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getPointA() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getPointA(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setPointA(PxVec3 value) {
        checkNotNull();
        Raw.setPointA(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getPointB() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getPointB(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setPointB(PxVec3 value) {
        checkNotNull();
        Raw.setPointB(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getSeparatingAxis() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getSeparatingAxis(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setSeparatingAxis(PxVec3 value) {
        checkNotNull();
        Raw.setSeparatingAxis(address, value.getAddress());
    }

    /**
     * @return WebIDL type: float
     */
    public float getSeparation() {
        checkNotNull();
        return Raw.getSeparation(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setSeparation(float value) {
        checkNotNull();
        Raw.setSeparation(address, value);
    }

    public static class Raw {
        public static native void PxGjkQueryProximityInfoResult_placed(long address);
        public static native long PxGjkQueryProximityInfoResult();
        public static native void destroy(long address);
        public static native boolean getSuccess(long address);
        public static native void setSuccess(long address, boolean value);
        public static native long getPointA(long address);
        public static native void setPointA(long address, long value);
        public static native long getPointB(long address);
        public static native void setPointB(long address, long value);
        public static native long getSeparatingAxis(long address);
        public static native void setSeparatingAxis(long address, long value);
        public static native float getSeparation(long address);
        public static native void setSeparation(long address, float value);
    }
}
