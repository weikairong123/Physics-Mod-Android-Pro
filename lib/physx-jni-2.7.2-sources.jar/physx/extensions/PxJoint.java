package physx.extensions;

import physx.NativeObject;
import physx.common.PxBase;
import physx.common.PxTransform;
import physx.common.PxVec3;
import physx.physics.PxConstraint;
import physx.physics.PxConstraintFlagEnum;
import physx.physics.PxConstraintFlags;
import physx.physics.PxRigidActor;
import physx.physics.PxScene;

/**
 * a base interface providing common functionality for PhysX joints
 */
public class PxJoint extends PxBase {

    protected PxJoint() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxJoint wrapPointer(long address) {
        return address != 0L ? new PxJoint(address) : null;
    }
    
    public static PxJoint arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxJoint(long address) {
        super(address);
    }

    // Attributes

    /**
     * user can assign this to whatever, usually to create a 1:1 relationship with a user object.
     */
    public NativeObject getUserData() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.getUserData(address));
    }

    /**
     * user can assign this to whatever, usually to create a 1:1 relationship with a user object.
     */
    public void setUserData(NativeObject value) {
        checkNotNull();
        Raw.setUserData(address, value.getAddress());
    }

    // Functions

    /**
     * Set the actors for this joint. 
     * <p>
     * An actor may be NULL to indicate the world frame. At most one of the actors may be NULL.
     * @param actor0 the first actor.
     * @param actor1 the second actor
     */
    public void setActors(PxRigidActor actor0, PxRigidActor actor1) {
        checkNotNull();
        Raw.setActors(address, actor0.getAddress(), actor1.getAddress());
    }

    /**
     * Set the joint local pose for an actor. 
     * <p>
     * This is the relative pose which locates the joint frame relative to the actor.
     * @param actor 0 for the first actor, 1 for the second actor.
     * @param localPose the local pose for the actor this joint
     * @see #getLocalPose
     */
    public void setLocalPose(PxJointActorIndexEnum actor, PxTransform localPose) {
        checkNotNull();
        Raw.setLocalPose(address, actor.value, localPose.getAddress());
    }

    /**
     * get the joint local pose for an actor. 
     * @param actor 0 for the first actor, 1 for the second actor.
     * <p>
     * return the local pose for this joint
     * @see #setLocalPose
     */
    public PxTransform getLocalPose(PxJointActorIndexEnum actor) {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getLocalPose(address, actor.value));
    }

    /**
     * get the relative pose for this joint
     * <p>
     * This function returns the pose of the joint frame of actor1 relative to actor0
     */
    public PxTransform getRelativeTransform() {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getRelativeTransform(address));
    }

    /**
     * get the relative linear velocity of the joint
     * <p>
     * This function returns the linear velocity of the origin of the constraint frame of actor1, relative to the origin of the constraint
     * frame of actor0. The value is returned in the constraint frame of actor0
     */
    public PxVec3 getRelativeLinearVelocity() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getRelativeLinearVelocity(address));
    }

    /**
     * get the relative angular velocity of the joint
     * <p>
     * This function returns the angular velocity of actor1 relative to actor0. The value is returned in the constraint frame of actor0
     */
    public PxVec3 getRelativeAngularVelocity() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getRelativeAngularVelocity(address));
    }

    /**
     * set the break force for this joint. 
     * <p>
     * if the constraint force or torque on the joint exceeds the specified values, the joint will break, 
     * at which point it will not constrain the two actors and the flag PxConstraintFlag::eBROKEN will be set. The
     * force and torque are measured in the joint frame of the first actor
     * @param force the maximum force the joint can apply before breaking
     * @param torque the maximum torque the joint can apply before breaking
     */
    public void setBreakForce(float force, float torque) {
        checkNotNull();
        Raw.setBreakForce(address, force, torque);
    }

    /**
     * set the constraint flags for this joint. 
     * @param flags the constraint flags
     */
    public void setConstraintFlags(PxConstraintFlags flags) {
        checkNotNull();
        Raw.setConstraintFlags(address, flags.getAddress());
    }

    /**
     * set a constraint flags for this joint to a specified value. 
     * @param flag the constraint flag
     * @param value the value to which to set the flag
     */
    public void setConstraintFlag(PxConstraintFlagEnum flag, boolean value) {
        checkNotNull();
        Raw.setConstraintFlag(address, flag.value, value);
    }

    /**
     * get the constraint flags for this joint. 
     * @return the constraint flags
     */
    public PxConstraintFlags getConstraintFlags() {
        checkNotNull();
        return PxConstraintFlags.wrapPointer(Raw.getConstraintFlags(address));
    }

    /**
     * set the inverse mass scale for actor0.
     * @param invMassScale the scale to apply to the inverse mass of actor 0 for resolving this constraint
     * @see #getInvMassScale0
     */
    public void setInvMassScale0(float invMassScale) {
        checkNotNull();
        Raw.setInvMassScale0(address, invMassScale);
    }

    /**
     * get the inverse mass scale for actor0.
     * @return inverse mass scale for actor0
     * @see #setInvMassScale0
     */
    public float getInvMassScale0() {
        checkNotNull();
        return Raw.getInvMassScale0(address);
    }

    /**
     * set the inverse mass scale for actor1.
     * @param invMassScale the scale to apply to the inverse mass of actor 1 for resolving this constraint
     * @see #getInvMassScale1
     */
    public void setInvMassScale1(float invMassScale) {
        checkNotNull();
        Raw.setInvMassScale1(address, invMassScale);
    }

    /**
     * get the inverse mass scale for actor1.
     * @return inverse mass scale for actor1
     * @see #setInvMassScale1
     */
    public float getInvMassScale1() {
        checkNotNull();
        return Raw.getInvMassScale1(address);
    }

    /**
     * set the inverse inertia scale for actor0.
     * @param invInertiaScale the scale to apply to the inverse inertia of actor0 for resolving this constraint
     * @see #getInvMassScale0
     */
    public void setInvInertiaScale0(float invInertiaScale) {
        checkNotNull();
        Raw.setInvInertiaScale0(address, invInertiaScale);
    }

    /**
     * get the inverse inertia scale for actor0.
     * @return inverse inertia scale for actor0
     * @see #setInvInertiaScale0
     */
    public float getInvInertiaScale0() {
        checkNotNull();
        return Raw.getInvInertiaScale0(address);
    }

    /**
     * set the inverse inertia scale for actor1.
     * @param invInertiaScale the scale to apply to the inverse inertia of actor1 for resolving this constraint
     * @see #getInvInertiaScale1
     */
    public void setInvInertiaScale1(float invInertiaScale) {
        checkNotNull();
        Raw.setInvInertiaScale1(address, invInertiaScale);
    }

    /**
     * get the inverse inertia scale for actor1.
     * @return inverse inertia scale for actor1
     * @see #setInvInertiaScale1
     */
    public float getInvInertiaScale1() {
        checkNotNull();
        return Raw.getInvInertiaScale1(address);
    }

    /**
     * Retrieves the PxConstraint corresponding to this joint.
     * <p>
     * This can be used to determine, among other things, the force applied at the joint.
     * @return the constraint
     */
    public PxConstraint getConstraint() {
        checkNotNull();
        return PxConstraint.wrapPointer(Raw.getConstraint(address));
    }

    /**
     * Sets a name string for the object that can be retrieved with getName().
     * <p>
     * This is for debugging and is not used by the SDK. The string is not copied by the SDK, 
     * only the pointer is stored.
     * @param name String to set the objects name to.
     * @see #getName
     */
    public void setName(String name) {
        checkNotNull();
        Raw.setName(address, name);
    }

    /**
     * Retrieves the name string set with setName().
     * @return Name string associated with object.
     * @see #setName
     */
    public String getName() {
        checkNotNull();
        return Raw.getName(address);
    }

    /**
     * Retrieves the scene which this joint belongs to.
     * @return Owner Scene. NULL if not part of a scene.
     * @see physx.physics.PxScene
     */
    public PxScene getScene() {
        checkNotNull();
        return PxScene.wrapPointer(Raw.getScene(address));
    }

    public static class Raw {
        public static native long getUserData(long address);
        public static native void setUserData(long address, long value);
        public static native void setActors(long address, long actor0, long actor1);
        public static native void setLocalPose(long address, int actor, long localPose);
        public static native long getLocalPose(long address, int actor);
        public static native long getRelativeTransform(long address);
        public static native long getRelativeLinearVelocity(long address);
        public static native long getRelativeAngularVelocity(long address);
        public static native void setBreakForce(long address, float force, float torque);
        public static native void setConstraintFlags(long address, long flags);
        public static native void setConstraintFlag(long address, int flag, boolean value);
        public static native long getConstraintFlags(long address);
        public static native void setInvMassScale0(long address, float invMassScale);
        public static native float getInvMassScale0(long address);
        public static native void setInvMassScale1(long address, float invMassScale);
        public static native float getInvMassScale1(long address);
        public static native void setInvInertiaScale0(long address, float invInertiaScale);
        public static native float getInvInertiaScale0(long address);
        public static native void setInvInertiaScale1(long address, float invInertiaScale);
        public static native float getInvInertiaScale1(long address);
        public static native long getConstraint(long address);
        public static native void setName(long address, String name);
        public static native String getName(long address);
        public static native long getScene(long address);
    }
}
