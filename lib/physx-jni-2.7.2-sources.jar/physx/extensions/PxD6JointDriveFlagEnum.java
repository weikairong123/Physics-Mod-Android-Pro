package physx.extensions;

/**
 * flags for configuring the drive model of a PxD6Joint
 * <p>
 * <b>See also:</b> PxD6JointDrive PxD6Joint
 */
public enum PxD6JointDriveFlagEnum {

    /**
     * drive spring is for the acceleration at the joint (rather than the force)
     */
    eACCELERATION(geteACCELERATION());
    public final int value;
    
    PxD6JointDriveFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteACCELERATION();
    private static int geteACCELERATION() {
        de.fabmax.physxjni.Loader.load();
        return _geteACCELERATION();
    }

    private static final int LUT_SIZE = 256;
    private static final PxD6JointDriveFlagEnum[] enumValues = values();
    private static final PxD6JointDriveFlagEnum[] enumLut = new PxD6JointDriveFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxD6JointDriveFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxD6JointDriveFlagEnum forValue(int value) {
        PxD6JointDriveFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxD6JointDriveFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxD6JointDriveFlagEnum: " + value);
        }
        return enumValue;
    }
}
