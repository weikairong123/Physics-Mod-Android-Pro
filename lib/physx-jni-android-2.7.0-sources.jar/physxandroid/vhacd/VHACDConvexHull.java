package physxandroid.vhacd;

import physxandroid.NativeObject;
import physxandroid.PlatformChecks;

public class VHACDConvexHull extends NativeObject {

    static {
        PlatformChecks.requirePlatform(15, "physxandroid.vhacd.VHACDConvexHull");
    }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static VHACDConvexHull wrapPointer(long address) {
        return address != 0L ? new VHACDConvexHull(address) : null;
    }
    
    public static VHACDConvexHull arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected VHACDConvexHull(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of VHACDConvexHull
     */
    public static VHACDConvexHull createAt(long address) {
        Raw.VHACDConvexHull_placed(address);
        VHACDConvexHull createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of VHACDConvexHull
     */
    public static <T> VHACDConvexHull createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.VHACDConvexHull_placed(address);
        VHACDConvexHull createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public VHACDConvexHull() {
        address = Raw.VHACDConvexHull();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link Vector_VHACDVertex} [Value]
     */
    public Vector_VHACDVertex getM_points() {
        checkNotNull();
        return Vector_VHACDVertex.wrapPointer(Raw.getM_points(address));
    }

    /**
     * @param value WebIDL type: {@link Vector_VHACDVertex} [Value]
     */
    public void setM_points(Vector_VHACDVertex value) {
        checkNotNull();
        Raw.setM_points(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link Vector_VHACDTriangle} [Value]
     */
    public Vector_VHACDTriangle getM_triangles() {
        checkNotNull();
        return Vector_VHACDTriangle.wrapPointer(Raw.getM_triangles(address));
    }

    /**
     * @param value WebIDL type: {@link Vector_VHACDTriangle} [Value]
     */
    public void setM_triangles(Vector_VHACDTriangle value) {
        checkNotNull();
        Raw.setM_triangles(address, value.getAddress());
    }

    /**
     * @return WebIDL type: double
     */
    public double getM_volume() {
        checkNotNull();
        return Raw.getM_volume(address);
    }

    /**
     * @param value WebIDL type: double
     */
    public void setM_volume(double value) {
        checkNotNull();
        Raw.setM_volume(address, value);
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getM_meshId() {
        checkNotNull();
        return Raw.getM_meshId(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setM_meshId(int value) {
        checkNotNull();
        Raw.setM_meshId(address, value);
    }

    public static class Raw {
        public static native void VHACDConvexHull_placed(long address);
        public static native long VHACDConvexHull();
        public static native void destroy(long address);
        public static native long getM_points(long address);
        public static native void setM_points(long address, long value);
        public static native long getM_triangles(long address);
        public static native void setM_triangles(long address, long value);
        public static native double getM_volume(long address);
        public static native void setM_volume(long address, double value);
        public static native int getM_meshId(long address);
        public static native void setM_meshId(long address, int value);
    }
}
