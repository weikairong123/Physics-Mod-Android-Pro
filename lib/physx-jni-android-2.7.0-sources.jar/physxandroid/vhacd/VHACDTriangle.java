package physxandroid.vhacd;

import physxandroid.NativeObject;
import physxandroid.PlatformChecks;

public class VHACDTriangle extends NativeObject {

    static {
        PlatformChecks.requirePlatform(15, "physxandroid.vhacd.VHACDTriangle");
    }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static VHACDTriangle wrapPointer(long address) {
        return address != 0L ? new VHACDTriangle(address) : null;
    }
    
    public static VHACDTriangle arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected VHACDTriangle(long address) {
        super(address);
    }

    // Constructors

    public VHACDTriangle() {
        address = Raw.VHACDTriangle();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: unsigned long
     */
    public int getMI0() {
        checkNotNull();
        return Raw.getMI0(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setMI0(int value) {
        checkNotNull();
        Raw.setMI0(address, value);
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getMI1() {
        checkNotNull();
        return Raw.getMI1(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setMI1(int value) {
        checkNotNull();
        Raw.setMI1(address, value);
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getMI2() {
        checkNotNull();
        return Raw.getMI2(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setMI2(int value) {
        checkNotNull();
        Raw.setMI2(address, value);
    }

    public static class Raw {
        public static native long VHACDTriangle();
        public static native void destroy(long address);
        public static native int getMI0(long address);
        public static native void setMI0(long address, int value);
        public static native int getMI1(long address);
        public static native void setMI1(long address, int value);
        public static native int getMI2(long address);
        public static native void setMI2(long address, int value);
    }
}
