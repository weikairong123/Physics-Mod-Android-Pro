package physxandroid;

import physxandroid.character.PxControllerManager;
import physxandroid.common.PxDefaultAllocator;
import physxandroid.common.PxDefaultCpuDispatcher;
import physxandroid.common.PxErrorCallback;
import physxandroid.common.PxFoundation;
import physxandroid.common.PxOutputStream;
import physxandroid.common.PxPlane;
import physxandroid.common.PxTolerancesScale;
import physxandroid.common.PxTransform;
import physxandroid.common.PxVec3;
import physxandroid.cooking.PxConvexMeshDesc;
import physxandroid.cooking.PxCookingParams;
import physxandroid.cooking.PxTriangleMeshDesc;
import physxandroid.extensions.PxD6Joint;
import physxandroid.extensions.PxDistanceJoint;
import physxandroid.extensions.PxFixedJoint;
import physxandroid.extensions.PxGearJoint;
import physxandroid.extensions.PxPrismaticJoint;
import physxandroid.extensions.PxRackAndPinionJoint;
import physxandroid.extensions.PxRevoluteJoint;
import physxandroid.extensions.PxSphericalJoint;
import physxandroid.geometry.PxConvexMesh;
import physxandroid.geometry.PxGeometry;
import physxandroid.geometry.PxHeightField;
import physxandroid.geometry.PxHeightFieldDesc;
import physxandroid.geometry.PxTriangleMesh;
import physxandroid.physics.PxMaterial;
import physxandroid.physics.PxPhysics;
import physxandroid.physics.PxRigidActor;
import physxandroid.physics.PxRigidDynamic;
import physxandroid.physics.PxRigidStatic;
import physxandroid.physics.PxScene;
import physxandroid.physics.PxSceneDesc;
import physxandroid.physics.PxShape;
import physxandroid.physics.PxSimulationFilterShader;
import physxandroid.support.PassThroughFilterShader;
import physxandroid.support.PxOmniPvd;
import physxandroid.support.PxPvd;
import physxandroid.support.PxPvdTransport;

public class PxTopLevelFunctions extends NativeObject {

    protected PxTopLevelFunctions() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxTopLevelFunctions wrapPointer(long address) {
        return address != 0L ? new PxTopLevelFunctions(address) : null;
    }
    
    public static PxTopLevelFunctions arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxTopLevelFunctions(long address) {
        super(address);
    }

    // Attributes

    /**
     * @return WebIDL type: unsigned long
     */
    public static int getPHYSICS_VERSION() {
        return Raw.getPHYSICS_VERSION();
    }

    // Functions

    /**
     * @return WebIDL type: {@link PxSimulationFilterShader} [Value]
     */
    public static PxSimulationFilterShader DefaultFilterShader() {
        return PxSimulationFilterShader.wrapPointer(Raw.DefaultFilterShader());
    }

    /**
     * @param sceneDesc    WebIDL type: {@link PxSceneDesc}
     * @param filterShader WebIDL type: {@link PassThroughFilterShader}
     */
    public static void setupPassThroughFilterShader(PxSceneDesc sceneDesc, PassThroughFilterShader filterShader) {
        Raw.setupPassThroughFilterShader(sceneDesc.getAddress(), filterShader.getAddress());
    }

    /**
     * @param scene WebIDL type: {@link PxScene} [Ref]
     * @return WebIDL type: {@link PxControllerManager}
     */
    public static PxControllerManager CreateControllerManager(PxScene scene) {
        return PxControllerManager.wrapPointer(Raw.CreateControllerManager(scene.getAddress()));
    }

    /**
     * @param scene          WebIDL type: {@link PxScene} [Ref]
     * @param lockingEnabled WebIDL type: boolean
     * @return WebIDL type: {@link PxControllerManager}
     */
    public static PxControllerManager CreateControllerManager(PxScene scene, boolean lockingEnabled) {
        return PxControllerManager.wrapPointer(Raw.CreateControllerManager(scene.getAddress(), lockingEnabled));
    }

    /**
     * @param version       WebIDL type: unsigned long
     * @param allocator     WebIDL type: {@link PxDefaultAllocator} [Ref]
     * @param errorCallback WebIDL type: {@link PxErrorCallback} [Ref]
     * @return WebIDL type: {@link PxFoundation}
     */
    public static PxFoundation CreateFoundation(int version, PxDefaultAllocator allocator, PxErrorCallback errorCallback) {
        return PxFoundation.wrapPointer(Raw.CreateFoundation(version, allocator.getAddress(), errorCallback.getAddress()));
    }

    /**
     * @param version    WebIDL type: unsigned long
     * @param foundation WebIDL type: {@link PxFoundation} [Ref]
     * @param params     WebIDL type: {@link PxTolerancesScale} [Const, Ref]
     * @return WebIDL type: {@link PxPhysics}
     */
    public static PxPhysics CreatePhysics(int version, PxFoundation foundation, PxTolerancesScale params) {
        return PxPhysics.wrapPointer(Raw.CreatePhysics(version, foundation.getAddress(), params.getAddress()));
    }

    /**
     * @param version    WebIDL type: unsigned long
     * @param foundation WebIDL type: {@link PxFoundation} [Ref]
     * @param params     WebIDL type: {@link PxTolerancesScale} [Const, Ref]
     * @param pvd        WebIDL type: {@link PxPvd} [Nullable]
     * @return WebIDL type: {@link PxPhysics}
     */
    public static PxPhysics CreatePhysics(int version, PxFoundation foundation, PxTolerancesScale params, PxPvd pvd) {
        return PxPhysics.wrapPointer(Raw.CreatePhysics(version, foundation.getAddress(), params.getAddress(), (pvd != null ? pvd.getAddress() : 0L)));
    }

    /**
     * @param version    WebIDL type: unsigned long
     * @param foundation WebIDL type: {@link PxFoundation} [Ref]
     * @param params     WebIDL type: {@link PxTolerancesScale} [Const, Ref]
     * @param pvd        WebIDL type: {@link PxPvd} [Nullable]
     * @param omniPvd    WebIDL type: {@link PxOmniPvd} [Nullable]
     * @return WebIDL type: {@link PxPhysics}
     */
    public static PxPhysics CreatePhysics(int version, PxFoundation foundation, PxTolerancesScale params, PxPvd pvd, PxOmniPvd omniPvd) {
        return PxPhysics.wrapPointer(Raw.CreatePhysics(version, foundation.getAddress(), params.getAddress(), (pvd != null ? pvd.getAddress() : 0L), (omniPvd != null ? omniPvd.getAddress() : 0L)));
    }

    /**
     * @param numThreads WebIDL type: unsigned long
     * @return WebIDL type: {@link PxDefaultCpuDispatcher}
     */
    public static PxDefaultCpuDispatcher DefaultCpuDispatcherCreate(int numThreads) {
        return PxDefaultCpuDispatcher.wrapPointer(Raw.DefaultCpuDispatcherCreate(numThreads));
    }

    /**
     * @param physics WebIDL type: {@link PxPhysics} [Ref]
     * @return WebIDL type: boolean
     */
    public static boolean InitExtensions(PxPhysics physics) {
        return Raw.InitExtensions(physics.getAddress());
    }

    public static void CloseExtensions() {
        Raw.CloseExtensions();
    }

    /**
     * @param foundation WebIDL type: {@link PxFoundation} [Ref]
     * @return WebIDL type: {@link PxPvd}
     */
    public static PxPvd CreatePvd(PxFoundation foundation) {
        return PxPvd.wrapPointer(Raw.CreatePvd(foundation.getAddress()));
    }

    /**
     * @param host                  WebIDL type: DOMString
     * @param port                  WebIDL type: long
     * @param timeoutInMilliseconds WebIDL type: unsigned long
     * @return WebIDL type: {@link PxPvdTransport} [Platforms=windows;linux;macos]
     */
    public static PxPvdTransport DefaultPvdSocketTransportCreate(String host, int port, int timeoutInMilliseconds) {
        PlatformChecks.requirePlatform(7, "physxandroid.PxTopLevelFunctions");
        return PxPvdTransport.wrapPointer(Raw.DefaultPvdSocketTransportCreate(host, port, timeoutInMilliseconds));
    }

    /**
     * @param foundation WebIDL type: {@link PxFoundation} [Ref]
     * @return WebIDL type: {@link PxOmniPvd} [Platforms=windows;linux;macos]
     */
    public static PxOmniPvd CreateOmniPvd(PxFoundation foundation) {
        PlatformChecks.requirePlatform(7, "physxandroid.PxTopLevelFunctions");
        return PxOmniPvd.wrapPointer(Raw.CreateOmniPvd(foundation.getAddress()));
    }

    /**
     * @param physics     WebIDL type: {@link PxPhysics} [Ref]
     * @param actor0      WebIDL type: {@link PxRigidActor} [Nullable]
     * @param localFrame0 WebIDL type: {@link PxTransform} [Ref]
     * @param actor1      WebIDL type: {@link PxRigidActor} [Nullable]
     * @param localFrame1 WebIDL type: {@link PxTransform} [Ref]
     * @return WebIDL type: {@link PxD6Joint}
     */
    public static PxD6Joint D6JointCreate(PxPhysics physics, PxRigidActor actor0, PxTransform localFrame0, PxRigidActor actor1, PxTransform localFrame1) {
        return PxD6Joint.wrapPointer(Raw.D6JointCreate(physics.getAddress(), (actor0 != null ? actor0.getAddress() : 0L), localFrame0.getAddress(), (actor1 != null ? actor1.getAddress() : 0L), localFrame1.getAddress()));
    }

    /**
     * @param physics     WebIDL type: {@link PxPhysics} [Ref]
     * @param actor0      WebIDL type: {@link PxRigidActor} [Nullable]
     * @param localFrame0 WebIDL type: {@link PxTransform} [Ref]
     * @param actor1      WebIDL type: {@link PxRigidActor} [Nullable]
     * @param localFrame1 WebIDL type: {@link PxTransform} [Ref]
     * @return WebIDL type: {@link PxDistanceJoint}
     */
    public static PxDistanceJoint DistanceJointCreate(PxPhysics physics, PxRigidActor actor0, PxTransform localFrame0, PxRigidActor actor1, PxTransform localFrame1) {
        return PxDistanceJoint.wrapPointer(Raw.DistanceJointCreate(physics.getAddress(), (actor0 != null ? actor0.getAddress() : 0L), localFrame0.getAddress(), (actor1 != null ? actor1.getAddress() : 0L), localFrame1.getAddress()));
    }

    /**
     * @param physics     WebIDL type: {@link PxPhysics} [Ref]
     * @param actor0      WebIDL type: {@link PxRigidActor} [Nullable]
     * @param localFrame0 WebIDL type: {@link PxTransform} [Ref]
     * @param actor1      WebIDL type: {@link PxRigidActor} [Nullable]
     * @param localFrame1 WebIDL type: {@link PxTransform} [Ref]
     * @return WebIDL type: {@link PxFixedJoint}
     */
    public static PxFixedJoint FixedJointCreate(PxPhysics physics, PxRigidActor actor0, PxTransform localFrame0, PxRigidActor actor1, PxTransform localFrame1) {
        return PxFixedJoint.wrapPointer(Raw.FixedJointCreate(physics.getAddress(), (actor0 != null ? actor0.getAddress() : 0L), localFrame0.getAddress(), (actor1 != null ? actor1.getAddress() : 0L), localFrame1.getAddress()));
    }

    /**
     * @param physics     WebIDL type: {@link PxPhysics} [Ref]
     * @param actor0      WebIDL type: {@link PxRigidActor}
     * @param localFrame0 WebIDL type: {@link PxTransform} [Ref]
     * @param actor1      WebIDL type: {@link PxRigidActor}
     * @param localFrame1 WebIDL type: {@link PxTransform} [Ref]
     * @return WebIDL type: {@link PxGearJoint}
     */
    public static PxGearJoint GearJointCreate(PxPhysics physics, PxRigidActor actor0, PxTransform localFrame0, PxRigidActor actor1, PxTransform localFrame1) {
        return PxGearJoint.wrapPointer(Raw.GearJointCreate(physics.getAddress(), actor0.getAddress(), localFrame0.getAddress(), actor1.getAddress(), localFrame1.getAddress()));
    }

    /**
     * @param physics     WebIDL type: {@link PxPhysics} [Ref]
     * @param actor0      WebIDL type: {@link PxRigidActor} [Nullable]
     * @param localFrame0 WebIDL type: {@link PxTransform} [Ref]
     * @param actor1      WebIDL type: {@link PxRigidActor} [Nullable]
     * @param localFrame1 WebIDL type: {@link PxTransform} [Ref]
     * @return WebIDL type: {@link PxPrismaticJoint}
     */
    public static PxPrismaticJoint PrismaticJointCreate(PxPhysics physics, PxRigidActor actor0, PxTransform localFrame0, PxRigidActor actor1, PxTransform localFrame1) {
        return PxPrismaticJoint.wrapPointer(Raw.PrismaticJointCreate(physics.getAddress(), (actor0 != null ? actor0.getAddress() : 0L), localFrame0.getAddress(), (actor1 != null ? actor1.getAddress() : 0L), localFrame1.getAddress()));
    }

    /**
     * @param physics     WebIDL type: {@link PxPhysics} [Ref]
     * @param actor0      WebIDL type: {@link PxRigidActor}
     * @param localFrame0 WebIDL type: {@link PxTransform} [Ref]
     * @param actor1      WebIDL type: {@link PxRigidActor}
     * @param localFrame1 WebIDL type: {@link PxTransform} [Ref]
     * @return WebIDL type: {@link PxRackAndPinionJoint}
     */
    public static PxRackAndPinionJoint RackAndPinionJointCreate(PxPhysics physics, PxRigidActor actor0, PxTransform localFrame0, PxRigidActor actor1, PxTransform localFrame1) {
        return PxRackAndPinionJoint.wrapPointer(Raw.RackAndPinionJointCreate(physics.getAddress(), actor0.getAddress(), localFrame0.getAddress(), actor1.getAddress(), localFrame1.getAddress()));
    }

    /**
     * @param physics     WebIDL type: {@link PxPhysics} [Ref]
     * @param actor0      WebIDL type: {@link PxRigidActor} [Nullable]
     * @param localFrame0 WebIDL type: {@link PxTransform} [Ref]
     * @param actor1      WebIDL type: {@link PxRigidActor} [Nullable]
     * @param localFrame1 WebIDL type: {@link PxTransform} [Ref]
     * @return WebIDL type: {@link PxRevoluteJoint}
     */
    public static PxRevoluteJoint RevoluteJointCreate(PxPhysics physics, PxRigidActor actor0, PxTransform localFrame0, PxRigidActor actor1, PxTransform localFrame1) {
        return PxRevoluteJoint.wrapPointer(Raw.RevoluteJointCreate(physics.getAddress(), (actor0 != null ? actor0.getAddress() : 0L), localFrame0.getAddress(), (actor1 != null ? actor1.getAddress() : 0L), localFrame1.getAddress()));
    }

    /**
     * @param physics     WebIDL type: {@link PxPhysics} [Ref]
     * @param actor0      WebIDL type: {@link PxRigidActor} [Nullable]
     * @param localFrame0 WebIDL type: {@link PxTransform} [Ref]
     * @param actor1      WebIDL type: {@link PxRigidActor} [Nullable]
     * @param localFrame1 WebIDL type: {@link PxTransform} [Ref]
     * @return WebIDL type: {@link PxSphericalJoint}
     */
    public static PxSphericalJoint SphericalJointCreate(PxPhysics physics, PxRigidActor actor0, PxTransform localFrame0, PxRigidActor actor1, PxTransform localFrame1) {
        return PxSphericalJoint.wrapPointer(Raw.SphericalJointCreate(physics.getAddress(), (actor0 != null ? actor0.getAddress() : 0L), localFrame0.getAddress(), (actor1 != null ? actor1.getAddress() : 0L), localFrame1.getAddress()));
    }

    /**
     * @param params WebIDL type: {@link PxCookingParams} [Const, Ref]
     * @param desc   WebIDL type: {@link PxConvexMeshDesc} [Const, Ref]
     * @return WebIDL type: {@link PxConvexMesh}
     */
    public static PxConvexMesh CreateConvexMesh(PxCookingParams params, PxConvexMeshDesc desc) {
        return PxConvexMesh.wrapPointer(Raw.CreateConvexMesh(params.getAddress(), desc.getAddress()));
    }

    /**
     * @param params WebIDL type: {@link PxCookingParams} [Const, Ref]
     * @param desc   WebIDL type: {@link PxTriangleMeshDesc} [Const, Ref]
     * @return WebIDL type: {@link PxTriangleMesh}
     */
    public static PxTriangleMesh CreateTriangleMesh(PxCookingParams params, PxTriangleMeshDesc desc) {
        return PxTriangleMesh.wrapPointer(Raw.CreateTriangleMesh(params.getAddress(), desc.getAddress()));
    }

    /**
     * @param desc WebIDL type: {@link PxHeightFieldDesc} [Const, Ref]
     * @return WebIDL type: {@link PxHeightField}
     */
    public static PxHeightField CreateHeightField(PxHeightFieldDesc desc) {
        return PxHeightField.wrapPointer(Raw.CreateHeightField(desc.getAddress()));
    }

    /**
     * @param params WebIDL type: {@link PxCookingParams} [Const, Ref]
     * @param desc   WebIDL type: {@link PxTriangleMeshDesc} [Const, Ref]
     * @param stream WebIDL type: {@link PxOutputStream} [Ref]
     * @return WebIDL type: boolean
     */
    public static boolean CookTriangleMesh(PxCookingParams params, PxTriangleMeshDesc desc, PxOutputStream stream) {
        return Raw.CookTriangleMesh(params.getAddress(), desc.getAddress(), stream.getAddress());
    }

    /**
     * @param params WebIDL type: {@link PxCookingParams} [Const, Ref]
     * @param desc   WebIDL type: {@link PxConvexMeshDesc} [Const, Ref]
     * @param stream WebIDL type: {@link PxOutputStream} [Ref]
     * @return WebIDL type: boolean
     */
    public static boolean CookConvexMesh(PxCookingParams params, PxConvexMeshDesc desc, PxOutputStream stream) {
        return Raw.CookConvexMesh(params.getAddress(), desc.getAddress(), stream.getAddress());
    }

    /**
     * @param sdk       WebIDL type: {@link PxPhysics} [Ref]
     * @param transform WebIDL type: {@link PxTransform} [Const, Ref]
     * @param shape     WebIDL type: {@link PxShape} [Ref]
     * @param density   WebIDL type: float
     * @return WebIDL type: {@link PxRigidDynamic}
     */
    public static PxRigidDynamic CreateDynamicFromShape(PxPhysics sdk, PxTransform transform, PxShape shape, float density) {
        return PxRigidDynamic.wrapPointer(Raw.CreateDynamicFromShape(sdk.getAddress(), transform.getAddress(), shape.getAddress(), density));
    }

    /**
     * @param sdk       WebIDL type: {@link PxPhysics} [Ref]
     * @param transform WebIDL type: {@link PxTransform} [Const, Ref]
     * @param geometry  WebIDL type: {@link PxGeometry} [Const, Ref]
     * @param material  WebIDL type: {@link PxMaterial} [Ref]
     * @param density   WebIDL type: float
     * @return WebIDL type: {@link PxRigidDynamic}
     */
    public static PxRigidDynamic CreateDynamic(PxPhysics sdk, PxTransform transform, PxGeometry geometry, PxMaterial material, float density) {
        return PxRigidDynamic.wrapPointer(Raw.CreateDynamic(sdk.getAddress(), transform.getAddress(), geometry.getAddress(), material.getAddress(), density));
    }

    /**
     * @param sdk         WebIDL type: {@link PxPhysics} [Ref]
     * @param transform   WebIDL type: {@link PxTransform} [Const, Ref]
     * @param geometry    WebIDL type: {@link PxGeometry} [Const, Ref]
     * @param material    WebIDL type: {@link PxMaterial} [Ref]
     * @param density     WebIDL type: float
     * @param shapeOffset WebIDL type: {@link PxTransform} [Const, Ref]
     * @return WebIDL type: {@link PxRigidDynamic}
     */
    public static PxRigidDynamic CreateDynamic(PxPhysics sdk, PxTransform transform, PxGeometry geometry, PxMaterial material, float density, PxTransform shapeOffset) {
        return PxRigidDynamic.wrapPointer(Raw.CreateDynamic(sdk.getAddress(), transform.getAddress(), geometry.getAddress(), material.getAddress(), density, shapeOffset.getAddress()));
    }

    /**
     * @param sdk       WebIDL type: {@link PxPhysics} [Ref]
     * @param transform WebIDL type: {@link PxTransform} [Const, Ref]
     * @param shape     WebIDL type: {@link PxShape} [Ref]
     * @param density   WebIDL type: float
     * @return WebIDL type: {@link PxRigidDynamic}
     */
    public static PxRigidDynamic CreateKinematicFromShape(PxPhysics sdk, PxTransform transform, PxShape shape, float density) {
        return PxRigidDynamic.wrapPointer(Raw.CreateKinematicFromShape(sdk.getAddress(), transform.getAddress(), shape.getAddress(), density));
    }

    /**
     * @param sdk       WebIDL type: {@link PxPhysics} [Ref]
     * @param transform WebIDL type: {@link PxTransform} [Const, Ref]
     * @param geometry  WebIDL type: {@link PxGeometry} [Const, Ref]
     * @param material  WebIDL type: {@link PxMaterial} [Ref]
     * @param density   WebIDL type: float
     * @return WebIDL type: {@link PxRigidDynamic}
     */
    public static PxRigidDynamic CreateKinematic(PxPhysics sdk, PxTransform transform, PxGeometry geometry, PxMaterial material, float density) {
        return PxRigidDynamic.wrapPointer(Raw.CreateKinematic(sdk.getAddress(), transform.getAddress(), geometry.getAddress(), material.getAddress(), density));
    }

    /**
     * @param sdk         WebIDL type: {@link PxPhysics} [Ref]
     * @param transform   WebIDL type: {@link PxTransform} [Const, Ref]
     * @param geometry    WebIDL type: {@link PxGeometry} [Const, Ref]
     * @param material    WebIDL type: {@link PxMaterial} [Ref]
     * @param density     WebIDL type: float
     * @param shapeOffset WebIDL type: {@link PxTransform} [Const, Ref]
     * @return WebIDL type: {@link PxRigidDynamic}
     */
    public static PxRigidDynamic CreateKinematic(PxPhysics sdk, PxTransform transform, PxGeometry geometry, PxMaterial material, float density, PxTransform shapeOffset) {
        return PxRigidDynamic.wrapPointer(Raw.CreateKinematic(sdk.getAddress(), transform.getAddress(), geometry.getAddress(), material.getAddress(), density, shapeOffset.getAddress()));
    }

    /**
     * @param sdk       WebIDL type: {@link PxPhysics} [Ref]
     * @param transform WebIDL type: {@link PxTransform} [Const, Ref]
     * @param shape     WebIDL type: {@link PxShape} [Ref]
     * @return WebIDL type: {@link PxRigidStatic}
     */
    public static PxRigidStatic CreateStaticFromShape(PxPhysics sdk, PxTransform transform, PxShape shape) {
        return PxRigidStatic.wrapPointer(Raw.CreateStaticFromShape(sdk.getAddress(), transform.getAddress(), shape.getAddress()));
    }

    /**
     * @param sdk         WebIDL type: {@link PxPhysics} [Ref]
     * @param transform   WebIDL type: {@link PxTransform} [Const, Ref]
     * @param geometry    WebIDL type: {@link PxGeometry} [Const, Ref]
     * @param material    WebIDL type: {@link PxMaterial} [Ref]
     * @param shapeOffset WebIDL type: {@link PxTransform} [Const, Ref]
     * @return WebIDL type: {@link PxRigidStatic}
     */
    public static PxRigidStatic CreateStatic(PxPhysics sdk, PxTransform transform, PxGeometry geometry, PxMaterial material, PxTransform shapeOffset) {
        return PxRigidStatic.wrapPointer(Raw.CreateStatic(sdk.getAddress(), transform.getAddress(), geometry.getAddress(), material.getAddress(), shapeOffset.getAddress()));
    }

    /**
     * @param sdk      WebIDL type: {@link PxPhysics} [Ref]
     * @param plane    WebIDL type: {@link PxPlane} [Const, Ref]
     * @param material WebIDL type: {@link PxMaterial} [Ref]
     * @return WebIDL type: {@link PxRigidStatic}
     */
    public static PxRigidStatic CreatePlane(PxPhysics sdk, PxPlane plane, PxMaterial material) {
        return PxRigidStatic.wrapPointer(Raw.CreatePlane(sdk.getAddress(), plane.getAddress(), material.getAddress()));
    }

    /**
     * @param physics     WebIDL type: {@link PxPhysics} [Ref]
     * @param from        WebIDL type: {@link PxShape} [Const, Ref]
     * @param isExclusive WebIDL type: boolean
     * @return WebIDL type: {@link PxShape}
     */
    public static PxShape CloneShape(PxPhysics physics, PxShape from, boolean isExclusive) {
        return PxShape.wrapPointer(Raw.CloneShape(physics.getAddress(), from.getAddress(), isExclusive));
    }

    /**
     * @param physicsSDK WebIDL type: {@link PxPhysics} [Ref]
     * @param transform  WebIDL type: {@link PxTransform} [Const, Ref]
     * @param from       WebIDL type: {@link PxRigidActor} [Const, Ref]
     * @return WebIDL type: {@link PxRigidStatic}
     */
    public static PxRigidStatic CloneStatic(PxPhysics physicsSDK, PxTransform transform, PxRigidActor from) {
        return PxRigidStatic.wrapPointer(Raw.CloneStatic(physicsSDK.getAddress(), transform.getAddress(), from.getAddress()));
    }

    /**
     * @param physicsSDK WebIDL type: {@link PxPhysics} [Ref]
     * @param transform  WebIDL type: {@link PxTransform} [Const, Ref]
     * @param from       WebIDL type: {@link PxRigidDynamic} [Const, Ref]
     * @return WebIDL type: {@link PxRigidDynamic}
     */
    public static PxRigidDynamic CloneDynamic(PxPhysics physicsSDK, PxTransform transform, PxRigidDynamic from) {
        return PxRigidDynamic.wrapPointer(Raw.CloneDynamic(physicsSDK.getAddress(), transform.getAddress(), from.getAddress()));
    }

    /**
     * @param actor          WebIDL type: {@link PxRigidActor} [Ref]
     * @param scale          WebIDL type: float
     * @param scaleMassProps WebIDL type: boolean
     */
    public static void ScaleRigidActor(PxRigidActor actor, float scale, boolean scaleMassProps) {
        Raw.ScaleRigidActor(actor.getAddress(), scale, scaleMassProps);
    }

    /**
     * @param curTrans WebIDL type: {@link PxTransform} [Const, Ref]
     * @param linvel   WebIDL type: {@link PxVec3} [Const, Ref]
     * @param angvel   WebIDL type: {@link PxVec3} [Const, Ref]
     * @param timeStep WebIDL type: float
     * @param result   WebIDL type: {@link PxTransform} [Ref]
     */
    public static void IntegrateTransform(PxTransform curTrans, PxVec3 linvel, PxVec3 angvel, float timeStep, PxTransform result) {
        Raw.IntegrateTransform(curTrans.getAddress(), linvel.getAddress(), angvel.getAddress(), timeStep, result.getAddress());
    }

    public static class Raw {
        public static native int getPHYSICS_VERSION();
        public static native long DefaultFilterShader();
        public static native void setupPassThroughFilterShader(long sceneDesc, long filterShader);
        public static native long CreateControllerManager(long scene);
        public static native long CreateControllerManager(long scene, boolean lockingEnabled);
        public static native long CreateFoundation(int version, long allocator, long errorCallback);
        public static native long CreatePhysics(int version, long foundation, long params);
        public static native long CreatePhysics(int version, long foundation, long params, long pvd);
        public static native long CreatePhysics(int version, long foundation, long params, long pvd, long omniPvd);
        public static native long DefaultCpuDispatcherCreate(int numThreads);
        public static native boolean InitExtensions(long physics);
        public static native void CloseExtensions();
        public static native long CreatePvd(long foundation);
        public static native long DefaultPvdSocketTransportCreate(String host, int port, int timeoutInMilliseconds);
        public static native long CreateOmniPvd(long foundation);
        public static native long D6JointCreate(long physics, long actor0, long localFrame0, long actor1, long localFrame1);
        public static native long DistanceJointCreate(long physics, long actor0, long localFrame0, long actor1, long localFrame1);
        public static native long FixedJointCreate(long physics, long actor0, long localFrame0, long actor1, long localFrame1);
        public static native long GearJointCreate(long physics, long actor0, long localFrame0, long actor1, long localFrame1);
        public static native long PrismaticJointCreate(long physics, long actor0, long localFrame0, long actor1, long localFrame1);
        public static native long RackAndPinionJointCreate(long physics, long actor0, long localFrame0, long actor1, long localFrame1);
        public static native long RevoluteJointCreate(long physics, long actor0, long localFrame0, long actor1, long localFrame1);
        public static native long SphericalJointCreate(long physics, long actor0, long localFrame0, long actor1, long localFrame1);
        public static native long CreateConvexMesh(long params, long desc);
        public static native long CreateTriangleMesh(long params, long desc);
        public static native long CreateHeightField(long desc);
        public static native boolean CookTriangleMesh(long params, long desc, long stream);
        public static native boolean CookConvexMesh(long params, long desc, long stream);
        public static native long CreateDynamicFromShape(long sdk, long transform, long shape, float density);
        public static native long CreateDynamic(long sdk, long transform, long geometry, long material, float density);
        public static native long CreateDynamic(long sdk, long transform, long geometry, long material, float density, long shapeOffset);
        public static native long CreateKinematicFromShape(long sdk, long transform, long shape, float density);
        public static native long CreateKinematic(long sdk, long transform, long geometry, long material, float density);
        public static native long CreateKinematic(long sdk, long transform, long geometry, long material, float density, long shapeOffset);
        public static native long CreateStaticFromShape(long sdk, long transform, long shape);
        public static native long CreateStatic(long sdk, long transform, long geometry, long material, long shapeOffset);
        public static native long CreatePlane(long sdk, long plane, long material);
        public static native long CloneShape(long physics, long from, boolean isExclusive);
        public static native long CloneStatic(long physicsSDK, long transform, long from);
        public static native long CloneDynamic(long physicsSDK, long transform, long from);
        public static native void ScaleRigidActor(long actor, float scale, boolean scaleMassProps);
        public static native void IntegrateTransform(long curTrans, long linvel, long angvel, float timeStep, long result);
    }
}
