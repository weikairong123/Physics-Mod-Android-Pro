package physxandroid.vehicle2;

import physxandroid.NativeObject;
import physxandroid.common.PxVec3;

/**
 * PxVehicleTireDirectionState stores the world frame lateral and longtidinal axes of the tire after 
 * projecting the wheel pose in the world frame onto the road geometry plane (also in the world frame).
 */
public class PxVehicleTireDirectionState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleTireDirectionState wrapPointer(long address) {
        return address != 0L ? new PxVehicleTireDirectionState(address) : null;
    }
    
    public static PxVehicleTireDirectionState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleTireDirectionState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleTireDirectionState() {
        address = Raw.PxVehicleTireDirectionState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getDirections(int index) {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getDirections(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setDirections(int index, PxVec3 value) {
        checkNotNull();
        Raw.setDirections(address, index, value.getAddress());
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleTireDirectionState();
        public static native void destroy(long address);
        public static native long getDirections(long address, int index);
        public static native void setDirections(long address, int index, long value);
        public static native void setToDefault(long address);
    }
}
