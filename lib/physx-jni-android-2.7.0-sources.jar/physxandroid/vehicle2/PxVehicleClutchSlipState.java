package physxandroid.vehicle2;

import physxandroid.NativeObject;

/**
 * The clutch is modelled as two spinning plates with one connected to the wheels through the gearing and the other connected to the engine. The clutch slip is angular speed difference of the two plates.
 */
public class PxVehicleClutchSlipState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleClutchSlipState wrapPointer(long address) {
        return address != 0L ? new PxVehicleClutchSlipState(address) : null;
    }
    
    public static PxVehicleClutchSlipState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleClutchSlipState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleClutchSlipState() {
        address = Raw.PxVehicleClutchSlipState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The slip at the clutch.
     * <p>
     * <b>Unit:</b> radians / time
     */
    public float getClutchSlip() {
        checkNotNull();
        return Raw.getClutchSlip(address);
    }

    /**
     * The slip at the clutch.
     * <p>
     * <b>Unit:</b> radians / time
     */
    public void setClutchSlip(float value) {
        checkNotNull();
        Raw.setClutchSlip(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleClutchSlipState();
        public static native void destroy(long address);
        public static native float getClutchSlip(long address);
        public static native void setClutchSlip(long address, float value);
        public static native void setToDefault(long address);
    }
}
