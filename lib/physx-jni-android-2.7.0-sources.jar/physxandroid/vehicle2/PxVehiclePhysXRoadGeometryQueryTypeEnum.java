package physxandroid.vehicle2;

/**
 * PhysX scene queries may be raycasts or sweeps.
 * <b>Note:</b> eNONE will result in no PhysX scene query. This option will not overwrite the associated PxVehicleRoadGeometryState.
 */
public enum PxVehiclePhysXRoadGeometryQueryTypeEnum {

    /**
     * Info about the road geometry below the wheel is provided by the user
     */
    eNONE(geteNONE()),
    /**
     * The road geometry below the wheel is analyzed using a raycast query
     */
    eRAYCAST(geteRAYCAST()),
    /**
     * The road geometry below the wheel is analyzed using a sweep query
     */
    eSWEEP(geteSWEEP());
    public final int value;
    
    PxVehiclePhysXRoadGeometryQueryTypeEnum(int value) {
        this.value = value;
    }

    private static native int _geteNONE();
    private static int geteNONE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteNONE();
    }

    private static native int _geteRAYCAST();
    private static int geteRAYCAST() {
        de.fabmax.physxandroid.Loader.load();
        return _geteRAYCAST();
    }

    private static native int _geteSWEEP();
    private static int geteSWEEP() {
        de.fabmax.physxandroid.Loader.load();
        return _geteSWEEP();
    }

    private static final int LUT_SIZE = 256;
    private static final PxVehiclePhysXRoadGeometryQueryTypeEnum[] enumValues = values();
    private static final PxVehiclePhysXRoadGeometryQueryTypeEnum[] enumLut = new PxVehiclePhysXRoadGeometryQueryTypeEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxVehiclePhysXRoadGeometryQueryTypeEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxVehiclePhysXRoadGeometryQueryTypeEnum forValue(int value) {
        PxVehiclePhysXRoadGeometryQueryTypeEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxVehiclePhysXRoadGeometryQueryTypeEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxVehiclePhysXRoadGeometryQueryTypeEnum: " + value);
        }
        return enumValue;
    }
}
