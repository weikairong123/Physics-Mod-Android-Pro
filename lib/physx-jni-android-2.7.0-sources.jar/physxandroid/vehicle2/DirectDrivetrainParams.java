package physxandroid.vehicle2;

import physxandroid.NativeObject;

public class DirectDrivetrainParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static DirectDrivetrainParams wrapPointer(long address) {
        return address != 0L ? new DirectDrivetrainParams(address) : null;
    }
    
    public static DirectDrivetrainParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected DirectDrivetrainParams(long address) {
        super(address);
    }

    // Constructors

    public DirectDrivetrainParams() {
        address = Raw.DirectDrivetrainParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxVehicleDirectDriveThrottleCommandResponseParams} [Value]
     */
    public PxVehicleDirectDriveThrottleCommandResponseParams getDirectDriveThrottleResponseParams() {
        checkNotNull();
        return PxVehicleDirectDriveThrottleCommandResponseParams.wrapPointer(Raw.getDirectDriveThrottleResponseParams(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleDirectDriveThrottleCommandResponseParams} [Value]
     */
    public void setDirectDriveThrottleResponseParams(PxVehicleDirectDriveThrottleCommandResponseParams value) {
        checkNotNull();
        Raw.setDirectDriveThrottleResponseParams(address, value.getAddress());
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link DirectDrivetrainParams} [Value]
     */
    public DirectDrivetrainParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return DirectDrivetrainParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @param axleDesc WebIDL type: {@link PxVehicleAxleDescription} [Const, Ref]
     * @return WebIDL type: boolean
     */
    public boolean isValid(PxVehicleAxleDescription axleDesc) {
        checkNotNull();
        return Raw.isValid(address, axleDesc.getAddress());
    }

    public static class Raw {
        public static native long DirectDrivetrainParams();
        public static native void destroy(long address);
        public static native long getDirectDriveThrottleResponseParams(long address);
        public static native void setDirectDriveThrottleResponseParams(long address, long value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address, long axleDesc);
    }
}
