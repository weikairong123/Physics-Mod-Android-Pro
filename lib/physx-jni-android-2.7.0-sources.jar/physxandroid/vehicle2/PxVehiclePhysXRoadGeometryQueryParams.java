package physxandroid.vehicle2;

import physxandroid.NativeObject;
import physxandroid.physics.PxQueryFilterCallback;
import physxandroid.physics.PxQueryFilterData;

/**
 * A description of type of PhysX scene query and the filter data to apply to the query.
 */
public class PxVehiclePhysXRoadGeometryQueryParams extends NativeObject {

    protected PxVehiclePhysXRoadGeometryQueryParams() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehiclePhysXRoadGeometryQueryParams wrapPointer(long address) {
        return address != 0L ? new PxVehiclePhysXRoadGeometryQueryParams(address) : null;
    }
    
    public static PxVehiclePhysXRoadGeometryQueryParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehiclePhysXRoadGeometryQueryParams(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * A description of the type of physx scene query to employ.
     */
    public PxVehiclePhysXRoadGeometryQueryTypeEnum getRoadGeometryQueryType() {
        checkNotNull();
        return PxVehiclePhysXRoadGeometryQueryTypeEnum.forValue(Raw.getRoadGeometryQueryType(address));
    }

    /**
     * A description of the type of physx scene query to employ.
     */
    public void setRoadGeometryQueryType(PxVehiclePhysXRoadGeometryQueryTypeEnum value) {
        checkNotNull();
        Raw.setRoadGeometryQueryType(address, value.value);
    }

    /**
     * The default filter data to use for the physx scene query.
     * <p>
     * If per wheel filter data is provided in #filterDataEntries, then this member
     * will be ignored.
     */
    public PxQueryFilterData getDefaultFilterData() {
        checkNotNull();
        return PxQueryFilterData.wrapPointer(Raw.getDefaultFilterData(address));
    }

    /**
     * The default filter data to use for the physx scene query.
     * <p>
     * If per wheel filter data is provided in #filterDataEntries, then this member
     * will be ignored.
     */
    public void setDefaultFilterData(PxQueryFilterData value) {
        checkNotNull();
        Raw.setDefaultFilterData(address, value.getAddress());
    }

    /**
     * Array of filter data entries (one per wheel) to use for the physx scene query.
     * <p>
     * A null pointer is allowed in which case #defaultFilterData will be used for all wheels.
     */
    public PxQueryFilterData getFilterDataEntries() {
        checkNotNull();
        return PxQueryFilterData.wrapPointer(Raw.getFilterDataEntries(address));
    }

    /**
     * Array of filter data entries (one per wheel) to use for the physx scene query.
     * <p>
     * A null pointer is allowed in which case #defaultFilterData will be used for all wheels.
     */
    public void setFilterDataEntries(PxQueryFilterData value) {
        checkNotNull();
        Raw.setFilterDataEntries(address, (value != null ? value.getAddress() : 0L));
    }

    /**
     * A filter callback to be used by the physx scene query
     * <b>Note:</b> A null pointer is allowed.
     */
    public PxQueryFilterCallback getFilterCallback() {
        checkNotNull();
        return PxQueryFilterCallback.wrapPointer(Raw.getFilterCallback(address));
    }

    /**
     * A filter callback to be used by the physx scene query
     * <b>Note:</b> A null pointer is allowed.
     */
    public void setFilterCallback(PxQueryFilterCallback value) {
        checkNotNull();
        Raw.setFilterCallback(address, value.getAddress());
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehiclePhysXRoadGeometryQueryParams} [Value]
     */
    public PxVehiclePhysXRoadGeometryQueryParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehiclePhysXRoadGeometryQueryParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native int getRoadGeometryQueryType(long address);
        public static native void setRoadGeometryQueryType(long address, int value);
        public static native long getDefaultFilterData(long address);
        public static native void setDefaultFilterData(long address, long value);
        public static native long getFilterDataEntries(long address);
        public static native void setFilterDataEntries(long address, long value);
        public static native long getFilterCallback(long address);
        public static native void setFilterCallback(long address, long value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address);
    }
}
