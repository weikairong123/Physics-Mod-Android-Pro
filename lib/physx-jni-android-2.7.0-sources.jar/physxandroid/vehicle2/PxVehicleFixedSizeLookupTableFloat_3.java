package physxandroid.vehicle2;

import physxandroid.NativeObject;

public class PxVehicleFixedSizeLookupTableFloat_3 extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleFixedSizeLookupTableFloat_3 wrapPointer(long address) {
        return address != 0L ? new PxVehicleFixedSizeLookupTableFloat_3(address) : null;
    }
    
    public static PxVehicleFixedSizeLookupTableFloat_3 arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleFixedSizeLookupTableFloat_3(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleFixedSizeLookupTableFloat_3() {
        address = Raw.PxVehicleFixedSizeLookupTableFloat_3();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param x WebIDL type: float
     * @param y WebIDL type: float
     * @return WebIDL type: boolean
     */
    public boolean addPair(float x, float y) {
        checkNotNull();
        return Raw.addPair(address, x, y);
    }

    /**
     * @param x WebIDL type: float
     * @return WebIDL type: float
     */
    public float interpolate(float x) {
        checkNotNull();
        return Raw.interpolate(address, x);
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native long PxVehicleFixedSizeLookupTableFloat_3();
        public static native void destroy(long address);
        public static native boolean addPair(long address, float x, float y);
        public static native float interpolate(long address, float x);
        public static native void clear(long address);
        public static native boolean isValid(long address);
    }
}
