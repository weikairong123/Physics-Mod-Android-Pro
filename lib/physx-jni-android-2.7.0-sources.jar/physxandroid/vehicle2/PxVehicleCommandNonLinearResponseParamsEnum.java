package physxandroid.vehicle2;

/**
 * <b>Note:</b> Brake, drive and steer response typically reduce at increased longitudinal speed. Moreover, response to a brake, throttle or steer command is typically
 * nonlinear and may be subject to dead zones where response is constant with either zero or non-zero response. PxVehicleCommandNonLinearResponseParams allows
 * command responses to be authored as multi-variate piecewise polynomials with normalized command response a function of command value and longitudinal speed.
 */
public enum PxVehicleCommandNonLinearResponseParamsEnum {

    eMAX_NB_COMMAND_VALUES(geteMAX_NB_COMMAND_VALUES());
    public final int value;
    
    PxVehicleCommandNonLinearResponseParamsEnum(int value) {
        this.value = value;
    }

    private static native int _geteMAX_NB_COMMAND_VALUES();
    private static int geteMAX_NB_COMMAND_VALUES() {
        de.fabmax.physxandroid.Loader.load();
        return _geteMAX_NB_COMMAND_VALUES();
    }

    private static final int LUT_SIZE = 256;
    private static final PxVehicleCommandNonLinearResponseParamsEnum[] enumValues = values();
    private static final PxVehicleCommandNonLinearResponseParamsEnum[] enumLut = new PxVehicleCommandNonLinearResponseParamsEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxVehicleCommandNonLinearResponseParamsEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxVehicleCommandNonLinearResponseParamsEnum forValue(int value) {
        PxVehicleCommandNonLinearResponseParamsEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxVehicleCommandNonLinearResponseParamsEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxVehicleCommandNonLinearResponseParamsEnum: " + value);
        }
        return enumValue;
    }
}
