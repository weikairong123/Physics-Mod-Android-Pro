package physxandroid.vehicle2;


/**
 * Distribute a throttle response to the wheels of a direct drive vehicle.
 * <b>Note:</b> The drive torque applied to each wheel on the ith axle is throttleCommand * maxResponse * wheelResponseMultipliers[i].
 * <b>Note:</b> A typical use case is to set maxResponse to be the vehicle's maximum achievable drive torque
 * that occurs when the steer command is equal to 1.0. The array wheelResponseMultipliers[i] would then be used
 * to specify the maximum achievable drive torque per wheel as a fractional multiplier of the vehicle's maximum achievable steer angle.
 */
public class PxVehicleDirectDriveThrottleCommandResponseParams extends PxVehicleCommandResponseParams {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleDirectDriveThrottleCommandResponseParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleDirectDriveThrottleCommandResponseParams(address) : null;
    }
    
    public static PxVehicleDirectDriveThrottleCommandResponseParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleDirectDriveThrottleCommandResponseParams(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleDirectDriveThrottleCommandResponseParams() {
        address = Raw.PxVehicleDirectDriveThrottleCommandResponseParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehicleDirectDriveThrottleCommandResponseParams} [Value]
     */
    public PxVehicleDirectDriveThrottleCommandResponseParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehicleDirectDriveThrottleCommandResponseParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @param axleDesc WebIDL type: {@link PxVehicleAxleDescription} [Const, Ref]
     * @return WebIDL type: boolean
     */
    public boolean isValid(PxVehicleAxleDescription axleDesc) {
        checkNotNull();
        return Raw.isValid(address, axleDesc.getAddress());
    }

    public static class Raw {
        public static native long PxVehicleDirectDriveThrottleCommandResponseParams();
        public static native void destroy(long address);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address, long axleDesc);
    }
}
