package physxandroid.vehicle2;

import physxandroid.NativeObject;

public class PxVehicleAxleDescription extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleAxleDescription wrapPointer(long address) {
        return address != 0L ? new PxVehicleAxleDescription(address) : null;
    }
    
    public static PxVehicleAxleDescription arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleAxleDescription(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleAxleDescription() {
        address = Raw.PxVehicleAxleDescription();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The number of axles on the vehicle
     */
    public int getNbAxles() {
        checkNotNull();
        return Raw.getNbAxles(address);
    }

    /**
     * The number of axles on the vehicle
     */
    public void setNbAxles(int value) {
        checkNotNull();
        Raw.setNbAxles(address, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: unsigned long
     */
    public int getNbWheelsPerAxle(int index) {
        checkNotNull();
        return Raw.getNbWheelsPerAxle(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: unsigned long
     */
    public void setNbWheelsPerAxle(int index, int value) {
        checkNotNull();
        Raw.setNbWheelsPerAxle(address, index, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: unsigned long
     */
    public int getAxleToWheelIds(int index) {
        checkNotNull();
        return Raw.getAxleToWheelIds(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: unsigned long
     */
    public void setAxleToWheelIds(int index, int value) {
        checkNotNull();
        Raw.setAxleToWheelIds(address, index, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: unsigned long
     */
    public int getWheelIdsInAxleOrder(int index) {
        checkNotNull();
        return Raw.getWheelIdsInAxleOrder(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: unsigned long
     */
    public void setWheelIdsInAxleOrder(int index, int value) {
        checkNotNull();
        Raw.setWheelIdsInAxleOrder(address, index, value);
    }

    /**
     * The number of wheels on the vehicle.
     */
    public int getNbWheels() {
        checkNotNull();
        return Raw.getNbWheels(address);
    }

    /**
     * The number of wheels on the vehicle.
     */
    public void setNbWheels(int value) {
        checkNotNull();
        Raw.setNbWheels(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    /**
     * Return the number of wheels on the ith axle.
     * @param i specifies the axle to be queried for its wheel count.
     * @return The number of wheels on the specified axle.
     * @see #getWheelOnAxle
     */
    public int getNbWheelsOnAxle(int i) {
        checkNotNull();
        return Raw.getNbWheelsOnAxle(address, i);
    }

    /**
     * Return the wheel id of the jth wheel on the ith axle.
     * @param j specifies that the wheel id to be returned is the jth wheel in the list of wheels on the specified axle. 
     * @param i specifies the axle to be queried.
     * @return The wheel id of the jth wheel on the ith axle.
     * @see #getNbWheelsOnAxle
     */
    public int getWheelOnAxle(int j, int i) {
        checkNotNull();
        return Raw.getWheelOnAxle(address, j, i);
    }

    /**
     * Return the axle of a specified wheel.
     * @param wheelId is the wheel whose axle is to be queried.
     * @return The axle of the specified wheel.
     */
    public int getAxle(int wheelId) {
        checkNotNull();
        return Raw.getAxle(address, wheelId);
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native long PxVehicleAxleDescription();
        public static native void destroy(long address);
        public static native int getNbAxles(long address);
        public static native void setNbAxles(long address, int value);
        public static native int getNbWheelsPerAxle(long address, int index);
        public static native void setNbWheelsPerAxle(long address, int index, int value);
        public static native int getAxleToWheelIds(long address, int index);
        public static native void setAxleToWheelIds(long address, int index, int value);
        public static native int getWheelIdsInAxleOrder(long address, int index);
        public static native void setWheelIdsInAxleOrder(long address, int index, int value);
        public static native int getNbWheels(long address);
        public static native void setNbWheels(long address, int value);
        public static native void setToDefault(long address);
        public static native int getNbWheelsOnAxle(long address, int i);
        public static native int getWheelOnAxle(long address, int j, int i);
        public static native int getAxle(long address, int wheelId);
        public static native boolean isValid(long address);
    }
}
