package physxandroid.vehicle2;

/**
 * Choose between a potentially more expensive but more accurate solution to the clutch model or a potentially cheaper but less accurate solution.
 * <b>See also:</b> PxVehicleClutchParams
 */
public enum PxVehicleClutchAccuracyModeEnum {

    eESTIMATE(geteESTIMATE()),
    eBEST_POSSIBLE(geteBEST_POSSIBLE());
    public final int value;
    
    PxVehicleClutchAccuracyModeEnum(int value) {
        this.value = value;
    }

    private static native int _geteESTIMATE();
    private static int geteESTIMATE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteESTIMATE();
    }

    private static native int _geteBEST_POSSIBLE();
    private static int geteBEST_POSSIBLE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteBEST_POSSIBLE();
    }

    private static final int LUT_SIZE = 256;
    private static final PxVehicleClutchAccuracyModeEnum[] enumValues = values();
    private static final PxVehicleClutchAccuracyModeEnum[] enumLut = new PxVehicleClutchAccuracyModeEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxVehicleClutchAccuracyModeEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxVehicleClutchAccuracyModeEnum forValue(int value) {
        PxVehicleClutchAccuracyModeEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxVehicleClutchAccuracyModeEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxVehicleClutchAccuracyModeEnum: " + value);
        }
        return enumValue;
    }
}
