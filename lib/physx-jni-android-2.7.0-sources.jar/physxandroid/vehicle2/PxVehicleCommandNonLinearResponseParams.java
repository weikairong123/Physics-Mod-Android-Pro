package physxandroid.vehicle2;

import physxandroid.NativeObject;

/**
 * <b>Note:</b> Brake, drive and steer response typically reduce at increased longitudinal speed. Moreover, response to a brake, throttle or steer command is typically
 * nonlinear and may be subject to dead zones where response is constant with either zero or non-zero response. PxVehicleCommandNonLinearResponseParams allows
 * command responses to be authored as multi-variate piecewise polynomials with normalized command response a function of command value and longitudinal speed.
 */
public class PxVehicleCommandNonLinearResponseParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleCommandNonLinearResponseParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleCommandNonLinearResponseParams(address) : null;
    }
    
    public static PxVehicleCommandNonLinearResponseParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleCommandNonLinearResponseParams(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleCommandNonLinearResponseParams() {
        address = Raw.PxVehicleCommandNonLinearResponseParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getSpeedResponses(int index) {
        checkNotNull();
        return Raw.getSpeedResponses(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setSpeedResponses(int index, float value) {
        checkNotNull();
        Raw.setSpeedResponses(address, index, value);
    }

    /**
     * The number of speeds and normalized responses.
     */
    public short getNbSpeedResponses() {
        checkNotNull();
        return Raw.getNbSpeedResponses(address);
    }

    /**
     * The number of speeds and normalized responses.
     */
    public void setNbSpeedResponses(short value) {
        checkNotNull();
        Raw.setNbSpeedResponses(address, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: short
     */
    public short getSpeedResponsesPerCommandValue(int index) {
        checkNotNull();
        return Raw.getSpeedResponsesPerCommandValue(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: short
     */
    public void setSpeedResponsesPerCommandValue(int index, short value) {
        checkNotNull();
        Raw.setSpeedResponsesPerCommandValue(address, index, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: short
     */
    public short getNbSpeedResponsesPerCommandValue(int index) {
        checkNotNull();
        return Raw.getNbSpeedResponsesPerCommandValue(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: short
     */
    public void setNbSpeedResponsesPerCommandValue(int index, short value) {
        checkNotNull();
        Raw.setNbSpeedResponsesPerCommandValue(address, index, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getCommandValues(int index) {
        checkNotNull();
        return Raw.getCommandValues(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setCommandValues(int index, float value) {
        checkNotNull();
        Raw.setCommandValues(address, index, value);
    }

    /**
     * The number of command values.
     */
    public short getNbCommandValues() {
        checkNotNull();
        return Raw.getNbCommandValues(address);
    }

    /**
     * The number of command values.
     */
    public void setNbCommandValues(short value) {
        checkNotNull();
        Raw.setNbCommandValues(address, value);
    }

    // Functions

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    /**
     * Add a table of normalised response vs speed and associated it with a specified command value. 
     * <b>Note:</b> commandValueSpeedResponses must be authored as a series of strictly increasing speeds with form {speed, normalizedResponse}
     * <b>Note:</b> The responses added must form a series of strictly increasing command values.
     */
    public boolean addResponse(PxVehicleCommandValueResponseTable commandValueSpeedResponses) {
        checkNotNull();
        return Raw.addResponse(address, commandValueSpeedResponses.getAddress());
    }

    public static class Raw {
        public static native long PxVehicleCommandNonLinearResponseParams();
        public static native void destroy(long address);
        public static native float getSpeedResponses(long address, int index);
        public static native void setSpeedResponses(long address, int index, float value);
        public static native short getNbSpeedResponses(long address);
        public static native void setNbSpeedResponses(long address, short value);
        public static native short getSpeedResponsesPerCommandValue(long address, int index);
        public static native void setSpeedResponsesPerCommandValue(long address, int index, short value);
        public static native short getNbSpeedResponsesPerCommandValue(long address, int index);
        public static native void setNbSpeedResponsesPerCommandValue(long address, int index, short value);
        public static native float getCommandValues(long address, int index);
        public static native void setCommandValues(long address, int index, float value);
        public static native short getNbCommandValues(long address);
        public static native void setNbCommandValues(long address, short value);
        public static native void clear(long address);
        public static native boolean addResponse(long address, long commandValueSpeedResponses);
    }
}
