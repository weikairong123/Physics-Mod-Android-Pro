package physxandroid.vehicle2;

import physxandroid.NativeObject;
import physxandroid.common.PxFoundation;
import physxandroid.cooking.PxCookingParams;
import physxandroid.geometry.PxConvexMesh;
import physxandroid.physics.PxPhysics;
import physxandroid.support.PxArray_PxReal;
import physxandroid.support.PxArray_PxVec3;

public class PxVehicleTopLevelFunctions extends NativeObject {

    protected PxVehicleTopLevelFunctions() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleTopLevelFunctions wrapPointer(long address) {
        return address != 0L ? new PxVehicleTopLevelFunctions(address) : null;
    }
    
    public static PxVehicleTopLevelFunctions arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleTopLevelFunctions(long address) {
        super(address);
    }

    // Attributes

    /**
     * @return WebIDL type: unsigned long
     */
    public static int getMAX_NB_ENGINE_TORQUE_CURVE_ENTRIES() {
        return Raw.getMAX_NB_ENGINE_TORQUE_CURVE_ENTRIES();
    }

    // Functions

    /**
     * @param foundation WebIDL type: {@link PxFoundation} [Ref]
     * @return WebIDL type: boolean
     */
    public static boolean InitVehicleExtension(PxFoundation foundation) {
        return Raw.InitVehicleExtension(foundation.getAddress());
    }

    public static void CloseVehicleExtension() {
        Raw.CloseVehicleExtension();
    }

    /**
     * @param nbSprungMasses        WebIDL type: unsigned long
     * @param sprungMassCoordinates WebIDL type: {@link PxArray_PxVec3} [Ref]
     * @param totalMass             WebIDL type: float
     * @param gravityDirection      WebIDL type: {@link PxVehicleAxesEnum} [enum]
     * @param sprungMasses          WebIDL type: {@link PxArray_PxReal} [Ref]
     * @return WebIDL type: boolean
     */
    public static boolean VehicleComputeSprungMasses(int nbSprungMasses, PxArray_PxVec3 sprungMassCoordinates, float totalMass, PxVehicleAxesEnum gravityDirection, PxArray_PxReal sprungMasses) {
        return Raw.VehicleComputeSprungMasses(nbSprungMasses, sprungMassCoordinates.getAddress(), totalMass, gravityDirection.value, sprungMasses.getAddress());
    }

    /**
     * @param vehicleFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param physics      WebIDL type: {@link PxPhysics} [Ref]
     * @param params       WebIDL type: {@link PxCookingParams} [Const, Ref]
     * @return WebIDL type: {@link PxConvexMesh}
     */
    public static PxConvexMesh VehicleUnitCylinderSweepMeshCreate(PxVehicleFrame vehicleFrame, PxPhysics physics, PxCookingParams params) {
        return PxConvexMesh.wrapPointer(Raw.VehicleUnitCylinderSweepMeshCreate(vehicleFrame.getAddress(), physics.getAddress(), params.getAddress()));
    }

    /**
     * @param mesh WebIDL type: {@link PxConvexMesh}
     */
    public static void VehicleUnitCylinderSweepMeshDestroy(PxConvexMesh mesh) {
        Raw.VehicleUnitCylinderSweepMeshDestroy(mesh.getAddress());
    }

    public static class Raw {
        public static native int getMAX_NB_ENGINE_TORQUE_CURVE_ENTRIES();
        public static native boolean InitVehicleExtension(long foundation);
        public static native void CloseVehicleExtension();
        public static native boolean VehicleComputeSprungMasses(int nbSprungMasses, long sprungMassCoordinates, float totalMass, int gravityDirection, long sprungMasses);
        public static native long VehicleUnitCylinderSweepMeshCreate(long vehicleFrame, long physics, long params);
        public static native void VehicleUnitCylinderSweepMeshDestroy(long mesh);
    }
}
