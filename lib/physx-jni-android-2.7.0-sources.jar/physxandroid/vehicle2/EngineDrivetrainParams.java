package physxandroid.vehicle2;

import physxandroid.NativeObject;

public class EngineDrivetrainParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static EngineDrivetrainParams wrapPointer(long address) {
        return address != 0L ? new EngineDrivetrainParams(address) : null;
    }
    
    public static EngineDrivetrainParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected EngineDrivetrainParams(long address) {
        super(address);
    }

    // Constructors

    public EngineDrivetrainParams() {
        address = Raw.EngineDrivetrainParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxVehicleAutoboxParams} [Value]
     */
    public PxVehicleAutoboxParams getAutoboxParams() {
        checkNotNull();
        return PxVehicleAutoboxParams.wrapPointer(Raw.getAutoboxParams(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleAutoboxParams} [Value]
     */
    public void setAutoboxParams(PxVehicleAutoboxParams value) {
        checkNotNull();
        Raw.setAutoboxParams(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleClutchCommandResponseParams} [Value]
     */
    public PxVehicleClutchCommandResponseParams getClutchCommandResponseParams() {
        checkNotNull();
        return PxVehicleClutchCommandResponseParams.wrapPointer(Raw.getClutchCommandResponseParams(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleClutchCommandResponseParams} [Value]
     */
    public void setClutchCommandResponseParams(PxVehicleClutchCommandResponseParams value) {
        checkNotNull();
        Raw.setClutchCommandResponseParams(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleEngineParams} [Value]
     */
    public PxVehicleEngineParams getEngineParams() {
        checkNotNull();
        return PxVehicleEngineParams.wrapPointer(Raw.getEngineParams(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleEngineParams} [Value]
     */
    public void setEngineParams(PxVehicleEngineParams value) {
        checkNotNull();
        Raw.setEngineParams(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleGearboxParams} [Value]
     */
    public PxVehicleGearboxParams getGearBoxParams() {
        checkNotNull();
        return PxVehicleGearboxParams.wrapPointer(Raw.getGearBoxParams(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleGearboxParams} [Value]
     */
    public void setGearBoxParams(PxVehicleGearboxParams value) {
        checkNotNull();
        Raw.setGearBoxParams(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleMultiWheelDriveDifferentialParams} [Value]
     */
    public PxVehicleMultiWheelDriveDifferentialParams getMultiWheelDifferentialParams() {
        checkNotNull();
        return PxVehicleMultiWheelDriveDifferentialParams.wrapPointer(Raw.getMultiWheelDifferentialParams(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleMultiWheelDriveDifferentialParams} [Value]
     */
    public void setMultiWheelDifferentialParams(PxVehicleMultiWheelDriveDifferentialParams value) {
        checkNotNull();
        Raw.setMultiWheelDifferentialParams(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleFourWheelDriveDifferentialParams} [Value]
     */
    public PxVehicleFourWheelDriveDifferentialParams getFourWheelDifferentialParams() {
        checkNotNull();
        return PxVehicleFourWheelDriveDifferentialParams.wrapPointer(Raw.getFourWheelDifferentialParams(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleFourWheelDriveDifferentialParams} [Value]
     */
    public void setFourWheelDifferentialParams(PxVehicleFourWheelDriveDifferentialParams value) {
        checkNotNull();
        Raw.setFourWheelDifferentialParams(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleTankDriveDifferentialParams} [Value]
     */
    public PxVehicleTankDriveDifferentialParams getTankDifferentialParams() {
        checkNotNull();
        return PxVehicleTankDriveDifferentialParams.wrapPointer(Raw.getTankDifferentialParams(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleTankDriveDifferentialParams} [Value]
     */
    public void setTankDifferentialParams(PxVehicleTankDriveDifferentialParams value) {
        checkNotNull();
        Raw.setTankDifferentialParams(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleClutchParams} [Value]
     */
    public PxVehicleClutchParams getClutchParams() {
        checkNotNull();
        return PxVehicleClutchParams.wrapPointer(Raw.getClutchParams(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleClutchParams} [Value]
     */
    public void setClutchParams(PxVehicleClutchParams value) {
        checkNotNull();
        Raw.setClutchParams(address, value.getAddress());
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link EngineDrivetrainParams} [Value]
     */
    public EngineDrivetrainParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return EngineDrivetrainParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @param axleDesc WebIDL type: {@link PxVehicleAxleDescription} [Const, Ref]
     * @return WebIDL type: boolean
     */
    public boolean isValid(PxVehicleAxleDescription axleDesc) {
        checkNotNull();
        return Raw.isValid(address, axleDesc.getAddress());
    }

    public static class Raw {
        public static native long EngineDrivetrainParams();
        public static native void destroy(long address);
        public static native long getAutoboxParams(long address);
        public static native void setAutoboxParams(long address, long value);
        public static native long getClutchCommandResponseParams(long address);
        public static native void setClutchCommandResponseParams(long address, long value);
        public static native long getEngineParams(long address);
        public static native void setEngineParams(long address, long value);
        public static native long getGearBoxParams(long address);
        public static native void setGearBoxParams(long address, long value);
        public static native long getMultiWheelDifferentialParams(long address);
        public static native void setMultiWheelDifferentialParams(long address, long value);
        public static native long getFourWheelDifferentialParams(long address);
        public static native void setFourWheelDifferentialParams(long address, long value);
        public static native long getTankDifferentialParams(long address);
        public static native void setTankDifferentialParams(long address, long value);
        public static native long getClutchParams(long address);
        public static native void setClutchParams(long address, long value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address, long axleDesc);
    }
}
