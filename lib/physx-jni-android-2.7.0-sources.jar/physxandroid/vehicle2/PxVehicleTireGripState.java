package physxandroid.vehicle2;

import physxandroid.NativeObject;

/**
 * The load and friction experienced by a tire.
 */
public class PxVehicleTireGripState extends NativeObject {

    protected PxVehicleTireGripState() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleTireGripState wrapPointer(long address) {
        return address != 0L ? new PxVehicleTireGripState(address) : null;
    }
    
    public static PxVehicleTireGripState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleTireGripState(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The tire load
     * <p>
     * <b>Unit:</b> force = mass * length / (time^2)
     */
    public float getLoad() {
        checkNotNull();
        return Raw.getLoad(address);
    }

    /**
     * The tire load
     * <p>
     * <b>Unit:</b> force = mass * length / (time^2)
     */
    public void setLoad(float value) {
        checkNotNull();
        Raw.setLoad(address, value);
    }

    /**
     * The tire friction is the product of the road geometry friction and a friction response multiplier.
     */
    public float getFriction() {
        checkNotNull();
        return Raw.getFriction(address);
    }

    /**
     * The tire friction is the product of the road geometry friction and a friction response multiplier.
     */
    public void setFriction(float value) {
        checkNotNull();
        Raw.setFriction(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native float getLoad(long address);
        public static native void setLoad(long address, float value);
        public static native float getFriction(long address);
        public static native void setFriction(long address, float value);
        public static native void setToDefault(long address);
    }
}
