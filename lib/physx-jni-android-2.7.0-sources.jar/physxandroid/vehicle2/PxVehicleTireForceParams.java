package physxandroid.vehicle2;

import physxandroid.NativeObject;

public class PxVehicleTireForceParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleTireForceParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleTireForceParams(address) : null;
    }
    
    public static PxVehicleTireForceParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleTireForceParams(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleTireForceParams() {
        address = Raw.PxVehicleTireForceParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Tire lateral stiffness is a graph of tire load that has linear behavior near zero load and
     * flattens at large loads. latStiffX describes the minimum normalized load (load/restLoad) that gives a
     * flat lateral stiffness response to load.
     * <b>Note:</b> A value of 0.0 indicates that the tire lateral stiffness is independent of load and will adopt 
     * the value #latStiffY for all values of tire load.
     */
    public float getLatStiffX() {
        checkNotNull();
        return Raw.getLatStiffX(address);
    }

    /**
     * Tire lateral stiffness is a graph of tire load that has linear behavior near zero load and
     * flattens at large loads. latStiffX describes the minimum normalized load (load/restLoad) that gives a
     * flat lateral stiffness response to load.
     * <b>Note:</b> A value of 0.0 indicates that the tire lateral stiffness is independent of load and will adopt 
     * the value #latStiffY for all values of tire load.
     */
    public void setLatStiffX(float value) {
        checkNotNull();
        Raw.setLatStiffX(address, value);
    }

    /**
     * Tire lateral stiffness is a graph of tire load that has linear behavior near zero load and
     * flattens at large loads. latStiffY describes the maximum possible value of lateral stiffness that occurs
     * when (load/restLoad) &gt;= #latStiffX.
     * <p>
     * <b>Unit:</b> force per lateral slip = mass * length / (time^2)
     */
    public float getLatStiffY() {
        checkNotNull();
        return Raw.getLatStiffY(address);
    }

    /**
     * Tire lateral stiffness is a graph of tire load that has linear behavior near zero load and
     * flattens at large loads. latStiffY describes the maximum possible value of lateral stiffness that occurs
     * when (load/restLoad) &gt;= #latStiffX.
     * <p>
     * <b>Unit:</b> force per lateral slip = mass * length / (time^2)
     */
    public void setLatStiffY(float value) {
        checkNotNull();
        Raw.setLatStiffY(address, value);
    }

    /**
     * Tire Longitudinal stiffness
     * <b>Note:</b> Longitudinal force can be approximated as longStiff*longitudinalSlip.
     * <p>
     * <b>Unit:</b> force per longitudinal slip = mass * length / (time^2)
     */
    public float getLongStiff() {
        checkNotNull();
        return Raw.getLongStiff(address);
    }

    /**
     * Tire Longitudinal stiffness
     * <b>Note:</b> Longitudinal force can be approximated as longStiff*longitudinalSlip.
     * <p>
     * <b>Unit:</b> force per longitudinal slip = mass * length / (time^2)
     */
    public void setLongStiff(float value) {
        checkNotNull();
        Raw.setLongStiff(address, value);
    }

    /**
     * Tire camber stiffness
     * <b>Note:</b> Camber force can be approximated as camberStiff*camberAngle.
     * <p>
     * <b>Unit:</b> force per radian = mass * length / (time^2)
     */
    public float getCamberStiff() {
        checkNotNull();
        return Raw.getCamberStiff(address);
    }

    /**
     * Tire camber stiffness
     * <b>Note:</b> Camber force can be approximated as camberStiff*camberAngle.
     * <p>
     * <b>Unit:</b> force per radian = mass * length / (time^2)
     */
    public void setCamberStiff(float value) {
        checkNotNull();
        Raw.setCamberStiff(address, value);
    }

    /**
     * The rest load is the load that develops on the tire when the vehicle is at rest on a flat plane.
     * <b>Note:</b> The rest load is approximately the product of gravitational acceleration and (sprungMass + wheelMass).
     * <p>
     * <b>Unit:</b> force = mass * length / (time^2)
     */
    public float getRestLoad() {
        checkNotNull();
        return Raw.getRestLoad(address);
    }

    /**
     * The rest load is the load that develops on the tire when the vehicle is at rest on a flat plane.
     * <b>Note:</b> The rest load is approximately the product of gravitational acceleration and (sprungMass + wheelMass).
     * <p>
     * <b>Unit:</b> force = mass * length / (time^2)
     */
    public void setRestLoad(float value) {
        checkNotNull();
        Raw.setRestLoad(address, value);
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehicleTireForceParams} [Value]
     */
    public PxVehicleTireForceParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehicleTireForceParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native long PxVehicleTireForceParams();
        public static native void destroy(long address);
        public static native float getLatStiffX(long address);
        public static native void setLatStiffX(long address, float value);
        public static native float getLatStiffY(long address);
        public static native void setLatStiffY(long address, float value);
        public static native float getLongStiff(long address);
        public static native void setLongStiff(long address, float value);
        public static native float getCamberStiff(long address);
        public static native void setCamberStiff(long address, float value);
        public static native float getRestLoad(long address);
        public static native void setRestLoad(long address, float value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address);
    }
}
