package physxandroid.vehicle2;

import physxandroid.NativeObject;
import physxandroid.common.PxVec3;

/**
 * PxVehiclePhysXConstraintState is a data structure used to write 
 * constraint data to the internal state of the associated PxScene.
 */
public class PxVehiclePhysXConstraintState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehiclePhysXConstraintState wrapPointer(long address) {
        return address != 0L ? new PxVehiclePhysXConstraintState(address) : null;
    }
    
    public static PxVehiclePhysXConstraintState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehiclePhysXConstraintState(long address) {
        super(address);
    }

    // Constructors

    public PxVehiclePhysXConstraintState() {
        address = Raw.PxVehiclePhysXConstraintState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: boolean
     */
    public boolean getTireActiveStatus(int index) {
        checkNotNull();
        return Raw.getTireActiveStatus(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: boolean
     */
    public void setTireActiveStatus(int index, boolean value) {
        checkNotNull();
        Raw.setTireActiveStatus(address, index, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getTireLinears(int index) {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getTireLinears(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setTireLinears(int index, PxVec3 value) {
        checkNotNull();
        Raw.setTireLinears(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getTireAngulars(int index) {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getTireAngulars(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setTireAngulars(int index, PxVec3 value) {
        checkNotNull();
        Raw.setTireAngulars(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getTireDamping(int index) {
        checkNotNull();
        return Raw.getTireDamping(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setTireDamping(int index, float value) {
        checkNotNull();
        Raw.setTireDamping(address, index, value);
    }

    /**
     * a boolean describing whether to trigger a suspension limit constraint.
     */
    public boolean getSuspActiveStatus() {
        checkNotNull();
        return Raw.getSuspActiveStatus(address);
    }

    /**
     * a boolean describing whether to trigger a suspension limit constraint.
     */
    public void setSuspActiveStatus(boolean value) {
        checkNotNull();
        Raw.setSuspActiveStatus(address, value);
    }

    /**
     * linear component of velocity jacobian in the world frame.
     */
    public PxVec3 getSuspLinear() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getSuspLinear(address));
    }

    /**
     * linear component of velocity jacobian in the world frame.
     */
    public void setSuspLinear(PxVec3 value) {
        checkNotNull();
        Raw.setSuspLinear(address, value.getAddress());
    }

    /**
     * angular component of velocity jacobian in the world frame.
     */
    public PxVec3 getSuspAngular() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getSuspAngular(address));
    }

    /**
     * angular component of velocity jacobian in the world frame.
     */
    public void setSuspAngular(PxVec3 value) {
        checkNotNull();
        Raw.setSuspAngular(address, value.getAddress());
    }

    /**
     * the excess suspension compression to be resolved by the constraint that cannot be resolved due to the travel limit
     * of the suspension spring.
     * <p>
     * <b>Note:</b> The expected error value is the excess suspension compression projected onto the ground plane normal and should have
     *       a negative sign.
     */
    public float getSuspGeometricError() {
        checkNotNull();
        return Raw.getSuspGeometricError(address);
    }

    /**
     * the excess suspension compression to be resolved by the constraint that cannot be resolved due to the travel limit
     * of the suspension spring.
     * <p>
     * <b>Note:</b> The expected error value is the excess suspension compression projected onto the ground plane normal and should have
     *       a negative sign.
     */
    public void setSuspGeometricError(float value) {
        checkNotNull();
        Raw.setSuspGeometricError(address, value);
    }

    /**
     * restitution value of the restitution model used to generate a target velocity that will resolve the geometric error.
     * <b>Note:</b> A value of 0.0 means that the restitution model is not employed.
     */
    public float getRestitution() {
        checkNotNull();
        return Raw.getRestitution(address);
    }

    /**
     * restitution value of the restitution model used to generate a target velocity that will resolve the geometric error.
     * <b>Note:</b> A value of 0.0 means that the restitution model is not employed.
     */
    public void setRestitution(float value) {
        checkNotNull();
        Raw.setRestitution(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehiclePhysXConstraintState();
        public static native void destroy(long address);
        public static native boolean getTireActiveStatus(long address, int index);
        public static native void setTireActiveStatus(long address, int index, boolean value);
        public static native long getTireLinears(long address, int index);
        public static native void setTireLinears(long address, int index, long value);
        public static native long getTireAngulars(long address, int index);
        public static native void setTireAngulars(long address, int index, long value);
        public static native float getTireDamping(long address, int index);
        public static native void setTireDamping(long address, int index, float value);
        public static native boolean getSuspActiveStatus(long address);
        public static native void setSuspActiveStatus(long address, boolean value);
        public static native long getSuspLinear(long address);
        public static native void setSuspLinear(long address, long value);
        public static native long getSuspAngular(long address);
        public static native void setSuspAngular(long address, long value);
        public static native float getSuspGeometricError(long address);
        public static native void setSuspGeometricError(long address, float value);
        public static native float getRestitution(long address);
        public static native void setRestitution(long address, float value);
        public static native void setToDefault(long address);
    }
}
