package physxandroid.vehicle2;

import physxandroid.NativeObject;
import physxandroid.common.PxTransform;
import physxandroid.common.PxVec3;

public class PxVehicleSuspensionParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleSuspensionParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleSuspensionParams(address) : null;
    }
    
    public static PxVehicleSuspensionParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleSuspensionParams(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleSuspensionParams() {
        address = Raw.PxVehicleSuspensionParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * suspensionAttachment specifies the wheel pose at maximum compression.
     * <b>Note:</b> suspensionAttachment is specified in the frame of the rigid body.
     * <b>Note:</b> camber, steer and toe angles are all applied in the suspension frame.
     */
    public PxTransform getSuspensionAttachment() {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getSuspensionAttachment(address));
    }

    /**
     * suspensionAttachment specifies the wheel pose at maximum compression.
     * <b>Note:</b> suspensionAttachment is specified in the frame of the rigid body.
     * <b>Note:</b> camber, steer and toe angles are all applied in the suspension frame.
     */
    public void setSuspensionAttachment(PxTransform value) {
        checkNotNull();
        Raw.setSuspensionAttachment(address, value.getAddress());
    }

    /**
     * suspensionTravelDir specifies the direction of suspension travel.
     * <b>Note:</b> suspensionTravelDir is specified in the frame of the rigid body.
     */
    public PxVec3 getSuspensionTravelDir() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getSuspensionTravelDir(address));
    }

    /**
     * suspensionTravelDir specifies the direction of suspension travel.
     * <b>Note:</b> suspensionTravelDir is specified in the frame of the rigid body.
     */
    public void setSuspensionTravelDir(PxVec3 value) {
        checkNotNull();
        Raw.setSuspensionTravelDir(address, value.getAddress());
    }

    /**
     * suspensionTravelDist is the maximum distance that the suspenson can elongate along #suspensionTravelDir
     * from the pose specified by #suspensionAttachment.
     * <b>Note:</b> The position suspensionAttachment.p + #suspensionTravelDir*#suspensionTravelDist corresponds to the 
     * the suspension at maximum droop in the rigid body frame.
     */
    public float getSuspensionTravelDist() {
        checkNotNull();
        return Raw.getSuspensionTravelDist(address);
    }

    /**
     * suspensionTravelDist is the maximum distance that the suspenson can elongate along #suspensionTravelDir
     * from the pose specified by #suspensionAttachment.
     * <b>Note:</b> The position suspensionAttachment.p + #suspensionTravelDir*#suspensionTravelDist corresponds to the 
     * the suspension at maximum droop in the rigid body frame.
     */
    public void setSuspensionTravelDist(float value) {
        checkNotNull();
        Raw.setSuspensionTravelDist(address, value);
    }

    /**
     * wheelAttachment is the pose of the wheel in the suspension frame.
     * <b>Note:</b> The rotation angle around the wheel's lateral axis is applied in the wheel attachment frame.
     */
    public PxTransform getWheelAttachment() {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getWheelAttachment(address));
    }

    /**
     * wheelAttachment is the pose of the wheel in the suspension frame.
     * <b>Note:</b> The rotation angle around the wheel's lateral axis is applied in the wheel attachment frame.
     */
    public void setWheelAttachment(PxTransform value) {
        checkNotNull();
        Raw.setWheelAttachment(address, value.getAddress());
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehicleSuspensionParams} [Value]
     */
    public PxVehicleSuspensionParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehicleSuspensionParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native long PxVehicleSuspensionParams();
        public static native void destroy(long address);
        public static native long getSuspensionAttachment(long address);
        public static native void setSuspensionAttachment(long address, long value);
        public static native long getSuspensionTravelDir(long address);
        public static native void setSuspensionTravelDir(long address, long value);
        public static native float getSuspensionTravelDist(long address);
        public static native void setSuspensionTravelDist(long address, float value);
        public static native long getWheelAttachment(long address);
        public static native void setWheelAttachment(long address, long value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address);
    }
}
