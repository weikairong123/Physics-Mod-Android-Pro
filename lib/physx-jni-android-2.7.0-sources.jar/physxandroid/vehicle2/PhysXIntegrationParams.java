package physxandroid.vehicle2;

import physxandroid.NativeObject;
import physxandroid.common.PxTransform;
import physxandroid.geometry.PxGeometry;
import physxandroid.physics.PxFilterData;
import physxandroid.physics.PxQueryFilterCallback;
import physxandroid.physics.PxQueryFilterData;
import physxandroid.physics.PxShapeFlags;

public class PhysXIntegrationParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PhysXIntegrationParams wrapPointer(long address) {
        return address != 0L ? new PhysXIntegrationParams(address) : null;
    }
    
    public static PhysXIntegrationParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PhysXIntegrationParams(long address) {
        super(address);
    }

    // Constructors

    public PhysXIntegrationParams() {
        address = Raw.PhysXIntegrationParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxVehiclePhysXRoadGeometryQueryParams} [Value]
     */
    public PxVehiclePhysXRoadGeometryQueryParams getPhysxRoadGeometryQueryParams() {
        checkNotNull();
        return PxVehiclePhysXRoadGeometryQueryParams.wrapPointer(Raw.getPhysxRoadGeometryQueryParams(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehiclePhysXRoadGeometryQueryParams} [Value]
     */
    public void setPhysxRoadGeometryQueryParams(PxVehiclePhysXRoadGeometryQueryParams value) {
        checkNotNull();
        Raw.setPhysxRoadGeometryQueryParams(address, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehiclePhysXMaterialFrictionParams} [Value]
     */
    public PxVehiclePhysXMaterialFrictionParams getPhysxMaterialFrictionParams(int index) {
        checkNotNull();
        return PxVehiclePhysXMaterialFrictionParams.wrapPointer(Raw.getPhysxMaterialFrictionParams(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehiclePhysXMaterialFrictionParams} [Value]
     */
    public void setPhysxMaterialFrictionParams(int index, PxVehiclePhysXMaterialFrictionParams value) {
        checkNotNull();
        Raw.setPhysxMaterialFrictionParams(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehiclePhysXSuspensionLimitConstraintParams} [Value]
     */
    public PxVehiclePhysXSuspensionLimitConstraintParams getPhysxSuspensionLimitConstraintParams(int index) {
        checkNotNull();
        return PxVehiclePhysXSuspensionLimitConstraintParams.wrapPointer(Raw.getPhysxSuspensionLimitConstraintParams(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehiclePhysXSuspensionLimitConstraintParams} [Value]
     */
    public void setPhysxSuspensionLimitConstraintParams(int index, PxVehiclePhysXSuspensionLimitConstraintParams value) {
        checkNotNull();
        Raw.setPhysxSuspensionLimitConstraintParams(address, index, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxTransform} [Value]
     */
    public PxTransform getPhysxActorCMassLocalPose() {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getPhysxActorCMassLocalPose(address));
    }

    /**
     * @param value WebIDL type: {@link PxTransform} [Value]
     */
    public void setPhysxActorCMassLocalPose(PxTransform value) {
        checkNotNull();
        Raw.setPhysxActorCMassLocalPose(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxGeometry}
     */
    public PxGeometry getPhysxActorGeometry() {
        checkNotNull();
        return PxGeometry.wrapPointer(Raw.getPhysxActorGeometry(address));
    }

    /**
     * @param value WebIDL type: {@link PxGeometry}
     */
    public void setPhysxActorGeometry(PxGeometry value) {
        checkNotNull();
        Raw.setPhysxActorGeometry(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxTransform} [Value]
     */
    public PxTransform getPhysxActorBoxShapeLocalPose() {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getPhysxActorBoxShapeLocalPose(address));
    }

    /**
     * @param value WebIDL type: {@link PxTransform} [Value]
     */
    public void setPhysxActorBoxShapeLocalPose(PxTransform value) {
        checkNotNull();
        Raw.setPhysxActorBoxShapeLocalPose(address, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxTransform} [Value]
     */
    public PxTransform getPhysxWheelShapeLocalPoses(int index) {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getPhysxWheelShapeLocalPoses(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxTransform} [Value]
     */
    public void setPhysxWheelShapeLocalPoses(int index, PxTransform value) {
        checkNotNull();
        Raw.setPhysxWheelShapeLocalPoses(address, index, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxShapeFlags} [Value]
     */
    public PxShapeFlags getPhysxActorShapeFlags() {
        checkNotNull();
        return PxShapeFlags.wrapPointer(Raw.getPhysxActorShapeFlags(address));
    }

    /**
     * @param value WebIDL type: {@link PxShapeFlags} [Value]
     */
    public void setPhysxActorShapeFlags(PxShapeFlags value) {
        checkNotNull();
        Raw.setPhysxActorShapeFlags(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxFilterData} [Value]
     */
    public PxFilterData getPhysxActorSimulationFilterData() {
        checkNotNull();
        return PxFilterData.wrapPointer(Raw.getPhysxActorSimulationFilterData(address));
    }

    /**
     * @param value WebIDL type: {@link PxFilterData} [Value]
     */
    public void setPhysxActorSimulationFilterData(PxFilterData value) {
        checkNotNull();
        Raw.setPhysxActorSimulationFilterData(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxFilterData} [Value]
     */
    public PxFilterData getPhysxActorQueryFilterData() {
        checkNotNull();
        return PxFilterData.wrapPointer(Raw.getPhysxActorQueryFilterData(address));
    }

    /**
     * @param value WebIDL type: {@link PxFilterData} [Value]
     */
    public void setPhysxActorQueryFilterData(PxFilterData value) {
        checkNotNull();
        Raw.setPhysxActorQueryFilterData(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxShapeFlags} [Value]
     */
    public PxShapeFlags getPhysxActorWheelShapeFlags() {
        checkNotNull();
        return PxShapeFlags.wrapPointer(Raw.getPhysxActorWheelShapeFlags(address));
    }

    /**
     * @param value WebIDL type: {@link PxShapeFlags} [Value]
     */
    public void setPhysxActorWheelShapeFlags(PxShapeFlags value) {
        checkNotNull();
        Raw.setPhysxActorWheelShapeFlags(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxFilterData} [Value]
     */
    public PxFilterData getPhysxActorWheelSimulationFilterData() {
        checkNotNull();
        return PxFilterData.wrapPointer(Raw.getPhysxActorWheelSimulationFilterData(address));
    }

    /**
     * @param value WebIDL type: {@link PxFilterData} [Value]
     */
    public void setPhysxActorWheelSimulationFilterData(PxFilterData value) {
        checkNotNull();
        Raw.setPhysxActorWheelSimulationFilterData(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxFilterData} [Value]
     */
    public PxFilterData getPhysxActorWheelQueryFilterData() {
        checkNotNull();
        return PxFilterData.wrapPointer(Raw.getPhysxActorWheelQueryFilterData(address));
    }

    /**
     * @param value WebIDL type: {@link PxFilterData} [Value]
     */
    public void setPhysxActorWheelQueryFilterData(PxFilterData value) {
        checkNotNull();
        Raw.setPhysxActorWheelQueryFilterData(address, value.getAddress());
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PhysXIntegrationParams} [Value]
     */
    public PhysXIntegrationParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PhysXIntegrationParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @param axleDesc WebIDL type: {@link PxVehicleAxleDescription} [Const, Ref]
     * @return WebIDL type: boolean
     */
    public boolean isValid(PxVehicleAxleDescription axleDesc) {
        checkNotNull();
        return Raw.isValid(address, axleDesc.getAddress());
    }

    /**
     * @param axleDesc                    WebIDL type: {@link PxVehicleAxleDescription} [Const, Ref]
     * @param roadQueryFilterData         WebIDL type: {@link PxQueryFilterData} [Const, Ref]
     * @param roadQueryFilterCallback     WebIDL type: {@link PxQueryFilterCallback} [Nullable]
     * @param materialFrictions           WebIDL type: {@link PxVehiclePhysXMaterialFriction}
     * @param nbMaterialFrictions         WebIDL type: unsigned long
     * @param defaultFriction             WebIDL type: float
     * @param physxActorCMassLocalPose    WebIDL type: {@link PxTransform} [Const, Ref]
     * @param actorGeometry               WebIDL type: {@link PxGeometry} [Ref]
     * @param physxActorBoxShapeLocalPose WebIDL type: {@link PxTransform} [Const, Ref]
     * @param roadGeometryQueryType       WebIDL type: {@link PxVehiclePhysXRoadGeometryQueryTypeEnum} [enum]
     */
    public void create(PxVehicleAxleDescription axleDesc, PxQueryFilterData roadQueryFilterData, PxQueryFilterCallback roadQueryFilterCallback, PxVehiclePhysXMaterialFriction materialFrictions, int nbMaterialFrictions, float defaultFriction, PxTransform physxActorCMassLocalPose, PxGeometry actorGeometry, PxTransform physxActorBoxShapeLocalPose, PxVehiclePhysXRoadGeometryQueryTypeEnum roadGeometryQueryType) {
        checkNotNull();
        Raw.create(address, axleDesc.getAddress(), roadQueryFilterData.getAddress(), (roadQueryFilterCallback != null ? roadQueryFilterCallback.getAddress() : 0L), materialFrictions.getAddress(), nbMaterialFrictions, defaultFriction, physxActorCMassLocalPose.getAddress(), actorGeometry.getAddress(), physxActorBoxShapeLocalPose.getAddress(), roadGeometryQueryType.value);
    }

    public static class Raw {
        public static native long PhysXIntegrationParams();
        public static native void destroy(long address);
        public static native long getPhysxRoadGeometryQueryParams(long address);
        public static native void setPhysxRoadGeometryQueryParams(long address, long value);
        public static native long getPhysxMaterialFrictionParams(long address, int index);
        public static native void setPhysxMaterialFrictionParams(long address, int index, long value);
        public static native long getPhysxSuspensionLimitConstraintParams(long address, int index);
        public static native void setPhysxSuspensionLimitConstraintParams(long address, int index, long value);
        public static native long getPhysxActorCMassLocalPose(long address);
        public static native void setPhysxActorCMassLocalPose(long address, long value);
        public static native long getPhysxActorGeometry(long address);
        public static native void setPhysxActorGeometry(long address, long value);
        public static native long getPhysxActorBoxShapeLocalPose(long address);
        public static native void setPhysxActorBoxShapeLocalPose(long address, long value);
        public static native long getPhysxWheelShapeLocalPoses(long address, int index);
        public static native void setPhysxWheelShapeLocalPoses(long address, int index, long value);
        public static native long getPhysxActorShapeFlags(long address);
        public static native void setPhysxActorShapeFlags(long address, long value);
        public static native long getPhysxActorSimulationFilterData(long address);
        public static native void setPhysxActorSimulationFilterData(long address, long value);
        public static native long getPhysxActorQueryFilterData(long address);
        public static native void setPhysxActorQueryFilterData(long address, long value);
        public static native long getPhysxActorWheelShapeFlags(long address);
        public static native void setPhysxActorWheelShapeFlags(long address, long value);
        public static native long getPhysxActorWheelSimulationFilterData(long address);
        public static native void setPhysxActorWheelSimulationFilterData(long address, long value);
        public static native long getPhysxActorWheelQueryFilterData(long address);
        public static native void setPhysxActorWheelQueryFilterData(long address, long value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address, long axleDesc);
        public static native void create(long address, long axleDesc, long roadQueryFilterData, long roadQueryFilterCallback, long materialFrictions, int nbMaterialFrictions, float defaultFriction, long physxActorCMassLocalPose, long actorGeometry, long physxActorBoxShapeLocalPose, int roadGeometryQueryType);
    }
}
