package physxandroid.vehicle2;

import physxandroid.NativeObject;

/**
 * A description of a single axle that is to be affected by Ackermann steer correction.
 */
public class PxVehicleAckermannParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleAckermannParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleAckermannParams(address) : null;
    }
    
    public static PxVehicleAckermannParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleAckermannParams(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleAckermannParams() {
        address = Raw.PxVehicleAckermannParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: unsigned long
     */
    public int getWheelIds(int index) {
        checkNotNull();
        return Raw.getWheelIds(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: unsigned long
     */
    public void setWheelIds(int index, int value) {
        checkNotNull();
        Raw.setWheelIds(address, index, value);
    }

    /**
     * wheelBase is the longitudinal distance between the axle that is affected by Ackermann correction and a reference axle.
     */
    public float getWheelBase() {
        checkNotNull();
        return Raw.getWheelBase(address);
    }

    /**
     * wheelBase is the longitudinal distance between the axle that is affected by Ackermann correction and a reference axle.
     */
    public void setWheelBase(float value) {
        checkNotNull();
        Raw.setWheelBase(address, value);
    }

    /**
     * trackWidth is the width of the axle specified by #wheelIds
     */
    public float getTrackWidth() {
        checkNotNull();
        return Raw.getTrackWidth(address);
    }

    /**
     * trackWidth is the width of the axle specified by #wheelIds
     */
    public void setTrackWidth(float value) {
        checkNotNull();
        Raw.setTrackWidth(address, value);
    }

    /**
     * is the strength of the correction with 0 denoting no correction and 1 denoting perfect correction.
     */
    public float getStrength() {
        checkNotNull();
        return Raw.getStrength(address);
    }

    /**
     * is the strength of the correction with 0 denoting no correction and 1 denoting perfect correction.
     */
    public void setStrength(float value) {
        checkNotNull();
        Raw.setStrength(address, value);
    }

    // Functions

    /**
     * @param axleDesc WebIDL type: {@link PxVehicleAxleDescription} [Const, Ref]
     * @return WebIDL type: boolean
     */
    public boolean isValid(PxVehicleAxleDescription axleDesc) {
        checkNotNull();
        return Raw.isValid(address, axleDesc.getAddress());
    }

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehicleAckermannParams} [Value]
     */
    public PxVehicleAckermannParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehicleAckermannParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    public static class Raw {
        public static native long PxVehicleAckermannParams();
        public static native void destroy(long address);
        public static native int getWheelIds(long address, int index);
        public static native void setWheelIds(long address, int index, int value);
        public static native float getWheelBase(long address);
        public static native void setWheelBase(long address, float value);
        public static native float getTrackWidth(long address);
        public static native void setTrackWidth(long address, float value);
        public static native float getStrength(long address);
        public static native void setStrength(long address, float value);
        public static native boolean isValid(long address, long axleDesc);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
    }
}
