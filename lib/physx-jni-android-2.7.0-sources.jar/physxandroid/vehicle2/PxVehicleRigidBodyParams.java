package physxandroid.vehicle2;

import physxandroid.NativeObject;
import physxandroid.common.PxVec3;

/**
 * The properties of the rigid body.
 */
public class PxVehicleRigidBodyParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleRigidBodyParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleRigidBodyParams(address) : null;
    }
    
    public static PxVehicleRigidBodyParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleRigidBodyParams(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleRigidBodyParams() {
        address = Raw.PxVehicleRigidBodyParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The mass of the rigid body.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> mass
     */
    public float getMass() {
        checkNotNull();
        return Raw.getMass(address);
    }

    /**
     * The mass of the rigid body.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> mass
     */
    public void setMass(float value) {
        checkNotNull();
        Raw.setMass(address, value);
    }

    /**
     * The moment of inertia of the rigid body.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> mass * (length^2)
     */
    public PxVec3 getMoi() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getMoi(address));
    }

    /**
     * The moment of inertia of the rigid body.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> mass * (length^2)
     */
    public void setMoi(PxVec3 value) {
        checkNotNull();
        Raw.setMoi(address, value.getAddress());
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehicleRigidBodyParams} [Value]
     */
    public PxVehicleRigidBodyParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehicleRigidBodyParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native long PxVehicleRigidBodyParams();
        public static native void destroy(long address);
        public static native float getMass(long address);
        public static native void setMass(long address, float value);
        public static native long getMoi(long address);
        public static native void setMoi(long address, long value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address);
    }
}
