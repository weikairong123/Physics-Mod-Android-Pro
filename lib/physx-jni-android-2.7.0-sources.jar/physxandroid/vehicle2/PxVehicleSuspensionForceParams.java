package physxandroid.vehicle2;

import physxandroid.NativeObject;

/**
 * Suspension force is computed by converting suspenson state to suspension force under the assumption of a linear spring.
 */
public class PxVehicleSuspensionForceParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleSuspensionForceParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleSuspensionForceParams(address) : null;
    }
    
    public static PxVehicleSuspensionForceParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleSuspensionForceParams(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleSuspensionForceParams() {
        address = Raw.PxVehicleSuspensionForceParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Spring strength of suspension.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> mass / (time^2)
     */
    public float getStiffness() {
        checkNotNull();
        return Raw.getStiffness(address);
    }

    /**
     * Spring strength of suspension.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> mass / (time^2)
     */
    public void setStiffness(float value) {
        checkNotNull();
        Raw.setStiffness(address, value);
    }

    /**
     * Spring damper rate of suspension.
     * <p>
     * <b>Range:</b> [0, inf)<br>
     * <b>Unit:</b> mass / time
     */
    public float getDamping() {
        checkNotNull();
        return Raw.getDamping(address);
    }

    /**
     * Spring damper rate of suspension.
     * <p>
     * <b>Range:</b> [0, inf)<br>
     * <b>Unit:</b> mass / time
     */
    public void setDamping(float value) {
        checkNotNull();
        Raw.setDamping(address, value);
    }

    /**
     * Part of the vehicle mass that is supported by the suspension spring.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> mass
     */
    public float getSprungMass() {
        checkNotNull();
        return Raw.getSprungMass(address);
    }

    /**
     * Part of the vehicle mass that is supported by the suspension spring.
     * <p>
     * <b>Range:</b> (0, inf)<br>
     * <b>Unit:</b> mass
     */
    public void setSprungMass(float value) {
        checkNotNull();
        Raw.setSprungMass(address, value);
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehicleSuspensionForceParams} [Value]
     */
    public PxVehicleSuspensionForceParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehicleSuspensionForceParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native long PxVehicleSuspensionForceParams();
        public static native void destroy(long address);
        public static native float getStiffness(long address);
        public static native void setStiffness(long address, float value);
        public static native float getDamping(long address);
        public static native void setDamping(long address, float value);
        public static native float getSprungMass(long address);
        public static native void setSprungMass(long address, float value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address);
    }
}
