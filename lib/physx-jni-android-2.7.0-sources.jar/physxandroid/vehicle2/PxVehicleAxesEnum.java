package physxandroid.vehicle2;

public enum PxVehicleAxesEnum {

    /**
     * The +x axis
     */
    ePosX(getePosX()),
    /**
     * The -x axis
     */
    eNegX(geteNegX()),
    /**
     * The +y axis
     */
    ePosY(getePosY()),
    /**
     * The -y axis
     */
    eNegY(geteNegY()),
    /**
     * The +z axis
     */
    ePosZ(getePosZ()),
    /**
     * The -z axis
     */
    eNegZ(geteNegZ());
    public final int value;
    
    PxVehicleAxesEnum(int value) {
        this.value = value;
    }

    private static native int _getePosX();
    private static int getePosX() {
        de.fabmax.physxandroid.Loader.load();
        return _getePosX();
    }

    private static native int _geteNegX();
    private static int geteNegX() {
        de.fabmax.physxandroid.Loader.load();
        return _geteNegX();
    }

    private static native int _getePosY();
    private static int getePosY() {
        de.fabmax.physxandroid.Loader.load();
        return _getePosY();
    }

    private static native int _geteNegY();
    private static int geteNegY() {
        de.fabmax.physxandroid.Loader.load();
        return _geteNegY();
    }

    private static native int _getePosZ();
    private static int getePosZ() {
        de.fabmax.physxandroid.Loader.load();
        return _getePosZ();
    }

    private static native int _geteNegZ();
    private static int geteNegZ() {
        de.fabmax.physxandroid.Loader.load();
        return _geteNegZ();
    }

    private static final int LUT_SIZE = 256;
    private static final PxVehicleAxesEnum[] enumValues = values();
    private static final PxVehicleAxesEnum[] enumLut = new PxVehicleAxesEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxVehicleAxesEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxVehicleAxesEnum forValue(int value) {
        PxVehicleAxesEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxVehicleAxesEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxVehicleAxesEnum: " + value);
        }
        return enumValue;
    }
}
