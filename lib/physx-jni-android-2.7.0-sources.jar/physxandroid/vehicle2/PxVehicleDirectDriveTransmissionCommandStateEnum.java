package physxandroid.vehicle2;

/**
 * Direct drive vehicles only have reverse, neutral or forward gear.
 */
public enum PxVehicleDirectDriveTransmissionCommandStateEnum {

    eREVERSE(geteREVERSE()),
    eNEUTRAL(geteNEUTRAL()),
    eFORWARD(geteFORWARD());
    public final int value;
    
    PxVehicleDirectDriveTransmissionCommandStateEnum(int value) {
        this.value = value;
    }

    private static native int _geteREVERSE();
    private static int geteREVERSE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteREVERSE();
    }

    private static native int _geteNEUTRAL();
    private static int geteNEUTRAL() {
        de.fabmax.physxandroid.Loader.load();
        return _geteNEUTRAL();
    }

    private static native int _geteFORWARD();
    private static int geteFORWARD() {
        de.fabmax.physxandroid.Loader.load();
        return _geteFORWARD();
    }

    private static final int LUT_SIZE = 256;
    private static final PxVehicleDirectDriveTransmissionCommandStateEnum[] enumValues = values();
    private static final PxVehicleDirectDriveTransmissionCommandStateEnum[] enumLut = new PxVehicleDirectDriveTransmissionCommandStateEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxVehicleDirectDriveTransmissionCommandStateEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxVehicleDirectDriveTransmissionCommandStateEnum forValue(int value) {
        PxVehicleDirectDriveTransmissionCommandStateEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxVehicleDirectDriveTransmissionCommandStateEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxVehicleDirectDriveTransmissionCommandStateEnum: " + value);
        }
        return enumValue;
    }
}
