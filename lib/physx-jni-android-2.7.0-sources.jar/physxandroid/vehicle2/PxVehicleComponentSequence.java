package physxandroid.vehicle2;

import physxandroid.NativeObject;

public class PxVehicleComponentSequence extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleComponentSequence wrapPointer(long address) {
        return address != 0L ? new PxVehicleComponentSequence(address) : null;
    }
    
    public static PxVehicleComponentSequence arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleComponentSequence(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleComponentSequence() {
        address = Raw.PxVehicleComponentSequence();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param component WebIDL type: {@link PxVehicleComponent}
     * @return WebIDL type: boolean
     */
    public boolean add(PxVehicleComponent component) {
        checkNotNull();
        return Raw.add(address, component.getAddress());
    }

    /**
     * @return WebIDL type: octet
     */
    public byte beginSubstepGroup() {
        checkNotNull();
        return Raw.beginSubstepGroup(address);
    }

    /**
     * @param nbSubSteps WebIDL type: octet
     * @return WebIDL type: octet
     */
    public byte beginSubstepGroup(byte nbSubSteps) {
        checkNotNull();
        return Raw.beginSubstepGroup(address, nbSubSteps);
    }

    public void endSubstepGroup() {
        checkNotNull();
        Raw.endSubstepGroup(address);
    }

    /**
     * @param subGroupHandle WebIDL type: octet
     * @param nbSteps        WebIDL type: octet
     */
    public void setSubsteps(byte subGroupHandle, byte nbSteps) {
        checkNotNull();
        Raw.setSubsteps(address, subGroupHandle, nbSteps);
    }

    /**
     * @param dt      WebIDL type: float
     * @param context WebIDL type: {@link PxVehicleSimulationContext} [Const, Ref]
     */
    public void update(float dt, PxVehicleSimulationContext context) {
        checkNotNull();
        Raw.update(address, dt, context.getAddress());
    }

    public static class Raw {
        public static native long PxVehicleComponentSequence();
        public static native void destroy(long address);
        public static native boolean add(long address, long component);
        public static native byte beginSubstepGroup(long address);
        public static native byte beginSubstepGroup(long address, byte nbSubSteps);
        public static native void endSubstepGroup(long address);
        public static native void setSubsteps(long address, byte subGroupHandle, byte nbSteps);
        public static native void update(long address, float dt, long context);
    }
}
