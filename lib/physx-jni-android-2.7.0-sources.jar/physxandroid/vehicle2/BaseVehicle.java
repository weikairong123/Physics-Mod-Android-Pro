package physxandroid.vehicle2;

import physxandroid.NativeObject;

public class BaseVehicle extends NativeObject {

    protected BaseVehicle() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static BaseVehicle wrapPointer(long address) {
        return address != 0L ? new BaseVehicle(address) : null;
    }
    
    public static BaseVehicle arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected BaseVehicle(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link BaseVehicleParams} [Value]
     */
    public BaseVehicleParams getBaseParams() {
        checkNotNull();
        return BaseVehicleParams.wrapPointer(Raw.getBaseParams(address));
    }

    /**
     * @param value WebIDL type: {@link BaseVehicleParams} [Value]
     */
    public void setBaseParams(BaseVehicleParams value) {
        checkNotNull();
        Raw.setBaseParams(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link BaseVehicleState} [Value]
     */
    public BaseVehicleState getBaseState() {
        checkNotNull();
        return BaseVehicleState.wrapPointer(Raw.getBaseState(address));
    }

    /**
     * @param value WebIDL type: {@link BaseVehicleState} [Value]
     */
    public void setBaseState(BaseVehicleState value) {
        checkNotNull();
        Raw.setBaseState(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleComponentSequence} [Value]
     */
    public PxVehicleComponentSequence getComponentSequence() {
        checkNotNull();
        return PxVehicleComponentSequence.wrapPointer(Raw.getComponentSequence(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleComponentSequence} [Value]
     */
    public void setComponentSequence(PxVehicleComponentSequence value) {
        checkNotNull();
        Raw.setComponentSequence(address, value.getAddress());
    }

    /**
     * @return WebIDL type: octet
     */
    public byte getComponentSequenceSubstepGroupHandle() {
        checkNotNull();
        return Raw.getComponentSequenceSubstepGroupHandle(address);
    }

    /**
     * @param value WebIDL type: octet
     */
    public void setComponentSequenceSubstepGroupHandle(byte value) {
        checkNotNull();
        Raw.setComponentSequenceSubstepGroupHandle(address, value);
    }

    // Functions

    /**
     * @return WebIDL type: boolean
     */
    public boolean initialize() {
        checkNotNull();
        return Raw.initialize(address);
    }

    public void destroyState() {
        checkNotNull();
        Raw.destroyState(address);
    }

    /**
     * @param addPhysXBeginEndComponents WebIDL type: boolean
     */
    public void initComponentSequence(boolean addPhysXBeginEndComponents) {
        checkNotNull();
        Raw.initComponentSequence(address, addPhysXBeginEndComponents);
    }

    /**
     * @param dt      WebIDL type: float
     * @param context WebIDL type: {@link PxVehicleSimulationContext} [Const, Ref]
     */
    public void step(float dt, PxVehicleSimulationContext context) {
        checkNotNull();
        Raw.step(address, dt, context.getAddress());
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getBaseParams(long address);
        public static native void setBaseParams(long address, long value);
        public static native long getBaseState(long address);
        public static native void setBaseState(long address, long value);
        public static native long getComponentSequence(long address);
        public static native void setComponentSequence(long address, long value);
        public static native byte getComponentSequenceSubstepGroupHandle(long address);
        public static native void setComponentSequenceSubstepGroupHandle(long address, byte value);
        public static native boolean initialize(long address);
        public static native void destroyState(long address);
        public static native void initComponentSequence(long address, boolean addPhysXBeginEndComponents);
        public static native void step(long address, float dt, long context);
    }
}
