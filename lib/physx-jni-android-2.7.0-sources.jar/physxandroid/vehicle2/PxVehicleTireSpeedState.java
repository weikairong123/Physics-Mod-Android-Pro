package physxandroid.vehicle2;

import physxandroid.NativeObject;

/**
 * PxVehicleTireSpeedState stores the components of the instantaneous velocity of the rigid body at the tire contact point projected 
 * along the lateral and longitudinal axes of the tire.
 * @see PxVehicleTireDirectionState
 */
public class PxVehicleTireSpeedState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleTireSpeedState wrapPointer(long address) {
        return address != 0L ? new PxVehicleTireSpeedState(address) : null;
    }
    
    public static PxVehicleTireSpeedState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleTireSpeedState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleTireSpeedState() {
        address = Raw.PxVehicleTireSpeedState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getSpeedStates(int index) {
        checkNotNull();
        return Raw.getSpeedStates(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setSpeedStates(int index, float value) {
        checkNotNull();
        Raw.setSpeedStates(address, index, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleTireSpeedState();
        public static native void destroy(long address);
        public static native float getSpeedStates(long address, int index);
        public static native void setSpeedStates(long address, int index, float value);
        public static native void setToDefault(long address);
    }
}
