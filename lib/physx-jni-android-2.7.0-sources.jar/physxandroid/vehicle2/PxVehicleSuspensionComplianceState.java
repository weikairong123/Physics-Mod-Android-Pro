package physxandroid.vehicle2;

import physxandroid.NativeObject;
import physxandroid.common.PxVec3;

/**
 * The effect of suspension compliance on toe and camber angle and on the tire and suspension force application points.
 */
public class PxVehicleSuspensionComplianceState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleSuspensionComplianceState wrapPointer(long address) {
        return address != 0L ? new PxVehicleSuspensionComplianceState(address) : null;
    }
    
    public static PxVehicleSuspensionComplianceState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleSuspensionComplianceState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleSuspensionComplianceState() {
        address = Raw.PxVehicleSuspensionComplianceState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The toe angle in radians that arises from suspension compliance.
     * <b>Note:</b> toe is expressed in the suspension frame.
     */
    public float getToe() {
        checkNotNull();
        return Raw.getToe(address);
    }

    /**
     * The toe angle in radians that arises from suspension compliance.
     * <b>Note:</b> toe is expressed in the suspension frame.
     */
    public void setToe(float value) {
        checkNotNull();
        Raw.setToe(address, value);
    }

    /**
     * The camber angle in radians that arises from suspension compliance.
     * <b>Note:</b> camber is expressed in the suspension frame.
     */
    public float getCamber() {
        checkNotNull();
        return Raw.getCamber(address);
    }

    /**
     * The camber angle in radians that arises from suspension compliance.
     * <b>Note:</b> camber is expressed in the suspension frame.
     */
    public void setCamber(float value) {
        checkNotNull();
        Raw.setCamber(address, value);
    }

    /**
     * The tire force application point that arises from suspension compliance.
     * <b>Note:</b> tireForceAppPoint is expressed in the suspension frame.
     */
    public PxVec3 getTireForceAppPoint() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getTireForceAppPoint(address));
    }

    /**
     * The tire force application point that arises from suspension compliance.
     * <b>Note:</b> tireForceAppPoint is expressed in the suspension frame.
     */
    public void setTireForceAppPoint(PxVec3 value) {
        checkNotNull();
        Raw.setTireForceAppPoint(address, value.getAddress());
    }

    /**
     * The suspension force application point that arises from suspension compliance.
     * <b>Note:</b> suspForceAppPoint is expressed in the suspension frame.
     */
    public PxVec3 getSuspForceAppPoint() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getSuspForceAppPoint(address));
    }

    /**
     * The suspension force application point that arises from suspension compliance.
     * <b>Note:</b> suspForceAppPoint is expressed in the suspension frame.
     */
    public void setSuspForceAppPoint(PxVec3 value) {
        checkNotNull();
        Raw.setSuspForceAppPoint(address, value.getAddress());
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleSuspensionComplianceState();
        public static native void destroy(long address);
        public static native float getToe(long address);
        public static native void setToe(long address, float value);
        public static native float getCamber(long address);
        public static native void setCamber(long address, float value);
        public static native long getTireForceAppPoint(long address);
        public static native void setTireForceAppPoint(long address, long value);
        public static native long getSuspForceAppPoint(long address);
        public static native void setSuspForceAppPoint(long address, long value);
        public static native void setToDefault(long address);
    }
}
