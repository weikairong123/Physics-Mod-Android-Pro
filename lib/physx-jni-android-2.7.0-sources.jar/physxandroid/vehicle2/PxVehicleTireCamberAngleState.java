package physxandroid.vehicle2;

import physxandroid.NativeObject;

/**
 * Camber angle of the tire relative to the ground plane.
 */
public class PxVehicleTireCamberAngleState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleTireCamberAngleState wrapPointer(long address) {
        return address != 0L ? new PxVehicleTireCamberAngleState(address) : null;
    }
    
    public static PxVehicleTireCamberAngleState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleTireCamberAngleState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleTireCamberAngleState() {
        address = Raw.PxVehicleTireCamberAngleState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     */
    public float getCamberAngle() {
        checkNotNull();
        return Raw.getCamberAngle(address);
    }

    /**
     */
    public void setCamberAngle(float value) {
        checkNotNull();
        Raw.setCamberAngle(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleTireCamberAngleState();
        public static native void destroy(long address);
        public static native float getCamberAngle(long address);
        public static native void setCamberAngle(long address, float value);
        public static native void setToDefault(long address);
    }
}
