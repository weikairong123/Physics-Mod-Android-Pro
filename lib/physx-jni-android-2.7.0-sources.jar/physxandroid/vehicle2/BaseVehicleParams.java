package physxandroid.vehicle2;

import physxandroid.NativeObject;

public class BaseVehicleParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static BaseVehicleParams wrapPointer(long address) {
        return address != 0L ? new BaseVehicleParams(address) : null;
    }
    
    public static BaseVehicleParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected BaseVehicleParams(long address) {
        super(address);
    }

    // Constructors

    public BaseVehicleParams() {
        address = Raw.BaseVehicleParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxVehicleAxleDescription} [Value]
     */
    public PxVehicleAxleDescription getAxleDescription() {
        checkNotNull();
        return PxVehicleAxleDescription.wrapPointer(Raw.getAxleDescription(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleAxleDescription} [Value]
     */
    public void setAxleDescription(PxVehicleAxleDescription value) {
        checkNotNull();
        Raw.setAxleDescription(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleFrame} [Value]
     */
    public PxVehicleFrame getFrame() {
        checkNotNull();
        return PxVehicleFrame.wrapPointer(Raw.getFrame(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleFrame} [Value]
     */
    public void setFrame(PxVehicleFrame value) {
        checkNotNull();
        Raw.setFrame(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleScale} [Value]
     */
    public PxVehicleScale getScale() {
        checkNotNull();
        return PxVehicleScale.wrapPointer(Raw.getScale(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleScale} [Value]
     */
    public void setScale(PxVehicleScale value) {
        checkNotNull();
        Raw.setScale(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleSuspensionStateCalculationParams} [Value]
     */
    public PxVehicleSuspensionStateCalculationParams getSuspensionStateCalculationParams() {
        checkNotNull();
        return PxVehicleSuspensionStateCalculationParams.wrapPointer(Raw.getSuspensionStateCalculationParams(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleSuspensionStateCalculationParams} [Value]
     */
    public void setSuspensionStateCalculationParams(PxVehicleSuspensionStateCalculationParams value) {
        checkNotNull();
        Raw.setSuspensionStateCalculationParams(address, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleBrakeCommandResponseParams} [Value]
     */
    public PxVehicleBrakeCommandResponseParams getBrakeResponseParams(int index) {
        checkNotNull();
        return PxVehicleBrakeCommandResponseParams.wrapPointer(Raw.getBrakeResponseParams(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleBrakeCommandResponseParams} [Value]
     */
    public void setBrakeResponseParams(int index, PxVehicleBrakeCommandResponseParams value) {
        checkNotNull();
        Raw.setBrakeResponseParams(address, index, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleSteerCommandResponseParams} [Value]
     */
    public PxVehicleSteerCommandResponseParams getSteerResponseParams() {
        checkNotNull();
        return PxVehicleSteerCommandResponseParams.wrapPointer(Raw.getSteerResponseParams(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleSteerCommandResponseParams} [Value]
     */
    public void setSteerResponseParams(PxVehicleSteerCommandResponseParams value) {
        checkNotNull();
        Raw.setSteerResponseParams(address, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleAckermannParams} [Value]
     */
    public PxVehicleAckermannParams getAckermannParams(int index) {
        checkNotNull();
        return PxVehicleAckermannParams.wrapPointer(Raw.getAckermannParams(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleAckermannParams} [Value]
     */
    public void setAckermannParams(int index, PxVehicleAckermannParams value) {
        checkNotNull();
        Raw.setAckermannParams(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleSuspensionParams} [Value]
     */
    public PxVehicleSuspensionParams getSuspensionParams(int index) {
        checkNotNull();
        return PxVehicleSuspensionParams.wrapPointer(Raw.getSuspensionParams(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleSuspensionParams} [Value]
     */
    public void setSuspensionParams(int index, PxVehicleSuspensionParams value) {
        checkNotNull();
        Raw.setSuspensionParams(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleSuspensionComplianceParams} [Value]
     */
    public PxVehicleSuspensionComplianceParams getSuspensionComplianceParams(int index) {
        checkNotNull();
        return PxVehicleSuspensionComplianceParams.wrapPointer(Raw.getSuspensionComplianceParams(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleSuspensionComplianceParams} [Value]
     */
    public void setSuspensionComplianceParams(int index, PxVehicleSuspensionComplianceParams value) {
        checkNotNull();
        Raw.setSuspensionComplianceParams(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleSuspensionForceParams} [Value]
     */
    public PxVehicleSuspensionForceParams getSuspensionForceParams(int index) {
        checkNotNull();
        return PxVehicleSuspensionForceParams.wrapPointer(Raw.getSuspensionForceParams(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleSuspensionForceParams} [Value]
     */
    public void setSuspensionForceParams(int index, PxVehicleSuspensionForceParams value) {
        checkNotNull();
        Raw.setSuspensionForceParams(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleAntiRollForceParams} [Value]
     */
    public PxVehicleAntiRollForceParams getAntiRollForceParams(int index) {
        checkNotNull();
        return PxVehicleAntiRollForceParams.wrapPointer(Raw.getAntiRollForceParams(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleAntiRollForceParams} [Value]
     */
    public void setAntiRollForceParams(int index, PxVehicleAntiRollForceParams value) {
        checkNotNull();
        Raw.setAntiRollForceParams(address, index, value.getAddress());
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getNbAntiRollForceParams() {
        checkNotNull();
        return Raw.getNbAntiRollForceParams(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setNbAntiRollForceParams(int value) {
        checkNotNull();
        Raw.setNbAntiRollForceParams(address, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleTireForceParams} [Value]
     */
    public PxVehicleTireForceParams getTireForceParams(int index) {
        checkNotNull();
        return PxVehicleTireForceParams.wrapPointer(Raw.getTireForceParams(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleTireForceParams} [Value]
     */
    public void setTireForceParams(int index, PxVehicleTireForceParams value) {
        checkNotNull();
        Raw.setTireForceParams(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVehicleWheelParams} [Value]
     */
    public PxVehicleWheelParams getWheelParams(int index) {
        checkNotNull();
        return PxVehicleWheelParams.wrapPointer(Raw.getWheelParams(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVehicleWheelParams} [Value]
     */
    public void setWheelParams(int index, PxVehicleWheelParams value) {
        checkNotNull();
        Raw.setWheelParams(address, index, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleRigidBodyParams} [Value]
     */
    public PxVehicleRigidBodyParams getRigidBodyParams() {
        checkNotNull();
        return PxVehicleRigidBodyParams.wrapPointer(Raw.getRigidBodyParams(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleRigidBodyParams} [Value]
     */
    public void setRigidBodyParams(PxVehicleRigidBodyParams value) {
        checkNotNull();
        Raw.setRigidBodyParams(address, value.getAddress());
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link BaseVehicleParams} [Value]
     */
    public BaseVehicleParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return BaseVehicleParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native long BaseVehicleParams();
        public static native void destroy(long address);
        public static native long getAxleDescription(long address);
        public static native void setAxleDescription(long address, long value);
        public static native long getFrame(long address);
        public static native void setFrame(long address, long value);
        public static native long getScale(long address);
        public static native void setScale(long address, long value);
        public static native long getSuspensionStateCalculationParams(long address);
        public static native void setSuspensionStateCalculationParams(long address, long value);
        public static native long getBrakeResponseParams(long address, int index);
        public static native void setBrakeResponseParams(long address, int index, long value);
        public static native long getSteerResponseParams(long address);
        public static native void setSteerResponseParams(long address, long value);
        public static native long getAckermannParams(long address, int index);
        public static native void setAckermannParams(long address, int index, long value);
        public static native long getSuspensionParams(long address, int index);
        public static native void setSuspensionParams(long address, int index, long value);
        public static native long getSuspensionComplianceParams(long address, int index);
        public static native void setSuspensionComplianceParams(long address, int index, long value);
        public static native long getSuspensionForceParams(long address, int index);
        public static native void setSuspensionForceParams(long address, int index, long value);
        public static native long getAntiRollForceParams(long address, int index);
        public static native void setAntiRollForceParams(long address, int index, long value);
        public static native int getNbAntiRollForceParams(long address);
        public static native void setNbAntiRollForceParams(long address, int value);
        public static native long getTireForceParams(long address, int index);
        public static native void setTireForceParams(long address, int index, long value);
        public static native long getWheelParams(long address, int index);
        public static native void setWheelParams(long address, int index, long value);
        public static native long getRigidBodyParams(long address);
        public static native void setRigidBodyParams(long address, long value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address);
    }
}
