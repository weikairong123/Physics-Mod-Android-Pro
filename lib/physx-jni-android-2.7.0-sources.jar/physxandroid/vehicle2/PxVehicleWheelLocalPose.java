package physxandroid.vehicle2;

import physxandroid.NativeObject;
import physxandroid.common.PxTransform;

public class PxVehicleWheelLocalPose extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleWheelLocalPose wrapPointer(long address) {
        return address != 0L ? new PxVehicleWheelLocalPose(address) : null;
    }
    
    public static PxVehicleWheelLocalPose arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleWheelLocalPose(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleWheelLocalPose() {
        address = Raw.PxVehicleWheelLocalPose();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The pose of the wheel in the rigid body frame.
     */
    public PxTransform getLocalPose() {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getLocalPose(address));
    }

    /**
     * The pose of the wheel in the rigid body frame.
     */
    public void setLocalPose(PxTransform value) {
        checkNotNull();
        Raw.setLocalPose(address, value.getAddress());
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleWheelLocalPose();
        public static native void destroy(long address);
        public static native long getLocalPose(long address);
        public static native void setLocalPose(long address, long value);
        public static native void setToDefault(long address);
    }
}
