package physxandroid.vehicle2;

import physxandroid.NativeObject;
import physxandroid.common.PxVec3;

/**
 * The force and torque for a single suspension to apply to the vehicle's rigid body.
 */
public class PxVehicleSuspensionForce extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleSuspensionForce wrapPointer(long address) {
        return address != 0L ? new PxVehicleSuspensionForce(address) : null;
    }
    
    public static PxVehicleSuspensionForce arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleSuspensionForce(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleSuspensionForce() {
        address = Raw.PxVehicleSuspensionForce();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The force to apply to the rigid body.
     * <b>Note:</b> force is expressed in the world frame.
     * <p>
     * <b>Unit:</b> mass * length / (time^2)
     */
    public PxVec3 getForce() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getForce(address));
    }

    /**
     * The force to apply to the rigid body.
     * <b>Note:</b> force is expressed in the world frame.
     * <p>
     * <b>Unit:</b> mass * length / (time^2)
     */
    public void setForce(PxVec3 value) {
        checkNotNull();
        Raw.setForce(address, value.getAddress());
    }

    /**
     * The torque to apply to the rigid body.
     * <b>Note:</b> torque is expressed in the world frame.
     * <p>
     * <b>Unit:</b> mass * (length^2) / (time^2)
     */
    public PxVec3 getTorque() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getTorque(address));
    }

    /**
     * The torque to apply to the rigid body.
     * <b>Note:</b> torque is expressed in the world frame.
     * <p>
     * <b>Unit:</b> mass * (length^2) / (time^2)
     */
    public void setTorque(PxVec3 value) {
        checkNotNull();
        Raw.setTorque(address, value.getAddress());
    }

    /**
     * The component of force that lies along the normal of the plane under the wheel.
     * <b>Note:</b> normalForce may be used by the tire model as the tire load.
     * <p>
     * <b>Unit:</b> mass * length / (time^2)
     */
    public float getNormalForce() {
        checkNotNull();
        return Raw.getNormalForce(address);
    }

    /**
     * The component of force that lies along the normal of the plane under the wheel.
     * <b>Note:</b> normalForce may be used by the tire model as the tire load.
     * <p>
     * <b>Unit:</b> mass * length / (time^2)
     */
    public void setNormalForce(float value) {
        checkNotNull();
        Raw.setNormalForce(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleSuspensionForce();
        public static native void destroy(long address);
        public static native long getForce(long address);
        public static native void setForce(long address, long value);
        public static native long getTorque(long address);
        public static native void setTorque(long address, long value);
        public static native float getNormalForce(long address);
        public static native void setNormalForce(long address, float value);
        public static native void setToDefault(long address);
    }
}
