package physxandroid.vehicle2;

/**
 * A description of the state of transmission-related commands that are applied to a vehicle with engine drive.
 */
public enum PxVehicleEngineDriveTransmissionCommandStateEnum {

    /**
     * Special gear value to denote the automatic shift mode (often referred to as DRIVE).
     * <p>
     * When using automatic transmission, setting this value as target gear will enable automatic 
     * gear shifts between first and highest gear. If the current gear is a reverse gear or
     * the neutral gear, then this value will trigger a shift to first gear. If this value is
     * used even though there is no automatic transmission available, the gear state will remain
     * unchanged.
     */
    eAUTOMATIC_GEAR(geteAUTOMATIC_GEAR());
    public final int value;
    
    PxVehicleEngineDriveTransmissionCommandStateEnum(int value) {
        this.value = value;
    }

    private static native int _geteAUTOMATIC_GEAR();
    private static int geteAUTOMATIC_GEAR() {
        de.fabmax.physxandroid.Loader.load();
        return _geteAUTOMATIC_GEAR();
    }

    private static final int LUT_SIZE = 256;
    private static final PxVehicleEngineDriveTransmissionCommandStateEnum[] enumValues = values();
    private static final PxVehicleEngineDriveTransmissionCommandStateEnum[] enumLut = new PxVehicleEngineDriveTransmissionCommandStateEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxVehicleEngineDriveTransmissionCommandStateEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxVehicleEngineDriveTransmissionCommandStateEnum forValue(int value) {
        PxVehicleEngineDriveTransmissionCommandStateEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxVehicleEngineDriveTransmissionCommandStateEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxVehicleEngineDriveTransmissionCommandStateEnum: " + value);
        }
        return enumValue;
    }
}
