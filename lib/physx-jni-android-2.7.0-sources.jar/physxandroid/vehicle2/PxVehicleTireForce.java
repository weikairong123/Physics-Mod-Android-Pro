package physxandroid.vehicle2;

import physxandroid.NativeObject;
import physxandroid.common.PxVec3;

/**
 * The longitudinal/lateral forces/torques that develop on the tire.
 */
public class PxVehicleTireForce extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleTireForce wrapPointer(long address) {
        return address != 0L ? new PxVehicleTireForce(address) : null;
    }
    
    public static PxVehicleTireForce arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleTireForce(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleTireForce() {
        address = Raw.PxVehicleTireForce();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getForces(int index) {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getForces(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setForces(int index, PxVec3 value) {
        checkNotNull();
        Raw.setForces(address, index, value.getAddress());
    }

    /**
     * @param index Array index
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getTorques(int index) {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getTorques(address, index));
    }

    /**
     * @param index Array index
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setTorques(int index, PxVec3 value) {
        checkNotNull();
        Raw.setTorques(address, index, value.getAddress());
    }

    /**
     * The aligning moment may be propagated to a torque-driven steering controller.
     */
    public float getAligningMoment() {
        checkNotNull();
        return Raw.getAligningMoment(address);
    }

    /**
     * The aligning moment may be propagated to a torque-driven steering controller.
     */
    public void setAligningMoment(float value) {
        checkNotNull();
        Raw.setAligningMoment(address, value);
    }

    /**
     * The torque to apply to the wheel's 1d rigid body.
     */
    public float getWheelTorque() {
        checkNotNull();
        return Raw.getWheelTorque(address);
    }

    /**
     * The torque to apply to the wheel's 1d rigid body.
     */
    public void setWheelTorque(float value) {
        checkNotNull();
        Raw.setWheelTorque(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleTireForce();
        public static native void destroy(long address);
        public static native long getForces(long address, int index);
        public static native void setForces(long address, int index, long value);
        public static native long getTorques(long address, int index);
        public static native void setTorques(long address, int index, long value);
        public static native float getAligningMoment(long address);
        public static native void setAligningMoment(long address, float value);
        public static native float getWheelTorque(long address);
        public static native void setWheelTorque(long address, float value);
        public static native void setToDefault(long address);
    }
}
