package physxandroid.vehicle2;

/**
 * Each command value may be associated with a table specifying a normalized response as a function of longitudinal speed.
 * Multiple instances of PxVehicleCommandValueResponseTable allow a normalized response to be authored as a multi-variate 
 * piecewise polynomial with normalized command response expressed as a nonlinear function of command value and speed.
 */
public enum PxVehicleCommandValueResponseTableEnum {

    eMAX_NB_SPEED_RESPONSES(geteMAX_NB_SPEED_RESPONSES());
    public final int value;
    
    PxVehicleCommandValueResponseTableEnum(int value) {
        this.value = value;
    }

    private static native int _geteMAX_NB_SPEED_RESPONSES();
    private static int geteMAX_NB_SPEED_RESPONSES() {
        de.fabmax.physxandroid.Loader.load();
        return _geteMAX_NB_SPEED_RESPONSES();
    }

    private static final int LUT_SIZE = 256;
    private static final PxVehicleCommandValueResponseTableEnum[] enumValues = values();
    private static final PxVehicleCommandValueResponseTableEnum[] enumLut = new PxVehicleCommandValueResponseTableEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxVehicleCommandValueResponseTableEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxVehicleCommandValueResponseTableEnum forValue(int value) {
        PxVehicleCommandValueResponseTableEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxVehicleCommandValueResponseTableEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxVehicleCommandValueResponseTableEnum: " + value);
        }
        return enumValue;
    }
}
