package physxandroid.vehicle2;


/**
 * A description of the state of transmission-related commands that are applied to a vehicle with tank drive.
 */
public class PxVehicleTankDriveTransmissionCommandState extends PxVehicleEngineDriveTransmissionCommandState {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleTankDriveTransmissionCommandState wrapPointer(long address) {
        return address != 0L ? new PxVehicleTankDriveTransmissionCommandState(address) : null;
    }
    
    public static PxVehicleTankDriveTransmissionCommandState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleTankDriveTransmissionCommandState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleTankDriveTransmissionCommandState() {
        address = Raw.PxVehicleTankDriveTransmissionCommandState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getThrusts(int index) {
        checkNotNull();
        return Raw.getThrusts(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setThrusts(int index, float value) {
        checkNotNull();
        Raw.setThrusts(address, index, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleTankDriveTransmissionCommandState();
        public static native void destroy(long address);
        public static native float getThrusts(long address, int index);
        public static native void setThrusts(long address, int index, float value);
        public static native void setToDefault(long address);
    }
}
