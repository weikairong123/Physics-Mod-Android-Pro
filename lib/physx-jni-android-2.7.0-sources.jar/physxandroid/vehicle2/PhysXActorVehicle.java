package physxandroid.vehicle2;

import physxandroid.cooking.PxCookingParams;
import physxandroid.physics.PxMaterial;
import physxandroid.physics.PxPhysics;

public class PhysXActorVehicle extends BaseVehicle {

    protected PhysXActorVehicle() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PhysXActorVehicle wrapPointer(long address) {
        return address != 0L ? new PhysXActorVehicle(address) : null;
    }
    
    public static PhysXActorVehicle arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PhysXActorVehicle(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PhysXIntegrationParams} [Value]
     */
    public PhysXIntegrationParams getPhysXParams() {
        checkNotNull();
        return PhysXIntegrationParams.wrapPointer(Raw.getPhysXParams(address));
    }

    /**
     * @param value WebIDL type: {@link PhysXIntegrationParams} [Value]
     */
    public void setPhysXParams(PhysXIntegrationParams value) {
        checkNotNull();
        Raw.setPhysXParams(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PhysXIntegrationState} [Value]
     */
    public PhysXIntegrationState getPhysXState() {
        checkNotNull();
        return PhysXIntegrationState.wrapPointer(Raw.getPhysXState(address));
    }

    /**
     * @param value WebIDL type: {@link PhysXIntegrationState} [Value]
     */
    public void setPhysXState(PhysXIntegrationState value) {
        checkNotNull();
        Raw.setPhysXState(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleCommandState} [Value]
     */
    public PxVehicleCommandState getCommandState() {
        checkNotNull();
        return PxVehicleCommandState.wrapPointer(Raw.getCommandState(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleCommandState} [Value]
     */
    public void setCommandState(PxVehicleCommandState value) {
        checkNotNull();
        Raw.setCommandState(address, value.getAddress());
    }

    // Functions

    /**
     * @param physics         WebIDL type: {@link PxPhysics} [Ref]
     * @param params          WebIDL type: {@link PxCookingParams} [Const, Ref]
     * @param defaultMaterial WebIDL type: {@link PxMaterial} [Ref]
     * @return WebIDL type: boolean
     */
    public boolean initialize(PxPhysics physics, PxCookingParams params, PxMaterial defaultMaterial) {
        checkNotNull();
        return Raw.initialize(address, physics.getAddress(), params.getAddress(), defaultMaterial.getAddress());
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getPhysXParams(long address);
        public static native void setPhysXParams(long address, long value);
        public static native long getPhysXState(long address);
        public static native void setPhysXState(long address, long value);
        public static native long getCommandState(long address);
        public static native void setCommandState(long address, long value);
        public static native boolean initialize(long address, long physics, long params, long defaultMaterial);
    }
}
