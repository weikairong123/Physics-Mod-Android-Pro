package physxandroid.vehicle2;

import physxandroid.cooking.PxCookingParams;
import physxandroid.physics.PxMaterial;
import physxandroid.physics.PxPhysics;

public class DirectDriveVehicle extends PhysXActorVehicle {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static DirectDriveVehicle wrapPointer(long address) {
        return address != 0L ? new DirectDriveVehicle(address) : null;
    }
    
    public static DirectDriveVehicle arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected DirectDriveVehicle(long address) {
        super(address);
    }

    // Constructors

    public DirectDriveVehicle() {
        address = Raw.DirectDriveVehicle();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link DirectDrivetrainParams} [Value]
     */
    public DirectDrivetrainParams getDirectDriveParams() {
        checkNotNull();
        return DirectDrivetrainParams.wrapPointer(Raw.getDirectDriveParams(address));
    }

    /**
     * @param value WebIDL type: {@link DirectDrivetrainParams} [Value]
     */
    public void setDirectDriveParams(DirectDrivetrainParams value) {
        checkNotNull();
        Raw.setDirectDriveParams(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link DirectDrivetrainState} [Value]
     */
    public DirectDrivetrainState getDirectDriveState() {
        checkNotNull();
        return DirectDrivetrainState.wrapPointer(Raw.getDirectDriveState(address));
    }

    /**
     * @param value WebIDL type: {@link DirectDrivetrainState} [Value]
     */
    public void setDirectDriveState(DirectDrivetrainState value) {
        checkNotNull();
        Raw.setDirectDriveState(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleDirectDriveTransmissionCommandState} [Value]
     */
    public PxVehicleDirectDriveTransmissionCommandState getTransmissionCommandState() {
        checkNotNull();
        return PxVehicleDirectDriveTransmissionCommandState.wrapPointer(Raw.getTransmissionCommandState(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleDirectDriveTransmissionCommandState} [Value]
     */
    public void setTransmissionCommandState(PxVehicleDirectDriveTransmissionCommandState value) {
        checkNotNull();
        Raw.setTransmissionCommandState(address, value.getAddress());
    }

    // Functions

    /**
     * @param physics         WebIDL type: {@link PxPhysics} [Ref]
     * @param params          WebIDL type: {@link PxCookingParams} [Const, Ref]
     * @param defaultMaterial WebIDL type: {@link PxMaterial} [Ref]
     * @return WebIDL type: boolean
     */
    public boolean initialize(PxPhysics physics, PxCookingParams params, PxMaterial defaultMaterial) {
        checkNotNull();
        return Raw.initialize(address, physics.getAddress(), params.getAddress(), defaultMaterial.getAddress());
    }

    /**
     * @param physics                    WebIDL type: {@link PxPhysics} [Ref]
     * @param params                     WebIDL type: {@link PxCookingParams} [Const, Ref]
     * @param defaultMaterial            WebIDL type: {@link PxMaterial} [Ref]
     * @param addPhysXBeginEndComponents WebIDL type: boolean
     * @return WebIDL type: boolean
     */
    public boolean initialize(PxPhysics physics, PxCookingParams params, PxMaterial defaultMaterial, boolean addPhysXBeginEndComponents) {
        checkNotNull();
        return Raw.initialize(address, physics.getAddress(), params.getAddress(), defaultMaterial.getAddress(), addPhysXBeginEndComponents);
    }

    /**
     * @param addPhysXBeginEndComponents WebIDL type: boolean
     */
    public void initComponentSequence(boolean addPhysXBeginEndComponents) {
        checkNotNull();
        Raw.initComponentSequence(address, addPhysXBeginEndComponents);
    }

    public static class Raw {
        public static native long DirectDriveVehicle();
        public static native void destroy(long address);
        public static native long getDirectDriveParams(long address);
        public static native void setDirectDriveParams(long address, long value);
        public static native long getDirectDriveState(long address);
        public static native void setDirectDriveState(long address, long value);
        public static native long getTransmissionCommandState(long address);
        public static native void setTransmissionCommandState(long address, long value);
        public static native boolean initialize(long address, long physics, long params, long defaultMaterial);
        public static native boolean initialize(long address, long physics, long params, long defaultMaterial, boolean addPhysXBeginEndComponents);
        public static native void initComponentSequence(long address, boolean addPhysXBeginEndComponents);
    }
}
