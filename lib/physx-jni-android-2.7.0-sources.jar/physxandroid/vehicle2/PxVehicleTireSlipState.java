package physxandroid.vehicle2;

import physxandroid.NativeObject;

/**
 * The lateral and longitudinal tire slips.
 * @see PxVehicleTireSpeedState
 */
public class PxVehicleTireSlipState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleTireSlipState wrapPointer(long address) {
        return address != 0L ? new PxVehicleTireSlipState(address) : null;
    }
    
    public static PxVehicleTireSlipState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleTireSlipState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleTireSlipState() {
        address = Raw.PxVehicleTireSlipState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getSlips(int index) {
        checkNotNull();
        return Raw.getSlips(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setSlips(int index, float value) {
        checkNotNull();
        Raw.setSlips(address, index, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleTireSlipState();
        public static native void destroy(long address);
        public static native float getSlips(long address, int index);
        public static native void setSlips(long address, int index, float value);
        public static native void setToDefault(long address);
    }
}
