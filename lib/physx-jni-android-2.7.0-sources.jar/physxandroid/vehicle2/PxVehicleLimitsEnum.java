package physxandroid.vehicle2;

public enum PxVehicleLimitsEnum {

    eMAX_NB_WHEELS(geteMAX_NB_WHEELS()),
    eMAX_NB_AXLES(geteMAX_NB_AXLES());
    public final int value;
    
    PxVehicleLimitsEnum(int value) {
        this.value = value;
    }

    private static native int _geteMAX_NB_WHEELS();
    private static int geteMAX_NB_WHEELS() {
        de.fabmax.physxandroid.Loader.load();
        return _geteMAX_NB_WHEELS();
    }

    private static native int _geteMAX_NB_AXLES();
    private static int geteMAX_NB_AXLES() {
        de.fabmax.physxandroid.Loader.load();
        return _geteMAX_NB_AXLES();
    }

    private static final int LUT_SIZE = 256;
    private static final PxVehicleLimitsEnum[] enumValues = values();
    private static final PxVehicleLimitsEnum[] enumLut = new PxVehicleLimitsEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxVehicleLimitsEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxVehicleLimitsEnum forValue(int value) {
        PxVehicleLimitsEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxVehicleLimitsEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxVehicleLimitsEnum: " + value);
        }
        return enumValue;
    }
}
