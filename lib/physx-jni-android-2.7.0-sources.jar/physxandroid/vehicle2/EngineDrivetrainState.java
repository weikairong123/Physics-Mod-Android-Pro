package physxandroid.vehicle2;

import physxandroid.NativeObject;

public class EngineDrivetrainState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static EngineDrivetrainState wrapPointer(long address) {
        return address != 0L ? new EngineDrivetrainState(address) : null;
    }
    
    public static EngineDrivetrainState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected EngineDrivetrainState(long address) {
        super(address);
    }

    // Constructors

    public EngineDrivetrainState() {
        address = Raw.EngineDrivetrainState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxVehicleEngineDriveThrottleCommandResponseState} [Value]
     */
    public PxVehicleEngineDriveThrottleCommandResponseState getThrottleCommandResponseState() {
        checkNotNull();
        return PxVehicleEngineDriveThrottleCommandResponseState.wrapPointer(Raw.getThrottleCommandResponseState(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleEngineDriveThrottleCommandResponseState} [Value]
     */
    public void setThrottleCommandResponseState(PxVehicleEngineDriveThrottleCommandResponseState value) {
        checkNotNull();
        Raw.setThrottleCommandResponseState(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleAutoboxState} [Value]
     */
    public PxVehicleAutoboxState getAutoboxState() {
        checkNotNull();
        return PxVehicleAutoboxState.wrapPointer(Raw.getAutoboxState(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleAutoboxState} [Value]
     */
    public void setAutoboxState(PxVehicleAutoboxState value) {
        checkNotNull();
        Raw.setAutoboxState(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleClutchCommandResponseState} [Value]
     */
    public PxVehicleClutchCommandResponseState getClutchCommandResponseState() {
        checkNotNull();
        return PxVehicleClutchCommandResponseState.wrapPointer(Raw.getClutchCommandResponseState(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleClutchCommandResponseState} [Value]
     */
    public void setClutchCommandResponseState(PxVehicleClutchCommandResponseState value) {
        checkNotNull();
        Raw.setClutchCommandResponseState(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleDifferentialState} [Value]
     */
    public PxVehicleDifferentialState getDifferentialState() {
        checkNotNull();
        return PxVehicleDifferentialState.wrapPointer(Raw.getDifferentialState(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleDifferentialState} [Value]
     */
    public void setDifferentialState(PxVehicleDifferentialState value) {
        checkNotNull();
        Raw.setDifferentialState(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleWheelConstraintGroupState} [Value]
     */
    public PxVehicleWheelConstraintGroupState getWheelConstraintGroupState() {
        checkNotNull();
        return PxVehicleWheelConstraintGroupState.wrapPointer(Raw.getWheelConstraintGroupState(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleWheelConstraintGroupState} [Value]
     */
    public void setWheelConstraintGroupState(PxVehicleWheelConstraintGroupState value) {
        checkNotNull();
        Raw.setWheelConstraintGroupState(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleEngineState} [Value]
     */
    public PxVehicleEngineState getEngineState() {
        checkNotNull();
        return PxVehicleEngineState.wrapPointer(Raw.getEngineState(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleEngineState} [Value]
     */
    public void setEngineState(PxVehicleEngineState value) {
        checkNotNull();
        Raw.setEngineState(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleGearboxState} [Value]
     */
    public PxVehicleGearboxState getGearboxState() {
        checkNotNull();
        return PxVehicleGearboxState.wrapPointer(Raw.getGearboxState(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleGearboxState} [Value]
     */
    public void setGearboxState(PxVehicleGearboxState value) {
        checkNotNull();
        Raw.setGearboxState(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVehicleClutchSlipState} [Value]
     */
    public PxVehicleClutchSlipState getClutchState() {
        checkNotNull();
        return PxVehicleClutchSlipState.wrapPointer(Raw.getClutchState(address));
    }

    /**
     * @param value WebIDL type: {@link PxVehicleClutchSlipState} [Value]
     */
    public void setClutchState(PxVehicleClutchSlipState value) {
        checkNotNull();
        Raw.setClutchState(address, value.getAddress());
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long EngineDrivetrainState();
        public static native void destroy(long address);
        public static native long getThrottleCommandResponseState(long address);
        public static native void setThrottleCommandResponseState(long address, long value);
        public static native long getAutoboxState(long address);
        public static native void setAutoboxState(long address, long value);
        public static native long getClutchCommandResponseState(long address);
        public static native void setClutchCommandResponseState(long address, long value);
        public static native long getDifferentialState(long address);
        public static native void setDifferentialState(long address, long value);
        public static native long getWheelConstraintGroupState(long address);
        public static native void setWheelConstraintGroupState(long address, long value);
        public static native long getEngineState(long address);
        public static native void setEngineState(long address, long value);
        public static native long getGearboxState(long address);
        public static native void setGearboxState(long address, long value);
        public static native long getClutchState(long address);
        public static native void setClutchState(long address, long value);
        public static native void setToDefault(long address);
    }
}
