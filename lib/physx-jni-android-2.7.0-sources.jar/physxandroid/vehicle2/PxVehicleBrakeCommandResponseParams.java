package physxandroid.vehicle2;


/**
 * Distribute a brake response to the wheels of a vehicle.
 * <b>Note:</b> The brake torque of each wheel on the ith wheel is brakeCommand * maxResponse * wheelResponseMultipliers[i].
 * <b>Note:</b> A typical use case is to set maxResponse to be the vehicle's maximum achievable brake torque
 * that occurs when the brake command is equal to 1.0.  The array wheelResponseMultipliers[i] would then be used
 * to specify the maximum achievable brake torque per wheel as a fractional multiplier of the vehicle's maximum achievable brake torque.
 */
public class PxVehicleBrakeCommandResponseParams extends PxVehicleCommandResponseParams {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleBrakeCommandResponseParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleBrakeCommandResponseParams(address) : null;
    }
    
    public static PxVehicleBrakeCommandResponseParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleBrakeCommandResponseParams(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleBrakeCommandResponseParams() {
        address = Raw.PxVehicleBrakeCommandResponseParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehicleBrakeCommandResponseParams} [Value]
     */
    public PxVehicleBrakeCommandResponseParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehicleBrakeCommandResponseParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @param axleDesc WebIDL type: {@link PxVehicleAxleDescription} [Const, Ref]
     * @return WebIDL type: boolean
     */
    public boolean isValid(PxVehicleAxleDescription axleDesc) {
        checkNotNull();
        return Raw.isValid(address, axleDesc.getAddress());
    }

    public static class Raw {
        public static native long PxVehicleBrakeCommandResponseParams();
        public static native void destroy(long address);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address, long axleDesc);
    }
}
