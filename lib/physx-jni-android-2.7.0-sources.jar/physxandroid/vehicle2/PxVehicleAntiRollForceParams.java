package physxandroid.vehicle2;

import physxandroid.NativeObject;

/**
 * The purpose of the anti-roll bar is to generate a torque to apply to the vehicle's rigid body that will reduce the jounce difference arising
 * between any pair of chosen wheels. If the chosen wheels share an axle, the anti-roll bar will attempt to reduce the roll angle of the vehicle's rigid body.
 * Alternatively, if the chosen wheels are the front and rear wheels along one side of the vehicle, the anti-roll bar will attempt to reduce the pitch angle of the 
 * vehicle's rigid body.
 */
public class PxVehicleAntiRollForceParams extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleAntiRollForceParams wrapPointer(long address) {
        return address != 0L ? new PxVehicleAntiRollForceParams(address) : null;
    }
    
    public static PxVehicleAntiRollForceParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleAntiRollForceParams(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleAntiRollForceParams() {
        address = Raw.PxVehicleAntiRollForceParams();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     */
    public int getWheel0() {
        checkNotNull();
        return Raw.getWheel0(address);
    }

    /**
     */
    public void setWheel0(int value) {
        checkNotNull();
        Raw.setWheel0(address, value);
    }

    /**
     */
    public int getWheel1() {
        checkNotNull();
        return Raw.getWheel1(address);
    }

    /**
     */
    public void setWheel1(int value) {
        checkNotNull();
        Raw.setWheel1(address, value);
    }

    /**
     */
    public float getStiffness() {
        checkNotNull();
        return Raw.getStiffness(address);
    }

    /**
     */
    public void setStiffness(float value) {
        checkNotNull();
        Raw.setStiffness(address, value);
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehicleAntiRollForceParams} [Value]
     */
    public PxVehicleAntiRollForceParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehicleAntiRollForceParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @param axleDesc WebIDL type: {@link PxVehicleAxleDescription} [Const, Ref]
     * @return WebIDL type: boolean
     */
    public boolean isValid(PxVehicleAxleDescription axleDesc) {
        checkNotNull();
        return Raw.isValid(address, axleDesc.getAddress());
    }

    public static class Raw {
        public static native long PxVehicleAntiRollForceParams();
        public static native void destroy(long address);
        public static native int getWheel0(long address);
        public static native void setWheel0(long address, int value);
        public static native int getWheel1(long address);
        public static native void setWheel1(long address, int value);
        public static native float getStiffness(long address);
        public static native void setStiffness(long address, float value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address, long axleDesc);
    }
}
