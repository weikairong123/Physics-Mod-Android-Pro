package physxandroid.vehicle2;

import physxandroid.NativeObject;
import physxandroid.common.PxTransform;
import physxandroid.common.PxVec3;

public class PxVehicleRigidBodyState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleRigidBodyState wrapPointer(long address) {
        return address != 0L ? new PxVehicleRigidBodyState(address) : null;
    }
    
    public static PxVehicleRigidBodyState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleRigidBodyState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleRigidBodyState() {
        address = Raw.PxVehicleRigidBodyState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * the body's pose (in world space)
     */
    public PxTransform getPose() {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getPose(address));
    }

    /**
     * the body's pose (in world space)
     */
    public void setPose(PxTransform value) {
        checkNotNull();
        Raw.setPose(address, value.getAddress());
    }

    /**
     * the body's linear velocity (in world space)
     */
    public PxVec3 getLinearVelocity() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getLinearVelocity(address));
    }

    /**
     * the body's linear velocity (in world space)
     */
    public void setLinearVelocity(PxVec3 value) {
        checkNotNull();
        Raw.setLinearVelocity(address, value.getAddress());
    }

    /**
     * the body's angular velocity (in world space)
     */
    public PxVec3 getAngularVelocity() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getAngularVelocity(address));
    }

    /**
     * the body's angular velocity (in world space)
     */
    public void setAngularVelocity(PxVec3 value) {
        checkNotNull();
        Raw.setAngularVelocity(address, value.getAddress());
    }

    /**
     * the previous linear velocity of the body (in world space)
     */
    public PxVec3 getPreviousLinearVelocity() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getPreviousLinearVelocity(address));
    }

    /**
     * the previous linear velocity of the body (in world space)
     */
    public void setPreviousLinearVelocity(PxVec3 value) {
        checkNotNull();
        Raw.setPreviousLinearVelocity(address, value.getAddress());
    }

    /**
     * the previous angular velocity of the body (in world space)
     */
    public PxVec3 getPreviousAngularVelocity() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getPreviousAngularVelocity(address));
    }

    /**
     * the previous angular velocity of the body (in world space)
     */
    public void setPreviousAngularVelocity(PxVec3 value) {
        checkNotNull();
        Raw.setPreviousAngularVelocity(address, value.getAddress());
    }

    /**
     * external force (in world space) affecting the rigid body (usually excluding gravitational force)
     */
    public PxVec3 getExternalForce() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getExternalForce(address));
    }

    /**
     * external force (in world space) affecting the rigid body (usually excluding gravitational force)
     */
    public void setExternalForce(PxVec3 value) {
        checkNotNull();
        Raw.setExternalForce(address, value.getAddress());
    }

    /**
     * external torque (in world space) affecting the rigid body
     */
    public PxVec3 getExternalTorque() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getExternalTorque(address));
    }

    /**
     * external torque (in world space) affecting the rigid body
     */
    public void setExternalTorque(PxVec3 value) {
        checkNotNull();
        Raw.setExternalTorque(address, value.getAddress());
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    /**
     * Compute the vertical speed of the rigid body transformed to the world frame.
     * @param frame describes the axes of the vehicle
     */
    public float getVerticalSpeed(PxVehicleFrame frame) {
        checkNotNull();
        return Raw.getVerticalSpeed(address, frame.getAddress());
    }

    /**
     * @param frame describes the axes of the vehicle
     * Compute the lateral speed of the rigid body transformed to the world frame.
     */
    public float getLateralSpeed(PxVehicleFrame frame) {
        checkNotNull();
        return Raw.getLateralSpeed(address, frame.getAddress());
    }

    /**
     * Compute the longitudinal speed of the rigid body transformed to the world frame.
     * @param frame describes the axes of the vehicle
     */
    public float getLongitudinalSpeed(PxVehicleFrame frame) {
        checkNotNull();
        return Raw.getLongitudinalSpeed(address, frame.getAddress());
    }

    public static class Raw {
        public static native long PxVehicleRigidBodyState();
        public static native void destroy(long address);
        public static native long getPose(long address);
        public static native void setPose(long address, long value);
        public static native long getLinearVelocity(long address);
        public static native void setLinearVelocity(long address, long value);
        public static native long getAngularVelocity(long address);
        public static native void setAngularVelocity(long address, long value);
        public static native long getPreviousLinearVelocity(long address);
        public static native void setPreviousLinearVelocity(long address, long value);
        public static native long getPreviousAngularVelocity(long address);
        public static native void setPreviousAngularVelocity(long address, long value);
        public static native long getExternalForce(long address);
        public static native void setExternalForce(long address, long value);
        public static native long getExternalTorque(long address);
        public static native void setExternalTorque(long address, long value);
        public static native void setToDefault(long address);
        public static native float getVerticalSpeed(long address, long frame);
        public static native float getLateralSpeed(long address, long frame);
        public static native float getLongitudinalSpeed(long address, long frame);
    }
}
