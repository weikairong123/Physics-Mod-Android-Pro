package physxandroid.vehicle2;

import physxandroid.NativeObject;

/**
 * Each command value may be associated with a table specifying a normalized response as a function of longitudinal speed.
 * Multiple instances of PxVehicleCommandValueResponseTable allow a normalized response to be authored as a multi-variate 
 * piecewise polynomial with normalized command response expressed as a nonlinear function of command value and speed.
 */
public class PxVehicleCommandValueResponseTable extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleCommandValueResponseTable wrapPointer(long address) {
        return address != 0L ? new PxVehicleCommandValueResponseTable(address) : null;
    }
    
    public static PxVehicleCommandValueResponseTable arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleCommandValueResponseTable(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleCommandValueResponseTable() {
        address = Raw.PxVehicleCommandValueResponseTable();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The command value associated with the table of speed responses.
     */
    public float getCommandValue() {
        checkNotNull();
        return Raw.getCommandValue(address);
    }

    /**
     * The command value associated with the table of speed responses.
     */
    public void setCommandValue(float value) {
        checkNotNull();
        Raw.setCommandValue(address, value);
    }

    public static class Raw {
        public static native long PxVehicleCommandValueResponseTable();
        public static native void destroy(long address);
        public static native float getCommandValue(long address);
        public static native void setCommandValue(long address, float value);
    }
}
