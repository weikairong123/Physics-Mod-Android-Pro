package physxandroid.vehicle2;

import physxandroid.NativeObject;

public class PxVehicleDifferentialState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleDifferentialState wrapPointer(long address) {
        return address != 0L ? new PxVehicleDifferentialState(address) : null;
    }
    
    public static PxVehicleDifferentialState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleDifferentialState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleDifferentialState() {
        address = Raw.PxVehicleDifferentialState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: unsigned long
     */
    public int getConnectedWheels(int index) {
        checkNotNull();
        return Raw.getConnectedWheels(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: unsigned long
     */
    public void setConnectedWheels(int index, int value) {
        checkNotNull();
        Raw.setConnectedWheels(address, index, value);
    }

    /**
     * The number of wheels that are connected to the differential.
     */
    public int getNbConnectedWheels() {
        checkNotNull();
        return Raw.getNbConnectedWheels(address);
    }

    /**
     * The number of wheels that are connected to the differential.
     */
    public void setNbConnectedWheels(int value) {
        checkNotNull();
        Raw.setNbConnectedWheels(address, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getTorqueRatiosAllWheels(int index) {
        checkNotNull();
        return Raw.getTorqueRatiosAllWheels(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setTorqueRatiosAllWheels(int index, float value) {
        checkNotNull();
        Raw.setTorqueRatiosAllWheels(address, index, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getAveWheelSpeedContributionAllWheels(int index) {
        checkNotNull();
        return Raw.getAveWheelSpeedContributionAllWheels(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setAveWheelSpeedContributionAllWheels(int index, float value) {
        checkNotNull();
        Raw.setAveWheelSpeedContributionAllWheels(address, index, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleDifferentialState();
        public static native void destroy(long address);
        public static native int getConnectedWheels(long address, int index);
        public static native void setConnectedWheels(long address, int index, int value);
        public static native int getNbConnectedWheels(long address);
        public static native void setNbConnectedWheels(long address, int value);
        public static native float getTorqueRatiosAllWheels(long address, int index);
        public static native void setTorqueRatiosAllWheels(long address, int index, float value);
        public static native float getAveWheelSpeedContributionAllWheels(long address, int index);
        public static native void setAveWheelSpeedContributionAllWheels(long address, int index, float value);
        public static native void setToDefault(long address);
    }
}
