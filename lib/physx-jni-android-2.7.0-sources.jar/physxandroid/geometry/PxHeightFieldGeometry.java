package physxandroid.geometry;


/**
 * Height field geometry class.
 * <p>
 * This class allows to create a scaled height field geometry instance.
 * <p>
 * There is a minimum allowed value for Y and XZ scaling - PX_MIN_HEIGHTFIELD_XZ_SCALE, heightfield creation will fail if XZ value is below this value.
 */
public class PxHeightFieldGeometry extends PxGeometry {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxHeightFieldGeometry wrapPointer(long address) {
        return address != 0L ? new PxHeightFieldGeometry(address) : null;
    }
    
    public static PxHeightFieldGeometry arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxHeightFieldGeometry(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxHeightFieldGeometry
     */
    public static PxHeightFieldGeometry createAt(long address) {
        Raw.PxHeightFieldGeometry_placed(address);
        PxHeightFieldGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxHeightFieldGeometry
     */
    public static <T> PxHeightFieldGeometry createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxHeightFieldGeometry_placed(address);
        PxHeightFieldGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address     Pre-allocated memory, where the object is created.
     * @param hf          WebIDL type: {@link PxHeightField}
     * @param flags       WebIDL type: {@link PxMeshGeometryFlags} [Ref]
     * @param heightScale WebIDL type: float
     * @param rowScale    WebIDL type: float
     * @param columnScale WebIDL type: float
     * @return Stack allocated object of PxHeightFieldGeometry
     */
    public static PxHeightFieldGeometry createAt(long address, PxHeightField hf, PxMeshGeometryFlags flags, float heightScale, float rowScale, float columnScale) {
        Raw.PxHeightFieldGeometry_placed(address, hf.getAddress(), flags.getAddress(), heightScale, rowScale, columnScale);
        PxHeightFieldGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>         Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator   Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate    Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param hf          WebIDL type: {@link PxHeightField}
     * @param flags       WebIDL type: {@link PxMeshGeometryFlags} [Ref]
     * @param heightScale WebIDL type: float
     * @param rowScale    WebIDL type: float
     * @param columnScale WebIDL type: float
     * @return Stack allocated object of PxHeightFieldGeometry
     */
    public static <T> PxHeightFieldGeometry createAt(T allocator, Allocator<T> allocate, PxHeightField hf, PxMeshGeometryFlags flags, float heightScale, float rowScale, float columnScale) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxHeightFieldGeometry_placed(address, hf.getAddress(), flags.getAddress(), heightScale, rowScale, columnScale);
        PxHeightFieldGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * Constructor.
     */
    public PxHeightFieldGeometry() {
        address = Raw.PxHeightFieldGeometry();
    }

    /**
     * Constructor.
     */
    public PxHeightFieldGeometry(PxHeightField hf, PxMeshGeometryFlags flags, float heightScale, float rowScale, float columnScale) {
        address = Raw.PxHeightFieldGeometry(hf.getAddress(), flags.getAddress(), heightScale, rowScale, columnScale);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The height field data.
     */
    public PxHeightField getHeightField() {
        checkNotNull();
        return PxHeightField.wrapPointer(Raw.getHeightField(address));
    }

    /**
     * The height field data.
     */
    public void setHeightField(PxHeightField value) {
        checkNotNull();
        Raw.setHeightField(address, value.getAddress());
    }

    /**
     * The scaling factor for the height field in vertical direction (y direction in local space).
     */
    public float getHeightScale() {
        checkNotNull();
        return Raw.getHeightScale(address);
    }

    /**
     * The scaling factor for the height field in vertical direction (y direction in local space).
     */
    public void setHeightScale(float value) {
        checkNotNull();
        Raw.setHeightScale(address, value);
    }

    /**
     * The scaling factor for the height field in the row direction (x direction in local space).
     */
    public float getRowScale() {
        checkNotNull();
        return Raw.getRowScale(address);
    }

    /**
     * The scaling factor for the height field in the row direction (x direction in local space).
     */
    public void setRowScale(float value) {
        checkNotNull();
        Raw.setRowScale(address, value);
    }

    /**
     * The scaling factor for the height field in the column direction (z direction in local space).
     */
    public float getColumnScale() {
        checkNotNull();
        return Raw.getColumnScale(address);
    }

    /**
     * The scaling factor for the height field in the column direction (z direction in local space).
     */
    public void setColumnScale(float value) {
        checkNotNull();
        Raw.setColumnScale(address, value);
    }

    /**
     * Flags to specify some collision properties for the height field.
     */
    public PxMeshGeometryFlags getHeightFieldFlags() {
        checkNotNull();
        return PxMeshGeometryFlags.wrapPointer(Raw.getHeightFieldFlags(address));
    }

    /**
     * Flags to specify some collision properties for the height field.
     */
    public void setHeightFieldFlags(PxMeshGeometryFlags value) {
        checkNotNull();
        Raw.setHeightFieldFlags(address, value.getAddress());
    }

    // Functions

    /**
     * Returns true if the geometry is valid.
     * @return True if the current settings are valid
     * <p>
     * <b>Note:</b> A valid height field has a positive scale value in each direction (heightScale &gt; 0, rowScale &gt; 0, columnScale &gt; 0).
     * It is illegal to call PxPhysics::createShape with a height field that has zero extents in any direction.
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native void PxHeightFieldGeometry_placed(long address);
        public static native void PxHeightFieldGeometry_placed(long address, long hf, long flags, float heightScale, float rowScale, float columnScale);
        public static native long PxHeightFieldGeometry();
        public static native long PxHeightFieldGeometry(long hf, long flags, float heightScale, float rowScale, float columnScale);
        public static native void destroy(long address);
        public static native long getHeightField(long address);
        public static native void setHeightField(long address, long value);
        public static native float getHeightScale(long address);
        public static native void setHeightScale(long address, float value);
        public static native float getRowScale(long address);
        public static native void setRowScale(long address, float value);
        public static native float getColumnScale(long address);
        public static native void setColumnScale(long address, float value);
        public static native long getHeightFieldFlags(long address);
        public static native void setHeightFieldFlags(long address, long value);
        public static native boolean isValid(long address);
    }
}
