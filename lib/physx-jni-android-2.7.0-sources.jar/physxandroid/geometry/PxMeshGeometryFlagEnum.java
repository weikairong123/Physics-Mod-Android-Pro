package physxandroid.geometry;

/**
 * Flags controlling the simulated behavior of the triangle mesh geometry.
 * <p>
 * Used in ::PxMeshGeometryFlags.
 */
public enum PxMeshGeometryFlagEnum {

    eDOUBLE_SIDED(geteDOUBLE_SIDED());
    public final int value;
    
    PxMeshGeometryFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteDOUBLE_SIDED();
    private static int geteDOUBLE_SIDED() {
        de.fabmax.physxandroid.Loader.load();
        return _geteDOUBLE_SIDED();
    }

    private static final int LUT_SIZE = 256;
    private static final PxMeshGeometryFlagEnum[] enumValues = values();
    private static final PxMeshGeometryFlagEnum[] enumLut = new PxMeshGeometryFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxMeshGeometryFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxMeshGeometryFlagEnum forValue(int value) {
        PxMeshGeometryFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxMeshGeometryFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxMeshGeometryFlagEnum: " + value);
        }
        return enumValue;
    }
}
