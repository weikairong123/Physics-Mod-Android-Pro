package physxandroid.geometry;

import physxandroid.NativeObject;

/**
 * Geometry holder class
 * <p>
 * This class contains enough space to hold a value of any PxGeometry subtype.
 * <p>
 * Its principal use is as a convenience class to allow geometries to be returned polymorphically from functions.
 */
public class PxGeometryHolder extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxGeometryHolder wrapPointer(long address) {
        return address != 0L ? new PxGeometryHolder(address) : null;
    }
    
    public static PxGeometryHolder arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxGeometryHolder(long address) {
        super(address);
    }

    // Constructors

    public PxGeometryHolder() {
        address = Raw.PxGeometryHolder();
    }

    /**
     * @param geometry WebIDL type: {@link PxGeometry} [Const, Ref]
     */
    public PxGeometryHolder(PxGeometry geometry) {
        address = Raw.PxGeometryHolder(geometry.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @return WebIDL type: {@link PxGeometryTypeEnum} [enum]
     */
    public PxGeometryTypeEnum getType() {
        checkNotNull();
        return PxGeometryTypeEnum.forValue(Raw.getType(address));
    }

    /**
     * @return WebIDL type: {@link PxSphereGeometry} [Ref]
     */
    public PxSphereGeometry sphere() {
        checkNotNull();
        return PxSphereGeometry.wrapPointer(Raw.sphere(address));
    }

    /**
     * @return WebIDL type: {@link PxPlaneGeometry} [Ref]
     */
    public PxPlaneGeometry plane() {
        checkNotNull();
        return PxPlaneGeometry.wrapPointer(Raw.plane(address));
    }

    /**
     * @return WebIDL type: {@link PxCapsuleGeometry} [Ref]
     */
    public PxCapsuleGeometry capsule() {
        checkNotNull();
        return PxCapsuleGeometry.wrapPointer(Raw.capsule(address));
    }

    /**
     * @return WebIDL type: {@link PxBoxGeometry} [Ref]
     */
    public PxBoxGeometry box() {
        checkNotNull();
        return PxBoxGeometry.wrapPointer(Raw.box(address));
    }

    /**
     * @return WebIDL type: {@link PxConvexMeshGeometry} [Ref]
     */
    public PxConvexMeshGeometry convexMesh() {
        checkNotNull();
        return PxConvexMeshGeometry.wrapPointer(Raw.convexMesh(address));
    }

    /**
     * @return WebIDL type: {@link PxTriangleMeshGeometry} [Ref]
     */
    public PxTriangleMeshGeometry triangleMesh() {
        checkNotNull();
        return PxTriangleMeshGeometry.wrapPointer(Raw.triangleMesh(address));
    }

    /**
     * @return WebIDL type: {@link PxHeightFieldGeometry} [Ref]
     */
    public PxHeightFieldGeometry heightField() {
        checkNotNull();
        return PxHeightFieldGeometry.wrapPointer(Raw.heightField(address));
    }

    /**
     * @param geometry WebIDL type: {@link PxGeometry} [Const, Ref]
     */
    public void storeAny(PxGeometry geometry) {
        checkNotNull();
        Raw.storeAny(address, geometry.getAddress());
    }

    public static class Raw {
        public static native long PxGeometryHolder();
        public static native long PxGeometryHolder(long geometry);
        public static native void destroy(long address);
        public static native int getType(long address);
        public static native long sphere(long address);
        public static native long plane(long address);
        public static native long capsule(long address);
        public static native long box(long address);
        public static native long convexMesh(long address);
        public static native long triangleMesh(long address);
        public static native long heightField(long address);
        public static native void storeAny(long address, long geometry);
    }
}
