package physxandroid.geometry;

import physxandroid.NativeObject;

public class PxTriangleMeshFlags extends NativeObject {

    protected PxTriangleMeshFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxTriangleMeshFlags wrapPointer(long address) {
        return address != 0L ? new PxTriangleMeshFlags(address) : null;
    }
    
    public static PxTriangleMeshFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxTriangleMeshFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: octet
     * @return Stack allocated object of PxTriangleMeshFlags
     */
    public static PxTriangleMeshFlags createAt(long address, byte flags) {
        Raw.PxTriangleMeshFlags_placed(address, flags);
        PxTriangleMeshFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: octet
     * @return Stack allocated object of PxTriangleMeshFlags
     */
    public static <T> PxTriangleMeshFlags createAt(T allocator, Allocator<T> allocate, byte flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxTriangleMeshFlags_placed(address, flags);
        PxTriangleMeshFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param flags WebIDL type: octet
     */
    public PxTriangleMeshFlags(byte flags) {
        address = Raw.PxTriangleMeshFlags(flags);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param flag WebIDL type: {@link PxTriangleMeshFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxTriangleMeshFlagEnum flag) {
        checkNotNull();
        return Raw.isSet(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxTriangleMeshFlagEnum} [enum]
     */
    public void raise(PxTriangleMeshFlagEnum flag) {
        checkNotNull();
        Raw.raise(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxTriangleMeshFlagEnum} [enum]
     */
    public void clear(PxTriangleMeshFlagEnum flag) {
        checkNotNull();
        Raw.clear(address, flag.value);
    }

    public static class Raw {
        public static native void PxTriangleMeshFlags_placed(long address, byte flags);
        public static native long PxTriangleMeshFlags(byte flags);
        public static native void destroy(long address);
        public static native boolean isSet(long address, int flag);
        public static native void raise(long address, int flag);
        public static native void clear(long address, int flag);
    }
}
