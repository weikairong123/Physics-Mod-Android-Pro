package physxandroid.geometry;

import physxandroid.NativeObject;

/**
 * Polygon data
 * <p>
 * Plane format: (mPlane[0],mPlane[1],mPlane[2]).dot(x) + mPlane[3] = 0
 * With the normal outward-facing from the hull.
 */
public class PxHullPolygon extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxHullPolygon wrapPointer(long address) {
        return address != 0L ? new PxHullPolygon(address) : null;
    }
    
    public static PxHullPolygon arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxHullPolygon(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxHullPolygon
     */
    public static PxHullPolygon createAt(long address) {
        Raw.PxHullPolygon_placed(address);
        PxHullPolygon createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxHullPolygon
     */
    public static <T> PxHullPolygon createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxHullPolygon_placed(address);
        PxHullPolygon createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxHullPolygon() {
        address = Raw.PxHullPolygon();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getMPlane(int index) {
        checkNotNull();
        return Raw.getMPlane(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setMPlane(int index, float value) {
        checkNotNull();
        Raw.setMPlane(address, index, value);
    }

    /**
     * Number of vertices/edges in the polygon
     */
    public short getMNbVerts() {
        checkNotNull();
        return Raw.getMNbVerts(address);
    }

    /**
     * Number of vertices/edges in the polygon
     */
    public void setMNbVerts(short value) {
        checkNotNull();
        Raw.setMNbVerts(address, value);
    }

    /**
     * Offset in index buffer
     */
    public short getMIndexBase() {
        checkNotNull();
        return Raw.getMIndexBase(address);
    }

    /**
     * Offset in index buffer
     */
    public void setMIndexBase(short value) {
        checkNotNull();
        Raw.setMIndexBase(address, value);
    }

    public static class Raw {
        public static native void PxHullPolygon_placed(long address);
        public static native long PxHullPolygon();
        public static native void destroy(long address);
        public static native float getMPlane(long address, int index);
        public static native void setMPlane(long address, int index, float value);
        public static native short getMNbVerts(long address);
        public static native void setMNbVerts(long address, short value);
        public static native short getMIndexBase(long address);
        public static native void setMIndexBase(long address, short value);
    }
}
