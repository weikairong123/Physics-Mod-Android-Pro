package physxandroid.geometry;

/**
 * Enum with flag values to be used in PxSimpleTriangleMesh::flags.
 */
public enum PxMeshFlagEnum {

    /**
     * Specifies if the SDK should flip normals.
     * <p>
     * The PhysX libraries assume that the face normal of a triangle with vertices [a,b,c] can be computed as:
     * edge1 = b-a
     * edge2 = c-a
     * face_normal = edge1 x edge2.
     * <p>
     * Note: This is the same as a counterclockwise winding in a right handed coordinate system or
     * alternatively a clockwise winding order in a left handed coordinate system.
     * <p>
     * If this does not match the winding order for your triangles, raise the below flag.
     */
    eFLIPNORMALS(geteFLIPNORMALS()),
    e16_BIT_INDICES(gete16_BIT_INDICES());
    public final int value;
    
    PxMeshFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteFLIPNORMALS();
    private static int geteFLIPNORMALS() {
        de.fabmax.physxandroid.Loader.load();
        return _geteFLIPNORMALS();
    }

    private static native int _gete16_BIT_INDICES();
    private static int gete16_BIT_INDICES() {
        de.fabmax.physxandroid.Loader.load();
        return _gete16_BIT_INDICES();
    }

    private static final int LUT_SIZE = 256;
    private static final PxMeshFlagEnum[] enumValues = values();
    private static final PxMeshFlagEnum[] enumLut = new PxMeshFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxMeshFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxMeshFlagEnum forValue(int value) {
        PxMeshFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxMeshFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxMeshFlagEnum: " + value);
        }
        return enumValue;
    }
}
