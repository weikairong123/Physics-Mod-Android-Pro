package physxandroid.geometry;

import physxandroid.NativeObject;

public class PxTetrahedronMeshFlags extends NativeObject {

    protected PxTetrahedronMeshFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxTetrahedronMeshFlags wrapPointer(long address) {
        return address != 0L ? new PxTetrahedronMeshFlags(address) : null;
    }
    
    public static PxTetrahedronMeshFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxTetrahedronMeshFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: octet
     * @return Stack allocated object of PxTetrahedronMeshFlags
     */
    public static PxTetrahedronMeshFlags createAt(long address, byte flags) {
        Raw.PxTetrahedronMeshFlags_placed(address, flags);
        PxTetrahedronMeshFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: octet
     * @return Stack allocated object of PxTetrahedronMeshFlags
     */
    public static <T> PxTetrahedronMeshFlags createAt(T allocator, Allocator<T> allocate, byte flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxTetrahedronMeshFlags_placed(address, flags);
        PxTetrahedronMeshFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param flags WebIDL type: octet
     */
    public PxTetrahedronMeshFlags(byte flags) {
        address = Raw.PxTetrahedronMeshFlags(flags);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param flag WebIDL type: {@link PxTetrahedronMeshFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxTetrahedronMeshFlagEnum flag) {
        checkNotNull();
        return Raw.isSet(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxTetrahedronMeshFlagEnum} [enum]
     */
    public void raise(PxTetrahedronMeshFlagEnum flag) {
        checkNotNull();
        Raw.raise(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxTetrahedronMeshFlagEnum} [enum]
     */
    public void clear(PxTetrahedronMeshFlagEnum flag) {
        checkNotNull();
        Raw.clear(address, flag.value);
    }

    public static class Raw {
        public static native void PxTetrahedronMeshFlags_placed(long address, byte flags);
        public static native long PxTetrahedronMeshFlags(byte flags);
        public static native void destroy(long address);
        public static native boolean isSet(long address, int flag);
        public static native void raise(long address, int flag);
        public static native void clear(long address, int flag);
    }
}
