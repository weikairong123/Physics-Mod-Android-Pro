package physxandroid.geometry;


/**
 * A class representing the geometry of a sphere.
 * <p>
 * Spheres are defined by their radius.
 * <b>Note:</b> The scaling of the sphere is expected to be baked into this value, there is no additional scaling parameter.
 */
public class PxSphereGeometry extends PxGeometry {

    protected PxSphereGeometry() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxSphereGeometry wrapPointer(long address) {
        return address != 0L ? new PxSphereGeometry(address) : null;
    }
    
    public static PxSphereGeometry arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxSphereGeometry(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param ir      WebIDL type: float
     * @return Stack allocated object of PxSphereGeometry
     */
    public static PxSphereGeometry createAt(long address, float ir) {
        Raw.PxSphereGeometry_placed(address, ir);
        PxSphereGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param ir        WebIDL type: float
     * @return Stack allocated object of PxSphereGeometry
     */
    public static <T> PxSphereGeometry createAt(T allocator, Allocator<T> allocate, float ir) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxSphereGeometry_placed(address, ir);
        PxSphereGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * Constructor.
     */
    public PxSphereGeometry(float ir) {
        address = Raw.PxSphereGeometry(ir);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The radius of the sphere.
     */
    public float getRadius() {
        checkNotNull();
        return Raw.getRadius(address);
    }

    /**
     * The radius of the sphere.
     */
    public void setRadius(float value) {
        checkNotNull();
        Raw.setRadius(address, value);
    }

    public static class Raw {
        public static native void PxSphereGeometry_placed(long address, float ir);
        public static native long PxSphereGeometry(float ir);
        public static native void destroy(long address);
        public static native float getRadius(long address);
        public static native void setRadius(long address, float value);
    }
}
