package physxandroid.geometry;

/**
 * Describes the format of height field samples.
 * <b>See also:</b> PxHeightFieldDesc.format PxHeightFieldDesc.samples
 */
public enum PxHeightFieldFormatEnum {

    /**
     * Height field height data is 16 bit signed integers, followed by triangle materials. 
     * <p>
     * Each sample is 32 bits wide arranged as follows:
     * <p>
     * \image html heightFieldFormat_S16_TM.png
     * <p>
     * 1) First there is a 16 bit height value.
     * 2) Next, two one byte material indices, with the high bit of each byte reserved for special use.
     * (so the material index is only 7 bits).
     * The high bit of material0 is the tess-flag.
     * The high bit of material1 is reserved for future use.
     * <p>
     * There are zero or more unused bytes before the next sample depending on PxHeightFieldDesc.sampleStride, 
     * where the application may eventually keep its own data.
     * <p>
     * This is the only format supported at the moment.
     * <p>
     * <b>See also:</b> PxHeightFieldDesc.format PxHeightFieldDesc.samples
     */
    eS16_TM(geteS16_TM());
    public final int value;
    
    PxHeightFieldFormatEnum(int value) {
        this.value = value;
    }

    private static native int _geteS16_TM();
    private static int geteS16_TM() {
        de.fabmax.physxandroid.Loader.load();
        return _geteS16_TM();
    }

    private static final int LUT_SIZE = 256;
    private static final PxHeightFieldFormatEnum[] enumValues = values();
    private static final PxHeightFieldFormatEnum[] enumLut = new PxHeightFieldFormatEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxHeightFieldFormatEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxHeightFieldFormatEnum forValue(int value) {
        PxHeightFieldFormatEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxHeightFieldFormatEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxHeightFieldFormatEnum: " + value);
        }
        return enumValue;
    }
}
