package physxandroid.geometry;


/**
 * Convex mesh geometry class.
 * <p>
 * This class unifies a convex mesh object with a scaling transform, and 
 * lets the combined object be used anywhere a PxGeometry is needed.
 * <p>
 * The scaling is a transform along arbitrary axes contained in the scale object.
 * The vertices of the mesh in geometry (or shape) space is the 
 * PxMeshScale::toMat33() transform, multiplied by the vertex space vertices 
 * in the PxConvexMesh object.
 */
public class PxConvexMeshGeometry extends PxGeometry {

    protected PxConvexMeshGeometry() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxConvexMeshGeometry wrapPointer(long address) {
        return address != 0L ? new PxConvexMeshGeometry(address) : null;
    }
    
    public static PxConvexMeshGeometry arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxConvexMeshGeometry(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param mesh    WebIDL type: {@link PxConvexMesh}
     * @return Stack allocated object of PxConvexMeshGeometry
     */
    public static PxConvexMeshGeometry createAt(long address, PxConvexMesh mesh) {
        Raw.PxConvexMeshGeometry_placed(address, mesh.getAddress());
        PxConvexMeshGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param mesh      WebIDL type: {@link PxConvexMesh}
     * @return Stack allocated object of PxConvexMeshGeometry
     */
    public static <T> PxConvexMeshGeometry createAt(T allocator, Allocator<T> allocate, PxConvexMesh mesh) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxConvexMeshGeometry_placed(address, mesh.getAddress());
        PxConvexMeshGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param mesh    WebIDL type: {@link PxConvexMesh}
     * @param scaling WebIDL type: {@link PxMeshScale} [Const, Ref]
     * @return Stack allocated object of PxConvexMeshGeometry
     */
    public static PxConvexMeshGeometry createAt(long address, PxConvexMesh mesh, PxMeshScale scaling) {
        Raw.PxConvexMeshGeometry_placed(address, mesh.getAddress(), scaling.getAddress());
        PxConvexMeshGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param mesh      WebIDL type: {@link PxConvexMesh}
     * @param scaling   WebIDL type: {@link PxMeshScale} [Const, Ref]
     * @return Stack allocated object of PxConvexMeshGeometry
     */
    public static <T> PxConvexMeshGeometry createAt(T allocator, Allocator<T> allocate, PxConvexMesh mesh, PxMeshScale scaling) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxConvexMeshGeometry_placed(address, mesh.getAddress(), scaling.getAddress());
        PxConvexMeshGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param mesh    WebIDL type: {@link PxConvexMesh}
     * @param scaling WebIDL type: {@link PxMeshScale} [Const, Ref]
     * @param flags   WebIDL type: {@link PxConvexMeshGeometryFlags} [Ref]
     * @return Stack allocated object of PxConvexMeshGeometry
     */
    public static PxConvexMeshGeometry createAt(long address, PxConvexMesh mesh, PxMeshScale scaling, PxConvexMeshGeometryFlags flags) {
        Raw.PxConvexMeshGeometry_placed(address, mesh.getAddress(), scaling.getAddress(), flags.getAddress());
        PxConvexMeshGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param mesh      WebIDL type: {@link PxConvexMesh}
     * @param scaling   WebIDL type: {@link PxMeshScale} [Const, Ref]
     * @param flags     WebIDL type: {@link PxConvexMeshGeometryFlags} [Ref]
     * @return Stack allocated object of PxConvexMeshGeometry
     */
    public static <T> PxConvexMeshGeometry createAt(T allocator, Allocator<T> allocate, PxConvexMesh mesh, PxMeshScale scaling, PxConvexMeshGeometryFlags flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxConvexMeshGeometry_placed(address, mesh.getAddress(), scaling.getAddress(), flags.getAddress());
        PxConvexMeshGeometry createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * Constructor. By default creates an empty object with a NULL mesh and identity scale.
     * @param mesh  Mesh pointer. May be NULL, though this will not make the object valid for shape construction.
     * \
     */
    public PxConvexMeshGeometry(PxConvexMesh mesh) {
        address = Raw.PxConvexMeshGeometry(mesh.getAddress());
    }

    /**
     * Constructor. By default creates an empty object with a NULL mesh and identity scale.
     * @param mesh  Mesh pointer. May be NULL, though this will not make the object valid for shape construction.
     * @param scaling Scale factor.
     * \
     */
    public PxConvexMeshGeometry(PxConvexMesh mesh, PxMeshScale scaling) {
        address = Raw.PxConvexMeshGeometry(mesh.getAddress(), scaling.getAddress());
    }

    /**
     * Constructor. By default creates an empty object with a NULL mesh and identity scale.
     * @param mesh  Mesh pointer. May be NULL, though this will not make the object valid for shape construction.
     * @param scaling Scale factor.
     * @param flags Mesh flags.
     * \
     */
    public PxConvexMeshGeometry(PxConvexMesh mesh, PxMeshScale scaling, PxConvexMeshGeometryFlags flags) {
        address = Raw.PxConvexMeshGeometry(mesh.getAddress(), scaling.getAddress(), flags.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The scaling transformation (from vertex space to shape space).
     */
    public PxMeshScale getScale() {
        checkNotNull();
        return PxMeshScale.wrapPointer(Raw.getScale(address));
    }

    /**
     * The scaling transformation (from vertex space to shape space).
     */
    public void setScale(PxMeshScale value) {
        checkNotNull();
        Raw.setScale(address, value.getAddress());
    }

    /**
     * A reference to the convex mesh object.
     */
    public PxConvexMesh getConvexMesh() {
        checkNotNull();
        return PxConvexMesh.wrapPointer(Raw.getConvexMesh(address));
    }

    /**
     * A reference to the convex mesh object.
     */
    public void setConvexMesh(PxConvexMesh value) {
        checkNotNull();
        Raw.setConvexMesh(address, value.getAddress());
    }

    /**
     * Mesh flags.
     */
    public PxConvexMeshGeometryFlags getMeshFlags() {
        checkNotNull();
        return PxConvexMeshGeometryFlags.wrapPointer(Raw.getMeshFlags(address));
    }

    /**
     * Mesh flags.
     */
    public void setMeshFlags(PxConvexMeshGeometryFlags value) {
        checkNotNull();
        Raw.setMeshFlags(address, value.getAddress());
    }

    public static class Raw {
        public static native void PxConvexMeshGeometry_placed(long address, long mesh);
        public static native void PxConvexMeshGeometry_placed(long address, long mesh, long scaling);
        public static native void PxConvexMeshGeometry_placed(long address, long mesh, long scaling, long flags);
        public static native long PxConvexMeshGeometry(long mesh);
        public static native long PxConvexMeshGeometry(long mesh, long scaling);
        public static native long PxConvexMeshGeometry(long mesh, long scaling, long flags);
        public static native void destroy(long address);
        public static native long getScale(long address);
        public static native void setScale(long address, long value);
        public static native long getConvexMesh(long address);
        public static native void setConvexMesh(long address, long value);
        public static native long getMeshFlags(long address);
        public static native void setMeshFlags(long address, long value);
    }
}
