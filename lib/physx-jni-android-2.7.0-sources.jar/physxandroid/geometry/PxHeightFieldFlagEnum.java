package physxandroid.geometry;

/**
 * Enum with flag values to be used in PxHeightFieldDesc.flags.
 */
public enum PxHeightFieldFlagEnum {

    /**
     * Disable collisions with height field with boundary edges.
     * <p>
     * Raise this flag if several terrain patches are going to be placed adjacent to each other, 
     * to avoid a bump when sliding across.
     * <p>
     * This flag is ignored in contact generation with sphere and capsule shapes.
     * <p>
     * <b>See also:</b> PxHeightFieldDesc.flags
     */
    eNO_BOUNDARY_EDGES(geteNO_BOUNDARY_EDGES());
    public final int value;
    
    PxHeightFieldFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteNO_BOUNDARY_EDGES();
    private static int geteNO_BOUNDARY_EDGES() {
        de.fabmax.physxandroid.Loader.load();
        return _geteNO_BOUNDARY_EDGES();
    }

    private static final int LUT_SIZE = 256;
    private static final PxHeightFieldFlagEnum[] enumValues = values();
    private static final PxHeightFieldFlagEnum[] enumLut = new PxHeightFieldFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxHeightFieldFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxHeightFieldFlagEnum forValue(int value) {
        PxHeightFieldFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxHeightFieldFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxHeightFieldFlagEnum: " + value);
        }
        return enumValue;
    }
}
