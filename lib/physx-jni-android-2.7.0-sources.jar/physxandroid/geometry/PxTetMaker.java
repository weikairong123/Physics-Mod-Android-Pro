package physxandroid.geometry;

import physxandroid.NativeObject;
import physxandroid.common.PxBoundedData;
import physxandroid.support.PxArray_PxU32;
import physxandroid.support.PxArray_PxVec3;
import physxandroid.support.PxI32ConstPtr;
import physxandroid.support.PxU32ConstPtr;

/**
 * Provides functionality to create a tetrahedral mesh from a triangle mesh.
 */
public class PxTetMaker extends NativeObject {

    protected PxTetMaker() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxTetMaker wrapPointer(long address) {
        return address != 0L ? new PxTetMaker(address) : null;
    }
    
    public static PxTetMaker arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxTetMaker(long address) {
        super(address);
    }

    // Functions

    /**
     * Create conforming tetrahedron mesh using TetMaker
     * @param triangleMesh The description of the triangle mesh including vertices and indices
     * @param outVertices The vertices to store the conforming tetrahedral mesh
     * @param outTetIndices The indices to store the conforming tetrahedral mesh
     * @param validate If set to true the input triangle mesh will get analyzed to find possible deficiencies
     * @param volumeThreshold Tetrahedra with a volume smaller than the specified threshold will be removed from the mesh
     * @return True if success
     */
    public static boolean createConformingTetrahedronMesh(PxSimpleTriangleMesh triangleMesh, PxArray_PxVec3 outVertices, PxArray_PxU32 outTetIndices, boolean validate, float volumeThreshold) {
        return Raw.createConformingTetrahedronMesh(triangleMesh.getAddress(), outVertices.getAddress(), outTetIndices.getAddress(), validate, volumeThreshold);
    }

    /**
     * Create voxel-based tetrahedron mesh using TetMaker
     * @param tetMesh The description of the tetrahedral mesh including vertices and indices
     * @param numVoxelsAlongLongestBoundingBoxAxis The number of voxels along the longest bounding box axis
     * @param outVertices The vertices to store the voxel-based tetrahedral mesh
     * @param outTetIndices The indices to store the voxel-based tetrahedral mesh
     * @return True if success
     */
    public static boolean createVoxelTetrahedronMesh(PxTetrahedronMeshDesc tetMesh, int numVoxelsAlongLongestBoundingBoxAxis, PxArray_PxVec3 outVertices, PxArray_PxU32 outTetIndices) {
        return Raw.createVoxelTetrahedronMesh(tetMesh.getAddress(), numVoxelsAlongLongestBoundingBoxAxis, outVertices.getAddress(), outTetIndices.getAddress());
    }

    /**
     * Create voxel-based tetrahedron mesh using TetMaker
     * @param tetMesh The description of the tetrahedral mesh including vertices and indices
     * @param voxelEdgeLength The edge length of a voxel.Can be adjusted slightly such that a multiple of it matches the input points' bounding box size
     * @param outVertices The vertices to store the voxel-based tetrahedral mesh
     * @param outTetIndices The indices to store the voxel-based tetrahedral mesh 
     * @return True if success
     */
    public static boolean createVoxelTetrahedronMeshFromEdgeLength(PxTetrahedronMeshDesc tetMesh, float voxelEdgeLength, PxArray_PxVec3 outVertices, PxArray_PxU32 outTetIndices) {
        return Raw.createVoxelTetrahedronMeshFromEdgeLength(tetMesh.getAddress(), voxelEdgeLength, outVertices.getAddress(), outTetIndices.getAddress());
    }

    /**
     * Analyzes the triangle mesh to get a report about deficiencies. Some deficiencies can be handled by the tetmesher, others cannot.
     * @param triangleMesh The description of the triangle mesh including vertices and indices
     * @param minVolumeThreshold Minimum volume the mesh must have such that no volume warning is generated
     * @param minTriangleAngleRadians Minimum angle allowed for triangles such that no angle warning is generated
     * @return Flags that describe the triangle mesh's deficiencies
     */
    public static PxTriangleMeshAnalysisResults validateTriangleMesh(PxSimpleTriangleMesh triangleMesh, float minVolumeThreshold, float minTriangleAngleRadians) {
        return PxTriangleMeshAnalysisResults.wrapPointer(Raw.validateTriangleMesh(triangleMesh.getAddress(), minVolumeThreshold, minTriangleAngleRadians));
    }

    /**
     * Analyzes the tetrahedron mesh to get a report about deficiencies. Some deficiencies can be handled by the deformable volume cooker, others cannot.
     * @param points The mesh's points
     * @param tetrahedra The mesh's tetrahedra (index buffer)
     * @param minTetVolumeThreshold Minimum volume every tetrahedron in the mesh must have such that no volume warning is generated
     * @return Flags that describe the tetrahedron mesh's deficiencies
     */
    public static PxTetrahedronMeshAnalysisResults validateTetrahedronMesh(PxBoundedData points, PxBoundedData tetrahedra, float minTetVolumeThreshold) {
        return PxTetrahedronMeshAnalysisResults.wrapPointer(Raw.validateTetrahedronMesh(points.getAddress(), tetrahedra.getAddress(), minTetVolumeThreshold));
    }

    /**
     * Simplifies (decimates) a triangle mesh using quadric simplification.
     * @param inputVertices The vertices of the input triangle mesh
     * @param inputIndices The indices of the input triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param targetTriangleCount Desired number of triangles in the output mesh
     * @param maximalEdgeLength Edges below this length will not be collapsed. A value of zero means there is no limit.
     * @param outputVertices The vertices of the output (decimated) triangle mesh
     * @param outputIndices The indices of the output (decimated) triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     */
    public static void simplifyTriangleMesh(PxArray_PxVec3 inputVertices, PxArray_PxU32 inputIndices, int targetTriangleCount, float maximalEdgeLength, PxArray_PxVec3 outputVertices, PxArray_PxU32 outputIndices) {
        Raw.simplifyTriangleMesh(inputVertices.getAddress(), inputIndices.getAddress(), targetTriangleCount, maximalEdgeLength, outputVertices.getAddress(), outputIndices.getAddress());
    }

    /**
     * Simplifies (decimates) a triangle mesh using quadric simplification.
     * @param inputVertices The vertices of the input triangle mesh
     * @param inputIndices The indices of the input triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param targetTriangleCount Desired number of triangles in the output mesh
     * @param maximalEdgeLength Edges below this length will not be collapsed. A value of zero means there is no limit.
     * @param outputVertices The vertices of the output (decimated) triangle mesh
     * @param outputIndices The indices of the output (decimated) triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param vertexMap Optional parameter which returns the mapping from input to output vertices. Note that multiple input vertices are typically collapsed into the same output vertex.
     */
    public static void simplifyTriangleMesh(PxArray_PxVec3 inputVertices, PxArray_PxU32 inputIndices, int targetTriangleCount, float maximalEdgeLength, PxArray_PxVec3 outputVertices, PxArray_PxU32 outputIndices, PxArray_PxU32 vertexMap) {
        Raw.simplifyTriangleMesh(inputVertices.getAddress(), inputIndices.getAddress(), targetTriangleCount, maximalEdgeLength, outputVertices.getAddress(), outputIndices.getAddress(), vertexMap.getAddress());
    }

    /**
     * Simplifies (decimates) a triangle mesh using quadric simplification.
     * @param inputVertices The vertices of the input triangle mesh
     * @param inputIndices The indices of the input triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param targetTriangleCount Desired number of triangles in the output mesh
     * @param maximalEdgeLength Edges below this length will not be collapsed. A value of zero means there is no limit.
     * @param outputVertices The vertices of the output (decimated) triangle mesh
     * @param outputIndices The indices of the output (decimated) triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param vertexMap Optional parameter which returns the mapping from input to output vertices. Note that multiple input vertices are typically collapsed into the same output vertex.
     * @param edgeLengthCostWeight Factor to scale influence of edge length when prioritizing edge collapses. Has no effect if set to zero.
     */
    public static void simplifyTriangleMesh(PxArray_PxVec3 inputVertices, PxArray_PxU32 inputIndices, int targetTriangleCount, float maximalEdgeLength, PxArray_PxVec3 outputVertices, PxArray_PxU32 outputIndices, PxArray_PxU32 vertexMap, float edgeLengthCostWeight) {
        Raw.simplifyTriangleMesh(inputVertices.getAddress(), inputIndices.getAddress(), targetTriangleCount, maximalEdgeLength, outputVertices.getAddress(), outputIndices.getAddress(), vertexMap.getAddress(), edgeLengthCostWeight);
    }

    /**
     * Simplifies (decimates) a triangle mesh using quadric simplification.
     * @param inputVertices The vertices of the input triangle mesh
     * @param inputIndices The indices of the input triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param targetTriangleCount Desired number of triangles in the output mesh
     * @param maximalEdgeLength Edges below this length will not be collapsed. A value of zero means there is no limit.
     * @param outputVertices The vertices of the output (decimated) triangle mesh
     * @param outputIndices The indices of the output (decimated) triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param vertexMap Optional parameter which returns the mapping from input to output vertices. Note that multiple input vertices are typically collapsed into the same output vertex.
     * @param edgeLengthCostWeight Factor to scale influence of edge length when prioritizing edge collapses. Has no effect if set to zero.
     * @param flatnessDetectionThreshold Threshold used to detect edges in flat regions and to improve the placement of the collapsed point. If set to a large value it will have no effect.
     */
    public static void simplifyTriangleMesh(PxArray_PxVec3 inputVertices, PxArray_PxU32 inputIndices, int targetTriangleCount, float maximalEdgeLength, PxArray_PxVec3 outputVertices, PxArray_PxU32 outputIndices, PxArray_PxU32 vertexMap, float edgeLengthCostWeight, float flatnessDetectionThreshold) {
        Raw.simplifyTriangleMesh(inputVertices.getAddress(), inputIndices.getAddress(), targetTriangleCount, maximalEdgeLength, outputVertices.getAddress(), outputIndices.getAddress(), vertexMap.getAddress(), edgeLengthCostWeight, flatnessDetectionThreshold);
    }

    /**
     * Simplifies (decimates) a triangle mesh using quadric simplification.
     * @param inputVertices The vertices of the input triangle mesh
     * @param inputIndices The indices of the input triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param targetTriangleCount Desired number of triangles in the output mesh
     * @param maximalEdgeLength Edges below this length will not be collapsed. A value of zero means there is no limit.
     * @param outputVertices The vertices of the output (decimated) triangle mesh
     * @param outputIndices The indices of the output (decimated) triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param vertexMap Optional parameter which returns the mapping from input to output vertices. Note that multiple input vertices are typically collapsed into the same output vertex.
     * @param edgeLengthCostWeight Factor to scale influence of edge length when prioritizing edge collapses. Has no effect if set to zero.
     * @param flatnessDetectionThreshold Threshold used to detect edges in flat regions and to improve the placement of the collapsed point. If set to a large value it will have no effect.
     * @param projectSimplifiedPointsOnInputMeshSurface If set to true, the simplified points will lie exactly on the original surface. 
     */
    public static void simplifyTriangleMesh(PxArray_PxVec3 inputVertices, PxArray_PxU32 inputIndices, int targetTriangleCount, float maximalEdgeLength, PxArray_PxVec3 outputVertices, PxArray_PxU32 outputIndices, PxArray_PxU32 vertexMap, float edgeLengthCostWeight, float flatnessDetectionThreshold, boolean projectSimplifiedPointsOnInputMeshSurface) {
        Raw.simplifyTriangleMesh(inputVertices.getAddress(), inputIndices.getAddress(), targetTriangleCount, maximalEdgeLength, outputVertices.getAddress(), outputIndices.getAddress(), vertexMap.getAddress(), edgeLengthCostWeight, flatnessDetectionThreshold, projectSimplifiedPointsOnInputMeshSurface);
    }

    /**
     * Simplifies (decimates) a triangle mesh using quadric simplification.
     * @param inputVertices The vertices of the input triangle mesh
     * @param inputIndices The indices of the input triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param targetTriangleCount Desired number of triangles in the output mesh
     * @param maximalEdgeLength Edges below this length will not be collapsed. A value of zero means there is no limit.
     * @param outputVertices The vertices of the output (decimated) triangle mesh
     * @param outputIndices The indices of the output (decimated) triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param vertexMap Optional parameter which returns the mapping from input to output vertices. Note that multiple input vertices are typically collapsed into the same output vertex.
     * @param edgeLengthCostWeight Factor to scale influence of edge length when prioritizing edge collapses. Has no effect if set to zero.
     * @param flatnessDetectionThreshold Threshold used to detect edges in flat regions and to improve the placement of the collapsed point. If set to a large value it will have no effect.
     * @param projectSimplifiedPointsOnInputMeshSurface If set to true, the simplified points will lie exactly on the original surface. 
     * @param outputVertexToInputTriangle Optional indices providing the triangle index per resulting vertex. Only available when projectSimplifiedPointsOnInputMeshSurface is set to true
     */
    public static void simplifyTriangleMesh(PxArray_PxVec3 inputVertices, PxArray_PxU32 inputIndices, int targetTriangleCount, float maximalEdgeLength, PxArray_PxVec3 outputVertices, PxArray_PxU32 outputIndices, PxArray_PxU32 vertexMap, float edgeLengthCostWeight, float flatnessDetectionThreshold, boolean projectSimplifiedPointsOnInputMeshSurface, PxArray_PxU32 outputVertexToInputTriangle) {
        Raw.simplifyTriangleMesh(inputVertices.getAddress(), inputIndices.getAddress(), targetTriangleCount, maximalEdgeLength, outputVertices.getAddress(), outputIndices.getAddress(), vertexMap.getAddress(), edgeLengthCostWeight, flatnessDetectionThreshold, projectSimplifiedPointsOnInputMeshSurface, outputVertexToInputTriangle.getAddress());
    }

    /**
     * Simplifies (decimates) a triangle mesh using quadric simplification.
     * @param inputVertices The vertices of the input triangle mesh
     * @param inputIndices The indices of the input triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param targetTriangleCount Desired number of triangles in the output mesh
     * @param maximalEdgeLength Edges below this length will not be collapsed. A value of zero means there is no limit.
     * @param outputVertices The vertices of the output (decimated) triangle mesh
     * @param outputIndices The indices of the output (decimated) triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param vertexMap Optional parameter which returns the mapping from input to output vertices. Note that multiple input vertices are typically collapsed into the same output vertex.
     * @param edgeLengthCostWeight Factor to scale influence of edge length when prioritizing edge collapses. Has no effect if set to zero.
     * @param flatnessDetectionThreshold Threshold used to detect edges in flat regions and to improve the placement of the collapsed point. If set to a large value it will have no effect.
     * @param projectSimplifiedPointsOnInputMeshSurface If set to true, the simplified points will lie exactly on the original surface. 
     * @param outputVertexToInputTriangle Optional indices providing the triangle index per resulting vertex. Only available when projectSimplifiedPointsOnInputMeshSurface is set to true
     * @param removeDisconnectedPatches Enables the optional removal of disconnected triangles in the mesh. Only the largest connected set/patch will be kept
     */
    public static void simplifyTriangleMesh(PxArray_PxVec3 inputVertices, PxArray_PxU32 inputIndices, int targetTriangleCount, float maximalEdgeLength, PxArray_PxVec3 outputVertices, PxArray_PxU32 outputIndices, PxArray_PxU32 vertexMap, float edgeLengthCostWeight, float flatnessDetectionThreshold, boolean projectSimplifiedPointsOnInputMeshSurface, PxArray_PxU32 outputVertexToInputTriangle, boolean removeDisconnectedPatches) {
        Raw.simplifyTriangleMesh(inputVertices.getAddress(), inputIndices.getAddress(), targetTriangleCount, maximalEdgeLength, outputVertices.getAddress(), outputIndices.getAddress(), vertexMap.getAddress(), edgeLengthCostWeight, flatnessDetectionThreshold, projectSimplifiedPointsOnInputMeshSurface, outputVertexToInputTriangle.getAddress(), removeDisconnectedPatches);
    }

    /**
     * Creates a new mesh from a given mesh. The input mesh is first voxelized. The new surface is created from the voxel surface and subsequent projection to the original mesh.
     * @param inputVertices The vertices of the input triangle mesh
     * @param inputIndices The indices of the input triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param gridResolution Size of the voxel grid (number of voxels along the longest dimension)
     * @param outputVertices The vertices of the output (decimated) triangle mesh
     * @param outputIndices The indices of the output (decimated) triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     */
    public static void remeshTriangleMesh(PxArray_PxVec3 inputVertices, PxArray_PxU32 inputIndices, int gridResolution, PxArray_PxVec3 outputVertices, PxArray_PxU32 outputIndices) {
        Raw.remeshTriangleMesh(inputVertices.getAddress(), inputIndices.getAddress(), gridResolution, outputVertices.getAddress(), outputIndices.getAddress());
    }

    /**
     * Creates a new mesh from a given mesh. The input mesh is first voxelized. The new surface is created from the voxel surface and subsequent projection to the original mesh.
     * @param inputVertices The vertices of the input triangle mesh
     * @param inputIndices The indices of the input triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param gridResolution Size of the voxel grid (number of voxels along the longest dimension)
     * @param outputVertices The vertices of the output (decimated) triangle mesh
     * @param outputIndices The indices of the output (decimated) triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param vertexMap Optional parameter which returns a mapping from input to output vertices. Since the meshes are independent, the mapping returns an output vertex that is topologically close to the input vertex.
     */
    public static void remeshTriangleMesh(PxArray_PxVec3 inputVertices, PxArray_PxU32 inputIndices, int gridResolution, PxArray_PxVec3 outputVertices, PxArray_PxU32 outputIndices, PxArray_PxU32 vertexMap) {
        Raw.remeshTriangleMesh(inputVertices.getAddress(), inputIndices.getAddress(), gridResolution, outputVertices.getAddress(), outputIndices.getAddress(), vertexMap.getAddress());
    }

    /**
     * Creates a tetrahedral mesh using an octree. 
     * @param inputVertices The vertices of the input triangle mesh
     * @param inputIndices The indices of the input triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param useTreeNodes Using the nodes of the octree as tetrahedral vertices
     * @param outputVertices The vertices of the output tetrahedral mesh
     * @param outputIndices The indices of the output tetrahedral mesh of the form  (id0, id1, id2, id3),  (id0, id1, id2, id3), ..
     * @param volumeThreshold Tetrahedra with a volume smaller than the specified threshold will be removed from the mesh
     */
    public static void createTreeBasedTetrahedralMesh(PxArray_PxVec3 inputVertices, PxArray_PxU32 inputIndices, boolean useTreeNodes, PxArray_PxVec3 outputVertices, PxArray_PxU32 outputIndices, float volumeThreshold) {
        Raw.createTreeBasedTetrahedralMesh(inputVertices.getAddress(), inputIndices.getAddress(), useTreeNodes, outputVertices.getAddress(), outputIndices.getAddress(), volumeThreshold);
    }

    /**
     * Creates a tetrahedral mesh by relaxing a voxel mesh around the input mesh
     * @param inputVertices The vertices of the input triangle mesh
     * @param inputIndices The indices of the input triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param outputVertices The vertices of the output tetrahedral mesh
     * @param outputIndices The indices of the output tetrahedral mesh of the form  (id0, id1, id2, id3),  (id0, id1, id2, id3), ..
     * @param resolution The grid spacing is computed as the diagonal of the bounding box of the input mesh divided by the resolution.
     */
    public static void createRelaxedVoxelTetrahedralMesh(PxArray_PxVec3 inputVertices, PxArray_PxU32 inputIndices, PxArray_PxVec3 outputVertices, PxArray_PxU32 outputIndices, int resolution) {
        Raw.createRelaxedVoxelTetrahedralMesh(inputVertices.getAddress(), inputIndices.getAddress(), outputVertices.getAddress(), outputIndices.getAddress(), resolution);
    }

    /**
     * Creates a tetrahedral mesh by relaxing a voxel mesh around the input mesh
     * @param inputVertices The vertices of the input triangle mesh
     * @param inputIndices The indices of the input triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param outputVertices The vertices of the output tetrahedral mesh
     * @param outputIndices The indices of the output tetrahedral mesh of the form  (id0, id1, id2, id3),  (id0, id1, id2, id3), ..
     * @param resolution The grid spacing is computed as the diagonal of the bounding box of the input mesh divided by the resolution.
     * @param numRelaxationIterations Number of iterations to pull the tetrahedral mesh towards the input mesh
     */
    public static void createRelaxedVoxelTetrahedralMesh(PxArray_PxVec3 inputVertices, PxArray_PxU32 inputIndices, PxArray_PxVec3 outputVertices, PxArray_PxU32 outputIndices, int resolution, int numRelaxationIterations) {
        Raw.createRelaxedVoxelTetrahedralMesh(inputVertices.getAddress(), inputIndices.getAddress(), outputVertices.getAddress(), outputIndices.getAddress(), resolution, numRelaxationIterations);
    }

    /**
     * Creates a tetrahedral mesh by relaxing a voxel mesh around the input mesh
     * @param inputVertices The vertices of the input triangle mesh
     * @param inputIndices The indices of the input triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param outputVertices The vertices of the output tetrahedral mesh
     * @param outputIndices The indices of the output tetrahedral mesh of the form  (id0, id1, id2, id3),  (id0, id1, id2, id3), ..
     * @param resolution The grid spacing is computed as the diagonal of the bounding box of the input mesh divided by the resolution.
     * @param numRelaxationIterations Number of iterations to pull the tetrahedral mesh towards the input mesh
     * @param relMinTetVolume Constrains the volumes of the tetrahedra to stay abobe relMinTetvolume times the tetrahedron's rest volume.
     */
    public static void createRelaxedVoxelTetrahedralMesh(PxArray_PxVec3 inputVertices, PxArray_PxU32 inputIndices, PxArray_PxVec3 outputVertices, PxArray_PxU32 outputIndices, int resolution, int numRelaxationIterations, float relMinTetVolume) {
        Raw.createRelaxedVoxelTetrahedralMesh(inputVertices.getAddress(), inputIndices.getAddress(), outputVertices.getAddress(), outputIndices.getAddress(), resolution, numRelaxationIterations, relMinTetVolume);
    }

    /**
     * Creates a tetrahedral mesh by relaxing a voxel mesh around the input mesh
     * @param triangles The indices of the input triangle mesh of the form  (id0, id1, id2),  (id0, id1, id2), ..
     * @param numTriangles The number of triangles
     * @param islandIndexPerTriangle Every triangle gets an island index assigned. Triangles with the same island index belong to the same patch of connected triangles.
     */
    public static void detectTriangleIslands(PxI32ConstPtr triangles, int numTriangles, PxArray_PxU32 islandIndexPerTriangle) {
        Raw.detectTriangleIslands(triangles.getAddress(), numTriangles, islandIndexPerTriangle.getAddress());
    }

    /**
     * Creates a tetrahedral mesh by relaxing a voxel mesh around the input mesh
     * @param islandIndexPerTriangle An island marker per triangles. All triangles with the same marker belong to an island. Can becomputed using the method detectTriangleIslands.
     * @param numTriangles The number of triangles
     * @return The marker value of the island that contains the most triangles
     */
    public static int findLargestIslandId(PxU32ConstPtr islandIndexPerTriangle, int numTriangles) {
        return Raw.findLargestIslandId(islandIndexPerTriangle.getAddress(), numTriangles);
    }

    public static class Raw {
        public static native boolean createConformingTetrahedronMesh(long triangleMesh, long outVertices, long outTetIndices, boolean validate, float volumeThreshold);
        public static native boolean createVoxelTetrahedronMesh(long tetMesh, int numVoxelsAlongLongestBoundingBoxAxis, long outVertices, long outTetIndices);
        public static native boolean createVoxelTetrahedronMeshFromEdgeLength(long tetMesh, float voxelEdgeLength, long outVertices, long outTetIndices);
        public static native long validateTriangleMesh(long triangleMesh, float minVolumeThreshold, float minTriangleAngleRadians);
        public static native long validateTetrahedronMesh(long points, long tetrahedra, float minTetVolumeThreshold);
        public static native void simplifyTriangleMesh(long inputVertices, long inputIndices, int targetTriangleCount, float maximalEdgeLength, long outputVertices, long outputIndices);
        public static native void simplifyTriangleMesh(long inputVertices, long inputIndices, int targetTriangleCount, float maximalEdgeLength, long outputVertices, long outputIndices, long vertexMap);
        public static native void simplifyTriangleMesh(long inputVertices, long inputIndices, int targetTriangleCount, float maximalEdgeLength, long outputVertices, long outputIndices, long vertexMap, float edgeLengthCostWeight);
        public static native void simplifyTriangleMesh(long inputVertices, long inputIndices, int targetTriangleCount, float maximalEdgeLength, long outputVertices, long outputIndices, long vertexMap, float edgeLengthCostWeight, float flatnessDetectionThreshold);
        public static native void simplifyTriangleMesh(long inputVertices, long inputIndices, int targetTriangleCount, float maximalEdgeLength, long outputVertices, long outputIndices, long vertexMap, float edgeLengthCostWeight, float flatnessDetectionThreshold, boolean projectSimplifiedPointsOnInputMeshSurface);
        public static native void simplifyTriangleMesh(long inputVertices, long inputIndices, int targetTriangleCount, float maximalEdgeLength, long outputVertices, long outputIndices, long vertexMap, float edgeLengthCostWeight, float flatnessDetectionThreshold, boolean projectSimplifiedPointsOnInputMeshSurface, long outputVertexToInputTriangle);
        public static native void simplifyTriangleMesh(long inputVertices, long inputIndices, int targetTriangleCount, float maximalEdgeLength, long outputVertices, long outputIndices, long vertexMap, float edgeLengthCostWeight, float flatnessDetectionThreshold, boolean projectSimplifiedPointsOnInputMeshSurface, long outputVertexToInputTriangle, boolean removeDisconnectedPatches);
        public static native void remeshTriangleMesh(long inputVertices, long inputIndices, int gridResolution, long outputVertices, long outputIndices);
        public static native void remeshTriangleMesh(long inputVertices, long inputIndices, int gridResolution, long outputVertices, long outputIndices, long vertexMap);
        public static native void createTreeBasedTetrahedralMesh(long inputVertices, long inputIndices, boolean useTreeNodes, long outputVertices, long outputIndices, float volumeThreshold);
        public static native void createRelaxedVoxelTetrahedralMesh(long inputVertices, long inputIndices, long outputVertices, long outputIndices, int resolution);
        public static native void createRelaxedVoxelTetrahedralMesh(long inputVertices, long inputIndices, long outputVertices, long outputIndices, int resolution, int numRelaxationIterations);
        public static native void createRelaxedVoxelTetrahedralMesh(long inputVertices, long inputIndices, long outputVertices, long outputIndices, int resolution, int numRelaxationIterations, float relMinTetVolume);
        public static native void detectTriangleIslands(long triangles, int numTriangles, long islandIndexPerTriangle);
        public static native int findLargestIslandId(long islandIndexPerTriangle, int numTriangles);
    }
}
