package physxandroid.geometry;

import physxandroid.NativeObject;
import physxandroid.common.PxQuat;
import physxandroid.common.PxVec3;

/**
 * A class expressing a nonuniform scaling transformation.
 * <p>
 * The scaling is along arbitrary axes that are specified by PxMeshScale::rotation. Specifically, PxMeshScale::rotation
 * describes the rotation from the scaling-axes frame to the mesh-local frame, i.e. PxMeshScale::rotation.rotate(v) transforms
 * the coordinates of vertex v from the mesh-local frame to the scaling-axes frame.
 * <p>
 * <b>Note:</b> Negative scale values are supported for PxTriangleMeshGeometry
 *   with absolute values for each component within [PX_MIN_ABS_MESH_SCALE, PX_MAX_ABS_MESH_SCALE] range.
 *   Negative scale causes a reflection around the specified axis, in addition PhysX will flip the normals
 *   for mesh triangles when scale.x*scale.y*scale.z &lt; 0.
 * <b>Note:</b> Only positive scale values are supported for PxConvexMeshGeometry
 *   with values for each component within [PX_MIN_ABS_MESH_SCALE, PX_MAX_ABS_MESH_SCALE] range).
 * @see PxConvexMeshGeometry
 * @see PxTriangleMeshGeometry
 */
public class PxMeshScale extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxMeshScale wrapPointer(long address) {
        return address != 0L ? new PxMeshScale(address) : null;
    }
    
    public static PxMeshScale arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxMeshScale(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxMeshScale
     */
    public static PxMeshScale createAt(long address) {
        Raw.PxMeshScale_placed(address);
        PxMeshScale createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxMeshScale
     */
    public static <T> PxMeshScale createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxMeshScale_placed(address);
        PxMeshScale createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param r       WebIDL type: float
     * @return Stack allocated object of PxMeshScale
     */
    public static PxMeshScale createAt(long address, float r) {
        Raw.PxMeshScale_placed(address, r);
        PxMeshScale createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param r         WebIDL type: float
     * @return Stack allocated object of PxMeshScale
     */
    public static <T> PxMeshScale createAt(T allocator, Allocator<T> allocate, float r) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxMeshScale_placed(address, r);
        PxMeshScale createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param s       WebIDL type: {@link PxVec3} [Const, Ref]
     * @param r       WebIDL type: {@link PxQuat} [Const, Ref]
     * @return Stack allocated object of PxMeshScale
     */
    public static PxMeshScale createAt(long address, PxVec3 s, PxQuat r) {
        Raw.PxMeshScale_placed(address, s.getAddress(), r.getAddress());
        PxMeshScale createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param s         WebIDL type: {@link PxVec3} [Const, Ref]
     * @param r         WebIDL type: {@link PxQuat} [Const, Ref]
     * @return Stack allocated object of PxMeshScale
     */
    public static <T> PxMeshScale createAt(T allocator, Allocator<T> allocate, PxVec3 s, PxQuat r) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxMeshScale_placed(address, s.getAddress(), r.getAddress());
        PxMeshScale createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * Constructor initializes to identity scale.
     */
    public PxMeshScale() {
        address = Raw.PxMeshScale();
    }

    /**
     * Constructor from scalar.
     */
    public PxMeshScale(float r) {
        address = Raw.PxMeshScale(r);
    }

    /**
     * Constructor to initialize to arbitrary scaling.
     */
    public PxMeshScale(PxVec3 s, PxQuat r) {
        address = Raw.PxMeshScale(s.getAddress(), r.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    public static class Raw {
        public static native void PxMeshScale_placed(long address);
        public static native void PxMeshScale_placed(long address, float r);
        public static native void PxMeshScale_placed(long address, long s, long r);
        public static native long PxMeshScale();
        public static native long PxMeshScale(float r);
        public static native long PxMeshScale(long s, long r);
        public static native void destroy(long address);
    }
}
