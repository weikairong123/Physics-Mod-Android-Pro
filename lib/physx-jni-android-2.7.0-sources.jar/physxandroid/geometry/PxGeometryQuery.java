package physxandroid.geometry;

import physxandroid.NativeObject;
import physxandroid.common.PxBounds3;
import physxandroid.common.PxTransform;
import physxandroid.common.PxVec3;
import physxandroid.physics.PxHitFlags;
import physxandroid.physics.PxRaycastHit;
import physxandroid.physics.PxSweepHit;

/**
 * Collection of geometry object queries (sweeps, raycasts, overlaps, ...).
 */
public class PxGeometryQuery extends NativeObject {

    protected PxGeometryQuery() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxGeometryQuery wrapPointer(long address) {
        return address != 0L ? new PxGeometryQuery(address) : null;
    }
    
    public static PxGeometryQuery arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxGeometryQuery(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * Sweep a specified geometry object in space and test for collision with a given object.
     * <p>
     * The following combinations are supported.
     * <p>
     * \li PxSphereGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * \li PxCapsuleGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * \li PxBoxGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * \li PxConvexCoreGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * \li PxConvexMeshGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * @param unitDir   Normalized direction along which object geom0 should be swept
     * @param maxDist   Maximum sweep distance, has to be in the [0, inf) range
     * @param geom0   The geometry object to sweep. Supported geometries are #PxSphereGeometry, #PxCapsuleGeometry, #PxBoxGeometry, #PxConvexCoreGeometry, and #PxConvexMeshGeometry
     * @param pose0   Pose of the geometry object to sweep
     * @param geom1   The geometry object to test the sweep against
     * @param pose1   Pose of the geometry object to sweep against
     * @param sweepHit  The sweep hit information. Only valid if this method returns true.
     * @return True if the swept geometry object geom0 hits the object geom1
     * @see physxandroid.physics.PxGeomSweepHit
     * @see PxGeometry
     * @see physxandroid.common.PxTransform
     */
    public static boolean sweep(PxVec3 unitDir, float maxDist, PxGeometry geom0, PxTransform pose0, PxGeometry geom1, PxTransform pose1, PxSweepHit sweepHit) {
        return Raw.sweep(unitDir.getAddress(), maxDist, geom0.getAddress(), pose0.getAddress(), geom1.getAddress(), pose1.getAddress(), sweepHit.getAddress());
    }

    /**
     * Sweep a specified geometry object in space and test for collision with a given object.
     * <p>
     * The following combinations are supported.
     * <p>
     * \li PxSphereGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * \li PxCapsuleGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * \li PxBoxGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * \li PxConvexCoreGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * \li PxConvexMeshGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * @param unitDir   Normalized direction along which object geom0 should be swept
     * @param maxDist   Maximum sweep distance, has to be in the [0, inf) range
     * @param geom0   The geometry object to sweep. Supported geometries are #PxSphereGeometry, #PxCapsuleGeometry, #PxBoxGeometry, #PxConvexCoreGeometry, and #PxConvexMeshGeometry
     * @param pose0   Pose of the geometry object to sweep
     * @param geom1   The geometry object to test the sweep against
     * @param pose1   Pose of the geometry object to sweep against
     * @param sweepHit  The sweep hit information. Only valid if this method returns true.
     * @param hitFlags   Specify which properties per hit should be computed and written to result hit array. Combination of #PxHitFlag flags
     * @return True if the swept geometry object geom0 hits the object geom1
     * @see physxandroid.physics.PxGeomSweepHit
     * @see PxGeometry
     * @see physxandroid.common.PxTransform
     */
    public static boolean sweep(PxVec3 unitDir, float maxDist, PxGeometry geom0, PxTransform pose0, PxGeometry geom1, PxTransform pose1, PxSweepHit sweepHit, PxHitFlags hitFlags) {
        return Raw.sweep(unitDir.getAddress(), maxDist, geom0.getAddress(), pose0.getAddress(), geom1.getAddress(), pose1.getAddress(), sweepHit.getAddress(), hitFlags.getAddress());
    }

    /**
     * Sweep a specified geometry object in space and test for collision with a given object.
     * <p>
     * The following combinations are supported.
     * <p>
     * \li PxSphereGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * \li PxCapsuleGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * \li PxBoxGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * \li PxConvexCoreGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * \li PxConvexMeshGeometry vs. {PxSphereGeometry, PxPlaneGeometry, PxCapsuleGeometry, PxBoxGeometry, PxConvexCoreGeometry, PxConvexMeshGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * @param unitDir   Normalized direction along which object geom0 should be swept
     * @param maxDist   Maximum sweep distance, has to be in the [0, inf) range
     * @param geom0   The geometry object to sweep. Supported geometries are #PxSphereGeometry, #PxCapsuleGeometry, #PxBoxGeometry, #PxConvexCoreGeometry, and #PxConvexMeshGeometry
     * @param pose0   Pose of the geometry object to sweep
     * @param geom1   The geometry object to test the sweep against
     * @param pose1   Pose of the geometry object to sweep against
     * @param sweepHit  The sweep hit information. Only valid if this method returns true.
     * @param hitFlags   Specify which properties per hit should be computed and written to result hit array. Combination of #PxHitFlag flags
     * @param inflation  Surface of the swept shape is additively extruded in the normal direction, rounding corners and edges.
     * @return True if the swept geometry object geom0 hits the object geom1
     * @see physxandroid.physics.PxGeomSweepHit
     * @see PxGeometry
     * @see physxandroid.common.PxTransform
     */
    public static boolean sweep(PxVec3 unitDir, float maxDist, PxGeometry geom0, PxTransform pose0, PxGeometry geom1, PxTransform pose1, PxSweepHit sweepHit, PxHitFlags hitFlags, float inflation) {
        return Raw.sweep(unitDir.getAddress(), maxDist, geom0.getAddress(), pose0.getAddress(), geom1.getAddress(), pose1.getAddress(), sweepHit.getAddress(), hitFlags.getAddress(), inflation);
    }

    /**
     * Overlap test for two geometry objects.
     * <p>
     * All combinations are supported except:
     * \li PxPlaneGeometry vs. {PxPlaneGeometry, PxTriangleMeshGeometry, PxHeightFieldGeometry}
     * \li PxTriangleMeshGeometry vs. PxHeightFieldGeometry
     * \li PxHeightFieldGeometry vs. PxHeightFieldGeometry
     * \li Anything involving PxParticleSystemGeometry or PxTetrahedronMeshGeometry
     * @param geom0   The first geometry object
     * @param pose0   Pose of the first geometry object
     * @param geom1   The second geometry object
     * @param pose1   Pose of the second geometry object
     * @return True if the two geometry objects overlap
     * @see PxGeometry
     * @see physxandroid.common.PxTransform
     */
    public static boolean overlap(PxGeometry geom0, PxTransform pose0, PxGeometry geom1, PxTransform pose1) {
        return Raw.overlap(geom0.getAddress(), pose0.getAddress(), geom1.getAddress(), pose1.getAddress());
    }

    /**
     * Raycast test against a geometry object.
     * <p>
     * All geometry types are supported except PxParticleSystemGeometry and PxTetrahedronMeshGeometry.
     * @param origin   The origin of the ray to test the geometry object against
     * @param unitDir   Normalized direction of the ray to test the geometry object against
     * @param geom    The geometry object to test the ray against
     * @param pose    Pose of the geometry object
     * @param maxDist   Maximum ray length, has to be in the [0, inf) range
     * @param hitFlags   Specification of the kind of information to retrieve on hit. Combination of #PxHitFlag flags
     * @param maxHits   max number of returned hits = size of 'rayHits' buffer
     * @param rayHits   Raycast hits information
     * @return Number of hits between the ray and the geometry object
     * @see physxandroid.physics.PxGeomRaycastHit
     * @see PxGeometry
     * @see physxandroid.common.PxTransform
     */
    public static int raycast(PxVec3 origin, PxVec3 unitDir, PxGeometry geom, PxTransform pose, float maxDist, PxHitFlags hitFlags, int maxHits, PxRaycastHit rayHits) {
        return Raw.raycast(origin.getAddress(), unitDir.getAddress(), geom.getAddress(), pose.getAddress(), maxDist, hitFlags.getAddress(), maxHits, rayHits.getAddress());
    }

    /**
     * Computes distance between a point and a geometry object.
     * <p>
     * Currently supported geometry objects: box, sphere, capsule, convex core, convex mesh, mesh.
     * <p>
     * <b>Note:</b> For meshes, only the BVH34 midphase data-structure is supported.
     * @param point   The point P
     * @param geom    The geometry object
     * @param pose    Pose of the geometry object
     * @return Square distance between the point and the geom object, or 0.0 if the point is inside the object, or -1.0 if an error occured (geometry type is not supported, or invalid pose)
     * @see PxGeometry
     * @see physxandroid.common.PxTransform
     */
    public static float pointDistance(PxVec3 point, PxGeometry geom, PxTransform pose) {
        return Raw.pointDistance(point.getAddress(), geom.getAddress(), pose.getAddress());
    }

    /**
     * Computes distance between a point and a geometry object.
     * <p>
     * Currently supported geometry objects: box, sphere, capsule, convex core, convex mesh, mesh.
     * <p>
     * <b>Note:</b> For meshes, only the BVH34 midphase data-structure is supported.
     * @param point   The point P
     * @param geom    The geometry object
     * @param pose    Pose of the geometry object
     * @param closestPoint Optionally returned closest point to P on the geom object. Only valid when returned distance is strictly positive.
     * @return Square distance between the point and the geom object, or 0.0 if the point is inside the object, or -1.0 if an error occured (geometry type is not supported, or invalid pose)
     * @see PxGeometry
     * @see physxandroid.common.PxTransform
     */
    public static float pointDistance(PxVec3 point, PxGeometry geom, PxTransform pose, PxVec3 closestPoint) {
        return Raw.pointDistance(point.getAddress(), geom.getAddress(), pose.getAddress(), closestPoint.getAddress());
    }

    /**
     * computes the bounds for a geometry object
     * @param bounds  Returned computed bounds
     * @param geom   The geometry object
     * @param pose   Pose of the geometry object
     * @see PxGeometry
     * @see physxandroid.common.PxTransform
     */
    public static void computeGeomBounds(PxBounds3 bounds, PxGeometry geom, PxTransform pose) {
        Raw.computeGeomBounds(bounds.getAddress(), geom.getAddress(), pose.getAddress());
    }

    /**
     * computes the bounds for a geometry object
     * @param bounds  Returned computed bounds
     * @param geom   The geometry object
     * @param pose   Pose of the geometry object
     * @param inflation Scale factor for computed bounds. The geom's extents are multiplied by this value.
     * @see PxGeometry
     * @see physxandroid.common.PxTransform
     */
    public static void computeGeomBounds(PxBounds3 bounds, PxGeometry geom, PxTransform pose, float inflation) {
        Raw.computeGeomBounds(bounds.getAddress(), geom.getAddress(), pose.getAddress(), inflation);
    }

    /**
     * Checks if provided geometry is valid.
     * @param geom The geometry object.
     * @return True if geometry is valid.
     * @see PxGeometry
     */
    public static boolean isValid(PxGeometry geom) {
        return Raw.isValid(geom.getAddress());
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native boolean sweep(long unitDir, float maxDist, long geom0, long pose0, long geom1, long pose1, long sweepHit);
        public static native boolean sweep(long unitDir, float maxDist, long geom0, long pose0, long geom1, long pose1, long sweepHit, long hitFlags);
        public static native boolean sweep(long unitDir, float maxDist, long geom0, long pose0, long geom1, long pose1, long sweepHit, long hitFlags, float inflation);
        public static native boolean overlap(long geom0, long pose0, long geom1, long pose1);
        public static native int raycast(long origin, long unitDir, long geom, long pose, float maxDist, long hitFlags, int maxHits, long rayHits);
        public static native float pointDistance(long point, long geom, long pose);
        public static native float pointDistance(long point, long geom, long pose, long closestPoint);
        public static native void computeGeomBounds(long bounds, long geom, long pose);
        public static native void computeGeomBounds(long bounds, long geom, long pose, float inflation);
        public static native boolean isValid(long geom);
    }
}
