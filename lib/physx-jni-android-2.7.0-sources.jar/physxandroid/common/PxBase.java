package physxandroid.common;

import physxandroid.NativeObject;

/**
 * Base class for objects that can be members of a PxCollection.
 * <p>
 * All PxBase sub-classes can be serialized.
 * @see PxCollection
 */
public class PxBase extends NativeObject {

    protected PxBase() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxBase wrapPointer(long address) {
        return address != 0L ? new PxBase(address) : null;
    }
    
    public static PxBase arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxBase(long address) {
        super(address);
    }

    // Functions

    /**
     * Releases the PxBase instance, please check documentation of release in derived class.
     */
    public void release() {
        checkNotNull();
        Raw.release(address);
    }

    /**
     * Returns string name of dynamic type.
     * @return Class name of most derived type of this object.
     */
    public String getConcreteTypeName() {
        checkNotNull();
        return Raw.getConcreteTypeName(address);
    }

    /**
     * Returns concrete type of object.
     * @return PxConcreteType::Enum of serialized object
     */
    public int getConcreteType() {
        checkNotNull();
        return Raw.getConcreteType(address);
    }

    /**
     * Set PxBaseFlag 
     * @param flag The flag to be set
     * @param value The flags new value
     */
    public void setBaseFlag(PxBaseFlagEnum flag, boolean value) {
        checkNotNull();
        Raw.setBaseFlag(address, flag.value, value);
    }

    /**
     * Set PxBaseFlags 
     * @param inFlags The flags to be set
     * @see PxBaseFlags
     */
    public void setBaseFlags(PxBaseFlags inFlags) {
        checkNotNull();
        Raw.setBaseFlags(address, inFlags.getAddress());
    }

    /**
     * Returns PxBaseFlags 
     * @return PxBaseFlags
     * @see PxBaseFlags
     */
    public PxBaseFlags getBaseFlags() {
        checkNotNull();
        return PxBaseFlags.wrapPointer(Raw.getBaseFlags(address));
    }

    /**
     * Whether the object is subordinate.
     * <p>
     * A class is subordinate, if it can only be instantiated in the context of another class.
     * @return Whether the class is subordinate
     */
    public boolean isReleasable() {
        checkNotNull();
        return Raw.isReleasable(address);
    }

    public static class Raw {
        public static native void release(long address);
        public static native String getConcreteTypeName(long address);
        public static native int getConcreteType(long address);
        public static native void setBaseFlag(long address, int flag, boolean value);
        public static native void setBaseFlags(long address, long inFlags);
        public static native long getBaseFlags(long address);
        public static native boolean isReleasable(long address);
    }
}
