package physxandroid.common;

import physxandroid.NativeObject;

/**
 * Used to store a single point and colour for debug rendering.
 */
public class PxDebugPoint extends NativeObject {

    protected PxDebugPoint() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxDebugPoint wrapPointer(long address) {
        return address != 0L ? new PxDebugPoint(address) : null;
    }
    
    public static PxDebugPoint arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxDebugPoint(long address) {
        super(address);
    }

    // Attributes

    /**
     */
    public PxVec3 getPos() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getPos(address));
    }

    /**
     */
    public void setPos(PxVec3 value) {
        checkNotNull();
        Raw.setPos(address, value.getAddress());
    }

    /**
     */
    public int getColor() {
        checkNotNull();
        return Raw.getColor(address);
    }

    /**
     */
    public void setColor(int value) {
        checkNotNull();
        Raw.setColor(address, value);
    }

    public static class Raw {
        public static native long getPos(long address);
        public static native void setPos(long address, long value);
        public static native int getColor(long address);
        public static native void setColor(long address, int value);
    }
}
