package physxandroid.common;

import physxandroid.NativeObject;

public class PxVec4 extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVec4 wrapPointer(long address) {
        return address != 0L ? new PxVec4(address) : null;
    }
    
    public static PxVec4 arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVec4(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxVec4
     */
    public static PxVec4 createAt(long address) {
        Raw.PxVec4_placed(address);
        PxVec4 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxVec4
     */
    public static <T> PxVec4 createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxVec4_placed(address);
        PxVec4 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param x       WebIDL type: float
     * @param y       WebIDL type: float
     * @param z       WebIDL type: float
     * @param w       WebIDL type: float
     * @return Stack allocated object of PxVec4
     */
    public static PxVec4 createAt(long address, float x, float y, float z, float w) {
        Raw.PxVec4_placed(address, x, y, z, w);
        PxVec4 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param x         WebIDL type: float
     * @param y         WebIDL type: float
     * @param z         WebIDL type: float
     * @param w         WebIDL type: float
     * @return Stack allocated object of PxVec4
     */
    public static <T> PxVec4 createAt(T allocator, Allocator<T> allocate, float x, float y, float z, float w) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxVec4_placed(address, x, y, z, w);
        PxVec4 createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxVec4() {
        address = Raw.PxVec4();
    }

    /**
     * @param x WebIDL type: float
     * @param y WebIDL type: float
     * @param z WebIDL type: float
     * @param w WebIDL type: float
     */
    public PxVec4(float x, float y, float z, float w) {
        address = Raw.PxVec4(x, y, z, w);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: float
     */
    public float getX() {
        checkNotNull();
        return Raw.getX(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setX(float value) {
        checkNotNull();
        Raw.setX(address, value);
    }

    /**
     * @return WebIDL type: float
     */
    public float getY() {
        checkNotNull();
        return Raw.getY(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setY(float value) {
        checkNotNull();
        Raw.setY(address, value);
    }

    /**
     * @return WebIDL type: float
     */
    public float getZ() {
        checkNotNull();
        return Raw.getZ(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setZ(float value) {
        checkNotNull();
        Raw.setZ(address, value);
    }

    /**
     * @return WebIDL type: float
     */
    public float getW() {
        checkNotNull();
        return Raw.getW(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setW(float value) {
        checkNotNull();
        Raw.setW(address, value);
    }

    // Functions

    /**
     * @return WebIDL type: boolean
     */
    public boolean isZero() {
        checkNotNull();
        return Raw.isZero(address);
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isFinite() {
        checkNotNull();
        return Raw.isFinite(address);
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isNormalized() {
        checkNotNull();
        return Raw.isNormalized(address);
    }

    /**
     * @return WebIDL type: float
     */
    public float magnitudeSquared() {
        checkNotNull();
        return Raw.magnitudeSquared(address);
    }

    /**
     * @return WebIDL type: float
     */
    public float magnitude() {
        checkNotNull();
        return Raw.magnitude(address);
    }

    /**
     * @param v WebIDL type: {@link PxVec4} [Const, Ref]
     * @return WebIDL type: float
     */
    public float dot(PxVec4 v) {
        checkNotNull();
        return Raw.dot(address, v.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVec4} [Value]
     */
    public PxVec4 getNormalized() {
        checkNotNull();
        return PxVec4.wrapPointer(Raw.getNormalized(address));
    }

    /**
     * @return WebIDL type: float
     */
    public float normalize() {
        checkNotNull();
        return Raw.normalize(address);
    }

    /**
     * @param a WebIDL type: {@link PxVec4} [Const, Ref]
     * @return WebIDL type: {@link PxVec4} [Value]
     */
    public PxVec4 multiply(PxVec4 a) {
        checkNotNull();
        return PxVec4.wrapPointer(Raw.multiply(address, a.getAddress()));
    }

    /**
     * @param v WebIDL type: {@link PxVec4} [Const, Ref]
     * @return WebIDL type: {@link PxVec4} [Value]
     */
    public PxVec4 minimum(PxVec4 v) {
        checkNotNull();
        return PxVec4.wrapPointer(Raw.minimum(address, v.getAddress()));
    }

    /**
     * @param v WebIDL type: {@link PxVec4} [Const, Ref]
     * @return WebIDL type: {@link PxVec4} [Value]
     */
    public PxVec4 maximum(PxVec4 v) {
        checkNotNull();
        return PxVec4.wrapPointer(Raw.maximum(address, v.getAddress()));
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getXYZ() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getXYZ(address));
    }

    public static class Raw {
        public static native void PxVec4_placed(long address);
        public static native void PxVec4_placed(long address, float x, float y, float z, float w);
        public static native long PxVec4();
        public static native long PxVec4(float x, float y, float z, float w);
        public static native void destroy(long address);
        public static native float getX(long address);
        public static native void setX(long address, float value);
        public static native float getY(long address);
        public static native void setY(long address, float value);
        public static native float getZ(long address);
        public static native void setZ(long address, float value);
        public static native float getW(long address);
        public static native void setW(long address, float value);
        public static native boolean isZero(long address);
        public static native boolean isFinite(long address);
        public static native boolean isNormalized(long address);
        public static native float magnitudeSquared(long address);
        public static native float magnitude(long address);
        public static native float dot(long address, long v);
        public static native long getNormalized(long address);
        public static native float normalize(long address);
        public static native long multiply(long address, long a);
        public static native long minimum(long address, long v);
        public static native long maximum(long address, long v);
        public static native long getXYZ(long address);
    }
}
