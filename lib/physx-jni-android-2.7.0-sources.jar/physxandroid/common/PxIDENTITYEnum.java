package physxandroid.common;

public enum PxIDENTITYEnum {

    PxIdentity(getPxIdentity());
    public final int value;
    
    PxIDENTITYEnum(int value) {
        this.value = value;
    }

    private static native int _getPxIdentity();
    private static int getPxIdentity() {
        de.fabmax.physxandroid.Loader.load();
        return _getPxIdentity();
    }

    private static final int LUT_SIZE = 256;
    private static final PxIDENTITYEnum[] enumValues = values();
    private static final PxIDENTITYEnum[] enumLut = new PxIDENTITYEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxIDENTITYEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxIDENTITYEnum forValue(int value) {
        PxIDENTITYEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxIDENTITYEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxIDENTITYEnum: " + value);
        }
        return enumValue;
    }
}
