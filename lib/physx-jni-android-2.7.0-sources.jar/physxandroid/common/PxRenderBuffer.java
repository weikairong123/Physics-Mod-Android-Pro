package physxandroid.common;

import physxandroid.NativeObject;

/**
 * Interface for points, lines, triangles, and text buffer.
 */
public class PxRenderBuffer extends NativeObject {

    protected PxRenderBuffer() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxRenderBuffer wrapPointer(long address) {
        return address != 0L ? new PxRenderBuffer(address) : null;
    }
    
    public static PxRenderBuffer arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxRenderBuffer(long address) {
        super(address);
    }

    // Functions

    /**
     * @return WebIDL type: unsigned long
     */
    public int getNbPoints() {
        checkNotNull();
        return Raw.getNbPoints(address);
    }

    /**
     * @return WebIDL type: {@link PxDebugPoint} [Const]
     */
    public PxDebugPoint getPoints() {
        checkNotNull();
        return PxDebugPoint.wrapPointer(Raw.getPoints(address));
    }

    /**
     * @param point WebIDL type: {@link PxDebugPoint} [Const, Ref]
     */
    public void addPoint(PxDebugPoint point) {
        checkNotNull();
        Raw.addPoint(address, point.getAddress());
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getNbLines() {
        checkNotNull();
        return Raw.getNbLines(address);
    }

    /**
     * @return WebIDL type: {@link PxDebugLine} [Const]
     */
    public PxDebugLine getLines() {
        checkNotNull();
        return PxDebugLine.wrapPointer(Raw.getLines(address));
    }

    /**
     * @param line WebIDL type: {@link PxDebugLine} [Const, Ref]
     */
    public void addLine(PxDebugLine line) {
        checkNotNull();
        Raw.addLine(address, line.getAddress());
    }

    /**
     * @param nbLines WebIDL type: unsigned long [Const]
     * @return WebIDL type: {@link PxDebugLine}
     */
    public PxDebugLine reserveLines(int nbLines) {
        checkNotNull();
        return PxDebugLine.wrapPointer(Raw.reserveLines(address, nbLines));
    }

    /**
     * @param nbLines WebIDL type: unsigned long [Const]
     * @return WebIDL type: {@link PxDebugPoint}
     */
    public PxDebugPoint reservePoints(int nbLines) {
        checkNotNull();
        return PxDebugPoint.wrapPointer(Raw.reservePoints(address, nbLines));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getNbTriangles() {
        checkNotNull();
        return Raw.getNbTriangles(address);
    }

    /**
     * @return WebIDL type: {@link PxDebugTriangle} [Const]
     */
    public PxDebugTriangle getTriangles() {
        checkNotNull();
        return PxDebugTriangle.wrapPointer(Raw.getTriangles(address));
    }

    /**
     * @param triangle WebIDL type: {@link PxDebugTriangle} [Const, Ref]
     */
    public void addTriangle(PxDebugTriangle triangle) {
        checkNotNull();
        Raw.addTriangle(address, triangle.getAddress());
    }

    /**
     * @param other WebIDL type: {@link PxRenderBuffer} [Const, Ref]
     */
    public void append(PxRenderBuffer other) {
        checkNotNull();
        Raw.append(address, other.getAddress());
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    /**
     * @param delta WebIDL type: {@link PxVec3} [Const, Ref]
     */
    public void shift(PxVec3 delta) {
        checkNotNull();
        Raw.shift(address, delta.getAddress());
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean empty() {
        checkNotNull();
        return Raw.empty(address);
    }

    public static class Raw {
        public static native int getNbPoints(long address);
        public static native long getPoints(long address);
        public static native void addPoint(long address, long point);
        public static native int getNbLines(long address);
        public static native long getLines(long address);
        public static native void addLine(long address, long line);
        public static native long reserveLines(long address, int nbLines);
        public static native long reservePoints(long address, int nbLines);
        public static native int getNbTriangles(long address);
        public static native long getTriangles(long address);
        public static native void addTriangle(long address, long triangle);
        public static native void append(long address, long other);
        public static native void clear(long address);
        public static native void shift(long address, long delta);
        public static native boolean empty(long address);
    }
}
