package physxandroid.common;

import physxandroid.NativeObject;

public class PxStridedData extends NativeObject {

    protected PxStridedData() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxStridedData wrapPointer(long address) {
        return address != 0L ? new PxStridedData(address) : null;
    }
    
    public static PxStridedData arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxStridedData(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: unsigned long
     */
    public int getStride() {
        checkNotNull();
        return Raw.getStride(address);
    }

    /**
     * @param value WebIDL type: unsigned long
     */
    public void setStride(int value) {
        checkNotNull();
        Raw.setStride(address, value);
    }

    /**
     * @return WebIDL type: VoidPtr [Const]
     */
    public NativeObject getData() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.getData(address));
    }

    /**
     * @param value WebIDL type: VoidPtr [Const]
     */
    public void setData(NativeObject value) {
        checkNotNull();
        Raw.setData(address, value.getAddress());
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native int getStride(long address);
        public static native void setStride(long address, int value);
        public static native long getData(long address);
        public static native void setData(long address, long value);
    }
}
