package physxandroid.common;

/**
 * Default color values used for debug rendering.
 */
public enum PxDebugColorEnum {

    eARGB_BLACK(geteARGB_BLACK()),
    eARGB_RED(geteARGB_RED()),
    eARGB_GREEN(geteARGB_GREEN()),
    eARGB_BLUE(geteARGB_BLUE()),
    eARGB_YELLOW(geteARGB_YELLOW()),
    eARGB_MAGENTA(geteARGB_MAGENTA()),
    eARGB_CYAN(geteARGB_CYAN()),
    eARGB_WHITE(geteARGB_WHITE()),
    eARGB_GREY(geteARGB_GREY()),
    eARGB_DARKRED(geteARGB_DARKRED()),
    eARGB_DARKGREEN(geteARGB_DARKGREEN()),
    eARGB_DARKBLUE(geteARGB_DARKBLUE());
    public final int value;
    
    PxDebugColorEnum(int value) {
        this.value = value;
    }

    private static native int _geteARGB_BLACK();
    private static int geteARGB_BLACK() {
        de.fabmax.physxandroid.Loader.load();
        return _geteARGB_BLACK();
    }

    private static native int _geteARGB_RED();
    private static int geteARGB_RED() {
        de.fabmax.physxandroid.Loader.load();
        return _geteARGB_RED();
    }

    private static native int _geteARGB_GREEN();
    private static int geteARGB_GREEN() {
        de.fabmax.physxandroid.Loader.load();
        return _geteARGB_GREEN();
    }

    private static native int _geteARGB_BLUE();
    private static int geteARGB_BLUE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteARGB_BLUE();
    }

    private static native int _geteARGB_YELLOW();
    private static int geteARGB_YELLOW() {
        de.fabmax.physxandroid.Loader.load();
        return _geteARGB_YELLOW();
    }

    private static native int _geteARGB_MAGENTA();
    private static int geteARGB_MAGENTA() {
        de.fabmax.physxandroid.Loader.load();
        return _geteARGB_MAGENTA();
    }

    private static native int _geteARGB_CYAN();
    private static int geteARGB_CYAN() {
        de.fabmax.physxandroid.Loader.load();
        return _geteARGB_CYAN();
    }

    private static native int _geteARGB_WHITE();
    private static int geteARGB_WHITE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteARGB_WHITE();
    }

    private static native int _geteARGB_GREY();
    private static int geteARGB_GREY() {
        de.fabmax.physxandroid.Loader.load();
        return _geteARGB_GREY();
    }

    private static native int _geteARGB_DARKRED();
    private static int geteARGB_DARKRED() {
        de.fabmax.physxandroid.Loader.load();
        return _geteARGB_DARKRED();
    }

    private static native int _geteARGB_DARKGREEN();
    private static int geteARGB_DARKGREEN() {
        de.fabmax.physxandroid.Loader.load();
        return _geteARGB_DARKGREEN();
    }

    private static native int _geteARGB_DARKBLUE();
    private static int geteARGB_DARKBLUE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteARGB_DARKBLUE();
    }

    private static final int LUT_SIZE = 256;
    private static final PxDebugColorEnum[] enumValues = values();
    private static final PxDebugColorEnum[] enumLut = new PxDebugColorEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxDebugColorEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxDebugColorEnum forValue(int value) {
        PxDebugColorEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxDebugColorEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxDebugColorEnum: " + value);
        }
        return enumValue;
    }
}
