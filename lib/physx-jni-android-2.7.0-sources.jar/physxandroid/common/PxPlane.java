package physxandroid.common;

import physxandroid.NativeObject;
import physxandroid.PlatformChecks;

/**
 * Representation of a plane.
 * <p>
 *  Plane equation used: n.dot(v) + d = 0
 */
public class PxPlane extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxPlane wrapPointer(long address) {
        return address != 0L ? new PxPlane(address) : null;
    }
    
    public static PxPlane arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxPlane(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxPlane
     */
    public static PxPlane createAt(long address) {
        Raw.PxPlane_placed(address);
        PxPlane createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxPlane
     */
    public static <T> PxPlane createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxPlane_placed(address);
        PxPlane createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address  Pre-allocated memory, where the object is created.
     * @param nx       WebIDL type: float
     * @param ny       WebIDL type: float
     * @param nz       WebIDL type: float
     * @param distance WebIDL type: float
     * @return Stack allocated object of PxPlane
     */
    public static PxPlane createAt(long address, float nx, float ny, float nz, float distance) {
        Raw.PxPlane_placed(address, nx, ny, nz, distance);
        PxPlane createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param nx        WebIDL type: float
     * @param ny        WebIDL type: float
     * @param nz        WebIDL type: float
     * @param distance  WebIDL type: float
     * @return Stack allocated object of PxPlane
     */
    public static <T> PxPlane createAt(T allocator, Allocator<T> allocate, float nx, float ny, float nz, float distance) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxPlane_placed(address, nx, ny, nz, distance);
        PxPlane createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address  Pre-allocated memory, where the object is created.
     * @param normal   WebIDL type: {@link PxVec3} [Const, Ref]
     * @param distance WebIDL type: float
     * @return Stack allocated object of PxPlane
     */
    public static PxPlane createAt(long address, PxVec3 normal, float distance) {
        Raw.PxPlane_placed(address, normal.getAddress(), distance);
        PxPlane createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param normal    WebIDL type: {@link PxVec3} [Const, Ref]
     * @param distance  WebIDL type: float
     * @return Stack allocated object of PxPlane
     */
    public static <T> PxPlane createAt(T allocator, Allocator<T> allocate, PxVec3 normal, float distance) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxPlane_placed(address, normal.getAddress(), distance);
        PxPlane createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param p0      WebIDL type: {@link PxVec3} [Const, Ref]
     * @param p1      WebIDL type: {@link PxVec3} [Const, Ref]
     * @param p2      WebIDL type: {@link PxVec3} [Const, Ref]
     * @return Stack allocated object of PxPlane
     */
    public static PxPlane createAt(long address, PxVec3 p0, PxVec3 p1, PxVec3 p2) {
        Raw.PxPlane_placed(address, p0.getAddress(), p1.getAddress(), p2.getAddress());
        PxPlane createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param p0        WebIDL type: {@link PxVec3} [Const, Ref]
     * @param p1        WebIDL type: {@link PxVec3} [Const, Ref]
     * @param p2        WebIDL type: {@link PxVec3} [Const, Ref]
     * @return Stack allocated object of PxPlane
     */
    public static <T> PxPlane createAt(T allocator, Allocator<T> allocate, PxVec3 p0, PxVec3 p1, PxVec3 p2) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxPlane_placed(address, p0.getAddress(), p1.getAddress(), p2.getAddress());
        PxPlane createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param point   WebIDL type: {@link PxVec3} [Const, Ref]
     * @param normal  WebIDL type: {@link PxVec3} [Const, Ref]
     * @return Stack allocated object of PxPlane
     */
    public static PxPlane createAt(long address, PxVec3 point, PxVec3 normal) {
    PlatformChecks.requirePlatform(15, "physxandroid.common.PxPlane");
        Raw.PxPlane_placed(address, point.getAddress(), normal.getAddress());
        PxPlane createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param point     WebIDL type: {@link PxVec3} [Const, Ref]
     * @param normal    WebIDL type: {@link PxVec3} [Const, Ref]
     * @return Stack allocated object of PxPlane
     */
    public static <T> PxPlane createAt(T allocator, Allocator<T> allocate, PxVec3 point, PxVec3 normal) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxPlane_placed(address, point.getAddress(), normal.getAddress());
        PxPlane createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * Constructor
     */
    public PxPlane() {
        address = Raw.PxPlane();
    }

    /**
     * Constructor from a normal and a distance
     */
    public PxPlane(float nx, float ny, float nz, float distance) {
        address = Raw.PxPlane(nx, ny, nz, distance);
    }

    /**
     * Constructor from a normal and a distance
     */
    public PxPlane(PxVec3 normal, float distance) {
        address = Raw.PxPlane(normal.getAddress(), distance);
    }

    /**
     * Constructor from three points
     */
    public PxPlane(PxVec3 p0, PxVec3 p1, PxVec3 p2) {
        address = Raw.PxPlane(p0.getAddress(), p1.getAddress(), p2.getAddress());
    }

    /**
     * Constructor from a normal and a distance
     */
    public PxPlane(PxVec3 point, PxVec3 normal) {
        PlatformChecks.requirePlatform(15, "physxandroid.common.PxPlane");
        address = Raw.PxPlane(point.getAddress(), normal.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The normal to the plane
     */
    public PxVec3 getN() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getN(address));
    }

    /**
     * The normal to the plane
     */
    public void setN(PxVec3 value) {
        checkNotNull();
        Raw.setN(address, value.getAddress());
    }

    /**
     * The distance from the origin
     */
    public float getD() {
        checkNotNull();
        return Raw.getD(address);
    }

    /**
     * The distance from the origin
     */
    public void setD(float value) {
        checkNotNull();
        Raw.setD(address, value);
    }

    // Functions

    /**
     * @param p WebIDL type: {@link PxVec3} [Const, Ref]
     * @return WebIDL type: float
     */
    public float distance(PxVec3 p) {
        checkNotNull();
        return Raw.distance(address, p.getAddress());
    }

    /**
     * @param p WebIDL type: {@link PxVec3} [Const, Ref]
     * @return WebIDL type: boolean
     */
    public boolean contains(PxVec3 p) {
        checkNotNull();
        return Raw.contains(address, p.getAddress());
    }

    /**
     * projects p into the plane
     */
    public PxVec3 project(PxVec3 p) {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.project(address, p.getAddress()));
    }

    /**
     * find an arbitrary point in the plane
     */
    public PxVec3 pointInPlane() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.pointInPlane(address));
    }

    /**
     * equivalent plane with unit normal
     */
    public void normalize() {
        checkNotNull();
        Raw.normalize(address);
    }

    /**
     * transform plane
     */
    public PxPlane transform(PxTransform pose) {
        checkNotNull();
        return PxPlane.wrapPointer(Raw.transform(address, pose.getAddress()));
    }

    /**
     * inverse-transform plane
     */
    public PxPlane inverseTransform(PxTransform pose) {
        checkNotNull();
        return PxPlane.wrapPointer(Raw.inverseTransform(address, pose.getAddress()));
    }

    public static class Raw {
        public static native void PxPlane_placed(long address);
        public static native void PxPlane_placed(long address, float nx, float ny, float nz, float distance);
        public static native void PxPlane_placed(long address, long normal, float distance);
        public static native void PxPlane_placed(long address, long p0, long p1, long p2);
        public static native void PxPlane_placed(long address, long point, long normal);
        public static native long PxPlane();
        public static native long PxPlane(float nx, float ny, float nz, float distance);
        public static native long PxPlane(long normal, float distance);
        public static native long PxPlane(long p0, long p1, long p2);
        public static native long PxPlane(long point, long normal);
        public static native void destroy(long address);
        public static native long getN(long address);
        public static native void setN(long address, long value);
        public static native float getD(long address);
        public static native void setD(long address, float value);
        public static native float distance(long address, long p);
        public static native boolean contains(long address, long p);
        public static native long project(long address, long p);
        public static native long pointInPlane(long address);
        public static native void normalize(long address);
        public static native long transform(long address, long pose);
        public static native long inverseTransform(long address, long pose);
    }
}
