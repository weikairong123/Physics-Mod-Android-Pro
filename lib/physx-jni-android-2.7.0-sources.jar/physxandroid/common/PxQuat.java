package physxandroid.common;

import physxandroid.NativeObject;
import physxandroid.PlatformChecks;

public class PxQuat extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxQuat wrapPointer(long address) {
        return address != 0L ? new PxQuat(address) : null;
    }
    
    public static PxQuat arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxQuat(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxQuat
     */
    public static PxQuat createAt(long address) {
        Raw.PxQuat_placed(address);
        PxQuat createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxQuat
     */
    public static <T> PxQuat createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxQuat_placed(address);
        PxQuat createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param r       WebIDL type: {@link PxIDENTITYEnum} [enum]
     * @return Stack allocated object of PxQuat
     */
    public static PxQuat createAt(long address, PxIDENTITYEnum r) {
        Raw.PxQuat_placed(address, r.value);
        PxQuat createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param r         WebIDL type: {@link PxIDENTITYEnum} [enum]
     * @return Stack allocated object of PxQuat
     */
    public static <T> PxQuat createAt(T allocator, Allocator<T> allocate, PxIDENTITYEnum r) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxQuat_placed(address, r.value);
        PxQuat createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param nx      WebIDL type: float
     * @param ny      WebIDL type: float
     * @param nz      WebIDL type: float
     * @param nw      WebIDL type: float
     * @return Stack allocated object of PxQuat
     */
    public static PxQuat createAt(long address, float nx, float ny, float nz, float nw) {
        Raw.PxQuat_placed(address, nx, ny, nz, nw);
        PxQuat createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param nx        WebIDL type: float
     * @param ny        WebIDL type: float
     * @param nz        WebIDL type: float
     * @param nw        WebIDL type: float
     * @return Stack allocated object of PxQuat
     */
    public static <T> PxQuat createAt(T allocator, Allocator<T> allocate, float nx, float ny, float nz, float nw) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxQuat_placed(address, nx, ny, nz, nw);
        PxQuat createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address      Pre-allocated memory, where the object is created.
     * @param angleRadians WebIDL type: float
     * @param unitAxis     WebIDL type: {@link PxVec3} [Const, Ref]
     * @return Stack allocated object of PxQuat
     */
    public static PxQuat createAt(long address, float angleRadians, PxVec3 unitAxis) {
        Raw.PxQuat_placed(address, angleRadians, unitAxis.getAddress());
        PxQuat createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>          Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator    Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate     Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param angleRadians WebIDL type: float
     * @param unitAxis     WebIDL type: {@link PxVec3} [Const, Ref]
     * @return Stack allocated object of PxQuat
     */
    public static <T> PxQuat createAt(T allocator, Allocator<T> allocate, float angleRadians, PxVec3 unitAxis) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxQuat_placed(address, angleRadians, unitAxis.getAddress());
        PxQuat createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param r       WebIDL type: float
     * @return Stack allocated object of PxQuat
     */
    public static PxQuat createAt(long address, float r) {
    PlatformChecks.requirePlatform(15, "physxandroid.common.PxQuat");
        Raw.PxQuat_placed(address, r);
        PxQuat createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param r         WebIDL type: float
     * @return Stack allocated object of PxQuat
     */
    public static <T> PxQuat createAt(T allocator, Allocator<T> allocate, float r) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxQuat_placed(address, r);
        PxQuat createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param m       WebIDL type: {@link PxMat33} [Const, Ref]
     * @return Stack allocated object of PxQuat
     */
    public static PxQuat createAt(long address, PxMat33 m) {
    PlatformChecks.requirePlatform(15, "physxandroid.common.PxQuat");
        Raw.PxQuat_placed(address, m.getAddress());
        PxQuat createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param m         WebIDL type: {@link PxMat33} [Const, Ref]
     * @return Stack allocated object of PxQuat
     */
    public static <T> PxQuat createAt(T allocator, Allocator<T> allocate, PxMat33 m) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxQuat_placed(address, m.getAddress());
        PxQuat createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxQuat() {
        address = Raw.PxQuat();
    }

    /**
     * @param r WebIDL type: {@link PxIDENTITYEnum} [enum]
     */
    public PxQuat(PxIDENTITYEnum r) {
        address = Raw.PxQuat(r.value);
    }

    /**
     * @param nx WebIDL type: float
     * @param ny WebIDL type: float
     * @param nz WebIDL type: float
     * @param nw WebIDL type: float
     */
    public PxQuat(float nx, float ny, float nz, float nw) {
        address = Raw.PxQuat(nx, ny, nz, nw);
    }

    /**
     * @param angleRadians WebIDL type: float
     * @param unitAxis     WebIDL type: {@link PxVec3} [Const, Ref]
     */
    public PxQuat(float angleRadians, PxVec3 unitAxis) {
        address = Raw.PxQuat(angleRadians, unitAxis.getAddress());
    }

    /**
     * @param r WebIDL type: float
     */
    public PxQuat(float r) {
        PlatformChecks.requirePlatform(15, "physxandroid.common.PxQuat");
        address = Raw.PxQuat(r);
    }

    /**
     * @param m WebIDL type: {@link PxMat33} [Const, Ref]
     */
    public PxQuat(PxMat33 m) {
        PlatformChecks.requirePlatform(15, "physxandroid.common.PxQuat");
        address = Raw.PxQuat(m.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: float
     */
    public float getX() {
        checkNotNull();
        return Raw.getX(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setX(float value) {
        checkNotNull();
        Raw.setX(address, value);
    }

    /**
     * @return WebIDL type: float
     */
    public float getY() {
        checkNotNull();
        return Raw.getY(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setY(float value) {
        checkNotNull();
        Raw.setY(address, value);
    }

    /**
     * @return WebIDL type: float
     */
    public float getZ() {
        checkNotNull();
        return Raw.getZ(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setZ(float value) {
        checkNotNull();
        Raw.setZ(address, value);
    }

    /**
     * @return WebIDL type: float
     */
    public float getW() {
        checkNotNull();
        return Raw.getW(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setW(float value) {
        checkNotNull();
        Raw.setW(address, value);
    }

    // Functions

    /**
     * @return WebIDL type: boolean
     */
    public boolean isIdentity() {
        checkNotNull();
        return Raw.isIdentity(address);
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isFinite() {
        checkNotNull();
        return Raw.isFinite(address);
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isUnit() {
        checkNotNull();
        return Raw.isUnit(address);
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isSane() {
        checkNotNull();
        return Raw.isSane(address);
    }

    /**
     * @return WebIDL type: float
     */
    public float getAngle() {
        checkNotNull();
        return Raw.getAngle(address);
    }

    /**
     * @param q WebIDL type: {@link PxQuat} [Const, Ref]
     * @return WebIDL type: float
     */
    public float getAngle(PxQuat q) {
        checkNotNull();
        return Raw.getAngle(address, q.getAddress());
    }

    /**
     * @return WebIDL type: float
     */
    public float magnitudeSquared() {
        checkNotNull();
        return Raw.magnitudeSquared(address);
    }

    /**
     * @param q WebIDL type: {@link PxQuat} [Const, Ref]
     * @return WebIDL type: float
     */
    public float dot(PxQuat q) {
        checkNotNull();
        return Raw.dot(address, q.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxQuat} [Value]
     */
    public PxQuat getNormalized() {
        checkNotNull();
        return PxQuat.wrapPointer(Raw.getNormalized(address));
    }

    /**
     * @return WebIDL type: float
     */
    public float magnitude() {
        checkNotNull();
        return Raw.magnitude(address);
    }

    /**
     * @return WebIDL type: float
     */
    public float normalize() {
        checkNotNull();
        return Raw.normalize(address);
    }

    /**
     * @return WebIDL type: {@link PxQuat} [Value]
     */
    public PxQuat getConjugate() {
        checkNotNull();
        return PxQuat.wrapPointer(Raw.getConjugate(address));
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getImaginaryPart() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getImaginaryPart(address));
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getBasisVector0() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getBasisVector0(address));
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getBasisVector1() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getBasisVector1(address));
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getBasisVector2() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getBasisVector2(address));
    }

    /**
     * @param v WebIDL type: {@link PxVec3} [Const, Ref]
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 rotate(PxVec3 v) {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.rotate(address, v.getAddress()));
    }

    /**
     * @param v WebIDL type: {@link PxVec3} [Const, Ref]
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 rotateInv(PxVec3 v) {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.rotateInv(address, v.getAddress()));
    }

    public static class Raw {
        public static native void PxQuat_placed(long address);
        public static native void PxQuat_placed(long address, int r);
        public static native void PxQuat_placed(long address, float nx, float ny, float nz, float nw);
        public static native void PxQuat_placed(long address, float angleRadians, long unitAxis);
        public static native void PxQuat_placed(long address, float r);
        public static native void PxQuat_placed(long address, long m);
        public static native long PxQuat();
        public static native long PxQuat(int r);
        public static native long PxQuat(float nx, float ny, float nz, float nw);
        public static native long PxQuat(float angleRadians, long unitAxis);
        public static native long PxQuat(float r);
        public static native long PxQuat(long m);
        public static native void destroy(long address);
        public static native float getX(long address);
        public static native void setX(long address, float value);
        public static native float getY(long address);
        public static native void setY(long address, float value);
        public static native float getZ(long address);
        public static native void setZ(long address, float value);
        public static native float getW(long address);
        public static native void setW(long address, float value);
        public static native boolean isIdentity(long address);
        public static native boolean isFinite(long address);
        public static native boolean isUnit(long address);
        public static native boolean isSane(long address);
        public static native float getAngle(long address);
        public static native float getAngle(long address, long q);
        public static native float magnitudeSquared(long address);
        public static native float dot(long address, long q);
        public static native long getNormalized(long address);
        public static native float magnitude(long address);
        public static native float normalize(long address);
        public static native long getConjugate(long address);
        public static native long getImaginaryPart(long address);
        public static native long getBasisVector0(long address);
        public static native long getBasisVector1(long address);
        public static native long getBasisVector2(long address);
        public static native long rotate(long address, long v);
        public static native long rotateInv(long address, long v);
    }
}
