package physxandroid.common;

import physxandroid.NativeObject;
import physxandroid.PlatformChecks;

public class PxTransform extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxTransform wrapPointer(long address) {
        return address != 0L ? new PxTransform(address) : null;
    }
    
    public static PxTransform arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxTransform(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxTransform
     */
    public static PxTransform createAt(long address) {
        Raw.PxTransform_placed(address);
        PxTransform createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxTransform
     */
    public static <T> PxTransform createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxTransform_placed(address);
        PxTransform createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param r       WebIDL type: {@link PxIDENTITYEnum} [enum]
     * @return Stack allocated object of PxTransform
     */
    public static PxTransform createAt(long address, PxIDENTITYEnum r) {
        Raw.PxTransform_placed(address, r.value);
        PxTransform createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param r         WebIDL type: {@link PxIDENTITYEnum} [enum]
     * @return Stack allocated object of PxTransform
     */
    public static <T> PxTransform createAt(T allocator, Allocator<T> allocate, PxIDENTITYEnum r) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxTransform_placed(address, r.value);
        PxTransform createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param p0      WebIDL type: {@link PxVec3} [Const, Ref]
     * @param q0      WebIDL type: {@link PxQuat} [Const, Ref]
     * @return Stack allocated object of PxTransform
     */
    public static PxTransform createAt(long address, PxVec3 p0, PxQuat q0) {
        Raw.PxTransform_placed(address, p0.getAddress(), q0.getAddress());
        PxTransform createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param p0        WebIDL type: {@link PxVec3} [Const, Ref]
     * @param q0        WebIDL type: {@link PxQuat} [Const, Ref]
     * @return Stack allocated object of PxTransform
     */
    public static <T> PxTransform createAt(T allocator, Allocator<T> allocate, PxVec3 p0, PxQuat q0) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxTransform_placed(address, p0.getAddress(), q0.getAddress());
        PxTransform createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address  Pre-allocated memory, where the object is created.
     * @param position WebIDL type: {@link PxVec3} [Const, Ref]
     * @return Stack allocated object of PxTransform
     */
    public static PxTransform createAt(long address, PxVec3 position) {
    PlatformChecks.requirePlatform(15, "physxandroid.common.PxTransform");
        Raw.PxTransform_placed(address, position.getAddress());
        PxTransform createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param position  WebIDL type: {@link PxVec3} [Const, Ref]
     * @return Stack allocated object of PxTransform
     */
    public static <T> PxTransform createAt(T allocator, Allocator<T> allocate, PxVec3 position) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxTransform_placed(address, position.getAddress());
        PxTransform createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxTransform() {
        address = Raw.PxTransform();
    }

    /**
     * @param r WebIDL type: {@link PxIDENTITYEnum} [enum]
     */
    public PxTransform(PxIDENTITYEnum r) {
        address = Raw.PxTransform(r.value);
    }

    /**
     * @param p0 WebIDL type: {@link PxVec3} [Const, Ref]
     * @param q0 WebIDL type: {@link PxQuat} [Const, Ref]
     */
    public PxTransform(PxVec3 p0, PxQuat q0) {
        address = Raw.PxTransform(p0.getAddress(), q0.getAddress());
    }

    /**
     * @param position WebIDL type: {@link PxVec3} [Const, Ref]
     */
    public PxTransform(PxVec3 position) {
        PlatformChecks.requirePlatform(15, "physxandroid.common.PxTransform");
        address = Raw.PxTransform(position.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxQuat} [Value]
     */
    public PxQuat getQ() {
        checkNotNull();
        return PxQuat.wrapPointer(Raw.getQ(address));
    }

    /**
     * @param value WebIDL type: {@link PxQuat} [Value]
     */
    public void setQ(PxQuat value) {
        checkNotNull();
        Raw.setQ(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getP() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getP(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setP(PxVec3 value) {
        checkNotNull();
        Raw.setP(address, value.getAddress());
    }

    // Functions

    /**
     * @return WebIDL type: {@link PxTransform} [Value]
     */
    public PxTransform getInverse() {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getInverse(address));
    }

    /**
     * @param input WebIDL type: {@link PxVec3} [Const, Ref]
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 transform(PxVec3 input) {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.transform(address, input.getAddress()));
    }

    /**
     * @param input WebIDL type: {@link PxVec3} [Const, Ref]
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 transformInv(PxVec3 input) {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.transformInv(address, input.getAddress()));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isSane() {
        checkNotNull();
        return Raw.isSane(address);
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isFinite() {
        checkNotNull();
        return Raw.isFinite(address);
    }

    /**
     * @return WebIDL type: {@link PxTransform} [Value]
     */
    public PxTransform getNormalized() {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getNormalized(address));
    }

    public static class Raw {
        public static native void PxTransform_placed(long address);
        public static native void PxTransform_placed(long address, int r);
        public static native void PxTransform_placed(long address, long p0, long q0);
        public static native void PxTransform_placed(long address, long position);
        public static native long PxTransform();
        public static native long PxTransform(int r);
        public static native long PxTransform(long p0, long q0);
        public static native long PxTransform(long position);
        public static native void destroy(long address);
        public static native long getQ(long address);
        public static native void setQ(long address, long value);
        public static native long getP(long address);
        public static native void setP(long address, long value);
        public static native long getInverse(long address);
        public static native long transform(long address, long input);
        public static native long transformInv(long address, long input);
        public static native boolean isValid(long address);
        public static native boolean isSane(long address);
        public static native boolean isFinite(long address);
        public static native long getNormalized(long address);
    }
}
