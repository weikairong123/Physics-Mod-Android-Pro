package physxandroid.cooking;

import physxandroid.NativeObject;

public class PxMeshPreprocessingFlags extends NativeObject {

    protected PxMeshPreprocessingFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxMeshPreprocessingFlags wrapPointer(long address) {
        return address != 0L ? new PxMeshPreprocessingFlags(address) : null;
    }
    
    public static PxMeshPreprocessingFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxMeshPreprocessingFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: unsigned long
     * @return Stack allocated object of PxMeshPreprocessingFlags
     */
    public static PxMeshPreprocessingFlags createAt(long address, int flags) {
        Raw.PxMeshPreprocessingFlags_placed(address, flags);
        PxMeshPreprocessingFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: unsigned long
     * @return Stack allocated object of PxMeshPreprocessingFlags
     */
    public static <T> PxMeshPreprocessingFlags createAt(T allocator, Allocator<T> allocate, int flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxMeshPreprocessingFlags_placed(address, flags);
        PxMeshPreprocessingFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param flags WebIDL type: unsigned long
     */
    public PxMeshPreprocessingFlags(int flags) {
        address = Raw.PxMeshPreprocessingFlags(flags);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param flag WebIDL type: {@link PxMeshPreprocessingFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxMeshPreprocessingFlagEnum flag) {
        checkNotNull();
        return Raw.isSet(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxMeshPreprocessingFlagEnum} [enum]
     */
    public void raise(PxMeshPreprocessingFlagEnum flag) {
        checkNotNull();
        Raw.raise(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxMeshPreprocessingFlagEnum} [enum]
     */
    public void clear(PxMeshPreprocessingFlagEnum flag) {
        checkNotNull();
        Raw.clear(address, flag.value);
    }

    public static class Raw {
        public static native void PxMeshPreprocessingFlags_placed(long address, int flags);
        public static native long PxMeshPreprocessingFlags(int flags);
        public static native void destroy(long address);
        public static native boolean isSet(long address, int flag);
        public static native void raise(long address, int flag);
        public static native void clear(long address, int flag);
    }
}
