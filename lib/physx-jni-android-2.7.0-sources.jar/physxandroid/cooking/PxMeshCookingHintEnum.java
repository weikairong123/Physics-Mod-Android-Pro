package physxandroid.cooking;

public enum PxMeshCookingHintEnum {

    eSIM_PERFORMANCE(geteSIM_PERFORMANCE()),
    eCOOKING_PERFORMANCE(geteCOOKING_PERFORMANCE());
    public final int value;
    
    PxMeshCookingHintEnum(int value) {
        this.value = value;
    }

    private static native int _geteSIM_PERFORMANCE();
    private static int geteSIM_PERFORMANCE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteSIM_PERFORMANCE();
    }

    private static native int _geteCOOKING_PERFORMANCE();
    private static int geteCOOKING_PERFORMANCE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteCOOKING_PERFORMANCE();
    }

    private static final int LUT_SIZE = 256;
    private static final PxMeshCookingHintEnum[] enumValues = values();
    private static final PxMeshCookingHintEnum[] enumLut = new PxMeshCookingHintEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxMeshCookingHintEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxMeshCookingHintEnum forValue(int value) {
        PxMeshCookingHintEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxMeshCookingHintEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxMeshCookingHintEnum: " + value);
        }
        return enumValue;
    }
}
