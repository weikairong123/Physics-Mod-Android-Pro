package physxandroid.cooking;

/**
 * Enum for the set of mesh pre-processing parameters.
 */
public enum PxMeshPreprocessingFlagEnum {

    /**
     * When set, mesh welding is performed. See PxCookingParams::meshWeldTolerance. Mesh cleaning must be enabled.
     */
    eWELD_VERTICES(geteWELD_VERTICES()),
    /**
     * When set, mesh cleaning is disabled. This makes cooking faster.
     * <p>
     * When mesh cleaning is disabled, mesh welding is also disabled.
     * <p>
     * It is recommended to use only meshes that passed during validateTriangleMesh.
     */
    eDISABLE_CLEAN_MESH(geteDISABLE_CLEAN_MESH()),
    /**
     * When set, active edges are not computed and just enabled for all edges. This makes cooking faster but contact generation slower.
     */
    eDISABLE_ACTIVE_EDGES_PRECOMPUTE(geteDISABLE_ACTIVE_EDGES_PRECOMPUTE()),
    /**
     * When set, 32-bit indices will always be created regardless of triangle count.
     * <p>
     * <b>Note:</b> By default mesh will be created with 16-bit indices for triangle count &lt;= 0xFFFF and 32-bit otherwise.
     */
    eFORCE_32BIT_INDICES(geteFORCE_32BIT_INDICES());
    public final int value;
    
    PxMeshPreprocessingFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteWELD_VERTICES();
    private static int geteWELD_VERTICES() {
        de.fabmax.physxandroid.Loader.load();
        return _geteWELD_VERTICES();
    }

    private static native int _geteDISABLE_CLEAN_MESH();
    private static int geteDISABLE_CLEAN_MESH() {
        de.fabmax.physxandroid.Loader.load();
        return _geteDISABLE_CLEAN_MESH();
    }

    private static native int _geteDISABLE_ACTIVE_EDGES_PRECOMPUTE();
    private static int geteDISABLE_ACTIVE_EDGES_PRECOMPUTE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteDISABLE_ACTIVE_EDGES_PRECOMPUTE();
    }

    private static native int _geteFORCE_32BIT_INDICES();
    private static int geteFORCE_32BIT_INDICES() {
        de.fabmax.physxandroid.Loader.load();
        return _geteFORCE_32BIT_INDICES();
    }

    private static final int LUT_SIZE = 256;
    private static final PxMeshPreprocessingFlagEnum[] enumValues = values();
    private static final PxMeshPreprocessingFlagEnum[] enumLut = new PxMeshPreprocessingFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxMeshPreprocessingFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxMeshPreprocessingFlagEnum forValue(int value) {
        PxMeshPreprocessingFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxMeshPreprocessingFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxMeshPreprocessingFlagEnum: " + value);
        }
        return enumValue;
    }
}
