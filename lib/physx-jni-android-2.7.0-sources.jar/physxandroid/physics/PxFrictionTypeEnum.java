package physxandroid.physics;

public enum PxFrictionTypeEnum {

    ePATCH(getePATCH()),
    eFRICTION_COUNT(geteFRICTION_COUNT());
    public final int value;
    
    PxFrictionTypeEnum(int value) {
        this.value = value;
    }

    private static native int _getePATCH();
    private static int getePATCH() {
        de.fabmax.physxandroid.Loader.load();
        return _getePATCH();
    }

    private static native int _geteFRICTION_COUNT();
    private static int geteFRICTION_COUNT() {
        de.fabmax.physxandroid.Loader.load();
        return _geteFRICTION_COUNT();
    }

    private static final int LUT_SIZE = 256;
    private static final PxFrictionTypeEnum[] enumValues = values();
    private static final PxFrictionTypeEnum[] enumLut = new PxFrictionTypeEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxFrictionTypeEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxFrictionTypeEnum forValue(int value) {
        PxFrictionTypeEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxFrictionTypeEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxFrictionTypeEnum: " + value);
        }
        return enumValue;
    }
}
