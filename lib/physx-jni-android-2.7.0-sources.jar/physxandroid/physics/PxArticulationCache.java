package physxandroid.physics;

import physxandroid.NativeObject;
import physxandroid.support.PxRealPtr;

/**
 * Data structure used to read and write internal articulation data.
 * <p>
 * PxArticulationReducedCoordinate::copyInternalStateToCache
 */
public class PxArticulationCache extends NativeObject {

    protected PxArticulationCache() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxArticulationCache wrapPointer(long address) {
        return address != 0L ? new PxArticulationCache(address) : null;
    }
    
    public static PxArticulationCache arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxArticulationCache(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * External forces acting on the articulation links for inverse dynamics computation.
     * <p>
     * - N = getNbLinks().
     * - Indexing follows the low-level link indices, see PxArticulationLink::getLinkIndex.
     * - The forces are with respect to the center of mass of the link.
     * - This field cannot be used to apply forces to links during the next PxScene::simulate() call. Use PxRigidBody::addForce and related functions instead.
     */
    public PxSpatialForce getExternalForces() {
        checkNotNull();
        return PxSpatialForce.wrapPointer(Raw.getExternalForces(address));
    }

    /**
     * External forces acting on the articulation links for inverse dynamics computation.
     * <p>
     * - N = getNbLinks().
     * - Indexing follows the low-level link indices, see PxArticulationLink::getLinkIndex.
     * - The forces are with respect to the center of mass of the link.
     * - This field cannot be used to apply forces to links during the next PxScene::simulate() call. Use PxRigidBody::addForce and related functions instead.
     */
    public void setExternalForces(PxSpatialForce value) {
        checkNotNull();
        Raw.setExternalForces(address, value.getAddress());
    }

    /**
     * Dense Jacobian data.
     * <p>
     * - N = nbRows * nbCols = (6 * getNbLinks()) * (6 + getDofs()) -&gt; size includes possible floating-base DOFs regardless of PxArticulationFlag::eFIX_BASE flag.
     * - The links, i.e. rows are in order of the low-level link indices (minus one if PxArticulationFlag::eFIX_BASE is true), see PxArticulationLink::getLinkIndex.
     * The corresponding spatial velocities are stacked [vx; vy; vz; wx; wy; wz], where vx and wx refer to the linear and rotational velocity in world X.
     * - The DOFs, i.e. column indices correspond to the low-level DOF indices, see PxArticulationCache::jointVelocity.
     */
    public PxRealPtr getDenseJacobian() {
        checkNotNull();
        return PxRealPtr.wrapPointer(Raw.getDenseJacobian(address));
    }

    /**
     * Dense Jacobian data.
     * <p>
     * - N = nbRows * nbCols = (6 * getNbLinks()) * (6 + getDofs()) -&gt; size includes possible floating-base DOFs regardless of PxArticulationFlag::eFIX_BASE flag.
     * - The links, i.e. rows are in order of the low-level link indices (minus one if PxArticulationFlag::eFIX_BASE is true), see PxArticulationLink::getLinkIndex.
     * The corresponding spatial velocities are stacked [vx; vy; vz; wx; wy; wz], where vx and wx refer to the linear and rotational velocity in world X.
     * - The DOFs, i.e. column indices correspond to the low-level DOF indices, see PxArticulationCache::jointVelocity.
     */
    public void setDenseJacobian(PxRealPtr value) {
        checkNotNull();
        Raw.setDenseJacobian(address, value.getAddress());
    }

    /**
     * The generalized mass matrix used in inverse dynamics algorithms.
     * <p>
     * - N = (getDofs() + 6) * (getDofs() + 6) -&gt; size includes possible floating-base DOFs regardless of PxArticulationFlag::eFIX_BASE flag.
     * - If PxArticulationFlag::eFIX_BASE is true, the terms corresponding to the root DoFs are included in the top left block of the matrix.
     *   For these terms, column indices correspond to linear acceleration first then angular acceleration, row indices correspond to force first then torque.
     *   The bottom right block of the matrix corresponds to the joint DoFs terms, column indices correspond to joint acceleration, row indices correspond to joint force.
     * - If PxArticulationFlag::eFIX_BASE is false, only the terms corresponding to the joint DoFs are included, column indices correspond to joint acceleration,
     *   row indices correspond to joint force.
     * - The indexing follows the internal DOF index order, see PxArticulationCache::jointVelocity.
     * - The mass matrix is indexed [nCols * row + column].
     */
    public PxRealPtr getMassMatrix() {
        checkNotNull();
        return PxRealPtr.wrapPointer(Raw.getMassMatrix(address));
    }

    /**
     * The generalized mass matrix used in inverse dynamics algorithms.
     * <p>
     * - N = (getDofs() + 6) * (getDofs() + 6) -&gt; size includes possible floating-base DOFs regardless of PxArticulationFlag::eFIX_BASE flag.
     * - If PxArticulationFlag::eFIX_BASE is true, the terms corresponding to the root DoFs are included in the top left block of the matrix.
     *   For these terms, column indices correspond to linear acceleration first then angular acceleration, row indices correspond to force first then torque.
     *   The bottom right block of the matrix corresponds to the joint DoFs terms, column indices correspond to joint acceleration, row indices correspond to joint force.
     * - If PxArticulationFlag::eFIX_BASE is false, only the terms corresponding to the joint DoFs are included, column indices correspond to joint acceleration,
     *   row indices correspond to joint force.
     * - The indexing follows the internal DOF index order, see PxArticulationCache::jointVelocity.
     * - The mass matrix is indexed [nCols * row + column].
     */
    public void setMassMatrix(PxRealPtr value) {
        checkNotNull();
        Raw.setMassMatrix(address, value.getAddress());
    }

    /**
     * The articulation joint DOF velocities.
     * <p>
     * - N = getDofs().
     * - Read/write using PxArticulationCacheFlag::eVELOCITY.
     * - The indexing follows the internal DOF index order. Therefore, the application should calculate the DOF data indices by summing the joint DOFs in the order of
     * the links' low-level indices (see the manual Section "Cache Indexing" for a snippet for this calculation):
     * \verbatim Low-level link index:   | link 0 | link 1 | link 2 | link 3 | ... | &lt;- PxArticulationLink::getLinkIndex()       \endverbatim
     * \verbatim Link inbound joint DOF: | 0      | 1      | 2      | 1      | ... | &lt;- PxArticulationLink::getInboundJointDof() \endverbatim
     * \verbatim Low-level DOF index:    | -      | 0      | 1, 2   | 3      | ... |                                             \endverbatim
     * The root link always has low-level index 0 and always has zero inbound joint DOFs. The link DOF indexing follows the order in PxArticulationAxis::Enum.
     * For example, assume that low-level link 2 has an inbound spherical joint with two DOFs: eSWING1 and eSWING2. The corresponding low-level joint DOF indices
     * are therefore 1 for eSWING1 and 2 for eSWING2.
     */
    public PxRealPtr getJointVelocity() {
        checkNotNull();
        return PxRealPtr.wrapPointer(Raw.getJointVelocity(address));
    }

    /**
     * The articulation joint DOF velocities.
     * <p>
     * - N = getDofs().
     * - Read/write using PxArticulationCacheFlag::eVELOCITY.
     * - The indexing follows the internal DOF index order. Therefore, the application should calculate the DOF data indices by summing the joint DOFs in the order of
     * the links' low-level indices (see the manual Section "Cache Indexing" for a snippet for this calculation):
     * \verbatim Low-level link index:   | link 0 | link 1 | link 2 | link 3 | ... | &lt;- PxArticulationLink::getLinkIndex()       \endverbatim
     * \verbatim Link inbound joint DOF: | 0      | 1      | 2      | 1      | ... | &lt;- PxArticulationLink::getInboundJointDof() \endverbatim
     * \verbatim Low-level DOF index:    | -      | 0      | 1, 2   | 3      | ... |                                             \endverbatim
     * The root link always has low-level index 0 and always has zero inbound joint DOFs. The link DOF indexing follows the order in PxArticulationAxis::Enum.
     * For example, assume that low-level link 2 has an inbound spherical joint with two DOFs: eSWING1 and eSWING2. The corresponding low-level joint DOF indices
     * are therefore 1 for eSWING1 and 2 for eSWING2.
     */
    public void setJointVelocity(PxRealPtr value) {
        checkNotNull();
        Raw.setJointVelocity(address, value.getAddress());
    }

    /**
     * The articulation joint DOF accelerations.
     * <p>
     * - N = getDofs().
     * - Read using PxArticulationCacheFlag::eACCELERATION.
     * - The indexing follows the internal DOF index order, see PxArticulationCache::jointVelocity.
     * - Delta joint DOF velocities can be computed from acceleration * dt.
     */
    public PxRealPtr getJointAcceleration() {
        checkNotNull();
        return PxRealPtr.wrapPointer(Raw.getJointAcceleration(address));
    }

    /**
     * The articulation joint DOF accelerations.
     * <p>
     * - N = getDofs().
     * - Read using PxArticulationCacheFlag::eACCELERATION.
     * - The indexing follows the internal DOF index order, see PxArticulationCache::jointVelocity.
     * - Delta joint DOF velocities can be computed from acceleration * dt.
     */
    public void setJointAcceleration(PxRealPtr value) {
        checkNotNull();
        Raw.setJointAcceleration(address, value.getAddress());
    }

    /**
     * The articulation joint DOF positions.
     * <p>
     * - N = getDofs().
     * - Read/write using PxArticulationCacheFlag::ePOSITION.
     * - The indexing follows the internal DOF index order, see PxArticulationCache::jointVelocity.
     *       - For spherical joints, the joint position for each axis on the joint must be in range [-Pi, Pi].
     */
    public PxRealPtr getJointPosition() {
        checkNotNull();
        return PxRealPtr.wrapPointer(Raw.getJointPosition(address));
    }

    /**
     * The articulation joint DOF positions.
     * <p>
     * - N = getDofs().
     * - Read/write using PxArticulationCacheFlag::ePOSITION.
     * - The indexing follows the internal DOF index order, see PxArticulationCache::jointVelocity.
     *       - For spherical joints, the joint position for each axis on the joint must be in range [-Pi, Pi].
     */
    public void setJointPosition(PxRealPtr value) {
        checkNotNull();
        Raw.setJointPosition(address, value.getAddress());
    }

    /**
     * The articulation joint DOF forces.
     * <p>
     * - N = getDofs().
     * - Read/Write using PxArticulationCacheFlag::eFORCE.
     * - The indexing follows the internal DOF index order, see PxArticulationCache::jointVelocity.
     * - Applied joint forces persist and are applied each frame until changed.
     */
    public PxRealPtr getJointForce() {
        checkNotNull();
        return PxRealPtr.wrapPointer(Raw.getJointForce(address));
    }

    /**
     * The articulation joint DOF forces.
     * <p>
     * - N = getDofs().
     * - Read/Write using PxArticulationCacheFlag::eFORCE.
     * - The indexing follows the internal DOF index order, see PxArticulationCache::jointVelocity.
     * - Applied joint forces persist and are applied each frame until changed.
     */
    public void setJointForce(PxRealPtr value) {
        checkNotNull();
        Raw.setJointForce(address, value.getAddress());
    }

    /**
     * Link spatial velocity.
     * <p>
     * - N = getNbLinks().
     * - Read using PxArticulationCacheFlag::eLINK_VELOCITY.
     * - The indexing follows the internal link indexing, see PxArticulationLink::getLinkIndex.
     * - The velocity is with respect to the link's center of mass but represented in world space.
     */
    public PxSpatialVelocity getLinkVelocity() {
        checkNotNull();
        return PxSpatialVelocity.wrapPointer(Raw.getLinkVelocity(address));
    }

    /**
     * Link spatial velocity.
     * <p>
     * - N = getNbLinks().
     * - Read using PxArticulationCacheFlag::eLINK_VELOCITY.
     * - The indexing follows the internal link indexing, see PxArticulationLink::getLinkIndex.
     * - The velocity is with respect to the link's center of mass but represented in world space.
     */
    public void setLinkVelocity(PxSpatialVelocity value) {
        checkNotNull();
        Raw.setLinkVelocity(address, value.getAddress());
    }

    /**
     * Link classical acceleration.
     * <p>
     * - N = getNbLinks().
     * - Read using PxArticulationCacheFlag::eLINK_ACCELERATION.
     * - The indexing follows the internal link indexing, see PxArticulationLink::getLinkIndex.
     * - The acceleration is with respect to the link's center of mass.
     */
    public PxSpatialVelocity getLinkAcceleration() {
        checkNotNull();
        return PxSpatialVelocity.wrapPointer(Raw.getLinkAcceleration(address));
    }

    /**
     * Link classical acceleration.
     * <p>
     * - N = getNbLinks().
     * - Read using PxArticulationCacheFlag::eLINK_ACCELERATION.
     * - The indexing follows the internal link indexing, see PxArticulationLink::getLinkIndex.
     * - The acceleration is with respect to the link's center of mass.
     */
    public void setLinkAcceleration(PxSpatialVelocity value) {
        checkNotNull();
        Raw.setLinkAcceleration(address, value.getAddress());
    }

    /**
     * Link incoming joint force, i.e. the total force transmitted from the parent link to this link.
     * <p>
     * - N = getNbLinks().
     * - Read using PxArticulationCacheFlag::eLINK_INCOMING_JOINT_FORCE.
     * - The indexing follows the internal link indexing, see PxArticulationLink::getLinkIndex.
     * - The force is reported in the child joint frame of the link's incoming joint.
     * <p>
     * <b>Note:</b> The root link reports a zero spatial force.
     */
    public PxSpatialForce getLinkIncomingJointForce() {
        checkNotNull();
        return PxSpatialForce.wrapPointer(Raw.getLinkIncomingJointForce(address));
    }

    /**
     * Link incoming joint force, i.e. the total force transmitted from the parent link to this link.
     * <p>
     * - N = getNbLinks().
     * - Read using PxArticulationCacheFlag::eLINK_INCOMING_JOINT_FORCE.
     * - The indexing follows the internal link indexing, see PxArticulationLink::getLinkIndex.
     * - The force is reported in the child joint frame of the link's incoming joint.
     * <p>
     * <b>Note:</b> The root link reports a zero spatial force.
     */
    public void setLinkIncomingJointForce(PxSpatialForce value) {
        checkNotNull();
        Raw.setLinkIncomingJointForce(address, value.getAddress());
    }

    /**
     * Root link transform, velocities, and accelerations.
     * <p>
     * - N = 1.
     * - Read/write using PxArticulationCacheFlag::eROOT_TRANSFORM and PxArticulationCacheFlag::eROOT_VELOCITIES (accelerations are read-only).
     * @see PxArticulationRootLinkData
     */
    public PxArticulationRootLinkData getRootLinkData() {
        checkNotNull();
        return PxArticulationRootLinkData.wrapPointer(Raw.getRootLinkData(address));
    }

    /**
     * Root link transform, velocities, and accelerations.
     * <p>
     * - N = 1.
     * - Read/write using PxArticulationCacheFlag::eROOT_TRANSFORM and PxArticulationCacheFlag::eROOT_VELOCITIES (accelerations are read-only).
     * @see PxArticulationRootLinkData
     */
    public void setRootLinkData(PxArticulationRootLinkData value) {
        checkNotNull();
        Raw.setRootLinkData(address, value.getAddress());
    }

    /**
     * @deprecated  The API related to loop joints will be removed in a future version once a replacement is made available.
     * <p>
     * Constraint coefficient matrix.
     * <p>
     * - N = getCoefficentMatrixSize().
     * - The user needs to allocate memory and set this member to the allocated memory.
     */
    @Deprecated
    public PxRealPtr getCoefficientMatrix() {
        checkNotNull();
        return PxRealPtr.wrapPointer(Raw.getCoefficientMatrix(address));
    }

    /**
     * @deprecated  The API related to loop joints will be removed in a future version once a replacement is made available.
     * <p>
     * Constraint coefficient matrix.
     * <p>
     * - N = getCoefficentMatrixSize().
     * - The user needs to allocate memory and set this member to the allocated memory.
     */
    @Deprecated
    public void setCoefficientMatrix(PxRealPtr value) {
        checkNotNull();
        Raw.setCoefficientMatrix(address, value.getAddress());
    }

    /**
     * @deprecated  The API related to loop joints will be removed in a future version once a replacement is made available.
     * <p>
     * Constraint lambda values (impulses applied by the respective constraints).
     * <p>
     * - N = getNbLoopJoints().
     * - The user needs to allocate memory and set this member to the allocated memory.
     */
    @Deprecated
    public PxRealPtr getLambda() {
        checkNotNull();
        return PxRealPtr.wrapPointer(Raw.getLambda(address));
    }

    /**
     * @deprecated  The API related to loop joints will be removed in a future version once a replacement is made available.
     * <p>
     * Constraint lambda values (impulses applied by the respective constraints).
     * <p>
     * - N = getNbLoopJoints().
     * - The user needs to allocate memory and set this member to the allocated memory.
     */
    @Deprecated
    public void setLambda(PxRealPtr value) {
        checkNotNull();
        Raw.setLambda(address, value.getAddress());
    }

    /**
     * The scratch memory is used for internal calculations.
     */
    public NativeObject getScratchMemory() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.getScratchMemory(address));
    }

    /**
     * The scratch memory is used for internal calculations.
     */
    public void setScratchMemory(NativeObject value) {
        checkNotNull();
        Raw.setScratchMemory(address, value.getAddress());
    }

    /**
     * The scratch allocator is used for internal calculations.
     */
    public NativeObject getScratchAllocator() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.getScratchAllocator(address));
    }

    /**
     * The scratch allocator is used for internal calculations.
     */
    public void setScratchAllocator(NativeObject value) {
        checkNotNull();
        Raw.setScratchAllocator(address, value.getAddress());
    }

    /**
     * The cache version used internally to check compatibility with the articulation, i.e. detect if the articulation configuration changed after the cache was created.
     */
    public int getVersion() {
        checkNotNull();
        return Raw.getVersion(address);
    }

    /**
     * The cache version used internally to check compatibility with the articulation, i.e. detect if the articulation configuration changed after the cache was created.
     */
    public void setVersion(int value) {
        checkNotNull();
        Raw.setVersion(address, value);
    }

    // Functions

    /**
     * Releases an articulation cache.
     * <p>
     *   PxArticulationReducedCoordinate::copyInternalStateToCache
     */
    public void release() {
        checkNotNull();
        Raw.release(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getExternalForces(long address);
        public static native void setExternalForces(long address, long value);
        public static native long getDenseJacobian(long address);
        public static native void setDenseJacobian(long address, long value);
        public static native long getMassMatrix(long address);
        public static native void setMassMatrix(long address, long value);
        public static native long getJointVelocity(long address);
        public static native void setJointVelocity(long address, long value);
        public static native long getJointAcceleration(long address);
        public static native void setJointAcceleration(long address, long value);
        public static native long getJointPosition(long address);
        public static native void setJointPosition(long address, long value);
        public static native long getJointForce(long address);
        public static native void setJointForce(long address, long value);
        public static native long getLinkVelocity(long address);
        public static native void setLinkVelocity(long address, long value);
        public static native long getLinkAcceleration(long address);
        public static native void setLinkAcceleration(long address, long value);
        public static native long getLinkIncomingJointForce(long address);
        public static native void setLinkIncomingJointForce(long address, long value);
        public static native long getRootLinkData(long address);
        public static native void setRootLinkData(long address, long value);
        public static native long getCoefficientMatrix(long address);
        public static native void setCoefficientMatrix(long address, long value);
        public static native long getLambda(long address);
        public static native void setLambda(long address, long value);
        public static native long getScratchMemory(long address);
        public static native void setScratchMemory(long address, long value);
        public static native long getScratchAllocator(long address);
        public static native void setScratchAllocator(long address, long value);
        public static native int getVersion(long address);
        public static native void setVersion(long address, int value);
        public static native void release(long address);
    }
}
