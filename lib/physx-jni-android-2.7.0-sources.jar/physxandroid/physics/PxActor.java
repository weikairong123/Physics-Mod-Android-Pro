package physxandroid.physics;

import physxandroid.NativeObject;
import physxandroid.common.PxBase;
import physxandroid.common.PxBounds3;

/**
 * PxActor is the base class for the main simulation objects in the physics SDK.
 * <p>
 * The actor is owned by and contained in a PxScene.
 */
public class PxActor extends PxBase {

    protected PxActor() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxActor wrapPointer(long address) {
        return address != 0L ? new PxActor(address) : null;
    }
    
    public static PxActor arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxActor(long address) {
        super(address);
    }

    // Attributes

    /**
     * user can assign this to whatever, usually to create a 1:1 relationship with a user object.
     */
    public NativeObject getUserData() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.getUserData(address));
    }

    /**
     * user can assign this to whatever, usually to create a 1:1 relationship with a user object.
     */
    public void setUserData(NativeObject value) {
        checkNotNull();
        Raw.setUserData(address, value.getAddress());
    }

    // Functions

    /**
     * Retrieves the type of actor.
     * @return The actor type of the actor.
     */
    public PxActorTypeEnum getType() {
        checkNotNull();
        return PxActorTypeEnum.forValue(Raw.getType(address));
    }

    /**
     * Retrieves the scene which this actor belongs to.
     * @return Owner Scene. NULL if not part of a scene.
     * @see PxScene
     */
    public PxScene getScene() {
        checkNotNull();
        return PxScene.wrapPointer(Raw.getScene(address));
    }

    /**
     * Sets a name string for the object that can be retrieved with getName().
     * <p>
     * This is for debugging and is not used by the SDK. The string is not copied by the SDK, 
     * only the pointer is stored.
     * @param name String to set the objects name to.
     * <p>
     * <b>Default:</b> NULL
     * @see #getName
     */
    public void setName(String name) {
        checkNotNull();
        Raw.setName(address, name);
    }

    /**
     * Retrieves the name string set with setName().
     * @return Name string associated with object.
     * @see #setName
     */
    public String getName() {
        checkNotNull();
        return Raw.getName(address);
    }

    /**
     * Retrieves the axis aligned bounding box enclosing the actor.
     * <p>
     * <b>Note:</b> It is not allowed to use this method while the simulation is running (except during PxScene::collide(),
     * in PxContactModifyCallback or in contact report callbacks).
     * @return The actor's bounding box.
     * @see physxandroid.common.PxBounds3
     */
    public PxBounds3 getWorldBounds() {
        checkNotNull();
        return PxBounds3.wrapPointer(Raw.getWorldBounds(address));
    }

    /**
     * Retrieves the axis aligned bounding box enclosing the actor.
     * <p>
     * <b>Note:</b> It is not allowed to use this method while the simulation is running (except during PxScene::collide(),
     * in PxContactModifyCallback or in contact report callbacks).
     * @param inflation  Scale factor for computed world bounds. Box extents are multiplied by this value.
     * @return The actor's bounding box.
     * @see physxandroid.common.PxBounds3
     */
    public PxBounds3 getWorldBounds(float inflation) {
        checkNotNull();
        return PxBounds3.wrapPointer(Raw.getWorldBounds(address, inflation));
    }

    /**
     * Raises or clears a particular actor flag.
     * <p>
     * See the list of flags #PxActorFlag
     * <p>
     * <b>Sleeping:</b> Does <b>NOT</b> wake the actor up automatically.
     * @param flag  The PxActor flag to raise(set) or clear. See #PxActorFlag.
     * @param value The boolean value to assign to the flag.
     * @see #getActorFlags
     */
    public void setActorFlag(PxActorFlagEnum flag, boolean value) {
        checkNotNull();
        Raw.setActorFlag(address, flag.value, value);
    }

    /**
     * Sets the actor flags.
     * <p>
     * See the list of flags #PxActorFlag
     * @see #setActorFlag
     */
    public void setActorFlags(PxActorFlags flags) {
        checkNotNull();
        Raw.setActorFlags(address, flags.getAddress());
    }

    /**
     * Reads the PxActor flags.
     * <p>
     * See the list of flags #PxActorFlag
     * @return The values of the PxActor flags.
     * @see #setActorFlag
     */
    public PxActorFlags getActorFlags() {
        checkNotNull();
        return PxActorFlags.wrapPointer(Raw.getActorFlags(address));
    }

    /**
     * Assigns dynamic actors a dominance group identifier.
     * <p>
     * PxDominanceGroup is a 5 bit group identifier (legal range from 0 to 31).
     * <p>
     * The PxScene::setDominanceGroupPair() lets you set certain behaviors for pairs of dominance groups.
     * By default every dynamic actor is created in group 0.
     * <p>
     * <b>Default:</b> 0
     * <p>
     * <b>Sleeping:</b> Changing the dominance group does <b>NOT</b> wake the actor up automatically.
     * @param dominanceGroup The dominance group identifier. <b>Range:</b> [0..31]
     * @see #getDominanceGroup
     */
    public void setDominanceGroup(byte dominanceGroup) {
        checkNotNull();
        Raw.setDominanceGroup(address, dominanceGroup);
    }

    /**
     * Retrieves the value set with setDominanceGroup().
     * @return The dominance group of this actor.
     * @see #setDominanceGroup
     */
    public byte getDominanceGroup() {
        checkNotNull();
        return Raw.getDominanceGroup(address);
    }

    /**
     * Sets the owner client of an actor.
     * <p>
     * This cannot be done once the actor has been placed into a scene.
     * <p>
     * <b>Default:</b> PX_DEFAULT_CLIENT
     */
    public void setOwnerClient(byte inClient) {
        checkNotNull();
        Raw.setOwnerClient(address, inClient);
    }

    /**
     * Returns the owner client that was specified at creation time.
     * <p>
     * This value cannot be changed once the object is placed into the scene.
     */
    public byte getOwnerClient() {
        checkNotNull();
        return Raw.getOwnerClient(address);
    }

    public static class Raw {
        public static native long getUserData(long address);
        public static native void setUserData(long address, long value);
        public static native int getType(long address);
        public static native long getScene(long address);
        public static native void setName(long address, String name);
        public static native String getName(long address);
        public static native long getWorldBounds(long address);
        public static native long getWorldBounds(long address, float inflation);
        public static native void setActorFlag(long address, int flag, boolean value);
        public static native void setActorFlags(long address, long flags);
        public static native long getActorFlags(long address);
        public static native void setDominanceGroup(long address, byte dominanceGroup);
        public static native byte getDominanceGroup(long address);
        public static native void setOwnerClient(long address, byte inClient);
        public static native byte getOwnerClient(long address);
    }
}
