package physxandroid.physics;

/**
 * Scene query and geometry query behavior flags.
 * <p>
 * PxHitFlags are used for 3 different purposes:
 * <p>
 * 1) To request hit fields to be filled in by scene queries (such as hit position, normal, face index or UVs).
 * 2) Once query is completed, to indicate which fields are valid (note that a query may produce more valid fields than requested).
 * 3) To specify additional options for the narrow phase and mid-phase intersection routines.
 * <p>
 * All these flags apply to both scene queries and geometry queries (PxGeometryQuery).
 * <p>
 * <b>See also:</b> PxRaycastHit PxSweepHit PxOverlapHit PxScene.raycast PxScene.sweep PxScene.overlap PxGeometryQuery PxFindFaceIndex
 */
public enum PxHitFlagEnum {

    /**
     * "position" member of #PxQueryHit is valid
     */
    ePOSITION(getePOSITION()),
    /**
     * "normal" member of #PxQueryHit is valid
     */
    eNORMAL(geteNORMAL()),
    /**
     * "u" and "v" barycentric coordinates of #PxQueryHit are valid. Not applicable to sweep queries.
     */
    eUV(geteUV()),
    /**
     * Performance hint flag for sweeps when it is known upfront there's no initial overlap.
     */
    eASSUME_NO_INITIAL_OVERLAP(geteASSUME_NO_INITIAL_OVERLAP()),
    /**
     * Report any first hit. Used for geometries that contain more than one primitive. For meshes,
     */
    eANY_HIT(geteANY_HIT()),
    /**
     * Report all hits for meshes rather than just the first. Not applicable to sweep queries.
     */
    eMESH_MULTIPLE(geteMESH_MULTIPLE()),
    /**
     * Report hits with back faces of mesh triangles. Also report hits for raycast
     */
    eMESH_BOTH_SIDES(geteMESH_BOTH_SIDES()),
    /**
     * Use more accurate but slower narrow phase sweep tests.
     */
    ePRECISE_SWEEP(getePRECISE_SWEEP()),
    /**
     * Report the minimum translation depth, normal and contact point.
     */
    eMTD(geteMTD()),
    /**
     * "face index" member of #PxQueryHit is valid
     */
    eFACE_INDEX(geteFACE_INDEX()),
    eDEFAULT(geteDEFAULT()),
    /**
     * Only this subset of flags can be modified by pre-filter. Other modifications will be discarded. 
     */
    eMODIFIABLE_FLAGS(geteMODIFIABLE_FLAGS());
    public final int value;
    
    PxHitFlagEnum(int value) {
        this.value = value;
    }

    private static native int _getePOSITION();
    private static int getePOSITION() {
        de.fabmax.physxandroid.Loader.load();
        return _getePOSITION();
    }

    private static native int _geteNORMAL();
    private static int geteNORMAL() {
        de.fabmax.physxandroid.Loader.load();
        return _geteNORMAL();
    }

    private static native int _geteUV();
    private static int geteUV() {
        de.fabmax.physxandroid.Loader.load();
        return _geteUV();
    }

    private static native int _geteASSUME_NO_INITIAL_OVERLAP();
    private static int geteASSUME_NO_INITIAL_OVERLAP() {
        de.fabmax.physxandroid.Loader.load();
        return _geteASSUME_NO_INITIAL_OVERLAP();
    }

    private static native int _geteANY_HIT();
    private static int geteANY_HIT() {
        de.fabmax.physxandroid.Loader.load();
        return _geteANY_HIT();
    }

    private static native int _geteMESH_MULTIPLE();
    private static int geteMESH_MULTIPLE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteMESH_MULTIPLE();
    }

    private static native int _geteMESH_BOTH_SIDES();
    private static int geteMESH_BOTH_SIDES() {
        de.fabmax.physxandroid.Loader.load();
        return _geteMESH_BOTH_SIDES();
    }

    private static native int _getePRECISE_SWEEP();
    private static int getePRECISE_SWEEP() {
        de.fabmax.physxandroid.Loader.load();
        return _getePRECISE_SWEEP();
    }

    private static native int _geteMTD();
    private static int geteMTD() {
        de.fabmax.physxandroid.Loader.load();
        return _geteMTD();
    }

    private static native int _geteFACE_INDEX();
    private static int geteFACE_INDEX() {
        de.fabmax.physxandroid.Loader.load();
        return _geteFACE_INDEX();
    }

    private static native int _geteDEFAULT();
    private static int geteDEFAULT() {
        de.fabmax.physxandroid.Loader.load();
        return _geteDEFAULT();
    }

    private static native int _geteMODIFIABLE_FLAGS();
    private static int geteMODIFIABLE_FLAGS() {
        de.fabmax.physxandroid.Loader.load();
        return _geteMODIFIABLE_FLAGS();
    }

    private static final int LUT_SIZE = 256;
    private static final PxHitFlagEnum[] enumValues = values();
    private static final PxHitFlagEnum[] enumLut = new PxHitFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxHitFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxHitFlagEnum forValue(int value) {
        PxHitFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxHitFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxHitFlagEnum: " + value);
        }
        return enumValue;
    }
}
