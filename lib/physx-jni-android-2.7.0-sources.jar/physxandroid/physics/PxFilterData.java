package physxandroid.physics;

import physxandroid.NativeObject;

/**
 * PxFilterData is user-definable data which gets passed into the collision filtering shader and/or callback.
 * @see PxShape#setSimulationFilterData
 * @see PxShape#getSimulationFilterData
 * @see PxSimulationFilterShader
 */
public class PxFilterData extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxFilterData wrapPointer(long address) {
        return address != 0L ? new PxFilterData(address) : null;
    }
    
    public static PxFilterData arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxFilterData(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxFilterData
     */
    public static PxFilterData createAt(long address) {
        Raw.PxFilterData_placed(address);
        PxFilterData createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxFilterData
     */
    public static <T> PxFilterData createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxFilterData_placed(address);
        PxFilterData createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param w0      WebIDL type: unsigned long
     * @param w1      WebIDL type: unsigned long
     * @param w2      WebIDL type: unsigned long
     * @param w3      WebIDL type: unsigned long
     * @return Stack allocated object of PxFilterData
     */
    public static PxFilterData createAt(long address, int w0, int w1, int w2, int w3) {
        Raw.PxFilterData_placed(address, w0, w1, w2, w3);
        PxFilterData createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param w0        WebIDL type: unsigned long
     * @param w1        WebIDL type: unsigned long
     * @param w2        WebIDL type: unsigned long
     * @param w3        WebIDL type: unsigned long
     * @return Stack allocated object of PxFilterData
     */
    public static <T> PxFilterData createAt(T allocator, Allocator<T> allocate, int w0, int w1, int w2, int w3) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxFilterData_placed(address, w0, w1, w2, w3);
        PxFilterData createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * Default constructor.
     */
    public PxFilterData() {
        address = Raw.PxFilterData();
    }

    /**
     * Constructor to set filter data initially.
     */
    public PxFilterData(int w0, int w1, int w2, int w3) {
        address = Raw.PxFilterData(w0, w1, w2, w3);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     */
    public int getWord0() {
        checkNotNull();
        return Raw.getWord0(address);
    }

    /**
     */
    public void setWord0(int value) {
        checkNotNull();
        Raw.setWord0(address, value);
    }

    /**
     */
    public int getWord1() {
        checkNotNull();
        return Raw.getWord1(address);
    }

    /**
     */
    public void setWord1(int value) {
        checkNotNull();
        Raw.setWord1(address, value);
    }

    /**
     */
    public int getWord2() {
        checkNotNull();
        return Raw.getWord2(address);
    }

    /**
     */
    public void setWord2(int value) {
        checkNotNull();
        Raw.setWord2(address, value);
    }

    /**
     */
    public int getWord3() {
        checkNotNull();
        return Raw.getWord3(address);
    }

    /**
     */
    public void setWord3(int value) {
        checkNotNull();
        Raw.setWord3(address, value);
    }

    public static class Raw {
        public static native void PxFilterData_placed(long address);
        public static native void PxFilterData_placed(long address, int w0, int w1, int w2, int w3);
        public static native long PxFilterData();
        public static native long PxFilterData(int w0, int w1, int w2, int w3);
        public static native void destroy(long address);
        public static native int getWord0(long address);
        public static native void setWord0(long address, int value);
        public static native int getWord1(long address);
        public static native void setWord1(long address, int value);
        public static native int getWord2(long address);
        public static native void setWord2(long address, int value);
        public static native int getWord3(long address);
        public static native void setWord3(long address, int value);
    }
}
