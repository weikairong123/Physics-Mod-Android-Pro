package physxandroid.physics;

/**
 * Flag that configures articulation-state updates by PxArticulationReducedCoordinate::updateKinematic.
 */
public enum PxArticulationKinematicFlagEnum {

    /**
     * Raise after any changes to the articulation root or joint positions using non-cache API calls. Updates links' positions and velocities.
     */
    ePOSITION(getePOSITION()),
    eVELOCITY(geteVELOCITY());
    public final int value;
    
    PxArticulationKinematicFlagEnum(int value) {
        this.value = value;
    }

    private static native int _getePOSITION();
    private static int getePOSITION() {
        de.fabmax.physxandroid.Loader.load();
        return _getePOSITION();
    }

    private static native int _geteVELOCITY();
    private static int geteVELOCITY() {
        de.fabmax.physxandroid.Loader.load();
        return _geteVELOCITY();
    }

    private static final int LUT_SIZE = 256;
    private static final PxArticulationKinematicFlagEnum[] enumValues = values();
    private static final PxArticulationKinematicFlagEnum[] enumLut = new PxArticulationKinematicFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxArticulationKinematicFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxArticulationKinematicFlagEnum forValue(int value) {
        PxArticulationKinematicFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxArticulationKinematicFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxArticulationKinematicFlagEnum: " + value);
        }
        return enumValue;
    }
}
