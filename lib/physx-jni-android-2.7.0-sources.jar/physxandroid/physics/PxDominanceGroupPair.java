package physxandroid.physics;

import physxandroid.NativeObject;

/**
 * Expresses the dominance relationship of a contact.
 * For the time being only three settings are permitted:
 * <p>
 * (1, 1), (0, 1), and (1, 0).
 */
public class PxDominanceGroupPair extends NativeObject {

    protected PxDominanceGroupPair() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxDominanceGroupPair wrapPointer(long address) {
        return address != 0L ? new PxDominanceGroupPair(address) : null;
    }
    
    public static PxDominanceGroupPair arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxDominanceGroupPair(long address) {
        super(address);
    }

    // Constructors

    /**
     * @param a WebIDL type: octet
     * @param b WebIDL type: octet
     */
    public PxDominanceGroupPair(byte a, byte b) {
        address = Raw.PxDominanceGroupPair(a, b);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     */
    public byte getDominance0() {
        checkNotNull();
        return Raw.getDominance0(address);
    }

    /**
     */
    public void setDominance0(byte value) {
        checkNotNull();
        Raw.setDominance0(address, value);
    }

    /**
     */
    public byte getDominance1() {
        checkNotNull();
        return Raw.getDominance1(address);
    }

    /**
     */
    public void setDominance1(byte value) {
        checkNotNull();
        Raw.setDominance1(address, value);
    }

    public static class Raw {
        public static native long PxDominanceGroupPair(byte a, byte b);
        public static native void destroy(long address);
        public static native byte getDominance0(long address);
        public static native void setDominance0(long address, byte value);
        public static native byte getDominance1(long address);
        public static native void setDominance1(long address, byte value);
    }
}
