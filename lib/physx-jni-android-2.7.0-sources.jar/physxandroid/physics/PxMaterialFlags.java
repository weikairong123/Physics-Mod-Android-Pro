package physxandroid.physics;

import physxandroid.NativeObject;

public class PxMaterialFlags extends NativeObject {

    protected PxMaterialFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxMaterialFlags wrapPointer(long address) {
        return address != 0L ? new PxMaterialFlags(address) : null;
    }
    
    public static PxMaterialFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxMaterialFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: unsigned short
     * @return Stack allocated object of PxMaterialFlags
     */
    public static PxMaterialFlags createAt(long address, short flags) {
        Raw.PxMaterialFlags_placed(address, flags);
        PxMaterialFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: unsigned short
     * @return Stack allocated object of PxMaterialFlags
     */
    public static <T> PxMaterialFlags createAt(T allocator, Allocator<T> allocate, short flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxMaterialFlags_placed(address, flags);
        PxMaterialFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param flags WebIDL type: unsigned short
     */
    public PxMaterialFlags(short flags) {
        address = Raw.PxMaterialFlags(flags);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param flag WebIDL type: {@link PxMaterialFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxMaterialFlagEnum flag) {
        checkNotNull();
        return Raw.isSet(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxMaterialFlagEnum} [enum]
     */
    public void raise(PxMaterialFlagEnum flag) {
        checkNotNull();
        Raw.raise(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxMaterialFlagEnum} [enum]
     */
    public void clear(PxMaterialFlagEnum flag) {
        checkNotNull();
        Raw.clear(address, flag.value);
    }

    public static class Raw {
        public static native void PxMaterialFlags_placed(long address, short flags);
        public static native long PxMaterialFlags(short flags);
        public static native void destroy(long address);
        public static native boolean isSet(long address, int flag);
        public static native void raise(long address, int flag);
        public static native void clear(long address, int flag);
    }
}
