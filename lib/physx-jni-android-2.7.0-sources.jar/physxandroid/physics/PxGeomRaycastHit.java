package physxandroid.physics;


/**
 * Stores results of raycast queries.
 * <p>
 * ::PxHitFlag flags can be passed to raycast function, as an optimization, to cause the SDK to only compute specified members of this
 * structure.
 * <p>
 * Some members like barycentric coordinates are currently only computed for triangle meshes and height fields, but next versions
 * might provide them in other cases. The client code should check #flags to make sure returned values are valid.
 */
public class PxGeomRaycastHit extends PxLocationHit {

    protected PxGeomRaycastHit() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxGeomRaycastHit wrapPointer(long address) {
        return address != 0L ? new PxGeomRaycastHit(address) : null;
    }
    
    public static PxGeomRaycastHit arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxGeomRaycastHit(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: float
     */
    public float getU() {
        checkNotNull();
        return Raw.getU(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setU(float value) {
        checkNotNull();
        Raw.setU(address, value);
    }

    /**
     * barycentric coordinates of hit point, for triangle mesh and height field (flag: #PxHitFlag::eUV)
     */
    public float getV() {
        checkNotNull();
        return Raw.getV(address);
    }

    /**
     * barycentric coordinates of hit point, for triangle mesh and height field (flag: #PxHitFlag::eUV)
     */
    public void setV(float value) {
        checkNotNull();
        Raw.setV(address, value);
    }

    // Functions

    /**
     * @return WebIDL type: boolean
     */
    public boolean hadInitialOverlap() {
        checkNotNull();
        return Raw.hadInitialOverlap(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native float getU(long address);
        public static native void setU(long address, float value);
        public static native float getV(long address);
        public static native void setV(long address, float value);
        public static native boolean hadInitialOverlap(long address);
    }
}
