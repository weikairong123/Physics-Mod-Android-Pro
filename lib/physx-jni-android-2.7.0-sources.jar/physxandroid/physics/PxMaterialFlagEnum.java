package physxandroid.physics;

/**
 * Flags which control the behavior of a material.
 * <p>
 * <b>See also:</b> PxMaterial 
 */
public enum PxMaterialFlagEnum {

    /**
     * If this flag is set, friction computations are always skipped between shapes with this material and any other shape.
     */
    eDISABLE_FRICTION(geteDISABLE_FRICTION()),
    /**
     * Whether to use strong friction.
     * The difference between "normal" and "strong" friction is that the strong friction feature
     * remembers the "friction error" between simulation steps. The friction is a force trying to
     * hold objects in place (or slow them down) and this is handled in the solver. But since the
     * solver is only an approximation, the result of the friction calculation can include a small
     * "error" - e.g. a box resting on a slope should not move at all if the static friction is in
     * action, but could slowly glide down the slope because of a small friction error in each 
     * simulation step. The strong friction counter-acts this by remembering the small error and
     * taking it to account during the next simulation step.
     * <p>
     * However, in some cases the strong friction could cause problems, and this is why it is
     * possible to disable the strong friction feature by setting this flag. One example is
     * raycast vehicles that are sliding fast across the surface, but still need a precise
     * steering behavior. It may be a good idea to reenable the strong friction when objects
     * are coming to a rest, to prevent them from slowly creeping down inclines.
     * <p>
     * Note: This flag only has an effect if the PxMaterialFlag::eDISABLE_FRICTION bit is 0.
     */
    eDISABLE_STRONG_FRICTION(geteDISABLE_STRONG_FRICTION()),
    /**
     * If this flag is raised in combination with negative restitution, the computed spring-damper output will be interpreted as
     * acceleration instead of force targets, analog to acceleration spring constraints.
     * The flag has no effect for non-compliant contacts (i.e., if restitution is nonnegative).
     * In an interaction between a compliant-force and a compliant-acceleration body the latter will dominate.
     * <b>See also:</b> PxMaterial.setRestitution, PxMaterial.setDamping
     * <b>See also:</b> Px1DConstraintFlag.eACCELERATION_SPRING
     */
    eCOMPLIANT_ACCELERATION_SPRING(geteCOMPLIANT_ACCELERATION_SPRING());
    public final int value;
    
    PxMaterialFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteDISABLE_FRICTION();
    private static int geteDISABLE_FRICTION() {
        de.fabmax.physxandroid.Loader.load();
        return _geteDISABLE_FRICTION();
    }

    private static native int _geteDISABLE_STRONG_FRICTION();
    private static int geteDISABLE_STRONG_FRICTION() {
        de.fabmax.physxandroid.Loader.load();
        return _geteDISABLE_STRONG_FRICTION();
    }

    private static native int _geteCOMPLIANT_ACCELERATION_SPRING();
    private static int geteCOMPLIANT_ACCELERATION_SPRING() {
        de.fabmax.physxandroid.Loader.load();
        return _geteCOMPLIANT_ACCELERATION_SPRING();
    }

    private static final int LUT_SIZE = 256;
    private static final PxMaterialFlagEnum[] enumValues = values();
    private static final PxMaterialFlagEnum[] enumLut = new PxMaterialFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxMaterialFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxMaterialFlagEnum forValue(int value) {
        PxMaterialFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxMaterialFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxMaterialFlagEnum: " + value);
        }
        return enumValue;
    }
}
