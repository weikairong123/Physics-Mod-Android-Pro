package physxandroid.physics;

import physxandroid.NativeObject;

/**
 * Information &amp; stats structure for a region
 */
public class PxBroadPhaseRegionInfo extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxBroadPhaseRegionInfo wrapPointer(long address) {
        return address != 0L ? new PxBroadPhaseRegionInfo(address) : null;
    }
    
    public static PxBroadPhaseRegionInfo arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxBroadPhaseRegionInfo(long address) {
        super(address);
    }

    // Constructors

    public PxBroadPhaseRegionInfo() {
        address = Raw.PxBroadPhaseRegionInfo();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * User-provided region data
     */
    public PxBroadPhaseRegion getMRegion() {
        checkNotNull();
        return PxBroadPhaseRegion.wrapPointer(Raw.getMRegion(address));
    }

    /**
     * User-provided region data
     */
    public void setMRegion(PxBroadPhaseRegion value) {
        checkNotNull();
        Raw.setMRegion(address, value.getAddress());
    }

    /**
     * Number of static objects in the region
     */
    public int getMNbStaticObjects() {
        checkNotNull();
        return Raw.getMNbStaticObjects(address);
    }

    /**
     * Number of static objects in the region
     */
    public void setMNbStaticObjects(int value) {
        checkNotNull();
        Raw.setMNbStaticObjects(address, value);
    }

    /**
     * Number of dynamic objects in the region
     */
    public int getMNbDynamicObjects() {
        checkNotNull();
        return Raw.getMNbDynamicObjects(address);
    }

    /**
     * Number of dynamic objects in the region
     */
    public void setMNbDynamicObjects(int value) {
        checkNotNull();
        Raw.setMNbDynamicObjects(address, value);
    }

    /**
     * True if region is currently used, i.e. it has not been removed
     */
    public boolean getMActive() {
        checkNotNull();
        return Raw.getMActive(address);
    }

    /**
     * True if region is currently used, i.e. it has not been removed
     */
    public void setMActive(boolean value) {
        checkNotNull();
        Raw.setMActive(address, value);
    }

    /**
     * True if region overlaps other regions (regions that are just touching are not considering overlapping)
     */
    public boolean getMOverlap() {
        checkNotNull();
        return Raw.getMOverlap(address);
    }

    /**
     * True if region overlaps other regions (regions that are just touching are not considering overlapping)
     */
    public void setMOverlap(boolean value) {
        checkNotNull();
        Raw.setMOverlap(address, value);
    }

    public static class Raw {
        public static native long PxBroadPhaseRegionInfo();
        public static native void destroy(long address);
        public static native long getMRegion(long address);
        public static native void setMRegion(long address, long value);
        public static native int getMNbStaticObjects(long address);
        public static native void setMNbStaticObjects(long address, int value);
        public static native int getMNbDynamicObjects(long address);
        public static native void setMNbDynamicObjects(long address, int value);
        public static native boolean getMActive(long address);
        public static native void setMActive(long address, boolean value);
        public static native boolean getMOverlap(long address);
        public static native void setMOverlap(long address, boolean value);
    }
}
