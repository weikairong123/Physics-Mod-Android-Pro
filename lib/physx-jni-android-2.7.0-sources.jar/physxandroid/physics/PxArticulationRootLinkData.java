package physxandroid.physics;

import physxandroid.NativeObject;
import physxandroid.common.PxTransform;
import physxandroid.common.PxVec3;

/**
 * Data structure used to access the root link state and acceleration.
 * @see PxArticulationCache
 */
public class PxArticulationRootLinkData extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxArticulationRootLinkData wrapPointer(long address) {
        return address != 0L ? new PxArticulationRootLinkData(address) : null;
    }
    
    public static PxArticulationRootLinkData arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxArticulationRootLinkData(long address) {
        super(address);
    }

    // Constructors

    public PxArticulationRootLinkData() {
        address = Raw.PxArticulationRootLinkData();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Actor transform
     */
    public PxTransform getTransform() {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getTransform(address));
    }

    /**
     * Actor transform
     */
    public void setTransform(PxTransform value) {
        checkNotNull();
        Raw.setTransform(address, value.getAddress());
    }

    /**
     * Link linear velocity
     */
    public PxVec3 getWorldLinVel() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getWorldLinVel(address));
    }

    /**
     * Link linear velocity
     */
    public void setWorldLinVel(PxVec3 value) {
        checkNotNull();
        Raw.setWorldLinVel(address, value.getAddress());
    }

    /**
     * Link angular velocity
     */
    public PxVec3 getWorldAngVel() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getWorldAngVel(address));
    }

    /**
     * Link angular velocity
     */
    public void setWorldAngVel(PxVec3 value) {
        checkNotNull();
        Raw.setWorldAngVel(address, value.getAddress());
    }

    /**
     * Link classical linear acceleration
     */
    public PxVec3 getWorldLinAccel() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getWorldLinAccel(address));
    }

    /**
     * Link classical linear acceleration
     */
    public void setWorldLinAccel(PxVec3 value) {
        checkNotNull();
        Raw.setWorldLinAccel(address, value.getAddress());
    }

    /**
     * Link angular acceleration
     */
    public PxVec3 getWorldAngAccel() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getWorldAngAccel(address));
    }

    /**
     * Link angular acceleration
     */
    public void setWorldAngAccel(PxVec3 value) {
        checkNotNull();
        Raw.setWorldAngAccel(address, value.getAddress());
    }

    public static class Raw {
        public static native long PxArticulationRootLinkData();
        public static native void destroy(long address);
        public static native long getTransform(long address);
        public static native void setTransform(long address, long value);
        public static native long getWorldLinVel(long address);
        public static native void setWorldLinVel(long address, long value);
        public static native long getWorldAngVel(long address);
        public static native void setWorldAngVel(long address, long value);
        public static native long getWorldLinAccel(long address);
        public static native void setWorldLinAccel(long address, long value);
        public static native long getWorldAngAccel(long address);
        public static native void setWorldAngAccel(long address, long value);
    }
}
