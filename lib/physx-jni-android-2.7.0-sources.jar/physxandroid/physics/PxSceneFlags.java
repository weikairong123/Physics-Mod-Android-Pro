package physxandroid.physics;

import physxandroid.NativeObject;

public class PxSceneFlags extends NativeObject {

    protected PxSceneFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxSceneFlags wrapPointer(long address) {
        return address != 0L ? new PxSceneFlags(address) : null;
    }
    
    public static PxSceneFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxSceneFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: unsigned long
     * @return Stack allocated object of PxSceneFlags
     */
    public static PxSceneFlags createAt(long address, int flags) {
        Raw.PxSceneFlags_placed(address, flags);
        PxSceneFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: unsigned long
     * @return Stack allocated object of PxSceneFlags
     */
    public static <T> PxSceneFlags createAt(T allocator, Allocator<T> allocate, int flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxSceneFlags_placed(address, flags);
        PxSceneFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param flags WebIDL type: unsigned long
     */
    public PxSceneFlags(int flags) {
        address = Raw.PxSceneFlags(flags);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param flag WebIDL type: {@link PxSceneFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxSceneFlagEnum flag) {
        checkNotNull();
        return Raw.isSet(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxSceneFlagEnum} [enum]
     */
    public void raise(PxSceneFlagEnum flag) {
        checkNotNull();
        Raw.raise(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxSceneFlagEnum} [enum]
     */
    public void clear(PxSceneFlagEnum flag) {
        checkNotNull();
        Raw.clear(address, flag.value);
    }

    public static class Raw {
        public static native void PxSceneFlags_placed(long address, int flags);
        public static native long PxSceneFlags(int flags);
        public static native void destroy(long address);
        public static native boolean isSet(long address, int flag);
        public static native void raise(long address, int flag);
        public static native void clear(long address, int flag);
    }
}
