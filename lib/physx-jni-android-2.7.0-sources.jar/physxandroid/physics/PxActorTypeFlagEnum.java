package physxandroid.physics;

/**
 * Identifies each type of actor for retrieving actors from a scene.
 * <p>
 * <b>Note:</b> #PxArticulationLink objects are not supported. Use the #PxArticulationReducedCoordinate object to retrieve all its links.
 * <p>
 * <b>See also:</b> PxScene::getActors(), PxScene::getNbActors()
 */
public enum PxActorTypeFlagEnum {

    /**
     * A static rigid body
     * <b>See also:</b> PxRigidStatic
     */
    eRIGID_STATIC(geteRIGID_STATIC()),
    /**
     * A dynamic rigid body
     * <b>See also:</b> PxRigidDynamic
     */
    eRIGID_DYNAMIC(geteRIGID_DYNAMIC());
    public final int value;
    
    PxActorTypeFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteRIGID_STATIC();
    private static int geteRIGID_STATIC() {
        de.fabmax.physxandroid.Loader.load();
        return _geteRIGID_STATIC();
    }

    private static native int _geteRIGID_DYNAMIC();
    private static int geteRIGID_DYNAMIC() {
        de.fabmax.physxandroid.Loader.load();
        return _geteRIGID_DYNAMIC();
    }

    private static final int LUT_SIZE = 256;
    private static final PxActorTypeFlagEnum[] enumValues = values();
    private static final PxActorTypeFlagEnum[] enumLut = new PxActorTypeFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxActorTypeFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxActorTypeFlagEnum forValue(int value) {
        PxActorTypeFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxActorTypeFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxActorTypeFlagEnum: " + value);
        }
        return enumValue;
    }
}
