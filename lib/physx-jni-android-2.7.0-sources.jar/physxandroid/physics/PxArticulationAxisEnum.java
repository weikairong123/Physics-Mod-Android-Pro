package physxandroid.physics;

public enum PxArticulationAxisEnum {

    /**
     * Rotational about eX
     */
    eTWIST(geteTWIST()),
    /**
     * Rotational about eY
     */
    eSWING1(geteSWING1()),
    /**
     * Rotational about eZ
     */
    eSWING2(geteSWING2()),
    /**
     * Linear in eX
     */
    eX(geteX()),
    /**
     * Linear in eY
     */
    eY(geteY()),
    /**
     * Linear in eZ
     */
    eZ(geteZ());
    public final int value;
    
    PxArticulationAxisEnum(int value) {
        this.value = value;
    }

    private static native int _geteTWIST();
    private static int geteTWIST() {
        de.fabmax.physxandroid.Loader.load();
        return _geteTWIST();
    }

    private static native int _geteSWING1();
    private static int geteSWING1() {
        de.fabmax.physxandroid.Loader.load();
        return _geteSWING1();
    }

    private static native int _geteSWING2();
    private static int geteSWING2() {
        de.fabmax.physxandroid.Loader.load();
        return _geteSWING2();
    }

    private static native int _geteX();
    private static int geteX() {
        de.fabmax.physxandroid.Loader.load();
        return _geteX();
    }

    private static native int _geteY();
    private static int geteY() {
        de.fabmax.physxandroid.Loader.load();
        return _geteY();
    }

    private static native int _geteZ();
    private static int geteZ() {
        de.fabmax.physxandroid.Loader.load();
        return _geteZ();
    }

    private static final int LUT_SIZE = 256;
    private static final PxArticulationAxisEnum[] enumValues = values();
    private static final PxArticulationAxisEnum[] enumLut = new PxArticulationAxisEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxArticulationAxisEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxArticulationAxisEnum forValue(int value) {
        PxArticulationAxisEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxArticulationAxisEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxArticulationAxisEnum: " + value);
        }
        return enumValue;
    }
}
