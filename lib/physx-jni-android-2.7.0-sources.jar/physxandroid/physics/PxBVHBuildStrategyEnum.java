package physxandroid.physics;

/**
 * Desired build strategy for bounding-volume hierarchies
 */
public enum PxBVHBuildStrategyEnum {

    /**
     * Fast build strategy. Fast build speed, good runtime performance in most cases. Recommended for runtime cooking.
     */
    eFAST(geteFAST()),
    /**
     * Default build strategy. Medium build speed, good runtime performance in all cases.
     */
    eDEFAULT(geteDEFAULT()),
    /**
     * SAH build strategy. Slower builds, slightly improved runtime performance in some cases.
     */
    eSAH(geteSAH());
    public final int value;
    
    PxBVHBuildStrategyEnum(int value) {
        this.value = value;
    }

    private static native int _geteFAST();
    private static int geteFAST() {
        de.fabmax.physxandroid.Loader.load();
        return _geteFAST();
    }

    private static native int _geteDEFAULT();
    private static int geteDEFAULT() {
        de.fabmax.physxandroid.Loader.load();
        return _geteDEFAULT();
    }

    private static native int _geteSAH();
    private static int geteSAH() {
        de.fabmax.physxandroid.Loader.load();
        return _geteSAH();
    }

    private static final int LUT_SIZE = 256;
    private static final PxBVHBuildStrategyEnum[] enumValues = values();
    private static final PxBVHBuildStrategyEnum[] enumLut = new PxBVHBuildStrategyEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxBVHBuildStrategyEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxBVHBuildStrategyEnum forValue(int value) {
        PxBVHBuildStrategyEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxBVHBuildStrategyEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxBVHBuildStrategyEnum: " + value);
        }
        return enumValue;
    }
}
