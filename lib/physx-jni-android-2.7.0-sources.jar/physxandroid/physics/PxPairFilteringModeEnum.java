package physxandroid.physics;

public enum PxPairFilteringModeEnum {

    /**
     * Output pair from BP, potentially send to user callbacks, create regular interaction object.
     * <p>
     * Enable contact pair filtering between kinematic/static or kinematic/kinematic rigid bodies.
     * <p>
     * By default contacts between these are suppressed (see #PxFilterFlag::eSUPPRESS) and don't get reported to the filter mechanism.
     * Use this mode if these pairs should go through the filtering pipeline nonetheless.
     * <p>
     * <b>Note:</b> This mode is not mutable, and must be set in PxSceneDesc at scene creation.
     */
    eKEEP(geteKEEP()),
    /**
     * Output pair from BP, create interaction marker. Can be later switched to regular interaction.
     */
    eSUPPRESS(geteSUPPRESS()),
    /**
     * Don't output pair from BP. Cannot be later switched to regular interaction, needs "resetFiltering" call.
     */
    eKILL(geteKILL()),
    /**
     * Default is eSUPPRESS for compatibility with previous PhysX versions.
     */
    eDEFAULT(geteDEFAULT());
    public final int value;
    
    PxPairFilteringModeEnum(int value) {
        this.value = value;
    }

    private static native int _geteKEEP();
    private static int geteKEEP() {
        de.fabmax.physxandroid.Loader.load();
        return _geteKEEP();
    }

    private static native int _geteSUPPRESS();
    private static int geteSUPPRESS() {
        de.fabmax.physxandroid.Loader.load();
        return _geteSUPPRESS();
    }

    private static native int _geteKILL();
    private static int geteKILL() {
        de.fabmax.physxandroid.Loader.load();
        return _geteKILL();
    }

    private static native int _geteDEFAULT();
    private static int geteDEFAULT() {
        de.fabmax.physxandroid.Loader.load();
        return _geteDEFAULT();
    }

    private static final int LUT_SIZE = 256;
    private static final PxPairFilteringModeEnum[] enumValues = values();
    private static final PxPairFilteringModeEnum[] enumLut = new PxPairFilteringModeEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxPairFilteringModeEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxPairFilteringModeEnum forValue(int value) {
        PxPairFilteringModeEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxPairFilteringModeEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxPairFilteringModeEnum: " + value);
        }
        return enumValue;
    }
}
