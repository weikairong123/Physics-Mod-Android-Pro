package physxandroid.physics;

import physxandroid.NativeObject;

/**
 * Descriptor for a broken constraint.
 * <p>
 * An array of these structs gets passed to the PxSimulationEventCallback::onConstraintBreak() report.
 * @see PxConstraint
 */
public class PxConstraintInfo extends NativeObject {

    protected PxConstraintInfo() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxConstraintInfo wrapPointer(long address) {
        return address != 0L ? new PxConstraintInfo(address) : null;
    }
    
    public static PxConstraintInfo arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxConstraintInfo(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The broken constraint.
     */
    public PxConstraint getConstraint() {
        checkNotNull();
        return PxConstraint.wrapPointer(Raw.getConstraint(address));
    }

    /**
     * The broken constraint.
     */
    public void setConstraint(PxConstraint value) {
        checkNotNull();
        Raw.setConstraint(address, value.getAddress());
    }

    /**
     * The external object which owns the constraint (see #PxConstraintConnector::getExternalReference())
     */
    public NativeObject getExternalReference() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.getExternalReference(address));
    }

    /**
     * The external object which owns the constraint (see #PxConstraintConnector::getExternalReference())
     */
    public void setExternalReference(NativeObject value) {
        checkNotNull();
        Raw.setExternalReference(address, value.getAddress());
    }

    /**
     * Unique type ID of the external object. Allows to cast the provided external reference to the appropriate type
     */
    public int getType() {
        checkNotNull();
        return Raw.getType(address);
    }

    /**
     * Unique type ID of the external object. Allows to cast the provided external reference to the appropriate type
     */
    public void setType(int value) {
        checkNotNull();
        Raw.setType(address, value);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getConstraint(long address);
        public static native void setConstraint(long address, long value);
        public static native long getExternalReference(long address);
        public static native void setExternalReference(long address, long value);
        public static native int getType(long address);
        public static native void setType(long address, int value);
    }
}
