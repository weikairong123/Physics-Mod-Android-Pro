package physxandroid.physics;

import physxandroid.NativeObject;

public class PxContactPairHeaderFlags extends NativeObject {

    protected PxContactPairHeaderFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxContactPairHeaderFlags wrapPointer(long address) {
        return address != 0L ? new PxContactPairHeaderFlags(address) : null;
    }
    
    public static PxContactPairHeaderFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxContactPairHeaderFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: unsigned short
     * @return Stack allocated object of PxContactPairHeaderFlags
     */
    public static PxContactPairHeaderFlags createAt(long address, short flags) {
        Raw.PxContactPairHeaderFlags_placed(address, flags);
        PxContactPairHeaderFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: unsigned short
     * @return Stack allocated object of PxContactPairHeaderFlags
     */
    public static <T> PxContactPairHeaderFlags createAt(T allocator, Allocator<T> allocate, short flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxContactPairHeaderFlags_placed(address, flags);
        PxContactPairHeaderFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param flags WebIDL type: unsigned short
     */
    public PxContactPairHeaderFlags(short flags) {
        address = Raw.PxContactPairHeaderFlags(flags);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param flag WebIDL type: {@link PxContactPairHeaderFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxContactPairHeaderFlagEnum flag) {
        checkNotNull();
        return Raw.isSet(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxContactPairHeaderFlagEnum} [enum]
     */
    public void raise(PxContactPairHeaderFlagEnum flag) {
        checkNotNull();
        Raw.raise(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxContactPairHeaderFlagEnum} [enum]
     */
    public void clear(PxContactPairHeaderFlagEnum flag) {
        checkNotNull();
        Raw.clear(address, flag.value);
    }

    public static class Raw {
        public static native void PxContactPairHeaderFlags_placed(long address, short flags);
        public static native long PxContactPairHeaderFlags(short flags);
        public static native void destroy(long address);
        public static native boolean isSet(long address, int flag);
        public static native void raise(long address, int flag);
        public static native void clear(long address, int flag);
    }
}
