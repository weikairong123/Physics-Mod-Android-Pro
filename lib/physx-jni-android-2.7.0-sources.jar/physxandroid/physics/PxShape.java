package physxandroid.physics;

import physxandroid.NativeObject;
import physxandroid.common.PxRefCounted;
import physxandroid.common.PxTransform;
import physxandroid.geometry.PxGeometry;
import physxandroid.support.PxMaterialPtr;

/**
 * Abstract class for collision shapes.
 * <p>
 * Shapes are shared, reference counted objects.
 * <p>
 * An instance can be created by calling the createShape() method of the PxRigidActor class, or
 * the createShape() method of the PxPhysics class.
 * <p>
 * <h3>Visualizations</h3>
 * \li PxVisualizationParameter::eCOLLISION_AABBS
 * \li PxVisualizationParameter::eCOLLISION_SHAPES
 * \li PxVisualizationParameter::eCOLLISION_AXES
 * @see PxPhysics#createShape
 * @see physxandroid.geometry.PxBoxGeometry
 * @see physxandroid.geometry.PxSphereGeometry
 * @see physxandroid.geometry.PxCapsuleGeometry
 * @see physxandroid.geometry.PxPlaneGeometry
 * @see physxandroid.geometry.PxConvexMeshGeometry
 * PxTriangleMeshGeometry PxHeightFieldGeometry
 */
public class PxShape extends PxRefCounted {

    protected PxShape() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxShape wrapPointer(long address) {
        return address != 0L ? new PxShape(address) : null;
    }
    
    public static PxShape arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxShape(long address) {
        super(address);
    }

    // Attributes

    /**
     * *********************************************************************************************
     */
    public NativeObject getUserData() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.getUserData(address));
    }

    /**
     * *********************************************************************************************
     */
    public void setUserData(NativeObject value) {
        checkNotNull();
        Raw.setUserData(address, value.getAddress());
    }

    // Functions

    /**
     * Adjust the geometry of the shape.
     * <p>
     * <b>Note:</b> The type of the passed in geometry must match the geometry type of the shape.
     * <b>Note:</b> It is not allowed to change the geometry type of a shape.
     * <b>Note:</b> This function does not guarantee correct/continuous behavior when objects are resting on top of old or new geometry.
     * @param geometry New geometry of the shape.
     * @see physxandroid.geometry.PxGeometry
     */
    public void setGeometry(PxGeometry geometry) {
        checkNotNull();
        Raw.setGeometry(address, geometry.getAddress());
    }

    /**
     * Retrieve a reference to the shape's geometry.
     * <p>
     * \warning The returned reference has the same lifetime as the PxShape it comes from.
     * @return Reference to internal PxGeometry object.
     * @see physxandroid.geometry.PxGeometry
     * @see #setGeometry
     */
    public PxGeometry getGeometry() {
        checkNotNull();
        return PxGeometry.wrapPointer(Raw.getGeometry(address));
    }

    /**
     * Retrieves the actor which this shape is associated with.
     * @return The actor this shape is associated with, if it is an exclusive shape, else NULL
     * @see PxArticulationLink
     */
    public PxRigidActor getActor() {
        checkNotNull();
        return PxRigidActor.wrapPointer(Raw.getActor(address));
    }

    /**
     * Assigns material(s) to the shape. Will remove existing materials from the shape.
     * <p>
     * <b>Sleeping:</b> Does <b>NOT</b> wake the associated actor up automatically.
     * @param materials List of material pointers to assign to the shape. See #PxMaterial
     * @param materialCount The number of materials provided.
     * @see PxPhysics#createMaterial
     * @see #getMaterials
     */
    public void setMaterials(PxMaterialPtr materials, short materialCount) {
        checkNotNull();
        Raw.setMaterials(address, materials.getAddress(), materialCount);
    }

    /**
     * Returns the number of materials assigned to the shape.
     * <p>
     * You can use #getMaterials() to retrieve the material pointers.
     * @return Number of materials associated with this shape.
     * @see PxMaterial
     * @see #getMaterials
     */
    public short getNbMaterials() {
        checkNotNull();
        return Raw.getNbMaterials(address);
    }

    /**
     * Retrieve all the material pointers associated with the shape.
     * <p>
     * You can retrieve the number of material pointers by calling #getNbMaterials()
     * <p>
     * Note: The returned data may contain invalid pointers if you release materials using #PxMaterial::release().
     * @param userBuffer The buffer to store the material pointers.
     * @param bufferSize Size of provided user buffer.
     * @param startIndex Index of first material pointer to be retrieved
     * @return Number of material pointers written to the buffer.
     * @see PxMaterial
     * @see #getNbMaterials
     */
    public int getMaterials(PxMaterialPtr userBuffer, int bufferSize, int startIndex) {
        checkNotNull();
        return Raw.getMaterials(address, userBuffer.getAddress(), bufferSize, startIndex);
    }

    /**
     * Retrieve material from given triangle index.
     * <p>
     * The input index is the internal triangle index as used inside the SDK. This is the index
     * returned to users by various SDK functions such as raycasts.
     * <p>
     * This function is only useful for triangle meshes or heightfields, which have per-triangle
     * materials. For other shapes or SDF triangle meshes, the function returns the single material
     * associated with the shape, regardless of the index.
     * @param faceIndex The internal triangle index whose material you want to retrieve.
     * @return Material from input triangle
     * <p>
     * <b>Note:</b> If faceIndex value of 0xFFFFffff is passed as an input for mesh and heightfield shapes, this function will issue a warning and return NULL.
     * <b>Note:</b> Scene queries set the value of PxQueryHit::faceIndex to 0xFFFFffff whenever it is undefined or does not apply.
     * @see PxMaterial
     * @see #getNbMaterials
     */
    public PxBaseMaterial getMaterialFromInternalFaceIndex(int faceIndex) {
        checkNotNull();
        return PxBaseMaterial.wrapPointer(Raw.getMaterialFromInternalFaceIndex(address, faceIndex));
    }

    /**
     * Sets the contact offset.
     * <p>
     * Shapes whose distance is less than the sum of their contactOffset values will generate contacts. The contact offset must be positive and
     * greater than the rest offset. Having a contactOffset greater than than the restOffset allows the collision detection system to
     * predictively enforce the contact constraint even when the objects are slightly separated. This prevents jitter that would occur
     * if the constraint were enforced only when shapes were within the rest distance.
     * <p>
     * <b>Default:</b> 0.02f * PxTolerancesScale::length
     * <p>
     * <b>Sleeping:</b> Does <b>NOT</b> wake the associated actor up automatically.
     * @param contactOffset <b>Range:</b> [maximum(0,restOffset), PX_MAX_F32)
     * @see #getContactOffset
     * @see physxandroid.common.PxTolerancesScale
     * @see #setRestOffset
     */
    public void setContactOffset(float contactOffset) {
        checkNotNull();
        Raw.setContactOffset(address, contactOffset);
    }

    /**
     * Retrieves the contact offset. 
     * @return The contact offset of the shape.
     * @see #setContactOffset
     */
    public float getContactOffset() {
        checkNotNull();
        return Raw.getContactOffset(address);
    }

    /**
     * Sets the rest offset. 
     * <p>
     * Two shapes will come to rest at a distance equal to the sum of their restOffset values. If the restOffset is 0, they should converge to touching 
     * exactly.  Having a restOffset greater than zero is useful to have objects slide smoothly, so that they do not get hung up on irregularities of 
     * each others' surfaces.
     * <p>
     * <b>Default:</b> 0.0f
     * <p>
     * <b>Sleeping:</b> Does <b>NOT</b> wake the associated actor up automatically.
     * @param restOffset <b>Range:</b> (-PX_MAX_F32, contactOffset)
     * @see #getRestOffset
     * @see #setContactOffset
     */
    public void setRestOffset(float restOffset) {
        checkNotNull();
        Raw.setRestOffset(address, restOffset);
    }

    /**
     * Retrieves the rest offset. 
     * @return The rest offset of the shape.
     * @see #setRestOffset
     */
    public float getRestOffset() {
        checkNotNull();
        return Raw.getRestOffset(address);
    }

    /**
     * Sets torsional patch radius.
     * <p>
     * This defines the radius of the contact patch used to apply torsional friction. If the radius is 0 (and minTorsionalPatchRadius
     * is 0 too, see #setMinTorsionalPatchRadius), no torsional friction will be applied. If the radius is &gt; 0, some torsional friction
     * will be applied. This is proportional to the penetration depth so, if the shapes are separated or penetration is zero, no
     * torsional friction will be applied. It is used to approximate rotational friction introduced by the compression of contacting surfaces.
     * <p>
     * <b>Note:</b> Will only be active, if the friction patch has a single anchor point only. This is for example the case, if a contact patch
     *       has a single contact point.
     * <p>
     * <b>Note:</b> Only supported in combination with solver type PxSolverType::eTGS.
     * <p>
     * <b>Default:</b> 0.0
     * @param radius <b>Range:</b> [0, PX_MAX_F32)
     */
    public void setTorsionalPatchRadius(float radius) {
        checkNotNull();
        Raw.setTorsionalPatchRadius(address, radius);
    }

    /**
     * Gets torsional patch radius.
     * <p>
     * See #setTorsionalPatchRadius for more info.
     * @return The torsional patch radius of the shape.
     */
    public float getTorsionalPatchRadius() {
        checkNotNull();
        return Raw.getTorsionalPatchRadius(address);
    }

    /**
     * Sets minimum torsional patch radius.
     * <p>
     * This defines the minimum radius of the contact patch used to apply torsional friction. If the radius is 0, the amount of torsional friction
     * that will be applied will be entirely dependent on the value of torsionalPatchRadius. 
     * <p>
     * If the radius is &gt; 0, some torsional friction will be applied regardless of the value of torsionalPatchRadius or the amount of penetration.
     * <p>
     * <b>Note:</b> Will only be active in certain cases, see #setTorsionalPatchRadius for details.
     * <p>
     * <b>Default:</b> 0.0
     * @param radius <b>Range:</b> [0, PX_MAX_F32)
     */
    public void setMinTorsionalPatchRadius(float radius) {
        checkNotNull();
        Raw.setMinTorsionalPatchRadius(address, radius);
    }

    /**
     * Gets minimum torsional patch radius.
     * <p>
     * See #setMinTorsionalPatchRadius for more info.
     * @return The minimum torsional patch radius of the shape.
     */
    public float getMinTorsionalPatchRadius() {
        checkNotNull();
        return Raw.getMinTorsionalPatchRadius(address);
    }

    /**
     * Sets shape flags
     * <p>
     * <b>Sleeping:</b> Does <b>NOT</b> wake the associated actor up automatically.
     * @param flag The shape flag to enable/disable. See #PxShapeFlag.
     * @param value True to set the flag. False to clear the flag specified in flag.
     * <p>
     * <b>Default:</b> PxShapeFlag::eVISUALIZATION | PxShapeFlag::eSIMULATION_SHAPE | PxShapeFlag::eSCENE_QUERY_SHAPE
     * @see #getFlags
     */
    public void setFlag(PxShapeFlagEnum flag, boolean value) {
        checkNotNull();
        Raw.setFlag(address, flag.value, value);
    }

    /**
     * Sets shape flags
     * @see #getFlags
     */
    public void setFlags(PxShapeFlags inFlags) {
        checkNotNull();
        Raw.setFlags(address, inFlags.getAddress());
    }

    /**
     * Retrieves shape flags.
     * @return The values of the shape flags.
     * @see #setFlag
     */
    public PxShapeFlags getFlags() {
        checkNotNull();
        return PxShapeFlags.wrapPointer(Raw.getFlags(address));
    }

    /**
     * Returns true if the shape is exclusive to an actor.
     */
    public boolean isExclusive() {
        checkNotNull();
        return Raw.isExclusive(address);
    }

    /**
     * Sets a name string for the object that can be retrieved with #getName().
     * <p>
     * This is for debugging and is not used by the SDK.
     * The string is not copied by the SDK, only the pointer is stored.
     * <p>
     * <b>Default:</b> NULL
     * @param name The name string to set the objects name to.
     * @see #getName
     */
    public void setName(String name) {
        checkNotNull();
        Raw.setName(address, name);
    }

    /**
     * retrieves the name string set with setName().
     * @return The name associated with the shape.
     * @see #setName
     */
    public String getName() {
        checkNotNull();
        return Raw.getName(address);
    }

    /**
     * Sets the pose of the shape in actor space, i.e. relative to the actors to which they are attached.
     * <p>
     * This transformation is identity by default.
     * <p>
     * The local pose is an attribute of the shape, and so will apply to all actors to which the shape is attached.
     * <p>
     * <b>Sleeping:</b> Does <b>NOT</b> wake the associated actor up automatically.
     * <p>
     * <i>Note:</i> Does not automatically update the inertia properties of the owning actor (if applicable); use the
     * PhysX extensions method #PxRigidBodyExt::updateMassAndInertia() to do this.
     * <p>
     * <b>Default:</b> the identity transform
     * @param pose The new transform from the actor frame to the shape frame. <b>Range:</b> rigid body transform
     * @see #getLocalPose
     */
    public void setLocalPose(PxTransform pose) {
        checkNotNull();
        Raw.setLocalPose(address, pose.getAddress());
    }

    /**
     * Retrieves the pose of the shape in actor space, i.e. relative to the actor they are owned by.
     * <p>
     * This transformation is identity by default.
     * @return Pose of shape relative to the actor's frame.
     * @see #setLocalPose
     */
    public PxTransform getLocalPose() {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getLocalPose(address));
    }

    /**
     * Sets the user definable collision filter data.
     * <p>
     * <b>Sleeping:</b> Does wake up the actor if the filter data change causes a formerly suppressed
     * collision pair to be enabled.
     * <p>
     * <b>Default:</b> (0,0,0,0)
     * @see #getSimulationFilterData
     */
    public void setSimulationFilterData(PxFilterData data) {
        checkNotNull();
        Raw.setSimulationFilterData(address, data.getAddress());
    }

    /**
     * Retrieves the shape's collision filter data.
     * @see #setSimulationFilterData
     */
    public PxFilterData getSimulationFilterData() {
        checkNotNull();
        return PxFilterData.wrapPointer(Raw.getSimulationFilterData(address));
    }

    /**
     * Sets the user definable query filter data.
     * <p>
     * <b>Default:</b> (0,0,0,0)
     * @see #getQueryFilterData
     */
    public void setQueryFilterData(PxFilterData data) {
        checkNotNull();
        Raw.setQueryFilterData(address, data.getAddress());
    }

    /**
     * Retrieves the shape's Query filter data.
     * @see #setQueryFilterData
     */
    public PxFilterData getQueryFilterData() {
        checkNotNull();
        return PxFilterData.wrapPointer(Raw.getQueryFilterData(address));
    }

    public static class Raw {
        public static native long getUserData(long address);
        public static native void setUserData(long address, long value);
        public static native void setGeometry(long address, long geometry);
        public static native long getGeometry(long address);
        public static native long getActor(long address);
        public static native void setMaterials(long address, long materials, short materialCount);
        public static native short getNbMaterials(long address);
        public static native int getMaterials(long address, long userBuffer, int bufferSize, int startIndex);
        public static native long getMaterialFromInternalFaceIndex(long address, int faceIndex);
        public static native void setContactOffset(long address, float contactOffset);
        public static native float getContactOffset(long address);
        public static native void setRestOffset(long address, float restOffset);
        public static native float getRestOffset(long address);
        public static native void setTorsionalPatchRadius(long address, float radius);
        public static native float getTorsionalPatchRadius(long address);
        public static native void setMinTorsionalPatchRadius(long address, float radius);
        public static native float getMinTorsionalPatchRadius(long address);
        public static native void setFlag(long address, int flag, boolean value);
        public static native void setFlags(long address, long inFlags);
        public static native long getFlags(long address);
        public static native boolean isExclusive(long address);
        public static native void setName(long address, String name);
        public static native String getName(long address);
        public static native void setLocalPose(long address, long pose);
        public static native long getLocalPose(long address);
        public static native void setSimulationFilterData(long address, long data);
        public static native long getSimulationFilterData(long address);
        public static native void setQueryFilterData(long address, long data);
        public static native long getQueryFilterData(long address);
    }
}
