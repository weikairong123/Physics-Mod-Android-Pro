package physxandroid.physics;

import physxandroid.common.PxTransform;
import physxandroid.support.PxShapePtr;

/**
 * PxRigidActor represents a base class shared between dynamic and static rigid bodies in the physics SDK.
 * <p>
 * PxRigidActor objects specify the geometry of the object by defining a set of attached shapes (see #PxShape).
 * @see PxActor
 */
public class PxRigidActor extends PxActor {

    protected PxRigidActor() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxRigidActor wrapPointer(long address) {
        return address != 0L ? new PxRigidActor(address) : null;
    }
    
    public static PxRigidActor arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxRigidActor(long address) {
        super(address);
    }

    // Functions

    /**
     * Retrieves the actors world space transform.
     * <p>
     * The getGlobalPose() method retrieves the actor's current actor space to world space transformation.
     * <p>
     * <b>Note:</b> It is not allowed to use this method while the simulation is running (except during PxScene::collide(),
     * in PxContactModifyCallback or in contact report callbacks).
     * <p>
     * <b>Note:</b> If this actor is a PxRigidDynamic or PxArticulationLink, this method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * @return Global pose of object.
     */
    public PxTransform getGlobalPose() {
        checkNotNull();
        return PxTransform.wrapPointer(Raw.getGlobalPose(address));
    }

    /**
     * Method for setting an actor's pose in the world.
     * <p>
     * This method instantaneously changes the actor space to world space transformation.
     * <p>
     * This method is mainly for dynamic rigid bodies (see #PxRigidDynamic). Calling this method on static actors is
     * likely to result in a performance penalty, since internal optimization structures for static actors may need to be
     * recomputed. In addition, moving static actors will not interact correctly with dynamic actors or joints.
     * <p>
     * To directly control an actor's position and have it correctly interact with dynamic bodies and joints, create a dynamic
     * body with the PxRigidBodyFlag::eKINEMATIC flag, then use the setKinematicTarget() commands to define its path.
     * <p>
     * Even when moving dynamic actors, exercise restraint in making use of this method. Where possible, avoid:
     * <p>
     * \li moving actors into other actors, thus causing overlap (an invalid physical state)
     * <p>
     * \li moving an actor that is connected by a joint to another away from the other (thus causing joint error)
     * <p>
     * <b>Note:</b> It is not allowed to use this method if the actor is part of a #PxPruningStructure that has not been
     * added to a scene yet.
     * <p>
     * <b>Note:</b> If this actor is a PxRigidDynamic or PxArticulationLink, this method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * <p>
     * <b>Sleeping:</b> This call wakes dynamic actors if they are sleeping and the autowake parameter is true (default).
     * @param pose Transformation from the actors local frame to the global frame. <b>Range:</b> rigid body transform.
     * @see #getGlobalPose
     */
    public void setGlobalPose(PxTransform pose) {
        checkNotNull();
        Raw.setGlobalPose(address, pose.getAddress());
    }

    /**
     * Method for setting an actor's pose in the world.
     * <p>
     * This method instantaneously changes the actor space to world space transformation.
     * <p>
     * This method is mainly for dynamic rigid bodies (see #PxRigidDynamic). Calling this method on static actors is
     * likely to result in a performance penalty, since internal optimization structures for static actors may need to be
     * recomputed. In addition, moving static actors will not interact correctly with dynamic actors or joints.
     * <p>
     * To directly control an actor's position and have it correctly interact with dynamic bodies and joints, create a dynamic
     * body with the PxRigidBodyFlag::eKINEMATIC flag, then use the setKinematicTarget() commands to define its path.
     * <p>
     * Even when moving dynamic actors, exercise restraint in making use of this method. Where possible, avoid:
     * <p>
     * \li moving actors into other actors, thus causing overlap (an invalid physical state)
     * <p>
     * \li moving an actor that is connected by a joint to another away from the other (thus causing joint error)
     * <p>
     * <b>Note:</b> It is not allowed to use this method if the actor is part of a #PxPruningStructure that has not been
     * added to a scene yet.
     * <p>
     * <b>Note:</b> If this actor is a PxRigidDynamic or PxArticulationLink, this method should not be used after the direct GPU API has been enabled and initialized. See #PxDirectGPUAPI for the details.
     * <p>
     * <b>Sleeping:</b> This call wakes dynamic actors if they are sleeping and the autowake parameter is true (default).
     * @param pose Transformation from the actors local frame to the global frame. <b>Range:</b> rigid body transform.
     * @param autowake whether to wake the object if it is dynamic. This parameter has no effect for static or kinematic actors. If true and the current wake counter value is smaller than #PxSceneDesc::wakeCounterResetValue it will get increased to the reset value.
     * @see #getGlobalPose
     */
    public void setGlobalPose(PxTransform pose, boolean autowake) {
        checkNotNull();
        Raw.setGlobalPose(address, pose.getAddress(), autowake);
    }

    /**
     * Attach a shape to an actor 
     * <p>
     * This call will increment the reference count of the shape.
     * <p>
     * <b>Note:</b> Mass properties of dynamic rigid actors will not automatically be recomputed 
     * to reflect the new mass distribution implied by the shape. Follow this call with a call to 
     * the PhysX extensions method #PxRigidBodyExt::updateMassAndInertia() to do that.
     * <p>
     * Attaching a triangle mesh, heightfield or plane geometry shape configured as eSIMULATION_SHAPE is not supported for 
     * non-kinematic PxRigidDynamic instances.
     * <p>
     * <b>Sleeping:</b> Does <b>NOT</b> wake the actor up automatically.
     * @param shape the shape to attach.
     * @return True if success.
     */
    public boolean attachShape(PxShape shape) {
        checkNotNull();
        return Raw.attachShape(address, shape.getAddress());
    }

    /**
     * Detach a shape from an actor. 
     * <p>
     * This will also decrement the reference count of the PxShape, and if the reference count is zero, will cause it to be deleted.
     * <p>
     * <b>Sleeping:</b> Does <b>NOT</b> wake the actor up automatically.
     * @param shape the shape to detach.
     */
    public void detachShape(PxShape shape) {
        checkNotNull();
        Raw.detachShape(address, shape.getAddress());
    }

    /**
     * Detach a shape from an actor. 
     * <p>
     * This will also decrement the reference count of the PxShape, and if the reference count is zero, will cause it to be deleted.
     * <p>
     * <b>Sleeping:</b> Does <b>NOT</b> wake the actor up automatically.
     * @param shape the shape to detach.
     * @param wakeOnLostTouch Specifies whether touching objects from the previous frame should get woken up in the next frame. Only applies to PxArticulationReducedCoordinate and PxRigidActor types.
     */
    public void detachShape(PxShape shape, boolean wakeOnLostTouch) {
        checkNotNull();
        Raw.detachShape(address, shape.getAddress(), wakeOnLostTouch);
    }

    /**
     * Returns the number of shapes assigned to the actor.
     * <p>
     * You can use #getShapes() to retrieve the shape pointers.
     * @return Number of shapes associated with this actor.
     * @see PxShape
     * @see #getShapes
     */
    public int getNbShapes() {
        checkNotNull();
        return Raw.getNbShapes(address);
    }

    /**
     * Retrieve all the shape pointers belonging to the actor.
     * <p>
     * These are the shapes used by the actor for collision detection.
     * <p>
     * You can retrieve the number of shape pointers by calling #getNbShapes()
     * <p>
     * Note: Removing shapes with #PxShape::release() will invalidate the pointer of the released shape.
     * @param userBuffer The buffer to store the shape pointers.
     * @param bufferSize Size of provided user buffer.
     * @param startIndex Index of first shape pointer to be retrieved
     * @return Number of shape pointers written to the buffer.
     * @see PxShape
     * @see #getNbShapes
     */
    public int getShapes(PxShapePtr userBuffer, int bufferSize, int startIndex) {
        checkNotNull();
        return Raw.getShapes(address, userBuffer.getAddress(), bufferSize, startIndex);
    }

    /**
     * Returns the number of constraint shaders attached to the actor.
     * <p>
     * You can use #getConstraints() to retrieve the constraint shader pointers.
     * @return Number of constraint shaders attached to this actor.
     * @see PxConstraint
     */
    public int getNbConstraints() {
        checkNotNull();
        return Raw.getNbConstraints(address);
    }

    public static class Raw {
        public static native long getGlobalPose(long address);
        public static native void setGlobalPose(long address, long pose);
        public static native void setGlobalPose(long address, long pose, boolean autowake);
        public static native boolean attachShape(long address, long shape);
        public static native void detachShape(long address, long shape);
        public static native void detachShape(long address, long shape, boolean wakeOnLostTouch);
        public static native int getNbShapes(long address);
        public static native int getShapes(long address, long userBuffer, int bufferSize, int startIndex);
        public static native int getNbConstraints(long address);
    }
}
