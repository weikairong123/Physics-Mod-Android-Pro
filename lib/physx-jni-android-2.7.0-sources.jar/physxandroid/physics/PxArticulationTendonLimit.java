package physxandroid.physics;

import physxandroid.NativeObject;

/**
 * Defines the low/high limits of the length of a tendon.
 */
public class PxArticulationTendonLimit extends NativeObject {

    protected PxArticulationTendonLimit() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxArticulationTendonLimit wrapPointer(long address) {
        return address != 0L ? new PxArticulationTendonLimit(address) : null;
    }
    
    public static PxArticulationTendonLimit arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxArticulationTendonLimit(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     */
    public float getLowLimit() {
        checkNotNull();
        return Raw.getLowLimit(address);
    }

    /**
     */
    public void setLowLimit(float value) {
        checkNotNull();
        Raw.setLowLimit(address, value);
    }

    /**
     */
    public float getHighLimit() {
        checkNotNull();
        return Raw.getHighLimit(address);
    }

    /**
     */
    public void setHighLimit(float value) {
        checkNotNull();
        Raw.setHighLimit(address, value);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native float getLowLimit(long address);
        public static native void setLowLimit(long address, float value);
        public static native float getHighLimit(long address);
        public static native void setHighLimit(long address, float value);
    }
}
