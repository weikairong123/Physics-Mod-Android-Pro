package physxandroid.physics;

public enum PxArticulationJointTypeEnum {

    /**
     * All joint axes, i.e. degrees of freedom (DOFs) locked
     */
    eFIX(geteFIX()),
    /**
     * Single linear DOF, e.g. cart on a rail
     */
    ePRISMATIC(getePRISMATIC()),
    /**
     * Single rotational DOF, e.g. an elbow joint or a rotational motor, position wrapped at 2pi radians
     */
    eREVOLUTE(geteREVOLUTE()),
    /**
     * Ball and socket joint with two or three DOFs
     */
    eSPHERICAL(geteSPHERICAL()),
    eUNDEFINED(geteUNDEFINED());
    public final int value;
    
    PxArticulationJointTypeEnum(int value) {
        this.value = value;
    }

    private static native int _geteFIX();
    private static int geteFIX() {
        de.fabmax.physxandroid.Loader.load();
        return _geteFIX();
    }

    private static native int _getePRISMATIC();
    private static int getePRISMATIC() {
        de.fabmax.physxandroid.Loader.load();
        return _getePRISMATIC();
    }

    private static native int _geteREVOLUTE();
    private static int geteREVOLUTE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteREVOLUTE();
    }

    private static native int _geteSPHERICAL();
    private static int geteSPHERICAL() {
        de.fabmax.physxandroid.Loader.load();
        return _geteSPHERICAL();
    }

    private static native int _geteUNDEFINED();
    private static int geteUNDEFINED() {
        de.fabmax.physxandroid.Loader.load();
        return _geteUNDEFINED();
    }

    private static final int LUT_SIZE = 256;
    private static final PxArticulationJointTypeEnum[] enumValues = values();
    private static final PxArticulationJointTypeEnum[] enumLut = new PxArticulationJointTypeEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxArticulationJointTypeEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxArticulationJointTypeEnum forValue(int value) {
        PxArticulationJointTypeEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxArticulationJointTypeEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxArticulationJointTypeEnum: " + value);
        }
        return enumValue;
    }
}
