package physxandroid.physics;

import physxandroid.NativeObject;

/**
 * Class used to retrieve statistics for a simulation step.
 */
public class PxSimulationStatistics extends NativeObject {

    protected PxSimulationStatistics() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxSimulationStatistics wrapPointer(long address) {
        return address != 0L ? new PxSimulationStatistics(address) : null;
    }
    
    public static PxSimulationStatistics arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxSimulationStatistics(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Number of active PxConstraint objects (joints etc.) for the current simulation step.
     */
    public int getNbActiveConstraints() {
        checkNotNull();
        return Raw.getNbActiveConstraints(address);
    }

    /**
     * Number of active PxConstraint objects (joints etc.) for the current simulation step.
     */
    public void setNbActiveConstraints(int value) {
        checkNotNull();
        Raw.setNbActiveConstraints(address, value);
    }

    /**
     * Number of active dynamic bodies for the current simulation step.
     * <p>
     * <b>Note:</b> Does not include active kinematic bodies
     */
    public int getNbActiveDynamicBodies() {
        checkNotNull();
        return Raw.getNbActiveDynamicBodies(address);
    }

    /**
     * Number of active dynamic bodies for the current simulation step.
     * <p>
     * <b>Note:</b> Does not include active kinematic bodies
     */
    public void setNbActiveDynamicBodies(int value) {
        checkNotNull();
        Raw.setNbActiveDynamicBodies(address, value);
    }

    /**
     * Number of active kinematic bodies for the current simulation step.
     * <p>
     * <b>Note:</b> Kinematic deactivation occurs at the end of the frame after the last call to PxRigidDynamic::setKinematicTarget() was called so kinematics that are
     * deactivated in a given frame will be included by this counter.
     */
    public int getNbActiveKinematicBodies() {
        checkNotNull();
        return Raw.getNbActiveKinematicBodies(address);
    }

    /**
     * Number of active kinematic bodies for the current simulation step.
     * <p>
     * <b>Note:</b> Kinematic deactivation occurs at the end of the frame after the last call to PxRigidDynamic::setKinematicTarget() was called so kinematics that are
     * deactivated in a given frame will be included by this counter.
     */
    public void setNbActiveKinematicBodies(int value) {
        checkNotNull();
        Raw.setNbActiveKinematicBodies(address, value);
    }

    /**
     * Number of static bodies for the current simulation step.
     */
    public int getNbStaticBodies() {
        checkNotNull();
        return Raw.getNbStaticBodies(address);
    }

    /**
     * Number of static bodies for the current simulation step.
     */
    public void setNbStaticBodies(int value) {
        checkNotNull();
        Raw.setNbStaticBodies(address, value);
    }

    /**
     * Number of dynamic bodies for the current simulation step.
     * <p>
     * <b>Note:</b> Includes inactive bodies and articulation links
     * <b>Note:</b> Does not include kinematic bodies
     */
    public int getNbDynamicBodies() {
        checkNotNull();
        return Raw.getNbDynamicBodies(address);
    }

    /**
     * Number of dynamic bodies for the current simulation step.
     * <p>
     * <b>Note:</b> Includes inactive bodies and articulation links
     * <b>Note:</b> Does not include kinematic bodies
     */
    public void setNbDynamicBodies(int value) {
        checkNotNull();
        Raw.setNbDynamicBodies(address, value);
    }

    /**
     * Number of kinematic bodies for the current simulation step.
     * <p>
     * <b>Note:</b> Includes inactive bodies
     */
    public int getNbKinematicBodies() {
        checkNotNull();
        return Raw.getNbKinematicBodies(address);
    }

    /**
     * Number of kinematic bodies for the current simulation step.
     * <p>
     * <b>Note:</b> Includes inactive bodies
     */
    public void setNbKinematicBodies(int value) {
        checkNotNull();
        Raw.setNbKinematicBodies(address, value);
    }

    /**
     * @param index Array index
     * @return WebIDL type: unsigned long
     */
    public int getNbShapes(int index) {
        checkNotNull();
        return Raw.getNbShapes(address, index);
    }

    /**
     * @param index Array index
     * @param value WebIDL type: unsigned long
     */
    public void setNbShapes(int index, int value) {
        checkNotNull();
        Raw.setNbShapes(address, index, value);
    }

    /**
     * Number of aggregates in the scene.
     */
    public int getNbAggregates() {
        checkNotNull();
        return Raw.getNbAggregates(address);
    }

    /**
     * Number of aggregates in the scene.
     */
    public void setNbAggregates(int value) {
        checkNotNull();
        Raw.setNbAggregates(address, value);
    }

    /**
     * Number of articulations in the scene.
     */
    public int getNbArticulations() {
        checkNotNull();
        return Raw.getNbArticulations(address);
    }

    /**
     * Number of articulations in the scene.
     */
    public void setNbArticulations(int value) {
        checkNotNull();
        Raw.setNbArticulations(address, value);
    }

    /**
     * The number of 1D axis constraints(joints+contact) present in the current simulation step.
     */
    public int getNbAxisSolverConstraints() {
        checkNotNull();
        return Raw.getNbAxisSolverConstraints(address);
    }

    /**
     * The number of 1D axis constraints(joints+contact) present in the current simulation step.
     */
    public void setNbAxisSolverConstraints(int value) {
        checkNotNull();
        Raw.setNbAxisSolverConstraints(address, value);
    }

    /**
     * The size (in bytes) of the compressed contact stream in the current simulation step
     */
    public int getCompressedContactSize() {
        checkNotNull();
        return Raw.getCompressedContactSize(address);
    }

    /**
     * The size (in bytes) of the compressed contact stream in the current simulation step
     */
    public void setCompressedContactSize(int value) {
        checkNotNull();
        Raw.setCompressedContactSize(address, value);
    }

    /**
     * The total required size (in bytes) of the contact constraints in the current simulation step
     */
    public int getRequiredContactConstraintMemory() {
        checkNotNull();
        return Raw.getRequiredContactConstraintMemory(address);
    }

    /**
     * The total required size (in bytes) of the contact constraints in the current simulation step
     */
    public void setRequiredContactConstraintMemory(int value) {
        checkNotNull();
        Raw.setRequiredContactConstraintMemory(address, value);
    }

    /**
     * The peak amount of memory (in bytes) that was allocated for constraints (this includes joints) in the current simulation step
     */
    public int getPeakConstraintMemory() {
        checkNotNull();
        return Raw.getPeakConstraintMemory(address);
    }

    /**
     * The peak amount of memory (in bytes) that was allocated for constraints (this includes joints) in the current simulation step
     */
    public void setPeakConstraintMemory(int value) {
        checkNotNull();
        Raw.setPeakConstraintMemory(address, value);
    }

    /**
     * Total number of (non CCD) pairs reaching narrow phase
     */
    public int getNbDiscreteContactPairsTotal() {
        checkNotNull();
        return Raw.getNbDiscreteContactPairsTotal(address);
    }

    /**
     * Total number of (non CCD) pairs reaching narrow phase
     */
    public void setNbDiscreteContactPairsTotal(int value) {
        checkNotNull();
        Raw.setNbDiscreteContactPairsTotal(address, value);
    }

    /**
     * Total number of (non CCD) pairs for which contacts are successfully cached (&lt;=nbDiscreteContactPairsTotal)
     * <b>Note:</b> This includes pairs for which no contacts are generated, it still counts as a cache hit.
     */
    public int getNbDiscreteContactPairsWithCacheHits() {
        checkNotNull();
        return Raw.getNbDiscreteContactPairsWithCacheHits(address);
    }

    /**
     * Total number of (non CCD) pairs for which contacts are successfully cached (&lt;=nbDiscreteContactPairsTotal)
     * <b>Note:</b> This includes pairs for which no contacts are generated, it still counts as a cache hit.
     */
    public void setNbDiscreteContactPairsWithCacheHits(int value) {
        checkNotNull();
        Raw.setNbDiscreteContactPairsWithCacheHits(address, value);
    }

    /**
     * Total number of (non CCD) pairs for which at least 1 contact was generated (&lt;=nbDiscreteContactPairsTotal)
     */
    public int getNbDiscreteContactPairsWithContacts() {
        checkNotNull();
        return Raw.getNbDiscreteContactPairsWithContacts(address);
    }

    /**
     * Total number of (non CCD) pairs for which at least 1 contact was generated (&lt;=nbDiscreteContactPairsTotal)
     */
    public void setNbDiscreteContactPairsWithContacts(int value) {
        checkNotNull();
        Raw.setNbDiscreteContactPairsWithContacts(address, value);
    }

    /**
     * Number of new pairs found by BP this frame
     */
    public int getNbNewPairs() {
        checkNotNull();
        return Raw.getNbNewPairs(address);
    }

    /**
     * Number of new pairs found by BP this frame
     */
    public void setNbNewPairs(int value) {
        checkNotNull();
        Raw.setNbNewPairs(address, value);
    }

    /**
     * Number of lost pairs from BP this frame
     */
    public int getNbLostPairs() {
        checkNotNull();
        return Raw.getNbLostPairs(address);
    }

    /**
     * Number of lost pairs from BP this frame
     */
    public void setNbLostPairs(int value) {
        checkNotNull();
        Raw.setNbLostPairs(address, value);
    }

    /**
     * Number of new touches found by NP this frame
     */
    public int getNbNewTouches() {
        checkNotNull();
        return Raw.getNbNewTouches(address);
    }

    /**
     * Number of new touches found by NP this frame
     */
    public void setNbNewTouches(int value) {
        checkNotNull();
        Raw.setNbNewTouches(address, value);
    }

    /**
     * Number of lost touches from NP this frame
     */
    public int getNbLostTouches() {
        checkNotNull();
        return Raw.getNbLostTouches(address);
    }

    /**
     * Number of lost touches from NP this frame
     */
    public void setNbLostTouches(int value) {
        checkNotNull();
        Raw.setNbLostTouches(address, value);
    }

    /**
     * Number of partitions used by the solver this frame
     */
    public int getNbPartitions() {
        checkNotNull();
        return Raw.getNbPartitions(address);
    }

    /**
     * Number of partitions used by the solver this frame
     */
    public void setNbPartitions(int value) {
        checkNotNull();
        Raw.setNbPartitions(address, value);
    }

    /**
     */
    public int getNbBroadPhaseAdds() {
        checkNotNull();
        return Raw.getNbBroadPhaseAdds(address);
    }

    /**
     */
    public void setNbBroadPhaseAdds(int value) {
        checkNotNull();
        Raw.setNbBroadPhaseAdds(address, value);
    }

    /**
     */
    public int getNbBroadPhaseRemoves() {
        checkNotNull();
        return Raw.getNbBroadPhaseRemoves(address);
    }

    /**
     */
    public void setNbBroadPhaseRemoves(int value) {
        checkNotNull();
        Raw.setNbBroadPhaseRemoves(address, value);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native int getNbActiveConstraints(long address);
        public static native void setNbActiveConstraints(long address, int value);
        public static native int getNbActiveDynamicBodies(long address);
        public static native void setNbActiveDynamicBodies(long address, int value);
        public static native int getNbActiveKinematicBodies(long address);
        public static native void setNbActiveKinematicBodies(long address, int value);
        public static native int getNbStaticBodies(long address);
        public static native void setNbStaticBodies(long address, int value);
        public static native int getNbDynamicBodies(long address);
        public static native void setNbDynamicBodies(long address, int value);
        public static native int getNbKinematicBodies(long address);
        public static native void setNbKinematicBodies(long address, int value);
        public static native int getNbShapes(long address, int index);
        public static native void setNbShapes(long address, int index, int value);
        public static native int getNbAggregates(long address);
        public static native void setNbAggregates(long address, int value);
        public static native int getNbArticulations(long address);
        public static native void setNbArticulations(long address, int value);
        public static native int getNbAxisSolverConstraints(long address);
        public static native void setNbAxisSolverConstraints(long address, int value);
        public static native int getCompressedContactSize(long address);
        public static native void setCompressedContactSize(long address, int value);
        public static native int getRequiredContactConstraintMemory(long address);
        public static native void setRequiredContactConstraintMemory(long address, int value);
        public static native int getPeakConstraintMemory(long address);
        public static native void setPeakConstraintMemory(long address, int value);
        public static native int getNbDiscreteContactPairsTotal(long address);
        public static native void setNbDiscreteContactPairsTotal(long address, int value);
        public static native int getNbDiscreteContactPairsWithCacheHits(long address);
        public static native void setNbDiscreteContactPairsWithCacheHits(long address, int value);
        public static native int getNbDiscreteContactPairsWithContacts(long address);
        public static native void setNbDiscreteContactPairsWithContacts(long address, int value);
        public static native int getNbNewPairs(long address);
        public static native void setNbNewPairs(long address, int value);
        public static native int getNbLostPairs(long address);
        public static native void setNbLostPairs(long address, int value);
        public static native int getNbNewTouches(long address);
        public static native void setNbNewTouches(long address, int value);
        public static native int getNbLostTouches(long address);
        public static native void setNbLostTouches(long address, int value);
        public static native int getNbPartitions(long address);
        public static native void setNbPartitions(long address, int value);
        public static native int getNbBroadPhaseAdds(long address);
        public static native void setNbBroadPhaseAdds(long address, int value);
        public static native int getNbBroadPhaseRemoves(long address);
        public static native void setNbBroadPhaseRemoves(long address, int value);
    }
}
