package physxandroid.physics;

/**
 * Collection of flags providing information on trigger report pairs.
 * <p>
 * <b>See also:</b> PxTriggerPair
 */
public enum PxTriggerPairFlagEnum {

    /**
     * The trigger shape has been removed from the actor/scene.
     */
    eREMOVED_SHAPE_TRIGGER(geteREMOVED_SHAPE_TRIGGER()),
    /**
     * The shape causing the trigger event has been removed from the actor/scene.
     */
    eREMOVED_SHAPE_OTHER(geteREMOVED_SHAPE_OTHER()),
    eNEXT_FREE(geteNEXT_FREE());
    public final int value;
    
    PxTriggerPairFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteREMOVED_SHAPE_TRIGGER();
    private static int geteREMOVED_SHAPE_TRIGGER() {
        de.fabmax.physxandroid.Loader.load();
        return _geteREMOVED_SHAPE_TRIGGER();
    }

    private static native int _geteREMOVED_SHAPE_OTHER();
    private static int geteREMOVED_SHAPE_OTHER() {
        de.fabmax.physxandroid.Loader.load();
        return _geteREMOVED_SHAPE_OTHER();
    }

    private static native int _geteNEXT_FREE();
    private static int geteNEXT_FREE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteNEXT_FREE();
    }

    private static final int LUT_SIZE = 256;
    private static final PxTriggerPairFlagEnum[] enumValues = values();
    private static final PxTriggerPairFlagEnum[] enumLut = new PxTriggerPairFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxTriggerPairFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxTriggerPairFlagEnum forValue(int value) {
        PxTriggerPairFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxTriggerPairFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxTriggerPairFlagEnum: " + value);
        }
        return enumValue;
    }
}
