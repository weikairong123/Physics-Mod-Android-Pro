package physxandroid.physics;

import physxandroid.NativeObject;
import physxandroid.common.PxBase;
import physxandroid.common.PxVec3;

/**
 * This class connects a custom constraint to the SDK
 * <p>
 * This class connects a custom constraint to the SDK, and functions are called by the SDK
 * to query the custom implementation for specific information to pass on to the application
 * or inform the constraint when the application makes calls into the SDK which will update
 * the custom constraint's internal implementation
 */
public class PxConstraintConnector extends NativeObject {

    protected PxConstraintConnector() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxConstraintConnector wrapPointer(long address) {
        return address != 0L ? new PxConstraintConnector(address) : null;
    }
    
    public static PxConstraintConnector arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxConstraintConnector(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     *  Pre-simulation data preparation
     * when the constraint is marked dirty, this function is called at the start of the simulation
     * step for the SDK to copy the constraint data block.
     */
    public void prepareData() {
        checkNotNull();
        Raw.prepareData(address);
    }

    /**
     * this function is called by the SDK to update OmniPVD's view of it
     */
    public void updateOmniPvdProperties() {
        checkNotNull();
        Raw.updateOmniPvdProperties(address);
    }

    /**
     * Constraint release callback
     * <p>
     * When the SDK deletes a PxConstraint object this function is called by the SDK. In general
     * custom constraints should not be deleted directly by applications: rather, the constraint
     * should respond to a release() request by calling PxConstraint::release(), then wait for
     * this call to release its own resources.
     * <p>
     * This function is also called when a PxConstraint object is deleted on cleanup due to 
     * destruction of the PxPhysics object.
     */
    public void onConstraintRelease() {
        checkNotNull();
        Raw.onConstraintRelease(address);
    }

    /**
     * Center-of-mass shift callback
     * <p>
     * This function is called by the SDK when the CoM of one of the actors is moved. Since the
     * API specifies constraint positions relative to actors, and the constraint shader functions
     * are supplied with coordinates relative to bodies, some synchronization is usually required
     * when the application moves an object's center of mass.
     */
    public void onComShift(int actor) {
        checkNotNull();
        Raw.onComShift(address, actor);
    }

    /**
     * Origin shift callback
     * <p>
     * This function is called by the SDK when the scene origin gets shifted and allows to adjust
     * custom data which contains world space transforms.
     * <p>
     * <b>Note:</b> If the adjustments affect constraint shader data, it is necessary to call PxConstraint::markDirty()
     * to make sure that the data gets synced at the beginning of the next simulation step.
     * @param shift Translation vector the origin is shifted by.
     * @see PxScene#shiftOrigin
     */
    public void onOriginShift(PxVec3 shift) {
        checkNotNull();
        Raw.onOriginShift(address, shift.getAddress());
    }

    /**
     * Obtain a reference to a PxBase interface if the constraint has one.
     * <p>
     * If the constraint does not implement the PxBase interface, it should return NULL. 
     */
    public PxBase getSerializable() {
        checkNotNull();
        return PxBase.wrapPointer(Raw.getSerializable(address));
    }

    /**
     * Obtain the shader function pointer used to prep rows for this constraint
     */
    public PxConstraintSolverPrep getPrep() {
        checkNotNull();
        return PxConstraintSolverPrep.wrapPointer(Raw.getPrep(address));
    }

    /**
     * Obtain the pointer to the constraint's constant data
     */
    public void getConstantBlock() {
        checkNotNull();
        Raw.getConstantBlock(address);
    }

    /**
     * Let the connector know it has been connected to a constraint.
     */
    public void connectToConstraint(PxConstraint constraint) {
        checkNotNull();
        Raw.connectToConstraint(address, constraint.getAddress());
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native void prepareData(long address);
        public static native void updateOmniPvdProperties(long address);
        public static native void onConstraintRelease(long address);
        public static native void onComShift(long address, int actor);
        public static native void onOriginShift(long address, long shift);
        public static native long getSerializable(long address);
        public static native long getPrep(long address);
        public static native void getConstantBlock(long address);
        public static native void connectToConstraint(long address, long constraint);
    }
}
