package physxandroid.physics;

import physxandroid.NativeObject;

/**
 * Class used to retrieve limits(e.g. maximum number of bodies) for a scene. The limits
 * are used as a hint to the size of the scene, not as a hard limit (i.e. it will be possible
 * to create more objects than specified in the scene limits).
 * <p>
 * 0 indicates no limit. Using limits allows the SDK to preallocate various arrays, leading to
 * less re-allocations and faster code at runtime.
 */
public class PxSceneLimits extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxSceneLimits wrapPointer(long address) {
        return address != 0L ? new PxSceneLimits(address) : null;
    }
    
    public static PxSceneLimits arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxSceneLimits(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxSceneLimits
     */
    public static PxSceneLimits createAt(long address) {
        Raw.PxSceneLimits_placed(address);
        PxSceneLimits createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxSceneLimits
     */
    public static <T> PxSceneLimits createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxSceneLimits_placed(address);
        PxSceneLimits createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * constructor sets to default 
     */
    public PxSceneLimits() {
        address = Raw.PxSceneLimits();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Expected maximum number of actors
     */
    public int getMaxNbActors() {
        checkNotNull();
        return Raw.getMaxNbActors(address);
    }

    /**
     * Expected maximum number of actors
     */
    public void setMaxNbActors(int value) {
        checkNotNull();
        Raw.setMaxNbActors(address, value);
    }

    /**
     * Expected maximum number of dynamic rigid bodies
     */
    public int getMaxNbBodies() {
        checkNotNull();
        return Raw.getMaxNbBodies(address);
    }

    /**
     * Expected maximum number of dynamic rigid bodies
     */
    public void setMaxNbBodies(int value) {
        checkNotNull();
        Raw.setMaxNbBodies(address, value);
    }

    /**
     * Expected maximum number of static shapes
     */
    public int getMaxNbStaticShapes() {
        checkNotNull();
        return Raw.getMaxNbStaticShapes(address);
    }

    /**
     * Expected maximum number of static shapes
     */
    public void setMaxNbStaticShapes(int value) {
        checkNotNull();
        Raw.setMaxNbStaticShapes(address, value);
    }

    /**
     * Expected maximum number of dynamic shapes
     */
    public int getMaxNbDynamicShapes() {
        checkNotNull();
        return Raw.getMaxNbDynamicShapes(address);
    }

    /**
     * Expected maximum number of dynamic shapes
     */
    public void setMaxNbDynamicShapes(int value) {
        checkNotNull();
        Raw.setMaxNbDynamicShapes(address, value);
    }

    /**
     * Expected maximum number of aggregates
     */
    public int getMaxNbAggregates() {
        checkNotNull();
        return Raw.getMaxNbAggregates(address);
    }

    /**
     * Expected maximum number of aggregates
     */
    public void setMaxNbAggregates(int value) {
        checkNotNull();
        Raw.setMaxNbAggregates(address, value);
    }

    /**
     * Expected maximum number of constraint shaders
     */
    public int getMaxNbConstraints() {
        checkNotNull();
        return Raw.getMaxNbConstraints(address);
    }

    /**
     * Expected maximum number of constraint shaders
     */
    public void setMaxNbConstraints(int value) {
        checkNotNull();
        Raw.setMaxNbConstraints(address, value);
    }

    /**
     * Expected maximum number of broad-phase regions
     */
    public int getMaxNbRegions() {
        checkNotNull();
        return Raw.getMaxNbRegions(address);
    }

    /**
     * Expected maximum number of broad-phase regions
     */
    public void setMaxNbRegions(int value) {
        checkNotNull();
        Raw.setMaxNbRegions(address, value);
    }

    /**
     * Expected maximum number of broad-phase overlaps
     */
    public int getMaxNbBroadPhaseOverlaps() {
        checkNotNull();
        return Raw.getMaxNbBroadPhaseOverlaps(address);
    }

    /**
     * Expected maximum number of broad-phase overlaps
     */
    public void setMaxNbBroadPhaseOverlaps(int value) {
        checkNotNull();
        Raw.setMaxNbBroadPhaseOverlaps(address, value);
    }

    // Functions

    /**
     * (re)sets the structure to the default
     */
    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    /**
     * Returns true if the descriptor is valid.
     * @return true if the current settings are valid.
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native void PxSceneLimits_placed(long address);
        public static native long PxSceneLimits();
        public static native void destroy(long address);
        public static native int getMaxNbActors(long address);
        public static native void setMaxNbActors(long address, int value);
        public static native int getMaxNbBodies(long address);
        public static native void setMaxNbBodies(long address, int value);
        public static native int getMaxNbStaticShapes(long address);
        public static native void setMaxNbStaticShapes(long address, int value);
        public static native int getMaxNbDynamicShapes(long address);
        public static native void setMaxNbDynamicShapes(long address, int value);
        public static native int getMaxNbAggregates(long address);
        public static native void setMaxNbAggregates(long address, int value);
        public static native int getMaxNbConstraints(long address);
        public static native void setMaxNbConstraints(long address, int value);
        public static native int getMaxNbRegions(long address);
        public static native void setMaxNbRegions(long address, int value);
        public static native int getMaxNbBroadPhaseOverlaps(long address);
        public static native void setMaxNbBroadPhaseOverlaps(long address, int value);
        public static native void setToDefault(long address);
        public static native boolean isValid(long address);
    }
}
