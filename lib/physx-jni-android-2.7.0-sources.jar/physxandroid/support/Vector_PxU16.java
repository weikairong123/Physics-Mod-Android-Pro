package physxandroid.support;

import physxandroid.NativeObject;

@Deprecated
public class Vector_PxU16 extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static Vector_PxU16 wrapPointer(long address) {
        return address != 0L ? new Vector_PxU16(address) : null;
    }
    
    public static Vector_PxU16 arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected Vector_PxU16(long address) {
        super(address);
    }

    // Constructors

    public Vector_PxU16() {
        address = Raw.Vector_PxU16();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public Vector_PxU16(int size) {
        address = Raw.Vector_PxU16(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: unsigned short
     */
    public short at(int index) {
        checkNotNull();
        return Raw.at(address, index);
    }

    /**
     * @return WebIDL type: VoidPtr
     */
    public NativeObject data() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.data(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: unsigned short
     */
    public void push_back(short value) {
        checkNotNull();
        Raw.push_back(address, value);
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native long Vector_PxU16();
        public static native long Vector_PxU16(int size);
        public static native void destroy(long address);
        public static native short at(long address, int index);
        public static native long data(long address);
        public static native int size(long address);
        public static native void push_back(long address, short value);
        public static native void clear(long address);
    }
}
