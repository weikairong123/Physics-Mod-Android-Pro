package physxandroid.support;

import physxandroid.NativeObject;
import physxandroid.physics.PxArticulationReducedCoordinate;
import physxandroid.physics.PxRigidActor;
import physxandroid.physics.PxScene;
import physxandroid.physics.PxShape;

public class SupportFunctions extends NativeObject {

    protected SupportFunctions() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static SupportFunctions wrapPointer(long address) {
        return address != 0L ? new SupportFunctions(address) : null;
    }
    
    public static SupportFunctions arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected SupportFunctions(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param actor WebIDL type: {@link PxRigidActor} [Ref]
     * @param index WebIDL type: long
     * @return WebIDL type: {@link PxShape}
     */
    public static PxShape PxActor_getShape(PxRigidActor actor, int index) {
        return PxShape.wrapPointer(Raw.PxActor_getShape(actor.getAddress(), index));
    }

    /**
     * @param scene WebIDL type: {@link PxScene}
     * @return WebIDL type: {@link PxArray_PxActorPtr} [Ref]
     */
    public static PxArray_PxActorPtr PxScene_getActiveActors(PxScene scene) {
        return PxArray_PxActorPtr.wrapPointer(Raw.PxScene_getActiveActors(scene.getAddress()));
    }

    /**
     * @param articulation WebIDL type: {@link PxArticulationReducedCoordinate}
     * @return WebIDL type: unsigned long
     */
    public static int PxArticulationReducedCoordinate_getMinSolverPositionIterations(PxArticulationReducedCoordinate articulation) {
        return Raw.PxArticulationReducedCoordinate_getMinSolverPositionIterations(articulation.getAddress());
    }

    /**
     * @param articulation WebIDL type: {@link PxArticulationReducedCoordinate}
     * @return WebIDL type: unsigned long
     */
    public static int PxArticulationReducedCoordinate_getMinSolverVelocityIterations(PxArticulationReducedCoordinate articulation) {
        return Raw.PxArticulationReducedCoordinate_getMinSolverVelocityIterations(articulation.getAddress());
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long PxActor_getShape(long actor, int index);
        public static native long PxScene_getActiveActors(long scene);
        public static native int PxArticulationReducedCoordinate_getMinSolverPositionIterations(long articulation);
        public static native int PxArticulationReducedCoordinate_getMinSolverVelocityIterations(long articulation);
    }
}
