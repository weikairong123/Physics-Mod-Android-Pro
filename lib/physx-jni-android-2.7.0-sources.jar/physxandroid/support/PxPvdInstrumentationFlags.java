package physxandroid.support;

import physxandroid.NativeObject;

public class PxPvdInstrumentationFlags extends NativeObject {

    protected PxPvdInstrumentationFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxPvdInstrumentationFlags wrapPointer(long address) {
        return address != 0L ? new PxPvdInstrumentationFlags(address) : null;
    }
    
    public static PxPvdInstrumentationFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxPvdInstrumentationFlags(long address) {
        super(address);
    }

    // Constructors

    /**
     * @param flags WebIDL type: octet
     */
    public PxPvdInstrumentationFlags(byte flags) {
        address = Raw.PxPvdInstrumentationFlags(flags);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param flag WebIDL type: {@link PxPvdInstrumentationFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxPvdInstrumentationFlagEnum flag) {
        checkNotNull();
        return Raw.isSet(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxPvdInstrumentationFlagEnum} [enum]
     */
    public void raise(PxPvdInstrumentationFlagEnum flag) {
        checkNotNull();
        Raw.raise(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxPvdInstrumentationFlagEnum} [enum]
     */
    public void clear(PxPvdInstrumentationFlagEnum flag) {
        checkNotNull();
        Raw.clear(address, flag.value);
    }

    public static class Raw {
        public static native long PxPvdInstrumentationFlags(byte flags);
        public static native void destroy(long address);
        public static native boolean isSet(long address, int flag);
        public static native void raise(long address, int flag);
        public static native void clear(long address, int flag);
    }
}
