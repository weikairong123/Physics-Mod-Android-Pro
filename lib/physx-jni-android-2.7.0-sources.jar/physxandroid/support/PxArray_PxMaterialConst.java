package physxandroid.support;

import physxandroid.NativeObject;
import physxandroid.physics.PxMaterial;

public class PxArray_PxMaterialConst extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxArray_PxMaterialConst wrapPointer(long address) {
        return address != 0L ? new PxArray_PxMaterialConst(address) : null;
    }
    
    public static PxArray_PxMaterialConst arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxArray_PxMaterialConst(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxArray_PxMaterialConst
     */
    public static PxArray_PxMaterialConst createAt(long address) {
        Raw.PxArray_PxMaterialConst_placed(address);
        PxArray_PxMaterialConst createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxArray_PxMaterialConst
     */
    public static <T> PxArray_PxMaterialConst createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxArray_PxMaterialConst_placed(address);
        PxArray_PxMaterialConst createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param size    WebIDL type: unsigned long
     * @return Stack allocated object of PxArray_PxMaterialConst
     */
    public static PxArray_PxMaterialConst createAt(long address, int size) {
        Raw.PxArray_PxMaterialConst_placed(address, size);
        PxArray_PxMaterialConst createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param size      WebIDL type: unsigned long
     * @return Stack allocated object of PxArray_PxMaterialConst
     */
    public static <T> PxArray_PxMaterialConst createAt(T allocator, Allocator<T> allocate, int size) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxArray_PxMaterialConst_placed(address, size);
        PxArray_PxMaterialConst createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxArray_PxMaterialConst() {
        address = Raw.PxArray_PxMaterialConst();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public PxArray_PxMaterialConst(int size) {
        address = Raw.PxArray_PxMaterialConst(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxMaterial} [Const]
     */
    public PxMaterial get(int index) {
        checkNotNull();
        return PxMaterial.wrapPointer(Raw.get(address, index));
    }

    /**
     * @param index WebIDL type: unsigned long
     * @param value WebIDL type: {@link PxMaterialConstPtr} [Const, Ref]
     */
    public void set(int index, PxMaterialConstPtr value) {
        checkNotNull();
        Raw.set(address, index, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxMaterialConstPtr}
     */
    public PxMaterialConstPtr begin() {
        checkNotNull();
        return PxMaterialConstPtr.wrapPointer(Raw.begin(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: {@link PxMaterial} [Const]
     */
    public void pushBack(PxMaterial value) {
        checkNotNull();
        Raw.pushBack(address, value.getAddress());
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native void PxArray_PxMaterialConst_placed(long address);
        public static native void PxArray_PxMaterialConst_placed(long address, int size);
        public static native long PxArray_PxMaterialConst();
        public static native long PxArray_PxMaterialConst(int size);
        public static native void destroy(long address);
        public static native long get(long address, int index);
        public static native void set(long address, int index, long value);
        public static native long begin(long address);
        public static native int size(long address);
        public static native void pushBack(long address, long value);
        public static native void clear(long address);
    }
}
