package physxandroid.support;

import physxandroid.NativeObject;
import physxandroid.PlatformChecks;

public class PxOmniPvd extends NativeObject {

    protected PxOmniPvd() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxOmniPvd wrapPointer(long address) {
        return address != 0L ? new PxOmniPvd(address) : null;
    }
    
    public static PxOmniPvd arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxOmniPvd(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @return WebIDL type: {@link OmniPvdWriter} [Platforms=windows;linux;macos]
     */
    public OmniPvdWriter getWriter() {
        checkNotNull();
        PlatformChecks.requirePlatform(7, "physxandroid.support.PxOmniPvd");
        return OmniPvdWriter.wrapPointer(Raw.getWriter(address));
    }

    /**
     * @return WebIDL type: {@link OmniPvdFileWriteStream} [Platforms=windows;linux;macos]
     */
    public OmniPvdFileWriteStream getFileWriteStream() {
        checkNotNull();
        PlatformChecks.requirePlatform(7, "physxandroid.support.PxOmniPvd");
        return OmniPvdFileWriteStream.wrapPointer(Raw.getFileWriteStream(address));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean startSampling() {
        checkNotNull();
        return Raw.startSampling(address);
    }

    public void release() {
        checkNotNull();
        Raw.release(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getWriter(long address);
        public static native long getFileWriteStream(long address);
        public static native boolean startSampling(long address);
        public static native void release(long address);
    }
}
