package physxandroid.support;

import physxandroid.NativeObject;

public class PxPvdSceneFlags extends NativeObject {

    protected PxPvdSceneFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxPvdSceneFlags wrapPointer(long address) {
        return address != 0L ? new PxPvdSceneFlags(address) : null;
    }
    
    public static PxPvdSceneFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxPvdSceneFlags(long address) {
        super(address);
    }

    // Constructors

    /**
     * @param flags WebIDL type: octet
     */
    public PxPvdSceneFlags(byte flags) {
        address = Raw.PxPvdSceneFlags(flags);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param flag WebIDL type: {@link PxPvdSceneFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxPvdSceneFlagEnum flag) {
        checkNotNull();
        return Raw.isSet(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxPvdSceneFlagEnum} [enum]
     */
    public void raise(PxPvdSceneFlagEnum flag) {
        checkNotNull();
        Raw.raise(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxPvdSceneFlagEnum} [enum]
     */
    public void clear(PxPvdSceneFlagEnum flag) {
        checkNotNull();
        Raw.clear(address, flag.value);
    }

    public static class Raw {
        public static native long PxPvdSceneFlags(byte flags);
        public static native void destroy(long address);
        public static native boolean isSet(long address, int flag);
        public static native void raise(long address, int flag);
        public static native void clear(long address, int flag);
    }
}
