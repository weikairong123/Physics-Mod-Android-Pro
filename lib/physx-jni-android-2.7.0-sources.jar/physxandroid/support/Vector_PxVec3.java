package physxandroid.support;

import physxandroid.NativeObject;
import physxandroid.common.PxVec3;

@Deprecated
public class Vector_PxVec3 extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static Vector_PxVec3 wrapPointer(long address) {
        return address != 0L ? new Vector_PxVec3(address) : null;
    }
    
    public static Vector_PxVec3 arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected Vector_PxVec3(long address) {
        super(address);
    }

    // Constructors

    public Vector_PxVec3() {
        address = Raw.Vector_PxVec3();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public Vector_PxVec3(int size) {
        address = Raw.Vector_PxVec3(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxVec3} [Ref]
     */
    public PxVec3 at(int index) {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.at(address, index));
    }

    /**
     * @return WebIDL type: {@link PxVec3}
     */
    public PxVec3 data() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.data(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Ref]
     */
    public void push_back(PxVec3 value) {
        checkNotNull();
        Raw.push_back(address, value.getAddress());
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native long Vector_PxVec3();
        public static native long Vector_PxVec3(int size);
        public static native void destroy(long address);
        public static native long at(long address, int index);
        public static native long data(long address);
        public static native int size(long address);
        public static native void push_back(long address, long value);
        public static native void clear(long address);
    }
}
