package physxandroid.support;

import physxandroid.NativeObject;
import physxandroid.physics.PxRaycastHit;

@Deprecated
public class Vector_PxRaycastHit extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static Vector_PxRaycastHit wrapPointer(long address) {
        return address != 0L ? new Vector_PxRaycastHit(address) : null;
    }
    
    public static Vector_PxRaycastHit arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected Vector_PxRaycastHit(long address) {
        super(address);
    }

    // Constructors

    public Vector_PxRaycastHit() {
        address = Raw.Vector_PxRaycastHit();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public Vector_PxRaycastHit(int size) {
        address = Raw.Vector_PxRaycastHit(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxRaycastHit} [Ref]
     */
    public PxRaycastHit at(int index) {
        checkNotNull();
        return PxRaycastHit.wrapPointer(Raw.at(address, index));
    }

    /**
     * @return WebIDL type: {@link PxRaycastHit}
     */
    public PxRaycastHit data() {
        checkNotNull();
        return PxRaycastHit.wrapPointer(Raw.data(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: {@link PxRaycastHit} [Ref]
     */
    public void push_back(PxRaycastHit value) {
        checkNotNull();
        Raw.push_back(address, value.getAddress());
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native long Vector_PxRaycastHit();
        public static native long Vector_PxRaycastHit(int size);
        public static native void destroy(long address);
        public static native long at(long address, int index);
        public static native long data(long address);
        public static native int size(long address);
        public static native void push_back(long address, long value);
        public static native void clear(long address);
    }
}
