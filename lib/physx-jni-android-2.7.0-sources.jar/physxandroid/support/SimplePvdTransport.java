package physxandroid.support;

import physxandroid.NativeObject;

public class SimplePvdTransport extends PxPvdTransport {

    protected SimplePvdTransport() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static SimplePvdTransport wrapPointer(long address) {
        return address != 0L ? new SimplePvdTransport(address) : null;
    }
    
    public static SimplePvdTransport arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected SimplePvdTransport(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param inBytes  WebIDL type: any
     * @param inLength WebIDL type: unsigned long
     */
    public void send(NativeObject inBytes, int inLength) {
        checkNotNull();
        Raw.send(address, inBytes.getAddress(), inLength);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native void send(long address, long inBytes, int inLength);
    }
}
