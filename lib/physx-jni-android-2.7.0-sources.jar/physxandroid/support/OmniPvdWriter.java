package physxandroid.support;

import physxandroid.NativeObject;
import physxandroid.PlatformChecks;

public class OmniPvdWriter extends NativeObject {

    static {
        PlatformChecks.requirePlatform(7, "physxandroid.support.OmniPvdWriter");
    }

    protected OmniPvdWriter() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static OmniPvdWriter wrapPointer(long address) {
        return address != 0L ? new OmniPvdWriter(address) : null;
    }
    
    public static OmniPvdWriter arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected OmniPvdWriter(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param writeStream WebIDL type: {@link OmniPvdWriteStream} [Ref]
     */
    public void setWriteStream(OmniPvdWriteStream writeStream) {
        checkNotNull();
        Raw.setWriteStream(address, writeStream.getAddress());
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native void setWriteStream(long address, long writeStream);
    }
}
