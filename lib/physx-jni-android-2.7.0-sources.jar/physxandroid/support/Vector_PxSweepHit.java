package physxandroid.support;

import physxandroid.NativeObject;
import physxandroid.physics.PxSweepHit;

@Deprecated
public class Vector_PxSweepHit extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static Vector_PxSweepHit wrapPointer(long address) {
        return address != 0L ? new Vector_PxSweepHit(address) : null;
    }
    
    public static Vector_PxSweepHit arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected Vector_PxSweepHit(long address) {
        super(address);
    }

    // Constructors

    public Vector_PxSweepHit() {
        address = Raw.Vector_PxSweepHit();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public Vector_PxSweepHit(int size) {
        address = Raw.Vector_PxSweepHit(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxSweepHit} [Ref]
     */
    public PxSweepHit at(int index) {
        checkNotNull();
        return PxSweepHit.wrapPointer(Raw.at(address, index));
    }

    /**
     * @return WebIDL type: {@link PxSweepHit}
     */
    public PxSweepHit data() {
        checkNotNull();
        return PxSweepHit.wrapPointer(Raw.data(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: {@link PxSweepHit} [Ref]
     */
    public void push_back(PxSweepHit value) {
        checkNotNull();
        Raw.push_back(address, value.getAddress());
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native long Vector_PxSweepHit();
        public static native long Vector_PxSweepHit(int size);
        public static native void destroy(long address);
        public static native long at(long address, int index);
        public static native long data(long address);
        public static native int size(long address);
        public static native void push_back(long address, long value);
        public static native void clear(long address);
    }
}
