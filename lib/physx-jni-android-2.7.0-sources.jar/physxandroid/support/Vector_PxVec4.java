package physxandroid.support;

import physxandroid.NativeObject;
import physxandroid.common.PxVec4;

@Deprecated
public class Vector_PxVec4 extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static Vector_PxVec4 wrapPointer(long address) {
        return address != 0L ? new Vector_PxVec4(address) : null;
    }
    
    public static Vector_PxVec4 arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected Vector_PxVec4(long address) {
        super(address);
    }

    // Constructors

    public Vector_PxVec4() {
        address = Raw.Vector_PxVec4();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public Vector_PxVec4(int size) {
        address = Raw.Vector_PxVec4(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxVec4} [Ref]
     */
    public PxVec4 at(int index) {
        checkNotNull();
        return PxVec4.wrapPointer(Raw.at(address, index));
    }

    /**
     * @return WebIDL type: {@link PxVec4}
     */
    public PxVec4 data() {
        checkNotNull();
        return PxVec4.wrapPointer(Raw.data(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: {@link PxVec4} [Ref]
     */
    public void push_back(PxVec4 value) {
        checkNotNull();
        Raw.push_back(address, value.getAddress());
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native long Vector_PxVec4();
        public static native long Vector_PxVec4(int size);
        public static native void destroy(long address);
        public static native long at(long address, int index);
        public static native long data(long address);
        public static native int size(long address);
        public static native void push_back(long address, long value);
        public static native void clear(long address);
    }
}
