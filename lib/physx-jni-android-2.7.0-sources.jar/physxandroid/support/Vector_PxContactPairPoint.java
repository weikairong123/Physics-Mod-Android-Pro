package physxandroid.support;

import physxandroid.NativeObject;
import physxandroid.physics.PxContactPairPoint;

@Deprecated
public class Vector_PxContactPairPoint extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static Vector_PxContactPairPoint wrapPointer(long address) {
        return address != 0L ? new Vector_PxContactPairPoint(address) : null;
    }
    
    public static Vector_PxContactPairPoint arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected Vector_PxContactPairPoint(long address) {
        super(address);
    }

    // Constructors

    public Vector_PxContactPairPoint() {
        address = Raw.Vector_PxContactPairPoint();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public Vector_PxContactPairPoint(int size) {
        address = Raw.Vector_PxContactPairPoint(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxContactPairPoint} [Ref]
     */
    public PxContactPairPoint at(int index) {
        checkNotNull();
        return PxContactPairPoint.wrapPointer(Raw.at(address, index));
    }

    /**
     * @return WebIDL type: {@link PxContactPairPoint}
     */
    public PxContactPairPoint data() {
        checkNotNull();
        return PxContactPairPoint.wrapPointer(Raw.data(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: {@link PxContactPairPoint} [Ref]
     */
    public void push_back(PxContactPairPoint value) {
        checkNotNull();
        Raw.push_back(address, value.getAddress());
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native long Vector_PxContactPairPoint();
        public static native long Vector_PxContactPairPoint(int size);
        public static native void destroy(long address);
        public static native long at(long address, int index);
        public static native long data(long address);
        public static native int size(long address);
        public static native void push_back(long address, long value);
        public static native void clear(long address);
    }
}
