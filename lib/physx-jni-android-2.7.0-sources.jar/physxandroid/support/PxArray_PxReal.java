package physxandroid.support;

import physxandroid.NativeObject;

public class PxArray_PxReal extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxArray_PxReal wrapPointer(long address) {
        return address != 0L ? new PxArray_PxReal(address) : null;
    }
    
    public static PxArray_PxReal arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxArray_PxReal(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxArray_PxReal
     */
    public static PxArray_PxReal createAt(long address) {
        Raw.PxArray_PxReal_placed(address);
        PxArray_PxReal createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxArray_PxReal
     */
    public static <T> PxArray_PxReal createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxArray_PxReal_placed(address);
        PxArray_PxReal createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param size    WebIDL type: unsigned long
     * @return Stack allocated object of PxArray_PxReal
     */
    public static PxArray_PxReal createAt(long address, int size) {
        Raw.PxArray_PxReal_placed(address, size);
        PxArray_PxReal createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param size      WebIDL type: unsigned long
     * @return Stack allocated object of PxArray_PxReal
     */
    public static <T> PxArray_PxReal createAt(T allocator, Allocator<T> allocate, int size) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxArray_PxReal_placed(address, size);
        PxArray_PxReal createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxArray_PxReal() {
        address = Raw.PxArray_PxReal();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public PxArray_PxReal(int size) {
        address = Raw.PxArray_PxReal(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: float
     */
    public float get(int index) {
        checkNotNull();
        return Raw.get(address, index);
    }

    /**
     * @param index WebIDL type: unsigned long
     * @param value WebIDL type: float
     */
    public void set(int index, float value) {
        checkNotNull();
        Raw.set(address, index, value);
    }

    /**
     * @return WebIDL type: VoidPtr
     */
    public NativeObject begin() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.begin(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void pushBack(float value) {
        checkNotNull();
        Raw.pushBack(address, value);
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native void PxArray_PxReal_placed(long address);
        public static native void PxArray_PxReal_placed(long address, int size);
        public static native long PxArray_PxReal();
        public static native long PxArray_PxReal(int size);
        public static native void destroy(long address);
        public static native float get(long address, int index);
        public static native void set(long address, int index, float value);
        public static native long begin(long address);
        public static native int size(long address);
        public static native void pushBack(long address, float value);
        public static native void clear(long address);
    }
}
