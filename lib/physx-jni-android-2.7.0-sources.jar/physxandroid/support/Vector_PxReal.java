package physxandroid.support;

import physxandroid.NativeObject;

@Deprecated
public class Vector_PxReal extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static Vector_PxReal wrapPointer(long address) {
        return address != 0L ? new Vector_PxReal(address) : null;
    }
    
    public static Vector_PxReal arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected Vector_PxReal(long address) {
        super(address);
    }

    // Constructors

    public Vector_PxReal() {
        address = Raw.Vector_PxReal();
    }

    /**
     * @param size WebIDL type: unsigned long
     */
    public Vector_PxReal(int size) {
        address = Raw.Vector_PxReal(size);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: float
     */
    public float at(int index) {
        checkNotNull();
        return Raw.at(address, index);
    }

    /**
     * @return WebIDL type: VoidPtr
     */
    public NativeObject data() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.data(address));
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return Raw.size(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void push_back(float value) {
        checkNotNull();
        Raw.push_back(address, value);
    }

    public void clear() {
        checkNotNull();
        Raw.clear(address);
    }

    public static class Raw {
        public static native long Vector_PxReal();
        public static native long Vector_PxReal(int size);
        public static native void destroy(long address);
        public static native float at(long address, int index);
        public static native long data(long address);
        public static native int size(long address);
        public static native void push_back(long address, float value);
        public static native void clear(long address);
    }
}
