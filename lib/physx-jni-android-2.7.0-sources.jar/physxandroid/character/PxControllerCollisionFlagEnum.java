package physxandroid.character;

/**
 * specifies which sides a character is colliding with.
 */
public enum PxControllerCollisionFlagEnum {

    /**
     * Character is colliding to the sides.
     */
    eCOLLISION_SIDES(geteCOLLISION_SIDES()),
    /**
     * Character has collision above.
     */
    eCOLLISION_UP(geteCOLLISION_UP()),
    eCOLLISION_DOWN(geteCOLLISION_DOWN());
    public final int value;
    
    PxControllerCollisionFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteCOLLISION_SIDES();
    private static int geteCOLLISION_SIDES() {
        de.fabmax.physxandroid.Loader.load();
        return _geteCOLLISION_SIDES();
    }

    private static native int _geteCOLLISION_UP();
    private static int geteCOLLISION_UP() {
        de.fabmax.physxandroid.Loader.load();
        return _geteCOLLISION_UP();
    }

    private static native int _geteCOLLISION_DOWN();
    private static int geteCOLLISION_DOWN() {
        de.fabmax.physxandroid.Loader.load();
        return _geteCOLLISION_DOWN();
    }

    private static final int LUT_SIZE = 256;
    private static final PxControllerCollisionFlagEnum[] enumValues = values();
    private static final PxControllerCollisionFlagEnum[] enumLut = new PxControllerCollisionFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxControllerCollisionFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxControllerCollisionFlagEnum forValue(int value) {
        PxControllerCollisionFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxControllerCollisionFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxControllerCollisionFlagEnum: " + value);
        }
        return enumValue;
    }
}
