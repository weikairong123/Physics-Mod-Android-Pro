package physxandroid.character;


/**
 * A capsule character controller.
 * <p>
 * The capsule is defined as a position, a vertical height, and a radius.
 * The height is the distance between the two sphere centers at the end of the capsule.
 * In other words:
 * <p>
 * p = pos (returned by controller)<br>
 * h = height<br>
 * r = radius<br>
 * <p>
 * p = center of capsule<br>
 * top sphere center = p.y + h*0.5<br>
 * bottom sphere center = p.y - h*0.5<br>
 * top capsule point = p.y + h*0.5 + r<br>
 * bottom capsule point = p.y - h*0.5 - r<br>
 */
public class PxCapsuleController extends PxController {

    protected PxCapsuleController() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxCapsuleController wrapPointer(long address) {
        return address != 0L ? new PxCapsuleController(address) : null;
    }
    
    public static PxCapsuleController arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxCapsuleController(long address) {
        super(address);
    }

    // Functions

    /**
     * Gets controller's radius.
     * @return The radius of the controller.
     * @see #setRadius
     */
    public float getRadius() {
        checkNotNull();
        return Raw.getRadius(address);
    }

    /**
     * Sets controller's radius.
     * <p>
     * \warning this doesn't check for collisions.
     * @param radius The new radius for the controller.
     * @return Currently always true.
     * @see #getRadius
     */
    public boolean setRadius(float radius) {
        checkNotNull();
        return Raw.setRadius(address, radius);
    }

    /**
     * Gets controller's height.
     * @return The height of the capsule controller.
     * @see #setHeight
     */
    public float getHeight() {
        checkNotNull();
        return Raw.getHeight(address);
    }

    /**
     * Resets controller's height.
     * <p>
     * \warning this doesn't check for collisions.
     * @param height The new height for the controller.
     * @return Currently always true.
     * @see #getHeight
     */
    public boolean setHeight(float height) {
        checkNotNull();
        return Raw.setHeight(address, height);
    }

    /**
     * Gets controller's climbing mode.
     * @return The capsule controller's climbing mode.
     * @see #setClimbingMode
     */
    public PxCapsuleClimbingModeEnum getClimbingMode() {
        checkNotNull();
        return PxCapsuleClimbingModeEnum.forValue(Raw.getClimbingMode(address));
    }

    /**
     * Sets controller's climbing mode.
     * @param mode The capsule controller's climbing mode.
     * @see #getClimbingMode
     */
    public boolean setClimbingMode(PxCapsuleClimbingModeEnum mode) {
        checkNotNull();
        return Raw.setClimbingMode(address, mode.value);
    }

    public static class Raw {
        public static native float getRadius(long address);
        public static native boolean setRadius(long address, float radius);
        public static native float getHeight(long address);
        public static native boolean setHeight(long address, float height);
        public static native int getClimbingMode(long address);
        public static native boolean setClimbingMode(long address, int mode);
    }
}
