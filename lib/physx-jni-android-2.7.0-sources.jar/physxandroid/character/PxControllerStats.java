package physxandroid.character;

import physxandroid.NativeObject;

/**
 * Describes a controller's internal statistics.
 */
public class PxControllerStats extends NativeObject {

    protected PxControllerStats() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxControllerStats wrapPointer(long address) {
        return address != 0L ? new PxControllerStats(address) : null;
    }
    
    public static PxControllerStats arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxControllerStats(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     */
    public short getNbIterations() {
        checkNotNull();
        return Raw.getNbIterations(address);
    }

    /**
     */
    public void setNbIterations(short value) {
        checkNotNull();
        Raw.setNbIterations(address, value);
    }

    /**
     */
    public short getNbFullUpdates() {
        checkNotNull();
        return Raw.getNbFullUpdates(address);
    }

    /**
     */
    public void setNbFullUpdates(short value) {
        checkNotNull();
        Raw.setNbFullUpdates(address, value);
    }

    /**
     */
    public short getNbPartialUpdates() {
        checkNotNull();
        return Raw.getNbPartialUpdates(address);
    }

    /**
     */
    public void setNbPartialUpdates(short value) {
        checkNotNull();
        Raw.setNbPartialUpdates(address, value);
    }

    /**
     */
    public short getNbTessellation() {
        checkNotNull();
        return Raw.getNbTessellation(address);
    }

    /**
     */
    public void setNbTessellation(short value) {
        checkNotNull();
        Raw.setNbTessellation(address, value);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native short getNbIterations(long address);
        public static native void setNbIterations(long address, short value);
        public static native short getNbFullUpdates(long address);
        public static native void setNbFullUpdates(long address, short value);
        public static native short getNbPartialUpdates(long address);
        public static native void setNbPartialUpdates(long address, short value);
        public static native short getNbTessellation(long address);
        public static native void setNbTessellation(long address, short value);
    }
}
