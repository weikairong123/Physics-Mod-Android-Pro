package physxandroid.character;


/**
 * A descriptor for a capsule character controller.
 * @see PxCapsuleController
 * @see PxControllerDesc
 */
public class PxCapsuleControllerDesc extends PxControllerDesc {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxCapsuleControllerDesc wrapPointer(long address) {
        return address != 0L ? new PxCapsuleControllerDesc(address) : null;
    }
    
    public static PxCapsuleControllerDesc arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxCapsuleControllerDesc(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxCapsuleControllerDesc
     */
    public static PxCapsuleControllerDesc createAt(long address) {
        Raw.PxCapsuleControllerDesc_placed(address);
        PxCapsuleControllerDesc createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxCapsuleControllerDesc
     */
    public static <T> PxCapsuleControllerDesc createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxCapsuleControllerDesc_placed(address);
        PxCapsuleControllerDesc createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * constructor sets to default.
     */
    public PxCapsuleControllerDesc() {
        address = Raw.PxCapsuleControllerDesc();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * The radius of the capsule
     * <p>
     * <b>Default:</b> 0.0
     * @see PxCapsuleController
     */
    public float getRadius() {
        checkNotNull();
        return Raw.getRadius(address);
    }

    /**
     * The radius of the capsule
     * <p>
     * <b>Default:</b> 0.0
     * @see PxCapsuleController
     */
    public void setRadius(float value) {
        checkNotNull();
        Raw.setRadius(address, value);
    }

    /**
     * The height of the controller
     * <p>
     * <b>Default:</b> 0.0
     * @see PxCapsuleController
     */
    public float getHeight() {
        checkNotNull();
        return Raw.getHeight(address);
    }

    /**
     * The height of the controller
     * <p>
     * <b>Default:</b> 0.0
     * @see PxCapsuleController
     */
    public void setHeight(float value) {
        checkNotNull();
        Raw.setHeight(address, value);
    }

    /**
     * The climbing mode
     * <p>
     * <b>Default:</b> PxCapsuleClimbingMode::eEASY
     * @see PxCapsuleController
     */
    public PxCapsuleClimbingModeEnum getClimbingMode() {
        checkNotNull();
        return PxCapsuleClimbingModeEnum.forValue(Raw.getClimbingMode(address));
    }

    /**
     * The climbing mode
     * <p>
     * <b>Default:</b> PxCapsuleClimbingMode::eEASY
     * @see PxCapsuleController
     */
    public void setClimbingMode(PxCapsuleClimbingModeEnum value) {
        checkNotNull();
        Raw.setClimbingMode(address, value.value);
    }

    // Functions

    /**
     * (re)sets the structure to the default.
     */
    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native void PxCapsuleControllerDesc_placed(long address);
        public static native long PxCapsuleControllerDesc();
        public static native void destroy(long address);
        public static native float getRadius(long address);
        public static native void setRadius(long address, float value);
        public static native float getHeight(long address);
        public static native void setHeight(long address, float value);
        public static native int getClimbingMode(long address);
        public static native void setClimbingMode(long address, int value);
        public static native void setToDefault(long address);
    }
}
