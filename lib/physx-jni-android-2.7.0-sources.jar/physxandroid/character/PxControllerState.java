package physxandroid.character;

import physxandroid.NativeObject;
import physxandroid.common.PxVec3;
import physxandroid.physics.PxRigidActor;
import physxandroid.physics.PxShape;

/**
 * Describes a controller's internal state.
 */
public class PxControllerState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxControllerState wrapPointer(long address) {
        return address != 0L ? new PxControllerState(address) : null;
    }
    
    public static PxControllerState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxControllerState(long address) {
        super(address);
    }

    // Constructors

    public PxControllerState() {
        address = Raw.PxControllerState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * delta position vector for the object the CCT is standing/riding on. Not always match the CCT delta when variable timesteps are used.
     */
    public PxVec3 getDeltaXP() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getDeltaXP(address));
    }

    /**
     * delta position vector for the object the CCT is standing/riding on. Not always match the CCT delta when variable timesteps are used.
     */
    public void setDeltaXP(PxVec3 value) {
        checkNotNull();
        Raw.setDeltaXP(address, value.getAddress());
    }

    /**
     * Shape on which the CCT is standing
     */
    public PxShape getTouchedShape() {
        checkNotNull();
        return PxShape.wrapPointer(Raw.getTouchedShape(address));
    }

    /**
     * Shape on which the CCT is standing
     */
    public void setTouchedShape(PxShape value) {
        checkNotNull();
        Raw.setTouchedShape(address, value.getAddress());
    }

    /**
     * Actor owning 'touchedShape'
     */
    public PxRigidActor getTouchedActor() {
        checkNotNull();
        return PxRigidActor.wrapPointer(Raw.getTouchedActor(address));
    }

    /**
     * Actor owning 'touchedShape'
     */
    public void setTouchedActor(PxRigidActor value) {
        checkNotNull();
        Raw.setTouchedActor(address, value.getAddress());
    }

    /**
     */
    public int getTouchedObstacleHandle() {
        checkNotNull();
        return Raw.getTouchedObstacleHandle(address);
    }

    /**
     */
    public void setTouchedObstacleHandle(int value) {
        checkNotNull();
        Raw.setTouchedObstacleHandle(address, value);
    }

    /**
     * Last known collision flags (PxControllerCollisionFlag)
     */
    public int getCollisionFlags() {
        checkNotNull();
        return Raw.getCollisionFlags(address);
    }

    /**
     * Last known collision flags (PxControllerCollisionFlag)
     */
    public void setCollisionFlags(int value) {
        checkNotNull();
        Raw.setCollisionFlags(address, value);
    }

    /**
     * Are we standing on another CCT?
     */
    public boolean getStandOnAnotherCCT() {
        checkNotNull();
        return Raw.getStandOnAnotherCCT(address);
    }

    /**
     * Are we standing on another CCT?
     */
    public void setStandOnAnotherCCT(boolean value) {
        checkNotNull();
        Raw.setStandOnAnotherCCT(address, value);
    }

    /**
     * Are we standing on a user-defined obstacle?
     */
    public boolean getStandOnObstacle() {
        checkNotNull();
        return Raw.getStandOnObstacle(address);
    }

    /**
     * Are we standing on a user-defined obstacle?
     */
    public void setStandOnObstacle(boolean value) {
        checkNotNull();
        Raw.setStandOnObstacle(address, value);
    }

    /**
     * is CCT moving up or not? (i.e. explicit jumping)
     */
    public boolean getIsMovingUp() {
        checkNotNull();
        return Raw.getIsMovingUp(address);
    }

    /**
     * is CCT moving up or not? (i.e. explicit jumping)
     */
    public void setIsMovingUp(boolean value) {
        checkNotNull();
        Raw.setIsMovingUp(address, value);
    }

    public static class Raw {
        public static native long PxControllerState();
        public static native void destroy(long address);
        public static native long getDeltaXP(long address);
        public static native void setDeltaXP(long address, long value);
        public static native long getTouchedShape(long address);
        public static native void setTouchedShape(long address, long value);
        public static native long getTouchedActor(long address);
        public static native void setTouchedActor(long address, long value);
        public static native int getTouchedObstacleHandle(long address);
        public static native void setTouchedObstacleHandle(long address, int value);
        public static native int getCollisionFlags(long address);
        public static native void setCollisionFlags(long address, int value);
        public static native boolean getStandOnAnotherCCT(long address);
        public static native void setStandOnAnotherCCT(long address, boolean value);
        public static native boolean getStandOnObstacle(long address);
        public static native void setStandOnObstacle(long address, boolean value);
        public static native boolean getIsMovingUp(long address);
        public static native void setIsMovingUp(long address, boolean value);
    }
}
