package physxandroid.character;


/**
 * Descriptor for a box character controller.
 * @see PxBoxController
 * @see PxControllerDesc
 */
public class PxBoxControllerDesc extends PxControllerDesc {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxBoxControllerDesc wrapPointer(long address) {
        return address != 0L ? new PxBoxControllerDesc(address) : null;
    }
    
    public static PxBoxControllerDesc arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxBoxControllerDesc(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxBoxControllerDesc
     */
    public static PxBoxControllerDesc createAt(long address) {
        Raw.PxBoxControllerDesc_placed(address);
        PxBoxControllerDesc createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxBoxControllerDesc
     */
    public static <T> PxBoxControllerDesc createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxBoxControllerDesc_placed(address);
        PxBoxControllerDesc createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * constructor sets to default.
     */
    public PxBoxControllerDesc() {
        address = Raw.PxBoxControllerDesc();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Half height
     * <p>
     * <b>Default:</b> 1.0
     */
    public float getHalfHeight() {
        checkNotNull();
        return Raw.getHalfHeight(address);
    }

    /**
     * Half height
     * <p>
     * <b>Default:</b> 1.0
     */
    public void setHalfHeight(float value) {
        checkNotNull();
        Raw.setHalfHeight(address, value);
    }

    /**
     * Half side extent
     * <p>
     * <b>Default:</b> 0.5
     */
    public float getHalfSideExtent() {
        checkNotNull();
        return Raw.getHalfSideExtent(address);
    }

    /**
     * Half side extent
     * <p>
     * <b>Default:</b> 0.5
     */
    public void setHalfSideExtent(float value) {
        checkNotNull();
        Raw.setHalfSideExtent(address, value);
    }

    /**
     * Half forward extent
     * <p>
     * <b>Default:</b> 0.5
     */
    public float getHalfForwardExtent() {
        checkNotNull();
        return Raw.getHalfForwardExtent(address);
    }

    /**
     * Half forward extent
     * <p>
     * <b>Default:</b> 0.5
     */
    public void setHalfForwardExtent(float value) {
        checkNotNull();
        Raw.setHalfForwardExtent(address, value);
    }

    // Functions

    /**
     * (re)sets the structure to the default.
     */
    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native void PxBoxControllerDesc_placed(long address);
        public static native long PxBoxControllerDesc();
        public static native void destroy(long address);
        public static native float getHalfHeight(long address);
        public static native void setHalfHeight(long address, float value);
        public static native float getHalfSideExtent(long address);
        public static native void setHalfSideExtent(long address, float value);
        public static native float getHalfForwardExtent(long address);
        public static native void setHalfForwardExtent(long address, float value);
        public static native void setToDefault(long address);
    }
}
