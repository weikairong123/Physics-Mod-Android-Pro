package physxandroid.character;

/**
 * specifies controller behavior
 */
public enum PxControllerBehaviorFlagEnum {

    /**
     * Controller can ride on touched object (i.e. when this touched object is moving horizontally). <b>Note:</b> The CCT vs. CCT case is not supported.
     */
    eCCT_CAN_RIDE_ON_OBJECT(geteCCT_CAN_RIDE_ON_OBJECT()),
    /**
     * Controller should slide on touched object
     */
    eCCT_SLIDE(geteCCT_SLIDE()),
    eCCT_USER_DEFINED_RIDE(geteCCT_USER_DEFINED_RIDE());
    public final int value;
    
    PxControllerBehaviorFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteCCT_CAN_RIDE_ON_OBJECT();
    private static int geteCCT_CAN_RIDE_ON_OBJECT() {
        de.fabmax.physxandroid.Loader.load();
        return _geteCCT_CAN_RIDE_ON_OBJECT();
    }

    private static native int _geteCCT_SLIDE();
    private static int geteCCT_SLIDE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteCCT_SLIDE();
    }

    private static native int _geteCCT_USER_DEFINED_RIDE();
    private static int geteCCT_USER_DEFINED_RIDE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteCCT_USER_DEFINED_RIDE();
    }

    private static final int LUT_SIZE = 256;
    private static final PxControllerBehaviorFlagEnum[] enumValues = values();
    private static final PxControllerBehaviorFlagEnum[] enumLut = new PxControllerBehaviorFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxControllerBehaviorFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxControllerBehaviorFlagEnum forValue(int value) {
        PxControllerBehaviorFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxControllerBehaviorFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxControllerBehaviorFlagEnum: " + value);
        }
        return enumValue;
    }
}
