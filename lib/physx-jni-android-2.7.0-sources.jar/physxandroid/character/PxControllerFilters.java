package physxandroid.character;

import physxandroid.NativeObject;
import physxandroid.physics.PxFilterData;
import physxandroid.physics.PxQueryFilterCallback;
import physxandroid.physics.PxQueryFlags;

/**
 * Filtering data for "move" call.
 * <p>
 * This class contains all filtering-related parameters for the PxController::move() call.
 * <p>
 * Collisions between a CCT and the world are filtered using the mFilterData, mFilterCallback and mFilterFlags
 * members. These parameters are internally passed to PxScene::overlap() to find objects touched by the CCT.
 * Please refer to the PxScene::overlap() documentation for details.
 * <p>
 * Collisions between a CCT and another CCT are filtered using the mCCTFilterCallback member. If this filter
 * callback is not defined, none of the CCT-vs-CCT collisions are filtered, and each CCT will collide against
 * all other CCTs.
 * <p>
 * <b>Note:</b> PxQueryFlag::eANY_HIT and PxQueryFlag::eNO_BLOCK are ignored in mFilterFlags.
 * @see PxController#move
 * @see PxControllerFilterCallback
 */
public class PxControllerFilters extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxControllerFilters wrapPointer(long address) {
        return address != 0L ? new PxControllerFilters(address) : null;
    }
    
    public static PxControllerFilters arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxControllerFilters(long address) {
        super(address);
    }

    // Constructors

    public PxControllerFilters() {
        address = Raw.PxControllerFilters();
    }

    /**
     * @param filterData WebIDL type: {@link PxFilterData} [Const]
     */
    public PxControllerFilters(PxFilterData filterData) {
        address = Raw.PxControllerFilters(filterData.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Data for internal PxQueryFilterData structure. Passed to PxScene::overlap() call.
     */
    public PxFilterData getMFilterData() {
        checkNotNull();
        return PxFilterData.wrapPointer(Raw.getMFilterData(address));
    }

    /**
     * Data for internal PxQueryFilterData structure. Passed to PxScene::overlap() call.
     */
    public void setMFilterData(PxFilterData value) {
        checkNotNull();
        Raw.setMFilterData(address, value.getAddress());
    }

    /**
     * Custom filter logic (can be NULL). Passed to PxScene::overlap() call.
     */
    public PxQueryFilterCallback getMFilterCallback() {
        checkNotNull();
        return PxQueryFilterCallback.wrapPointer(Raw.getMFilterCallback(address));
    }

    /**
     * Custom filter logic (can be NULL). Passed to PxScene::overlap() call.
     */
    public void setMFilterCallback(PxQueryFilterCallback value) {
        checkNotNull();
        Raw.setMFilterCallback(address, value.getAddress());
    }

    /**
     * Flags for internal PxQueryFilterData structure. Passed to PxScene::overlap() call.
     */
    public PxQueryFlags getMFilterFlags() {
        checkNotNull();
        return PxQueryFlags.wrapPointer(Raw.getMFilterFlags(address));
    }

    /**
     * Flags for internal PxQueryFilterData structure. Passed to PxScene::overlap() call.
     */
    public void setMFilterFlags(PxQueryFlags value) {
        checkNotNull();
        Raw.setMFilterFlags(address, value.getAddress());
    }

    /**
     * CCT-vs-CCT filter callback. If NULL, all CCT-vs-CCT collisions are kept.
     */
    public PxControllerFilterCallback getMCCTFilterCallback() {
        checkNotNull();
        return PxControllerFilterCallback.wrapPointer(Raw.getMCCTFilterCallback(address));
    }

    /**
     * CCT-vs-CCT filter callback. If NULL, all CCT-vs-CCT collisions are kept.
     */
    public void setMCCTFilterCallback(PxControllerFilterCallback value) {
        checkNotNull();
        Raw.setMCCTFilterCallback(address, value.getAddress());
    }

    public static class Raw {
        public static native long PxControllerFilters();
        public static native long PxControllerFilters(long filterData);
        public static native void destroy(long address);
        public static native long getMFilterData(long address);
        public static native void setMFilterData(long address, long value);
        public static native long getMFilterCallback(long address);
        public static native void setMFilterCallback(long address, long value);
        public static native long getMFilterFlags(long address);
        public static native void setMFilterFlags(long address, long value);
        public static native long getMCCTFilterCallback(long address);
        public static native void setMCCTFilterCallback(long address, long value);
    }
}
