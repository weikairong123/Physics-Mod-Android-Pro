package physxandroid.character;

public enum PxCapsuleClimbingModeEnum {

    /**
     * Standard mode, let the capsule climb over surfaces according to impact normal
     */
    eEASY(geteEASY()),
    /**
     * Constrained mode, try to limit climbing according to the step offset
     */
    eCONSTRAINED(geteCONSTRAINED());
    public final int value;
    
    PxCapsuleClimbingModeEnum(int value) {
        this.value = value;
    }

    private static native int _geteEASY();
    private static int geteEASY() {
        de.fabmax.physxandroid.Loader.load();
        return _geteEASY();
    }

    private static native int _geteCONSTRAINED();
    private static int geteCONSTRAINED() {
        de.fabmax.physxandroid.Loader.load();
        return _geteCONSTRAINED();
    }

    private static final int LUT_SIZE = 256;
    private static final PxCapsuleClimbingModeEnum[] enumValues = values();
    private static final PxCapsuleClimbingModeEnum[] enumLut = new PxCapsuleClimbingModeEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxCapsuleClimbingModeEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxCapsuleClimbingModeEnum forValue(int value) {
        PxCapsuleClimbingModeEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxCapsuleClimbingModeEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxCapsuleClimbingModeEnum: " + value);
        }
        return enumValue;
    }
}
