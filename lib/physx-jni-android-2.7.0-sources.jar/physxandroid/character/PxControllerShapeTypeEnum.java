package physxandroid.character;

/**
 * The type of controller, eg box, sphere or capsule.
 */
public enum PxControllerShapeTypeEnum {

    /**
     * A box controller.
     * <p>
     * <b>See also:</b> PxBoxController PxBoxControllerDesc
     */
    eBOX(geteBOX()),
    /**
     * A capsule controller
     * <p>
     * <b>See also:</b> PxCapsuleController PxCapsuleControllerDesc
     */
    eCAPSULE(geteCAPSULE());
    public final int value;
    
    PxControllerShapeTypeEnum(int value) {
        this.value = value;
    }

    private static native int _geteBOX();
    private static int geteBOX() {
        de.fabmax.physxandroid.Loader.load();
        return _geteBOX();
    }

    private static native int _geteCAPSULE();
    private static int geteCAPSULE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteCAPSULE();
    }

    private static final int LUT_SIZE = 256;
    private static final PxControllerShapeTypeEnum[] enumValues = values();
    private static final PxControllerShapeTypeEnum[] enumLut = new PxControllerShapeTypeEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxControllerShapeTypeEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxControllerShapeTypeEnum forValue(int value) {
        PxControllerShapeTypeEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxControllerShapeTypeEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxControllerShapeTypeEnum: " + value);
        }
        return enumValue;
    }
}
