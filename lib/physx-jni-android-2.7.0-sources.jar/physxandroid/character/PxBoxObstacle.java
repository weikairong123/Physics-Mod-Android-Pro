package physxandroid.character;

import physxandroid.common.PxVec3;

/**
 * A box obstacle.
 * @see PxObstacle
 * @see PxCapsuleObstacle
 * @see PxObstacleContext
 */
public class PxBoxObstacle extends PxObstacle {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxBoxObstacle wrapPointer(long address) {
        return address != 0L ? new PxBoxObstacle(address) : null;
    }
    
    public static PxBoxObstacle arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxBoxObstacle(long address) {
        super(address);
    }

    // Constructors

    public PxBoxObstacle() {
        address = Raw.PxBoxObstacle();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     */
    public PxVec3 getMHalfExtents() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getMHalfExtents(address));
    }

    /**
     */
    public void setMHalfExtents(PxVec3 value) {
        checkNotNull();
        Raw.setMHalfExtents(address, value.getAddress());
    }

    public static class Raw {
        public static native long PxBoxObstacle();
        public static native void destroy(long address);
        public static native long getMHalfExtents(long address);
        public static native void setMHalfExtents(long address, long value);
    }
}
