package physxandroid.character;

import physxandroid.physics.PxRigidActor;
import physxandroid.physics.PxShape;

/**
 * Describes a hit between a CCT and a shape. Passed to onShapeHit()
 * @see PxUserControllerHitReport#onShapeHit
 */
public class PxControllerShapeHit extends PxControllerHit {

    protected PxControllerShapeHit() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxControllerShapeHit wrapPointer(long address) {
        return address != 0L ? new PxControllerShapeHit(address) : null;
    }
    
    public static PxControllerShapeHit arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxControllerShapeHit(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * Touched shape
     */
    public PxShape getShape() {
        checkNotNull();
        return PxShape.wrapPointer(Raw.getShape(address));
    }

    /**
     * Touched shape
     */
    public void setShape(PxShape value) {
        checkNotNull();
        Raw.setShape(address, value.getAddress());
    }

    /**
     * Touched actor
     */
    public PxRigidActor getActor() {
        checkNotNull();
        return PxRigidActor.wrapPointer(Raw.getActor(address));
    }

    /**
     * Touched actor
     */
    public void setActor(PxRigidActor value) {
        checkNotNull();
        Raw.setActor(address, value.getAddress());
    }

    /**
     * touched triangle index (only for meshes/heightfields)
     */
    public int getTriangleIndex() {
        checkNotNull();
        return Raw.getTriangleIndex(address);
    }

    /**
     * touched triangle index (only for meshes/heightfields)
     */
    public void setTriangleIndex(int value) {
        checkNotNull();
        Raw.setTriangleIndex(address, value);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getShape(long address);
        public static native void setShape(long address, long value);
        public static native long getActor(long address);
        public static native void setActor(long address, long value);
        public static native int getTriangleIndex(long address);
        public static native void setTriangleIndex(long address, int value);
    }
}
