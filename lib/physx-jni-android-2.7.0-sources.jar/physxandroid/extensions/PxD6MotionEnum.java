package physxandroid.extensions;

/**
 * Used to specify the range of motions allowed for a degree of freedom in a D6 joint.
 * <p>
 * <b>See also:</b> PxD6Joint
 */
public enum PxD6MotionEnum {

    /**
     * The DOF is locked, it does not allow relative motion.
     */
    eLOCKED(geteLOCKED()),
    /**
     * The DOF is limited, it only allows motion within a specific range.
     */
    eLIMITED(geteLIMITED()),
    eFREE(geteFREE());
    public final int value;
    
    PxD6MotionEnum(int value) {
        this.value = value;
    }

    private static native int _geteLOCKED();
    private static int geteLOCKED() {
        de.fabmax.physxandroid.Loader.load();
        return _geteLOCKED();
    }

    private static native int _geteLIMITED();
    private static int geteLIMITED() {
        de.fabmax.physxandroid.Loader.load();
        return _geteLIMITED();
    }

    private static native int _geteFREE();
    private static int geteFREE() {
        de.fabmax.physxandroid.Loader.load();
        return _geteFREE();
    }

    private static final int LUT_SIZE = 256;
    private static final PxD6MotionEnum[] enumValues = values();
    private static final PxD6MotionEnum[] enumLut = new PxD6MotionEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxD6MotionEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxD6MotionEnum forValue(int value) {
        PxD6MotionEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxD6MotionEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxD6MotionEnum: " + value);
        }
        return enumValue;
    }
}
