package physxandroid.extensions;

import physxandroid.NativeObject;
import physxandroid.common.PxCollection;
import physxandroid.common.PxInputData;
import physxandroid.common.PxOutputStream;
import physxandroid.cooking.PxCookingParams;
import physxandroid.physics.PxPhysics;

/**
 * Utility functions for serialization
 * @see PxSerializationRegistry
 */
public class PxSerialization extends NativeObject {

    protected PxSerialization() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxSerialization wrapPointer(long address) {
        return address != 0L ? new PxSerialization(address) : null;
    }
    
    public static PxSerialization arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxSerialization(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param collection WebIDL type: {@link PxCollection} [Ref]
     * @param sr         WebIDL type: {@link PxSerializationRegistry} [Ref]
     * @return WebIDL type: boolean
     */
    public static boolean isSerializable(PxCollection collection, PxSerializationRegistry sr) {
        return Raw.isSerializable(collection.getAddress(), sr.getAddress());
    }

    /**
     * @param collection         WebIDL type: {@link PxCollection} [Ref]
     * @param sr                 WebIDL type: {@link PxSerializationRegistry} [Ref]
     * @param externalReferences WebIDL type: {@link PxCollection} [Const]
     * @return WebIDL type: boolean
     */
    public static boolean isSerializable(PxCollection collection, PxSerializationRegistry sr, PxCollection externalReferences) {
        return Raw.isSerializable(collection.getAddress(), sr.getAddress(), externalReferences.getAddress());
    }

    /**
     * @param collection WebIDL type: {@link PxCollection} [Ref]
     * @param sr         WebIDL type: {@link PxSerializationRegistry} [Ref]
     */
    public static void complete(PxCollection collection, PxSerializationRegistry sr) {
        Raw.complete(collection.getAddress(), sr.getAddress());
    }

    /**
     * @param collection WebIDL type: {@link PxCollection} [Ref]
     * @param sr         WebIDL type: {@link PxSerializationRegistry} [Ref]
     * @param exceptFor  WebIDL type: {@link PxCollection} [Const]
     */
    public static void complete(PxCollection collection, PxSerializationRegistry sr, PxCollection exceptFor) {
        Raw.complete(collection.getAddress(), sr.getAddress(), exceptFor.getAddress());
    }

    /**
     * @param collection   WebIDL type: {@link PxCollection} [Ref]
     * @param sr           WebIDL type: {@link PxSerializationRegistry} [Ref]
     * @param exceptFor    WebIDL type: {@link PxCollection} [Const]
     * @param followJoints WebIDL type: boolean
     */
    public static void complete(PxCollection collection, PxSerializationRegistry sr, PxCollection exceptFor, boolean followJoints) {
        Raw.complete(collection.getAddress(), sr.getAddress(), exceptFor.getAddress(), followJoints);
    }

    /**
     * @param collection WebIDL type: {@link PxCollection} [Ref]
     * @param base       WebIDL type: unsigned long long
     */
    public static void createSerialObjectIds(PxCollection collection, long base) {
        Raw.createSerialObjectIds(collection.getAddress(), base);
    }

    /**
     * @param inputData WebIDL type: {@link PxInputData} [Ref]
     * @param params    WebIDL type: {@link PxCookingParams} [Const, Ref]
     * @param sr        WebIDL type: {@link PxSerializationRegistry} [Ref]
     * @return WebIDL type: {@link PxCollection}
     */
    public static PxCollection createCollectionFromXml(PxInputData inputData, PxCookingParams params, PxSerializationRegistry sr) {
        return PxCollection.wrapPointer(Raw.createCollectionFromXml(inputData.getAddress(), params.getAddress(), sr.getAddress()));
    }

    /**
     * @param inputData    WebIDL type: {@link PxInputData} [Ref]
     * @param params       WebIDL type: {@link PxCookingParams} [Const, Ref]
     * @param sr           WebIDL type: {@link PxSerializationRegistry} [Ref]
     * @param externalRefs WebIDL type: {@link PxCollection} [Const]
     * @return WebIDL type: {@link PxCollection}
     */
    public static PxCollection createCollectionFromXml(PxInputData inputData, PxCookingParams params, PxSerializationRegistry sr, PxCollection externalRefs) {
        return PxCollection.wrapPointer(Raw.createCollectionFromXml(inputData.getAddress(), params.getAddress(), sr.getAddress(), externalRefs.getAddress()));
    }

    /**
     * @param memBlock WebIDL type: VoidPtr
     * @param sr       WebIDL type: {@link PxSerializationRegistry} [Ref]
     * @return WebIDL type: {@link PxCollection}
     */
    public static PxCollection createCollectionFromBinary(NativeObject memBlock, PxSerializationRegistry sr) {
        return PxCollection.wrapPointer(Raw.createCollectionFromBinary(memBlock.getAddress(), sr.getAddress()));
    }

    /**
     * @param memBlock     WebIDL type: VoidPtr
     * @param sr           WebIDL type: {@link PxSerializationRegistry} [Ref]
     * @param externalRefs WebIDL type: {@link PxCollection} [Const]
     * @return WebIDL type: {@link PxCollection}
     */
    public static PxCollection createCollectionFromBinary(NativeObject memBlock, PxSerializationRegistry sr, PxCollection externalRefs) {
        return PxCollection.wrapPointer(Raw.createCollectionFromBinary(memBlock.getAddress(), sr.getAddress(), externalRefs.getAddress()));
    }

    /**
     * @param outputStream WebIDL type: {@link PxOutputStream} [Ref]
     * @param collection   WebIDL type: {@link PxCollection} [Ref]
     * @param sr           WebIDL type: {@link PxSerializationRegistry} [Ref]
     * @return WebIDL type: boolean
     */
    public static boolean serializeCollectionToXml(PxOutputStream outputStream, PxCollection collection, PxSerializationRegistry sr) {
        return Raw.serializeCollectionToXml(outputStream.getAddress(), collection.getAddress(), sr.getAddress());
    }

    /**
     * @param outputStream WebIDL type: {@link PxOutputStream} [Ref]
     * @param collection   WebIDL type: {@link PxCollection} [Ref]
     * @param sr           WebIDL type: {@link PxSerializationRegistry} [Ref]
     * @param params       WebIDL type: {@link PxCookingParams} [Const]
     * @return WebIDL type: boolean
     */
    public static boolean serializeCollectionToXml(PxOutputStream outputStream, PxCollection collection, PxSerializationRegistry sr, PxCookingParams params) {
        return Raw.serializeCollectionToXml(outputStream.getAddress(), collection.getAddress(), sr.getAddress(), params.getAddress());
    }

    /**
     * @param outputStream WebIDL type: {@link PxOutputStream} [Ref]
     * @param collection   WebIDL type: {@link PxCollection} [Ref]
     * @param sr           WebIDL type: {@link PxSerializationRegistry} [Ref]
     * @param params       WebIDL type: {@link PxCookingParams} [Const]
     * @param externalRefs WebIDL type: {@link PxCollection} [Const]
     * @return WebIDL type: boolean
     */
    public static boolean serializeCollectionToXml(PxOutputStream outputStream, PxCollection collection, PxSerializationRegistry sr, PxCookingParams params, PxCollection externalRefs) {
        return Raw.serializeCollectionToXml(outputStream.getAddress(), collection.getAddress(), sr.getAddress(), params.getAddress(), externalRefs.getAddress());
    }

    /**
     * @param outputStream WebIDL type: {@link PxOutputStream} [Ref]
     * @param collection   WebIDL type: {@link PxCollection} [Ref]
     * @param sr           WebIDL type: {@link PxSerializationRegistry} [Ref]
     * @return WebIDL type: boolean
     */
    public static boolean serializeCollectionToBinary(PxOutputStream outputStream, PxCollection collection, PxSerializationRegistry sr) {
        return Raw.serializeCollectionToBinary(outputStream.getAddress(), collection.getAddress(), sr.getAddress());
    }

    /**
     * @param outputStream WebIDL type: {@link PxOutputStream} [Ref]
     * @param collection   WebIDL type: {@link PxCollection} [Ref]
     * @param sr           WebIDL type: {@link PxSerializationRegistry} [Ref]
     * @param externalRefs WebIDL type: {@link PxCollection} [Const]
     * @return WebIDL type: boolean
     */
    public static boolean serializeCollectionToBinary(PxOutputStream outputStream, PxCollection collection, PxSerializationRegistry sr, PxCollection externalRefs) {
        return Raw.serializeCollectionToBinary(outputStream.getAddress(), collection.getAddress(), sr.getAddress(), externalRefs.getAddress());
    }

    /**
     * @param outputStream WebIDL type: {@link PxOutputStream} [Ref]
     * @param collection   WebIDL type: {@link PxCollection} [Ref]
     * @param sr           WebIDL type: {@link PxSerializationRegistry} [Ref]
     * @param externalRefs WebIDL type: {@link PxCollection} [Const]
     * @param exportNames  WebIDL type: boolean
     * @return WebIDL type: boolean
     */
    public static boolean serializeCollectionToBinary(PxOutputStream outputStream, PxCollection collection, PxSerializationRegistry sr, PxCollection externalRefs, boolean exportNames) {
        return Raw.serializeCollectionToBinary(outputStream.getAddress(), collection.getAddress(), sr.getAddress(), externalRefs.getAddress(), exportNames);
    }

    /**
     * @param physics WebIDL type: {@link PxPhysics} [Ref]
     * @return WebIDL type: {@link PxSerializationRegistry}
     */
    public static PxSerializationRegistry createSerializationRegistry(PxPhysics physics) {
        return PxSerializationRegistry.wrapPointer(Raw.createSerializationRegistry(physics.getAddress()));
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native boolean isSerializable(long collection, long sr);
        public static native boolean isSerializable(long collection, long sr, long externalReferences);
        public static native void complete(long collection, long sr);
        public static native void complete(long collection, long sr, long exceptFor);
        public static native void complete(long collection, long sr, long exceptFor, boolean followJoints);
        public static native void createSerialObjectIds(long collection, long base);
        public static native long createCollectionFromXml(long inputData, long params, long sr);
        public static native long createCollectionFromXml(long inputData, long params, long sr, long externalRefs);
        public static native long createCollectionFromBinary(long memBlock, long sr);
        public static native long createCollectionFromBinary(long memBlock, long sr, long externalRefs);
        public static native boolean serializeCollectionToXml(long outputStream, long collection, long sr);
        public static native boolean serializeCollectionToXml(long outputStream, long collection, long sr, long params);
        public static native boolean serializeCollectionToXml(long outputStream, long collection, long sr, long params, long externalRefs);
        public static native boolean serializeCollectionToBinary(long outputStream, long collection, long sr);
        public static native boolean serializeCollectionToBinary(long outputStream, long collection, long sr, long externalRefs);
        public static native boolean serializeCollectionToBinary(long outputStream, long collection, long sr, long externalRefs, boolean exportNames);
        public static native long createSerializationRegistry(long physics);
    }
}
