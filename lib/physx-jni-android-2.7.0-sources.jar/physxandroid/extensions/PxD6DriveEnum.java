package physxandroid.extensions;

/**
 * Used to specify which axes of a D6 joint are driven. 
 * <p>
 * Each drive is an implicit force-limited damped spring:
 * <p>
 * force = spring * (target position - position) + damping * (targetVelocity - velocity)
 * <p>
 * Alternatively, the spring may be configured to generate a specified acceleration instead of a force.
 * <p>
 * A linear axis is affected by drive only if the corresponding drive flag is set. There are two possible models
 * for angular drive: swing/twist, which may be used to drive one or more angular degrees of freedom, or slerp,
 * which may only be used to drive all three angular degrees simultaneously. Please use #PxD6AngularDriveConfig
 * to configure the angular drive model.
 * <p>
 * <b>See also:</b> PxD6Joint PxD6AngularDriveConfig
 */
public enum PxD6DriveEnum {

    /**
     * drive along the X-axis
     */
    eX(geteX()),
    /**
     * drive along the Y-axis
     */
    eY(geteY()),
    /**
     * drive along the Z-axis
     */
    eZ(geteZ()),
    eSWING(geteSWING()),
    /**
     * rotational drive around the X-axis
     * <p>
     * <b>Note:</b> Only allowed if the angular drive configuration is set to PxD6AngularDriveConfig::eLEGACY or
     *       PxD6AngularDriveConfig::eSWING_TWIST.
     */
    eTWIST(geteTWIST()),
    /**
     * drive of all three angular degrees along a SLERP-path
     * <p>
     * <b>Note:</b> Only allowed if the angular drive configuration is set to PxD6AngularDriveConfig::eSLERP or
     *       PxD6AngularDriveConfig::eLEGACY.
     * <p>
     * <b>Note:</b> If the angular drive configuration is set to PxD6AngularDriveConfig::eLEGACY, then eSLERP takes
     *       precedence over eSWING/eTWIST
     */
    eSLERP(geteSLERP());
    public final int value;
    
    PxD6DriveEnum(int value) {
        this.value = value;
    }

    private static native int _geteX();
    private static int geteX() {
        de.fabmax.physxandroid.Loader.load();
        return _geteX();
    }

    private static native int _geteY();
    private static int geteY() {
        de.fabmax.physxandroid.Loader.load();
        return _geteY();
    }

    private static native int _geteZ();
    private static int geteZ() {
        de.fabmax.physxandroid.Loader.load();
        return _geteZ();
    }

    private static native int _geteSWING();
    private static int geteSWING() {
        de.fabmax.physxandroid.Loader.load();
        return _geteSWING();
    }

    private static native int _geteTWIST();
    private static int geteTWIST() {
        de.fabmax.physxandroid.Loader.load();
        return _geteTWIST();
    }

    private static native int _geteSLERP();
    private static int geteSLERP() {
        de.fabmax.physxandroid.Loader.load();
        return _geteSLERP();
    }

    private static final int LUT_SIZE = 256;
    private static final PxD6DriveEnum[] enumValues = values();
    private static final PxD6DriveEnum[] enumLut = new PxD6DriveEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxD6DriveEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxD6DriveEnum forValue(int value) {
        PxD6DriveEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxD6DriveEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxD6DriveEnum: " + value);
        }
        return enumValue;
    }
}
