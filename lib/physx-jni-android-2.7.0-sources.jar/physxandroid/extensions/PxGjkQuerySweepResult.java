package physxandroid.extensions;

import physxandroid.NativeObject;
import physxandroid.common.PxVec3;

public class PxGjkQuerySweepResult extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxGjkQuerySweepResult wrapPointer(long address) {
        return address != 0L ? new PxGjkQuerySweepResult(address) : null;
    }
    
    public static PxGjkQuerySweepResult arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxGjkQuerySweepResult(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxGjkQuerySweepResult
     */
    public static PxGjkQuerySweepResult createAt(long address) {
        Raw.PxGjkQuerySweepResult_placed(address);
        PxGjkQuerySweepResult createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxGjkQuerySweepResult
     */
    public static <T> PxGjkQuerySweepResult createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxGjkQuerySweepResult_placed(address);
        PxGjkQuerySweepResult createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    public PxGjkQuerySweepResult() {
        address = Raw.PxGjkQuerySweepResult();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: boolean
     */
    public boolean getSuccess() {
        checkNotNull();
        return Raw.getSuccess(address);
    }

    /**
     * @param value WebIDL type: boolean
     */
    public void setSuccess(boolean value) {
        checkNotNull();
        Raw.setSuccess(address, value);
    }

    /**
     * @return WebIDL type: float
     */
    public float getT() {
        checkNotNull();
        return Raw.getT(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setT(float value) {
        checkNotNull();
        Raw.setT(address, value);
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getN() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getN(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setN(PxVec3 value) {
        checkNotNull();
        Raw.setN(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getP() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getP(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setP(PxVec3 value) {
        checkNotNull();
        Raw.setP(address, value.getAddress());
    }

    public static class Raw {
        public static native void PxGjkQuerySweepResult_placed(long address);
        public static native long PxGjkQuerySweepResult();
        public static native void destroy(long address);
        public static native boolean getSuccess(long address);
        public static native void setSuccess(long address, boolean value);
        public static native float getT(long address);
        public static native void setT(long address, float value);
        public static native long getN(long address);
        public static native void setN(long address, long value);
        public static native long getP(long address);
        public static native void setP(long address, long value);
    }
}
