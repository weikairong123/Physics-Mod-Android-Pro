package physxandroid.extensions;

/**
 * Flags specific to the Revolute Joint.
 * <p>
 * <b>See also:</b> PxRevoluteJoint
 */
public enum PxRevoluteJointFlagEnum {

    /**
     * enable the limit
     */
    eLIMIT_ENABLED(geteLIMIT_ENABLED()),
    /**
     * enable the drive
     */
    eDRIVE_ENABLED(geteDRIVE_ENABLED()),
    eDRIVE_FREESPIN(geteDRIVE_FREESPIN());
    public final int value;
    
    PxRevoluteJointFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteLIMIT_ENABLED();
    private static int geteLIMIT_ENABLED() {
        de.fabmax.physxandroid.Loader.load();
        return _geteLIMIT_ENABLED();
    }

    private static native int _geteDRIVE_ENABLED();
    private static int geteDRIVE_ENABLED() {
        de.fabmax.physxandroid.Loader.load();
        return _geteDRIVE_ENABLED();
    }

    private static native int _geteDRIVE_FREESPIN();
    private static int geteDRIVE_FREESPIN() {
        de.fabmax.physxandroid.Loader.load();
        return _geteDRIVE_FREESPIN();
    }

    private static final int LUT_SIZE = 256;
    private static final PxRevoluteJointFlagEnum[] enumValues = values();
    private static final PxRevoluteJointFlagEnum[] enumLut = new PxRevoluteJointFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxRevoluteJointFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxRevoluteJointFlagEnum forValue(int value) {
        PxRevoluteJointFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxRevoluteJointFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxRevoluteJointFlagEnum: " + value);
        }
        return enumValue;
    }
}
