package physxandroid.extensions;

import physxandroid.NativeObject;

/**
 * Class serving as a registry for XML (RepX) and binary serializable types.
 * <p>
 * In order to serialize and deserialize objects the application needs
 * to maintain an instance of this class. It can be created with
 * PxSerialization::createSerializationRegistry() and released with
 * PxSerializationRegistry::release().
 */
public class PxSerializationRegistry extends NativeObject {

    protected PxSerializationRegistry() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxSerializationRegistry wrapPointer(long address) {
        return address != 0L ? new PxSerializationRegistry(address) : null;
    }
    
    public static PxSerializationRegistry arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxSerializationRegistry(long address) {
        super(address);
    }

    // Functions

    /**
     * Releases PxSerializationRegistry instance.
     * <p>
     * This unregisters all PhysX and PhysXExtension serializers. Make sure to unregister all custom type
     * serializers before releasing the PxSerializationRegistry.
     */
    public void release() {
        checkNotNull();
        Raw.release(address);
    }

    public static class Raw {
        public static native void release(long address);
    }
}
