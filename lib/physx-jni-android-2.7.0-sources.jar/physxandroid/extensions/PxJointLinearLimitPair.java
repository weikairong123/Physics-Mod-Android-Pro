package physxandroid.extensions;


/**
 * Describes a two-sided limit.
 */
public class PxJointLinearLimitPair extends PxJointLimitParameters {

    protected PxJointLinearLimitPair() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxJointLinearLimitPair wrapPointer(long address) {
        return address != 0L ? new PxJointLinearLimitPair(address) : null;
    }
    
    public static PxJointLinearLimitPair arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxJointLinearLimitPair(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address    Pre-allocated memory, where the object is created.
     * @param lowerLimit WebIDL type: float
     * @param upperLimit WebIDL type: float
     * @param spring     WebIDL type: {@link PxSpring} [Const, Ref]
     * @return Stack allocated object of PxJointLinearLimitPair
     */
    public static PxJointLinearLimitPair createAt(long address, float lowerLimit, float upperLimit, PxSpring spring) {
        Raw.PxJointLinearLimitPair_placed(address, lowerLimit, upperLimit, spring.getAddress());
        PxJointLinearLimitPair createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>        Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator  Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate   Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param lowerLimit WebIDL type: float
     * @param upperLimit WebIDL type: float
     * @param spring     WebIDL type: {@link PxSpring} [Const, Ref]
     * @return Stack allocated object of PxJointLinearLimitPair
     */
    public static <T> PxJointLinearLimitPair createAt(T allocator, Allocator<T> allocate, float lowerLimit, float upperLimit, PxSpring spring) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxJointLinearLimitPair_placed(address, lowerLimit, upperLimit, spring.getAddress());
        PxJointLinearLimitPair createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * construct a linear soft limit pair
     * @param lowerLimit The lower distance of the limit
     * @param upperLimit The upper distance of the limit
     * @param spring  The stiffness and damping parameters of the limit spring
     * @see PxJointLimitParameters
     */
    public PxJointLinearLimitPair(float lowerLimit, float upperLimit, PxSpring spring) {
        address = Raw.PxJointLinearLimitPair(lowerLimit, upperLimit, spring.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: float
     */
    public float getUpper() {
        checkNotNull();
        return Raw.getUpper(address);
    }

    /**
     * @param value WebIDL type: float
     */
    public void setUpper(float value) {
        checkNotNull();
        Raw.setUpper(address, value);
    }

    /**
     * the range of the limit. The upper limit must be no lower than the
     * lower limit, and if they are equal the limited degree of freedom will be treated as locked.
     * <p>
     * <b>Range:</b> See the joint on which the limit is used for details<br>
     * <b>Default:</b> lower = -PX_MAX_F32/3, upper = PX_MAX_F32/3
     */
    public float getLower() {
        checkNotNull();
        return Raw.getLower(address);
    }

    /**
     * the range of the limit. The upper limit must be no lower than the
     * lower limit, and if they are equal the limited degree of freedom will be treated as locked.
     * <p>
     * <b>Range:</b> See the joint on which the limit is used for details<br>
     * <b>Default:</b> lower = -PX_MAX_F32/3, upper = PX_MAX_F32/3
     */
    public void setLower(float value) {
        checkNotNull();
        Raw.setLower(address, value);
    }

    public static class Raw {
        public static native void PxJointLinearLimitPair_placed(long address, float lowerLimit, float upperLimit, long spring);
        public static native long PxJointLinearLimitPair(float lowerLimit, float upperLimit, long spring);
        public static native void destroy(long address);
        public static native float getUpper(long address);
        public static native void setUpper(long address, float value);
        public static native float getLower(long address);
        public static native void setLower(long address, float value);
    }
}
