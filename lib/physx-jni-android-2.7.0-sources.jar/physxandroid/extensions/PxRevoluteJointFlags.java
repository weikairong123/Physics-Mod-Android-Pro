package physxandroid.extensions;

import physxandroid.NativeObject;

public class PxRevoluteJointFlags extends NativeObject {

    protected PxRevoluteJointFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxRevoluteJointFlags wrapPointer(long address) {
        return address != 0L ? new PxRevoluteJointFlags(address) : null;
    }
    
    public static PxRevoluteJointFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxRevoluteJointFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: unsigned short
     * @return Stack allocated object of PxRevoluteJointFlags
     */
    public static PxRevoluteJointFlags createAt(long address, short flags) {
        Raw.PxRevoluteJointFlags_placed(address, flags);
        PxRevoluteJointFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: unsigned short
     * @return Stack allocated object of PxRevoluteJointFlags
     */
    public static <T> PxRevoluteJointFlags createAt(T allocator, Allocator<T> allocate, short flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxRevoluteJointFlags_placed(address, flags);
        PxRevoluteJointFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * @param flags WebIDL type: unsigned short
     */
    public PxRevoluteJointFlags(short flags) {
        address = Raw.PxRevoluteJointFlags(flags);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param flag WebIDL type: {@link PxRevoluteJointFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxRevoluteJointFlagEnum flag) {
        checkNotNull();
        return Raw.isSet(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxRevoluteJointFlagEnum} [enum]
     */
    public void raise(PxRevoluteJointFlagEnum flag) {
        checkNotNull();
        Raw.raise(address, flag.value);
    }

    /**
     * @param flag WebIDL type: {@link PxRevoluteJointFlagEnum} [enum]
     */
    public void clear(PxRevoluteJointFlagEnum flag) {
        checkNotNull();
        Raw.clear(address, flag.value);
    }

    public static class Raw {
        public static native void PxRevoluteJointFlags_placed(long address, short flags);
        public static native long PxRevoluteJointFlags(short flags);
        public static native void destroy(long address);
        public static native boolean isSet(long address, int flag);
        public static native void raise(long address, int flag);
        public static native void clear(long address, int flag);
    }
}
