package physxandroid.extensions;

/**
 * flags for configuring the drive of a PxDistanceJoint
 * <p>
 * <b>See also:</b> PxDistanceJoint
 */
public enum PxDistanceJointFlagEnum {

    eMAX_DISTANCE_ENABLED(geteMAX_DISTANCE_ENABLED()),
    eMIN_DISTANCE_ENABLED(geteMIN_DISTANCE_ENABLED()),
    eSPRING_ENABLED(geteSPRING_ENABLED());
    public final int value;
    
    PxDistanceJointFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteMAX_DISTANCE_ENABLED();
    private static int geteMAX_DISTANCE_ENABLED() {
        de.fabmax.physxandroid.Loader.load();
        return _geteMAX_DISTANCE_ENABLED();
    }

    private static native int _geteMIN_DISTANCE_ENABLED();
    private static int geteMIN_DISTANCE_ENABLED() {
        de.fabmax.physxandroid.Loader.load();
        return _geteMIN_DISTANCE_ENABLED();
    }

    private static native int _geteSPRING_ENABLED();
    private static int geteSPRING_ENABLED() {
        de.fabmax.physxandroid.Loader.load();
        return _geteSPRING_ENABLED();
    }

    private static final int LUT_SIZE = 256;
    private static final PxDistanceJointFlagEnum[] enumValues = values();
    private static final PxDistanceJointFlagEnum[] enumLut = new PxDistanceJointFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxDistanceJointFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxDistanceJointFlagEnum forValue(int value) {
        PxDistanceJointFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxDistanceJointFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxDistanceJointFlagEnum: " + value);
        }
        return enumValue;
    }
}
