package physxandroid.extensions;


/**
 * A joint which behaves in a similar way to a ball and socket.
 * <p>
 *  A spherical joint removes all linear degrees of freedom from two objects.
 * <p>
 *  The position of the joint on each actor is specified by the origin of the body's joint frame.
 * <p>
 *  A spherical joint may have a cone limit, to restrict the motion to within a certain range.
 * <p>
 *  Dirve and limits are activated by setting the appropriate flags on the joint.
 * @see PxJoint
 */
public class PxSphericalJoint extends PxJoint {

    protected PxSphericalJoint() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxSphericalJoint wrapPointer(long address) {
        return address != 0L ? new PxSphericalJoint(address) : null;
    }
    
    public static PxSphericalJoint arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxSphericalJoint(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * Get the limit cone.
     * @see PxJointLimitCone
     */
    public void setLimitCone(PxJointLimitCone limitCone) {
        checkNotNull();
        Raw.setLimitCone(address, limitCone.getAddress());
    }

    /**
     * get the swing angle of the joint from the Y axis
     */
    public float getSwingYAngle() {
        checkNotNull();
        return Raw.getSwingYAngle(address);
    }

    /**
     * get the swing angle of the joint from the Z axis
     */
    public float getSwingZAngle() {
        checkNotNull();
        return Raw.getSwingZAngle(address);
    }

    /**
     * Set the flags specific to the Spherical Joint.
     * <p>
     * <b>Default</b> PxSphericalJointFlags(0)
     * @param flags The joint flags.
     */
    public void setSphericalJointFlags(PxSphericalJointFlags flags) {
        checkNotNull();
        Raw.setSphericalJointFlags(address, flags.getAddress());
    }

    /**
     * Set a single flag specific to a Spherical Joint to true or false.
     * @param flag The flag to set or clear.
     * @param value the value to which to set the flag
     */
    public void setSphericalJointFlag(PxSphericalJointFlagEnum flag, boolean value) {
        checkNotNull();
        Raw.setSphericalJointFlag(address, flag.value, value);
    }

    /**
     * Get the flags specific to the Spherical Joint.
     * @return the joint flags
     */
    public PxSphericalJointFlags getSphericalJointFlags() {
        checkNotNull();
        return PxSphericalJointFlags.wrapPointer(Raw.getSphericalJointFlags(address));
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native void setLimitCone(long address, long limitCone);
        public static native float getSwingYAngle(long address);
        public static native float getSwingZAngle(long address);
        public static native void setSphericalJointFlags(long address, long flags);
        public static native void setSphericalJointFlag(long address, int flag, boolean value);
        public static native long getSphericalJointFlags(long address);
    }
}
