package physxandroid.extensions;


/**
 * Describes a pyramidal joint limit.
 * @see PxD6Joint
 */
public class PxJointLimitPyramid extends PxJointLimitParameters {

    protected PxJointLimitPyramid() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxJointLimitPyramid wrapPointer(long address) {
        return address != 0L ? new PxJointLimitPyramid(address) : null;
    }
    
    public static PxJointLimitPyramid arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxJointLimitPyramid(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address        Pre-allocated memory, where the object is created.
     * @param yLimitAngleMin WebIDL type: float
     * @param yLimitAngleMax WebIDL type: float
     * @param zLimitAngleMin WebIDL type: float
     * @param zLimitAngleMax WebIDL type: float
     * @return Stack allocated object of PxJointLimitPyramid
     */
    public static PxJointLimitPyramid createAt(long address, float yLimitAngleMin, float yLimitAngleMax, float zLimitAngleMin, float zLimitAngleMax) {
        Raw.PxJointLimitPyramid_placed(address, yLimitAngleMin, yLimitAngleMax, zLimitAngleMin, zLimitAngleMax);
        PxJointLimitPyramid createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>            Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator      Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate       Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param yLimitAngleMin WebIDL type: float
     * @param yLimitAngleMax WebIDL type: float
     * @param zLimitAngleMin WebIDL type: float
     * @param zLimitAngleMax WebIDL type: float
     * @return Stack allocated object of PxJointLimitPyramid
     */
    public static <T> PxJointLimitPyramid createAt(T allocator, Allocator<T> allocate, float yLimitAngleMin, float yLimitAngleMax, float zLimitAngleMin, float zLimitAngleMax) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxJointLimitPyramid_placed(address, yLimitAngleMin, yLimitAngleMax, zLimitAngleMin, zLimitAngleMax);
        PxJointLimitPyramid createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address        Pre-allocated memory, where the object is created.
     * @param yLimitAngleMin WebIDL type: float
     * @param yLimitAngleMax WebIDL type: float
     * @param zLimitAngleMin WebIDL type: float
     * @param zLimitAngleMax WebIDL type: float
     * @param spring         WebIDL type: {@link PxSpring} [Const, Ref]
     * @return Stack allocated object of PxJointLimitPyramid
     */
    public static PxJointLimitPyramid createAt(long address, float yLimitAngleMin, float yLimitAngleMax, float zLimitAngleMin, float zLimitAngleMax, PxSpring spring) {
        Raw.PxJointLimitPyramid_placed(address, yLimitAngleMin, yLimitAngleMax, zLimitAngleMin, zLimitAngleMax, spring.getAddress());
        PxJointLimitPyramid createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>            Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator      Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate       Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param yLimitAngleMin WebIDL type: float
     * @param yLimitAngleMax WebIDL type: float
     * @param zLimitAngleMin WebIDL type: float
     * @param zLimitAngleMax WebIDL type: float
     * @param spring         WebIDL type: {@link PxSpring} [Const, Ref]
     * @return Stack allocated object of PxJointLimitPyramid
     */
    public static <T> PxJointLimitPyramid createAt(T allocator, Allocator<T> allocate, float yLimitAngleMin, float yLimitAngleMax, float zLimitAngleMin, float zLimitAngleMax, PxSpring spring) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxJointLimitPyramid_placed(address, yLimitAngleMin, yLimitAngleMax, zLimitAngleMin, zLimitAngleMax, spring.getAddress());
        PxJointLimitPyramid createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * Construct a pyramid hard limit. 
     * @param yLimitAngleMin The minimum limit angle from the Y-axis of the constraint frame
     * @param yLimitAngleMax The maximum limit angle from the Y-axis of the constraint frame
     * @param zLimitAngleMin The minimum limit angle from the Z-axis of the constraint frame
     * @param zLimitAngleMax The maximum limit angle from the Z-axis of the constraint frame
     * @see PxJointLimitParameters
     */
    public PxJointLimitPyramid(float yLimitAngleMin, float yLimitAngleMax, float zLimitAngleMin, float zLimitAngleMax) {
        address = Raw.PxJointLimitPyramid(yLimitAngleMin, yLimitAngleMax, zLimitAngleMin, zLimitAngleMax);
    }

    /**
     * Construct a pyramid soft limit. 
     * @param yLimitAngleMin The minimum limit angle from the Y-axis of the constraint frame
     * @param yLimitAngleMax The maximum limit angle from the Y-axis of the constraint frame
     * @param zLimitAngleMin The minimum limit angle from the Z-axis of the constraint frame
     * @param zLimitAngleMax The maximum limit angle from the Z-axis of the constraint frame
     * @param spring   The stiffness and damping of the limit spring
     * @see PxJointLimitParameters
     */
    public PxJointLimitPyramid(float yLimitAngleMin, float yLimitAngleMax, float zLimitAngleMin, float zLimitAngleMax, PxSpring spring) {
        address = Raw.PxJointLimitPyramid(yLimitAngleMin, yLimitAngleMax, zLimitAngleMin, zLimitAngleMax, spring.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * the minimum angle from the Y axis of the constraint frame.
     * <p>
     * <b>Unit:</b> Angular: Radians
     * <b>Range:</b> Angular: (-PI,PI)<br>
     * <b>Default:</b> -PI/2
     */
    public float getYAngleMin() {
        checkNotNull();
        return Raw.getYAngleMin(address);
    }

    /**
     * the minimum angle from the Y axis of the constraint frame.
     * <p>
     * <b>Unit:</b> Angular: Radians
     * <b>Range:</b> Angular: (-PI,PI)<br>
     * <b>Default:</b> -PI/2
     */
    public void setYAngleMin(float value) {
        checkNotNull();
        Raw.setYAngleMin(address, value);
    }

    /**
     * the maximum angle from the Y axis of the constraint frame.
     * <p>
     * <b>Unit:</b> Angular: Radians
     * <b>Range:</b> Angular: (-PI,PI)<br>
     * <b>Default:</b> PI/2
     */
    public float getYAngleMax() {
        checkNotNull();
        return Raw.getYAngleMax(address);
    }

    /**
     * the maximum angle from the Y axis of the constraint frame.
     * <p>
     * <b>Unit:</b> Angular: Radians
     * <b>Range:</b> Angular: (-PI,PI)<br>
     * <b>Default:</b> PI/2
     */
    public void setYAngleMax(float value) {
        checkNotNull();
        Raw.setYAngleMax(address, value);
    }

    /**
     * the minimum angle from the Z-axis of the constraint frame.
     * <p>
     * <b>Unit:</b> Angular: Radians
     * <b>Range:</b> Angular: (-PI,PI)<br>
     * <b>Default:</b> -PI/2
     */
    public float getZAngleMin() {
        checkNotNull();
        return Raw.getZAngleMin(address);
    }

    /**
     * the minimum angle from the Z-axis of the constraint frame.
     * <p>
     * <b>Unit:</b> Angular: Radians
     * <b>Range:</b> Angular: (-PI,PI)<br>
     * <b>Default:</b> -PI/2
     */
    public void setZAngleMin(float value) {
        checkNotNull();
        Raw.setZAngleMin(address, value);
    }

    /**
     * the maximum angle from the Z-axis of the constraint frame.
     * <p>
     * <b>Unit:</b> Angular: Radians
     * <b>Range:</b> Angular: (-PI,PI)<br>
     * <b>Default:</b> PI/2
     */
    public float getZAngleMax() {
        checkNotNull();
        return Raw.getZAngleMax(address);
    }

    /**
     * the maximum angle from the Z-axis of the constraint frame.
     * <p>
     * <b>Unit:</b> Angular: Radians
     * <b>Range:</b> Angular: (-PI,PI)<br>
     * <b>Default:</b> PI/2
     */
    public void setZAngleMax(float value) {
        checkNotNull();
        Raw.setZAngleMax(address, value);
    }

    public static class Raw {
        public static native void PxJointLimitPyramid_placed(long address, float yLimitAngleMin, float yLimitAngleMax, float zLimitAngleMin, float zLimitAngleMax);
        public static native void PxJointLimitPyramid_placed(long address, float yLimitAngleMin, float yLimitAngleMax, float zLimitAngleMin, float zLimitAngleMax, long spring);
        public static native long PxJointLimitPyramid(float yLimitAngleMin, float yLimitAngleMax, float zLimitAngleMin, float zLimitAngleMax);
        public static native long PxJointLimitPyramid(float yLimitAngleMin, float yLimitAngleMax, float zLimitAngleMin, float zLimitAngleMax, long spring);
        public static native void destroy(long address);
        public static native float getYAngleMin(long address);
        public static native void setYAngleMin(long address, float value);
        public static native float getYAngleMax(long address);
        public static native void setYAngleMax(long address, float value);
        public static native float getZAngleMin(long address);
        public static native void setZAngleMin(long address, float value);
        public static native float getZAngleMax(long address);
        public static native void setZAngleMax(long address, float value);
    }
}
