package physxandroid.extensions;

/**
 * Flags specific to the prismatic joint.
 * <p>
 * <b>See also:</b> PxPrismaticJoint
 */
public enum PxPrismaticJointFlagEnum {

    eLIMIT_ENABLED(geteLIMIT_ENABLED());
    public final int value;
    
    PxPrismaticJointFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteLIMIT_ENABLED();
    private static int geteLIMIT_ENABLED() {
        de.fabmax.physxandroid.Loader.load();
        return _geteLIMIT_ENABLED();
    }

    private static final int LUT_SIZE = 256;
    private static final PxPrismaticJointFlagEnum[] enumValues = values();
    private static final PxPrismaticJointFlagEnum[] enumLut = new PxPrismaticJointFlagEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxPrismaticJointFlagEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxPrismaticJointFlagEnum forValue(int value) {
        PxPrismaticJointFlagEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxPrismaticJointFlagEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxPrismaticJointFlagEnum: " + value);
        }
        return enumValue;
    }
}
