package physxandroid.extensions;

/**
 * an enumeration for specifying one or other of the actors referenced by a joint
 * <p>
 * <b>See also:</b> PxJoint
 */
public enum PxJointActorIndexEnum {

    eACTOR0(geteACTOR0()),
    eACTOR1(geteACTOR1());
    public final int value;
    
    PxJointActorIndexEnum(int value) {
        this.value = value;
    }

    private static native int _geteACTOR0();
    private static int geteACTOR0() {
        de.fabmax.physxandroid.Loader.load();
        return _geteACTOR0();
    }

    private static native int _geteACTOR1();
    private static int geteACTOR1() {
        de.fabmax.physxandroid.Loader.load();
        return _geteACTOR1();
    }

    private static final int LUT_SIZE = 256;
    private static final PxJointActorIndexEnum[] enumValues = values();
    private static final PxJointActorIndexEnum[] enumLut = new PxJointActorIndexEnum[LUT_SIZE];
    
    static {
        for (int i = 0; i < enumValues.length; i++) {
            final PxJointActorIndexEnum it = enumValues[i];
            if (it.value >= 0 && it.value < LUT_SIZE) {
                enumLut[it.value] = it;
            }
        }
    }
    
    public static PxJointActorIndexEnum forValue(int value) {
        PxJointActorIndexEnum enumValue = null;
        if (value >= 0 && value < LUT_SIZE) {
            enumValue = enumLut[value];
        } else {
            for (int i = 0; i < enumValues.length; i++) {
                final PxJointActorIndexEnum it = enumValues[i];
                if (it.value == value) {
                    enumValue = it;
                    break;
                }
            }
        }
        if (enumValue == null) {
            throw new IllegalArgumentException("Invalid ordinal value for enum PxJointActorIndexEnum: " + value);
        }
        return enumValue;
    }
}
