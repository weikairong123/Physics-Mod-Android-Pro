package physxandroid.extensions;

import physxandroid.NativeObject;
import physxandroid.common.PxOutputStream;

/**
 * default implementation of a memory write stream
 * @see physxandroid.common.PxOutputStream
 */
public class PxDefaultMemoryOutputStream extends PxOutputStream {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxDefaultMemoryOutputStream wrapPointer(long address) {
        return address != 0L ? new PxDefaultMemoryOutputStream(address) : null;
    }
    
    public static PxDefaultMemoryOutputStream arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxDefaultMemoryOutputStream(long address) {
        super(address);
    }

    // Constructors

    public PxDefaultMemoryOutputStream() {
        address = Raw.PxDefaultMemoryOutputStream();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * @param src   WebIDL type: VoidPtr
     * @param count WebIDL type: unsigned long
     */
    public void write(NativeObject src, int count) {
        checkNotNull();
        Raw.write(address, src.getAddress(), count);
    }

    /**
     * @return WebIDL type: unsigned long
     */
    public int getSize() {
        checkNotNull();
        return Raw.getSize(address);
    }

    /**
     * @return WebIDL type: VoidPtr
     */
    public NativeObject getData() {
        checkNotNull();
        return NativeObject.wrapPointer(Raw.getData(address));
    }

    public static class Raw {
        public static native long PxDefaultMemoryOutputStream();
        public static native void destroy(long address);
        public static native void write(long address, long src, int count);
        public static native int getSize(long address);
        public static native long getData(long address);
    }
}
