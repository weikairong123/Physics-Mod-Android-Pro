package physxandroid.extensions;


/**
 * Describes an elliptical conical joint limit. Note that very small or highly elliptical limit cones may 
 * result in jitter.
 * @see PxD6Joint
 * @see PxSphericalJoint
 */
public class PxJointLimitCone extends PxJointLimitParameters {

    protected PxJointLimitCone() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxJointLimitCone wrapPointer(long address) {
        return address != 0L ? new PxJointLimitCone(address) : null;
    }
    
    public static PxJointLimitCone arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxJointLimitCone(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address     Pre-allocated memory, where the object is created.
     * @param yLimitAngle WebIDL type: float
     * @param zLimitAngle WebIDL type: float
     * @return Stack allocated object of PxJointLimitCone
     */
    public static PxJointLimitCone createAt(long address, float yLimitAngle, float zLimitAngle) {
        Raw.PxJointLimitCone_placed(address, yLimitAngle, zLimitAngle);
        PxJointLimitCone createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>         Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator   Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate    Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param yLimitAngle WebIDL type: float
     * @param zLimitAngle WebIDL type: float
     * @return Stack allocated object of PxJointLimitCone
     */
    public static <T> PxJointLimitCone createAt(T allocator, Allocator<T> allocate, float yLimitAngle, float zLimitAngle) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxJointLimitCone_placed(address, yLimitAngle, zLimitAngle);
        PxJointLimitCone createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address     Pre-allocated memory, where the object is created.
     * @param yLimitAngle WebIDL type: float
     * @param zLimitAngle WebIDL type: float
     * @param spring      WebIDL type: {@link PxSpring} [Const, Ref]
     * @return Stack allocated object of PxJointLimitCone
     */
    public static PxJointLimitCone createAt(long address, float yLimitAngle, float zLimitAngle, PxSpring spring) {
        Raw.PxJointLimitCone_placed(address, yLimitAngle, zLimitAngle, spring.getAddress());
        PxJointLimitCone createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>         Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator   Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate    Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param yLimitAngle WebIDL type: float
     * @param zLimitAngle WebIDL type: float
     * @param spring      WebIDL type: {@link PxSpring} [Const, Ref]
     * @return Stack allocated object of PxJointLimitCone
     */
    public static <T> PxJointLimitCone createAt(T allocator, Allocator<T> allocate, float yLimitAngle, float zLimitAngle, PxSpring spring) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.PxJointLimitCone_placed(address, yLimitAngle, zLimitAngle, spring.getAddress());
        PxJointLimitCone createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * Construct a cone hard limit. 
     * @param yLimitAngle The limit angle from the Y-axis of the constraint frame
     * @param zLimitAngle The limit angle from the Z-axis of the constraint frame
     * @see PxJointLimitParameters
     */
    public PxJointLimitCone(float yLimitAngle, float zLimitAngle) {
        address = Raw.PxJointLimitCone(yLimitAngle, zLimitAngle);
    }

    /**
     * Construct a cone soft limit. 
     * @param yLimitAngle The limit angle from the Y-axis of the constraint frame
     * @param zLimitAngle The limit angle from the Z-axis of the constraint frame
     * @param spring  The stiffness and damping of the limit spring
     * @see PxJointLimitParameters
     */
    public PxJointLimitCone(float yLimitAngle, float zLimitAngle, PxSpring spring) {
        address = Raw.PxJointLimitCone(yLimitAngle, zLimitAngle, spring.getAddress());
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * the maximum angle from the Y axis of the constraint frame.
     * <p>
     * <b>Unit:</b> Angular: Radians
     * <b>Range:</b> Angular: (0,PI)<br>
     * <b>Default:</b> PI/2
     */
    public float getYAngle() {
        checkNotNull();
        return Raw.getYAngle(address);
    }

    /**
     * the maximum angle from the Y axis of the constraint frame.
     * <p>
     * <b>Unit:</b> Angular: Radians
     * <b>Range:</b> Angular: (0,PI)<br>
     * <b>Default:</b> PI/2
     */
    public void setYAngle(float value) {
        checkNotNull();
        Raw.setYAngle(address, value);
    }

    /**
     * the maximum angle from the Z-axis of the constraint frame.
     * <p>
     * <b>Unit:</b> Angular: Radians
     * <b>Range:</b> Angular: (0,PI)<br>
     * <b>Default:</b> PI/2
     */
    public float getZAngle() {
        checkNotNull();
        return Raw.getZAngle(address);
    }

    /**
     * the maximum angle from the Z-axis of the constraint frame.
     * <p>
     * <b>Unit:</b> Angular: Radians
     * <b>Range:</b> Angular: (0,PI)<br>
     * <b>Default:</b> PI/2
     */
    public void setZAngle(float value) {
        checkNotNull();
        Raw.setZAngle(address, value);
    }

    public static class Raw {
        public static native void PxJointLimitCone_placed(long address, float yLimitAngle, float zLimitAngle);
        public static native void PxJointLimitCone_placed(long address, float yLimitAngle, float zLimitAngle, long spring);
        public static native long PxJointLimitCone(float yLimitAngle, float zLimitAngle);
        public static native long PxJointLimitCone(float yLimitAngle, float zLimitAngle, long spring);
        public static native void destroy(long address);
        public static native float getYAngle(long address);
        public static native void setYAngle(long address, float value);
        public static native float getZAngle(long address);
        public static native void setZAngle(long address, float value);
    }
}
