package physxandroid.extensions;


/**
 * a joint that maintains an upper or lower bound (or both) on the distance between two points on different objects
 * @see PxJoint
 */
public class PxDistanceJoint extends PxJoint {

    protected PxDistanceJoint() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxDistanceJoint wrapPointer(long address) {
        return address != 0L ? new PxDistanceJoint(address) : null;
    }
    
    public static PxDistanceJoint arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxDistanceJoint(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Functions

    /**
     * Return the current distance of the joint
     */
    public float getDistance() {
        checkNotNull();
        return Raw.getDistance(address);
    }

    /**
     * Set the allowed minimum distance for the joint.
     * <p>
     * The minimum distance must be no more than the maximum distance
     * <p>
     * <b>Default</b> 0.0f
     * <b>Range</b> [0, PX_MAX_F32)
     * @param distance the minimum distance
     * @see #getMinDistance
     */
    public void setMinDistance(float distance) {
        checkNotNull();
        Raw.setMinDistance(address, distance);
    }

    /**
     * Get the allowed minimum distance for the joint.
     * @return the allowed minimum distance
     * @see #setMinDistance
     */
    public float getMinDistance() {
        checkNotNull();
        return Raw.getMinDistance(address);
    }

    /**
     * Set the allowed maximum distance for the joint.
     * <p>
     * The maximum distance must be no less than the minimum distance. 
     * <p>
     * <b>Default</b> 0.0f
     * <b>Range</b> [0, PX_MAX_F32)
     * @param distance the maximum distance
     * @see #getMinDistance
     */
    public void setMaxDistance(float distance) {
        checkNotNull();
        Raw.setMaxDistance(address, distance);
    }

    /**
     * Get the allowed maximum distance for the joint.
     * @return the allowed maximum distance
     * @see #setMaxDistance
     */
    public float getMaxDistance() {
        checkNotNull();
        return Raw.getMaxDistance(address);
    }

    /**
     * Set the error tolerance of the joint.
     * @param tolerance the distance beyond the allowed range at which the joint becomes active
     * @see #getTolerance
     */
    public void setTolerance(float tolerance) {
        checkNotNull();
        Raw.setTolerance(address, tolerance);
    }

    /**
     * Get the error tolerance of the joint.
     * <p>
     * the distance beyond the joint's [min, max] range before the joint becomes active.
     * <p>
     * <b>Default</b> 0.25f * PxTolerancesScale::length
     * <b>Range</b> (0, PX_MAX_F32)
     * <p>
     * This value should be used to ensure that if the minimum distance is zero and the 
     * spring function is in use, the rest length of the spring is non-zero. 
     * @see #setTolerance
     */
    public float getTolerance() {
        checkNotNull();
        return Raw.getTolerance(address);
    }

    /**
     * Set the strength of the joint spring.
     * <p>
     * The spring is used if enabled, and the distance exceeds the range [min-error, max+error].
     * <p>
     * <b>Default</b> 0.0f
     * <b>Range</b> [0, PX_MAX_F32)
     * @param stiffness the spring strength of the joint
     * @see #getStiffness
     */
    public void setStiffness(float stiffness) {
        checkNotNull();
        Raw.setStiffness(address, stiffness);
    }

    /**
     * Get the strength of the joint spring.
     * @return stiffness the spring strength of the joint
     * @see #setStiffness
     */
    public float getStiffness() {
        checkNotNull();
        return Raw.getStiffness(address);
    }

    /**
     * Set the damping of the joint spring.
     * <p>
     * The spring is used if enabled, and the distance exceeds the range [min-error, max+error].
     * <p>
     * <b>Default</b> 0.0f
     * <b>Range</b> [0, PX_MAX_F32)
     * @param damping the degree of damping of the joint spring of the joint
     * @see #setDamping
     */
    public void setDamping(float damping) {
        checkNotNull();
        Raw.setDamping(address, damping);
    }

    /**
     * Get the damping of the joint spring.
     * @return the degree of damping of the joint spring of the joint
     * @see #setDamping
     */
    public float getDamping() {
        checkNotNull();
        return Raw.getDamping(address);
    }

    /**
     * Set the flags specific to the Distance Joint.
     * <p>
     * <b>Default</b> PxDistanceJointFlag::eMAX_DISTANCE_ENABLED
     * @param flags The joint flags.
     */
    public void setDistanceJointFlags(PxDistanceJointFlags flags) {
        checkNotNull();
        Raw.setDistanceJointFlags(address, flags.getAddress());
    }

    /**
     * Set a single flag specific to a Distance Joint to true or false.
     * @param flag The flag to set or clear.
     * @param value the value to which to set the flag
     */
    public void setDistanceJointFlag(PxDistanceJointFlagEnum flag, boolean value) {
        checkNotNull();
        Raw.setDistanceJointFlag(address, flag.value, value);
    }

    /**
     * Get the flags specific to the Distance Joint.
     * @return the joint flags
     */
    public PxDistanceJointFlags getDistanceJointFlags() {
        checkNotNull();
        return PxDistanceJointFlags.wrapPointer(Raw.getDistanceJointFlags(address));
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native float getDistance(long address);
        public static native void setMinDistance(long address, float distance);
        public static native float getMinDistance(long address);
        public static native void setMaxDistance(long address, float distance);
        public static native float getMaxDistance(long address);
        public static native void setTolerance(long address, float tolerance);
        public static native float getTolerance(long address);
        public static native void setStiffness(long address, float stiffness);
        public static native float getStiffness(long address);
        public static native void setDamping(long address, float damping);
        public static native float getDamping(long address);
        public static native void setDistanceJointFlags(long address, long flags);
        public static native void setDistanceJointFlag(long address, int flag, boolean value);
        public static native long getDistanceJointFlags(long address);
    }
}
