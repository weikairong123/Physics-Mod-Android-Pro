package physx.common;

import physx.NativeObject;

public class PxTransform extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxTransform wrapPointer(long address) {
        return address != 0L ? new PxTransform(address) : null;
    }
    
    public static PxTransform arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxTransform(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxTransform
     */
    public static PxTransform createAt(long address) {
        __placement_new_PxTransform(address);
        PxTransform createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxTransform
     */
    public static <T> PxTransform createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF); 
        __placement_new_PxTransform(address);
        PxTransform createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    private static native void __placement_new_PxTransform(long address);

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param r       WebIDL type: {@link PxIDENTITYEnum} [enum]
     * @return Stack allocated object of PxTransform
     */
    public static PxTransform createAt(long address, PxIDENTITYEnum r) {
        __placement_new_PxTransform(address, r.value);
        PxTransform createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param r         WebIDL type: {@link PxIDENTITYEnum} [enum]
     * @return Stack allocated object of PxTransform
     */
    public static <T> PxTransform createAt(T allocator, Allocator<T> allocate, PxIDENTITYEnum r) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF); 
        __placement_new_PxTransform(address, r.value);
        PxTransform createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    private static native void __placement_new_PxTransform(long address, int r);

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param p0      WebIDL type: {@link PxVec3} [Const, Ref]
     * @param q0      WebIDL type: {@link PxQuat} [Const, Ref]
     * @return Stack allocated object of PxTransform
     */
    public static PxTransform createAt(long address, PxVec3 p0, PxQuat q0) {
        __placement_new_PxTransform(address, p0.getAddress(), q0.getAddress());
        PxTransform createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param p0        WebIDL type: {@link PxVec3} [Const, Ref]
     * @param q0        WebIDL type: {@link PxQuat} [Const, Ref]
     * @return Stack allocated object of PxTransform
     */
    public static <T> PxTransform createAt(T allocator, Allocator<T> allocate, PxVec3 p0, PxQuat q0) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF); 
        __placement_new_PxTransform(address, p0.getAddress(), q0.getAddress());
        PxTransform createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    private static native void __placement_new_PxTransform(long address, long p0, long q0);

    // Constructors

    public PxTransform() {
        address = _PxTransform();
    }
    private static native long _PxTransform();

    /**
     * @param r WebIDL type: {@link PxIDENTITYEnum} [enum]
     */
    public PxTransform(PxIDENTITYEnum r) {
        address = _PxTransform(r.value);
    }
    private static native long _PxTransform(int r);

    /**
     * @param p0 WebIDL type: {@link PxVec3} [Const, Ref]
     * @param q0 WebIDL type: {@link PxQuat} [Const, Ref]
     */
    public PxTransform(PxVec3 p0, PxQuat q0) {
        address = _PxTransform(p0.getAddress(), q0.getAddress());
    }
    private static native long _PxTransform(long p0, long q0);

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

    // Attributes

    /**
     * @return WebIDL type: {@link PxQuat} [Value]
     */
    public PxQuat getQ() {
        checkNotNull();
        return PxQuat.wrapPointer(_getQ(address));
    }
    private static native long _getQ(long address);

    /**
     * @param value WebIDL type: {@link PxQuat} [Value]
     */
    public void setQ(PxQuat value) {
        checkNotNull();
        _setQ(address, value.getAddress());
    }
    private static native void _setQ(long address, long value);

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getP() {
        checkNotNull();
        return PxVec3.wrapPointer(_getP(address));
    }
    private static native long _getP(long address);

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setP(PxVec3 value) {
        checkNotNull();
        _setP(address, value.getAddress());
    }
    private static native void _setP(long address, long value);

}
