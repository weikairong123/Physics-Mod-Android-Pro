package physx.extensions;


/**
 * Describes a two-sided limit.
 */
public class PxJointLinearLimitPair extends PxJointLimitParameters {

    protected PxJointLinearLimitPair() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxJointLinearLimitPair wrapPointer(long address) {
        return address != 0L ? new PxJointLinearLimitPair(address) : null;
    }
    
    public static PxJointLinearLimitPair arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxJointLinearLimitPair(long address) {
        super(address);
    }

    // Constructors

    /**
     * construct a linear soft limit pair
     * @param lowerLimit The lower distance of the limit
     * @param upperLimit The upper distance of the limit
     * @param spring  The stiffness and damping parameters of the limit spring
     * @see PxJointLimitParameters
     */
    public PxJointLinearLimitPair(float lowerLimit, float upperLimit, PxSpring spring) {
        address = _PxJointLinearLimitPair(lowerLimit, upperLimit, spring.getAddress());
    }
    private static native long _PxJointLinearLimitPair(float lowerLimit, float upperLimit, long spring);

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

    // Attributes

    /**
     * @return WebIDL type: float
     */
    public float getUpper() {
        checkNotNull();
        return _getUpper(address);
    }
    private static native float _getUpper(long address);

    /**
     * @param value WebIDL type: float
     */
    public void setUpper(float value) {
        checkNotNull();
        _setUpper(address, value);
    }
    private static native void _setUpper(long address, float value);

    /**
     * the range of the limit. The upper limit must be no lower than the
     * lower limit, and if they are equal the limited degree of freedom will be treated as locked.
     * <p>
     * <b>Range:</b> See the joint on which the limit is used for details<br>
     * <b>Default:</b> lower = -PX_MAX_F32/3, upper = PX_MAX_F32/3
     */
    public float getLower() {
        checkNotNull();
        return _getLower(address);
    }
    private static native float _getLower(long address);

    /**
     * the range of the limit. The upper limit must be no lower than the
     * lower limit, and if they are equal the limited degree of freedom will be treated as locked.
     * <p>
     * <b>Range:</b> See the joint on which the limit is used for details<br>
     * <b>Default:</b> lower = -PX_MAX_F32/3, upper = PX_MAX_F32/3
     */
    public void setLower(float value) {
        checkNotNull();
        _setLower(address, value);
    }
    private static native void _setLower(long address, float value);

}
