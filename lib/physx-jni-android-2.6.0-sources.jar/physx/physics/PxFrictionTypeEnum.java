package physx.physics;

public enum PxFrictionTypeEnum {

    ePATCH(getePATCH()),
    eFRICTION_COUNT(geteFRICTION_COUNT());
    public final int value;
    
    PxFrictionTypeEnum(int value) {
        this.value = value;
    }

    private static native int _getePATCH();
    private static int getePATCH() {
        de.fabmax.physxjni.Loader.load();
        return _getePATCH();
    }

    private static native int _geteFRICTION_COUNT();
    private static int geteFRICTION_COUNT() {
        de.fabmax.physxjni.Loader.load();
        return _geteFRICTION_COUNT();
    }

    public static PxFrictionTypeEnum forValue(int value) {
        for (int i = 0; i < values().length; i++) {
            if (values()[i].value == value) {
                return values()[i];
            }
        }
        throw new IllegalArgumentException("Unknown value for enum PxFrictionTypeEnum: " + value);
    }

}
