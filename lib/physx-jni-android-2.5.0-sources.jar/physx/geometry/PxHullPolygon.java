package physx.geometry;

import physx.NativeObject;

/**
 * Polygon data
 * <p>
 * Plane format: (mPlane[0],mPlane[1],mPlane[2]).dot(x) + mPlane[3] = 0
 * With the normal outward-facing from the hull.
 */
public class PxHullPolygon extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxHullPolygon wrapPointer(long address) {
        return address != 0L ? new PxHullPolygon(address) : null;
    }
    
    public static PxHullPolygon arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxHullPolygon(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxHullPolygon
     */
    public static PxHullPolygon createAt(long address) {
        __placement_new_PxHullPolygon(address);
        PxHullPolygon createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxHullPolygon
     */
    public static <T> PxHullPolygon createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF); 
        __placement_new_PxHullPolygon(address);
        PxHullPolygon createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    private static native void __placement_new_PxHullPolygon(long address);

    // Constructors

    public PxHullPolygon() {
        address = _PxHullPolygon();
    }
    private static native long _PxHullPolygon();

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

    // Attributes

    /**
     * @param index Array index
     * @return WebIDL type: float
     */
    public float getMPlane(int index) {
        checkNotNull();
        return _getMPlane(address, index);
    }
    private static native float _getMPlane(long address, int index);

    /**
     * @param index Array index
     * @param value WebIDL type: float
     */
    public void setMPlane(int index, float value) {
        checkNotNull();
        _setMPlane(address, index, value);
    }
    private static native void _setMPlane(long address, int index, float value);

    /**
     * Number of vertices/edges in the polygon
     */
    public short getMNbVerts() {
        checkNotNull();
        return _getMNbVerts(address);
    }
    private static native short _getMNbVerts(long address);

    /**
     * Number of vertices/edges in the polygon
     */
    public void setMNbVerts(short value) {
        checkNotNull();
        _setMNbVerts(address, value);
    }
    private static native void _setMNbVerts(long address, short value);

    /**
     * Offset in index buffer
     */
    public short getMIndexBase() {
        checkNotNull();
        return _getMIndexBase(address);
    }
    private static native short _getMIndexBase(long address);

    /**
     * Offset in index buffer
     */
    public void setMIndexBase(short value) {
        checkNotNull();
        _setMIndexBase(address, value);
    }
    private static native void _setMIndexBase(long address, short value);

}
