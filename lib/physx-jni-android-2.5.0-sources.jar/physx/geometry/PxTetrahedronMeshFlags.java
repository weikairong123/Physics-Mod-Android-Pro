package physx.geometry;

import physx.NativeObject;

public class PxTetrahedronMeshFlags extends NativeObject {

    protected PxTetrahedronMeshFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxTetrahedronMeshFlags wrapPointer(long address) {
        return address != 0L ? new PxTetrahedronMeshFlags(address) : null;
    }
    
    public static PxTetrahedronMeshFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxTetrahedronMeshFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: octet
     * @return Stack allocated object of PxTetrahedronMeshFlags
     */
    public static PxTetrahedronMeshFlags createAt(long address, byte flags) {
        __placement_new_PxTetrahedronMeshFlags(address, flags);
        PxTetrahedronMeshFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: octet
     * @return Stack allocated object of PxTetrahedronMeshFlags
     */
    public static <T> PxTetrahedronMeshFlags createAt(T allocator, Allocator<T> allocate, byte flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF); 
        __placement_new_PxTetrahedronMeshFlags(address, flags);
        PxTetrahedronMeshFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    private static native void __placement_new_PxTetrahedronMeshFlags(long address, byte flags);

    // Constructors

    /**
     * @param flags WebIDL type: octet
     */
    public PxTetrahedronMeshFlags(byte flags) {
        address = _PxTetrahedronMeshFlags(flags);
    }
    private static native long _PxTetrahedronMeshFlags(byte flags);

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

    // Functions

    /**
     * @param flag WebIDL type: {@link PxTetrahedronMeshFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxTetrahedronMeshFlagEnum flag) {
        checkNotNull();
        return _isSet(address, flag.value);
    }
    private static native boolean _isSet(long address, int flag);

    /**
     * @param flag WebIDL type: {@link PxTetrahedronMeshFlagEnum} [enum]
     */
    public void raise(PxTetrahedronMeshFlagEnum flag) {
        checkNotNull();
        _raise(address, flag.value);
    }
    private static native void _raise(long address, int flag);

    /**
     * @param flag WebIDL type: {@link PxTetrahedronMeshFlagEnum} [enum]
     */
    public void clear(PxTetrahedronMeshFlagEnum flag) {
        checkNotNull();
        _clear(address, flag.value);
    }
    private static native void _clear(long address, int flag);

}
