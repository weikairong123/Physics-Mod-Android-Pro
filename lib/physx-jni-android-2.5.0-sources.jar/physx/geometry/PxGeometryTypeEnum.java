package physx.geometry;

/**
 * A geometry type.
 * <p>
 * Used to distinguish the type of a ::PxGeometry object.
 */
public enum PxGeometryTypeEnum {

    eSPHERE(geteSPHERE()),
    ePLANE(getePLANE()),
    eCAPSULE(geteCAPSULE()),
    eBOX(geteBOX()),
    eCONVEXMESH(geteCONVEXMESH()),
    eTRIANGLEMESH(geteTRIANGLEMESH()),
    eHEIGHTFIELD(geteHEIGHTFIELD()),
    eCUSTOM(geteCUSTOM());
    public final int value;
    
    PxGeometryTypeEnum(int value) {
        this.value = value;
    }

    private static native int _geteSPHERE();
    private static int geteSPHERE() {
        de.fabmax.physxjni.Loader.load();
        return _geteSPHERE();
    }

    private static native int _getePLANE();
    private static int getePLANE() {
        de.fabmax.physxjni.Loader.load();
        return _getePLANE();
    }

    private static native int _geteCAPSULE();
    private static int geteCAPSULE() {
        de.fabmax.physxjni.Loader.load();
        return _geteCAPSULE();
    }

    private static native int _geteBOX();
    private static int geteBOX() {
        de.fabmax.physxjni.Loader.load();
        return _geteBOX();
    }

    private static native int _geteCONVEXMESH();
    private static int geteCONVEXMESH() {
        de.fabmax.physxjni.Loader.load();
        return _geteCONVEXMESH();
    }

    private static native int _geteTRIANGLEMESH();
    private static int geteTRIANGLEMESH() {
        de.fabmax.physxjni.Loader.load();
        return _geteTRIANGLEMESH();
    }

    private static native int _geteHEIGHTFIELD();
    private static int geteHEIGHTFIELD() {
        de.fabmax.physxjni.Loader.load();
        return _geteHEIGHTFIELD();
    }

    private static native int _geteCUSTOM();
    private static int geteCUSTOM() {
        de.fabmax.physxjni.Loader.load();
        return _geteCUSTOM();
    }

    public static PxGeometryTypeEnum forValue(int value) {
        for (int i = 0; i < values().length; i++) {
            if (values()[i].value == value) {
                return values()[i];
            }
        }
        throw new IllegalArgumentException("Unknown value for enum PxGeometryTypeEnum: " + value);
    }

}
