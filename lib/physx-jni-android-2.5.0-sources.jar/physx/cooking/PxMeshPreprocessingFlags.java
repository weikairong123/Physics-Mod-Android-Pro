package physx.cooking;

import physx.NativeObject;

public class PxMeshPreprocessingFlags extends NativeObject {

    protected PxMeshPreprocessingFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxMeshPreprocessingFlags wrapPointer(long address) {
        return address != 0L ? new PxMeshPreprocessingFlags(address) : null;
    }
    
    public static PxMeshPreprocessingFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxMeshPreprocessingFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: unsigned long
     * @return Stack allocated object of PxMeshPreprocessingFlags
     */
    public static PxMeshPreprocessingFlags createAt(long address, int flags) {
        __placement_new_PxMeshPreprocessingFlags(address, flags);
        PxMeshPreprocessingFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: unsigned long
     * @return Stack allocated object of PxMeshPreprocessingFlags
     */
    public static <T> PxMeshPreprocessingFlags createAt(T allocator, Allocator<T> allocate, int flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF); 
        __placement_new_PxMeshPreprocessingFlags(address, flags);
        PxMeshPreprocessingFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    private static native void __placement_new_PxMeshPreprocessingFlags(long address, int flags);

    // Constructors

    /**
     * @param flags WebIDL type: unsigned long
     */
    public PxMeshPreprocessingFlags(int flags) {
        address = _PxMeshPreprocessingFlags(flags);
    }
    private static native long _PxMeshPreprocessingFlags(int flags);

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

    // Functions

    /**
     * @param flag WebIDL type: {@link PxMeshPreprocessingFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxMeshPreprocessingFlagEnum flag) {
        checkNotNull();
        return _isSet(address, flag.value);
    }
    private static native boolean _isSet(long address, int flag);

    /**
     * @param flag WebIDL type: {@link PxMeshPreprocessingFlagEnum} [enum]
     */
    public void raise(PxMeshPreprocessingFlagEnum flag) {
        checkNotNull();
        _raise(address, flag.value);
    }
    private static native void _raise(long address, int flag);

    /**
     * @param flag WebIDL type: {@link PxMeshPreprocessingFlagEnum} [enum]
     */
    public void clear(PxMeshPreprocessingFlagEnum flag) {
        checkNotNull();
        _clear(address, flag.value);
    }
    private static native void _clear(long address, int flag);

}
