package physx.cooking;

/**
 * Enum for the set of mesh pre-processing parameters.
 */
public enum PxMeshPreprocessingFlagEnum {

    /**
     * When set, mesh welding is performed. See PxCookingParams::meshWeldTolerance. Mesh cleaning must be enabled.
     */
    eWELD_VERTICES(geteWELD_VERTICES()),
    /**
     * When set, mesh cleaning is disabled. This makes cooking faster.
     * <p>
     * When mesh cleaning is disabled, mesh welding is also disabled.
     * <p>
     * It is recommended to use only meshes that passed during validateTriangleMesh.
     */
    eDISABLE_CLEAN_MESH(geteDISABLE_CLEAN_MESH()),
    /**
     * When set, active edges are not computed and just enabled for all edges. This makes cooking faster but contact generation slower.
     */
    eDISABLE_ACTIVE_EDGES_PRECOMPUTE(geteDISABLE_ACTIVE_EDGES_PRECOMPUTE()),
    /**
     * When set, 32-bit indices will always be created regardless of triangle count.
     * <p>
     * <b>Note:</b> By default mesh will be created with 16-bit indices for triangle count &lt;= 0xFFFF and 32-bit otherwise.
     */
    eFORCE_32BIT_INDICES(geteFORCE_32BIT_INDICES());
    public final int value;
    
    PxMeshPreprocessingFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteWELD_VERTICES();
    private static int geteWELD_VERTICES() {
        de.fabmax.physxjni.Loader.load();
        return _geteWELD_VERTICES();
    }

    private static native int _geteDISABLE_CLEAN_MESH();
    private static int geteDISABLE_CLEAN_MESH() {
        de.fabmax.physxjni.Loader.load();
        return _geteDISABLE_CLEAN_MESH();
    }

    private static native int _geteDISABLE_ACTIVE_EDGES_PRECOMPUTE();
    private static int geteDISABLE_ACTIVE_EDGES_PRECOMPUTE() {
        de.fabmax.physxjni.Loader.load();
        return _geteDISABLE_ACTIVE_EDGES_PRECOMPUTE();
    }

    private static native int _geteFORCE_32BIT_INDICES();
    private static int geteFORCE_32BIT_INDICES() {
        de.fabmax.physxjni.Loader.load();
        return _geteFORCE_32BIT_INDICES();
    }

    public static PxMeshPreprocessingFlagEnum forValue(int value) {
        for (int i = 0; i < values().length; i++) {
            if (values()[i].value == value) {
                return values()[i];
            }
        }
        throw new IllegalArgumentException("Unknown value for enum PxMeshPreprocessingFlagEnum: " + value);
    }

}
