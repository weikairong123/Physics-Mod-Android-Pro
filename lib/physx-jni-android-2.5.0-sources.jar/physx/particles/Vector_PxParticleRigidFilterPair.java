package physx.particles;

import physx.NativeObject;
import physx.PlatformChecks;

@Deprecated
public class Vector_PxParticleRigidFilterPair extends NativeObject {

    static {
        PlatformChecks.requirePlatform(3, "physx.particles.Vector_PxParticleRigidFilterPair");
    }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static Vector_PxParticleRigidFilterPair wrapPointer(long address) {
        return address != 0L ? new Vector_PxParticleRigidFilterPair(address) : null;
    }
    
    public static Vector_PxParticleRigidFilterPair arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected Vector_PxParticleRigidFilterPair(long address) {
        super(address);
    }

    // Constructors

    public Vector_PxParticleRigidFilterPair() {
        address = _Vector_PxParticleRigidFilterPair();
    }
    private static native long _Vector_PxParticleRigidFilterPair();

    /**
     * @param size WebIDL type: unsigned long
     */
    public Vector_PxParticleRigidFilterPair(int size) {
        address = _Vector_PxParticleRigidFilterPair(size);
    }
    private static native long _Vector_PxParticleRigidFilterPair(int size);

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxParticleRigidFilterPair} [Ref]
     */
    public PxParticleRigidFilterPair at(int index) {
        checkNotNull();
        return PxParticleRigidFilterPair.wrapPointer(_at(address, index));
    }
    private static native long _at(long address, int index);

    /**
     * @return WebIDL type: {@link PxParticleRigidFilterPair}
     */
    public PxParticleRigidFilterPair data() {
        checkNotNull();
        return PxParticleRigidFilterPair.wrapPointer(_data(address));
    }
    private static native long _data(long address);

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return _size(address);
    }
    private static native int _size(long address);

    /**
     * @param value WebIDL type: {@link PxParticleRigidFilterPair} [Ref]
     */
    public void push_back(PxParticleRigidFilterPair value) {
        checkNotNull();
        _push_back(address, value.getAddress());
    }
    private static native void _push_back(long address, long value);

    public void clear() {
        checkNotNull();
        _clear(address);
    }
    private static native void _clear(long address);

}
