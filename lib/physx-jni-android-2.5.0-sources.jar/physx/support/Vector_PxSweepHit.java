package physx.support;

import physx.NativeObject;
import physx.physics.PxSweepHit;

@Deprecated
public class Vector_PxSweepHit extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static Vector_PxSweepHit wrapPointer(long address) {
        return address != 0L ? new Vector_PxSweepHit(address) : null;
    }
    
    public static Vector_PxSweepHit arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected Vector_PxSweepHit(long address) {
        super(address);
    }

    // Constructors

    public Vector_PxSweepHit() {
        address = _Vector_PxSweepHit();
    }
    private static native long _Vector_PxSweepHit();

    /**
     * @param size WebIDL type: unsigned long
     */
    public Vector_PxSweepHit(int size) {
        address = _Vector_PxSweepHit(size);
    }
    private static native long _Vector_PxSweepHit(int size);

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxSweepHit} [Ref]
     */
    public PxSweepHit at(int index) {
        checkNotNull();
        return PxSweepHit.wrapPointer(_at(address, index));
    }
    private static native long _at(long address, int index);

    /**
     * @return WebIDL type: {@link PxSweepHit}
     */
    public PxSweepHit data() {
        checkNotNull();
        return PxSweepHit.wrapPointer(_data(address));
    }
    private static native long _data(long address);

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return _size(address);
    }
    private static native int _size(long address);

    /**
     * @param value WebIDL type: {@link PxSweepHit} [Ref]
     */
    public void push_back(PxSweepHit value) {
        checkNotNull();
        _push_back(address, value.getAddress());
    }
    private static native void _push_back(long address, long value);

    public void clear() {
        checkNotNull();
        _clear(address);
    }
    private static native void _clear(long address);

}
