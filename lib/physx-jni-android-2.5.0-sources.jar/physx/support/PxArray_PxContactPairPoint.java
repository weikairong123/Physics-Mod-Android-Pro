package physx.support;

import physx.NativeObject;
import physx.physics.PxContactPairPoint;

public class PxArray_PxContactPairPoint extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxArray_PxContactPairPoint wrapPointer(long address) {
        return address != 0L ? new PxArray_PxContactPairPoint(address) : null;
    }
    
    public static PxArray_PxContactPairPoint arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxArray_PxContactPairPoint(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @return Stack allocated object of PxArray_PxContactPairPoint
     */
    public static PxArray_PxContactPairPoint createAt(long address) {
        __placement_new_PxArray_PxContactPairPoint(address);
        PxArray_PxContactPairPoint createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @return Stack allocated object of PxArray_PxContactPairPoint
     */
    public static <T> PxArray_PxContactPairPoint createAt(T allocator, Allocator<T> allocate) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF); 
        __placement_new_PxArray_PxContactPairPoint(address);
        PxArray_PxContactPairPoint createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    private static native void __placement_new_PxArray_PxContactPairPoint(long address);

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param size    WebIDL type: unsigned long
     * @return Stack allocated object of PxArray_PxContactPairPoint
     */
    public static PxArray_PxContactPairPoint createAt(long address, int size) {
        __placement_new_PxArray_PxContactPairPoint(address, size);
        PxArray_PxContactPairPoint createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param size      WebIDL type: unsigned long
     * @return Stack allocated object of PxArray_PxContactPairPoint
     */
    public static <T> PxArray_PxContactPairPoint createAt(T allocator, Allocator<T> allocate, int size) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF); 
        __placement_new_PxArray_PxContactPairPoint(address, size);
        PxArray_PxContactPairPoint createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    private static native void __placement_new_PxArray_PxContactPairPoint(long address, int size);

    // Constructors

    public PxArray_PxContactPairPoint() {
        address = _PxArray_PxContactPairPoint();
    }
    private static native long _PxArray_PxContactPairPoint();

    /**
     * @param size WebIDL type: unsigned long
     */
    public PxArray_PxContactPairPoint(int size) {
        address = _PxArray_PxContactPairPoint(size);
    }
    private static native long _PxArray_PxContactPairPoint(int size);

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

    // Functions

    /**
     * @param index WebIDL type: unsigned long
     * @return WebIDL type: {@link PxContactPairPoint} [Ref]
     */
    public PxContactPairPoint get(int index) {
        checkNotNull();
        return PxContactPairPoint.wrapPointer(_get(address, index));
    }
    private static native long _get(long address, int index);

    /**
     * @param index WebIDL type: unsigned long
     * @param value WebIDL type: {@link PxContactPairPoint} [Const, Ref]
     */
    public void set(int index, PxContactPairPoint value) {
        checkNotNull();
        _set(address, index, value.getAddress());
    }
    private static native void _set(long address, int index, long value);

    /**
     * @return WebIDL type: {@link PxContactPairPoint}
     */
    public PxContactPairPoint begin() {
        checkNotNull();
        return PxContactPairPoint.wrapPointer(_begin(address));
    }
    private static native long _begin(long address);

    /**
     * @return WebIDL type: unsigned long
     */
    public int size() {
        checkNotNull();
        return _size(address);
    }
    private static native int _size(long address);

    /**
     * @param value WebIDL type: {@link PxContactPairPoint} [Ref]
     */
    public void pushBack(PxContactPairPoint value) {
        checkNotNull();
        _pushBack(address, value.getAddress());
    }
    private static native void _pushBack(long address, long value);

    public void clear() {
        checkNotNull();
        _clear(address);
    }
    private static native void _clear(long address);

}
