package physx.extensions;

/**
 * Flags specific to the prismatic joint.
 * <p>
 * <b>See also:</b> PxPrismaticJoint
 */
public enum PxPrismaticJointFlagEnum {

    eLIMIT_ENABLED(geteLIMIT_ENABLED());
    public final int value;
    
    PxPrismaticJointFlagEnum(int value) {
        this.value = value;
    }

    private static native int _geteLIMIT_ENABLED();
    private static int geteLIMIT_ENABLED() {
        de.fabmax.physxjni.Loader.load();
        return _geteLIMIT_ENABLED();
    }

    public static PxPrismaticJointFlagEnum forValue(int value) {
        for (int i = 0; i < values().length; i++) {
            if (values()[i].value == value) {
                return values()[i];
            }
        }
        throw new IllegalArgumentException("Unknown value for enum PxPrismaticJointFlagEnum: " + value);
    }

}
