package physx.extensions;

import physx.NativeObject;

public class PxPrismaticJointFlags extends NativeObject {

    protected PxPrismaticJointFlags() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxPrismaticJointFlags wrapPointer(long address) {
        return address != 0L ? new PxPrismaticJointFlags(address) : null;
    }
    
    public static PxPrismaticJointFlags arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxPrismaticJointFlags(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address Pre-allocated memory, where the object is created.
     * @param flags   WebIDL type: unsigned short
     * @return Stack allocated object of PxPrismaticJointFlags
     */
    public static PxPrismaticJointFlags createAt(long address, short flags) {
        __placement_new_PxPrismaticJointFlags(address, flags);
        PxPrismaticJointFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>       Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate  Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param flags     WebIDL type: unsigned short
     * @return Stack allocated object of PxPrismaticJointFlags
     */
    public static <T> PxPrismaticJointFlags createAt(T allocator, Allocator<T> allocate, short flags) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF); 
        __placement_new_PxPrismaticJointFlags(address, flags);
        PxPrismaticJointFlags createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    private static native void __placement_new_PxPrismaticJointFlags(long address, short flags);

    // Constructors

    /**
     * @param flags WebIDL type: unsigned short
     */
    public PxPrismaticJointFlags(short flags) {
        address = _PxPrismaticJointFlags(flags);
    }
    private static native long _PxPrismaticJointFlags(short flags);

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

    // Functions

    /**
     * @param flag WebIDL type: {@link PxPrismaticJointFlagEnum} [enum]
     * @return WebIDL type: boolean
     */
    public boolean isSet(PxPrismaticJointFlagEnum flag) {
        checkNotNull();
        return _isSet(address, flag.value);
    }
    private static native boolean _isSet(long address, int flag);

    /**
     * @param flag WebIDL type: {@link PxPrismaticJointFlagEnum} [enum]
     */
    public void raise(PxPrismaticJointFlagEnum flag) {
        checkNotNull();
        _raise(address, flag.value);
    }
    private static native void _raise(long address, int flag);

    /**
     * @param flag WebIDL type: {@link PxPrismaticJointFlagEnum} [enum]
     */
    public void clear(PxPrismaticJointFlagEnum flag) {
        checkNotNull();
        _clear(address, flag.value);
    }
    private static native void _clear(long address, int flag);

}
