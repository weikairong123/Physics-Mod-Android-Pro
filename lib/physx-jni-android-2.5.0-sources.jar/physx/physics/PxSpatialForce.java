package physx.physics;

import physx.NativeObject;
import physx.common.PxVec3;

/**
 * Data structure to represent spatial forces.
 */
public class PxSpatialForce extends NativeObject {

    protected PxSpatialForce() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxSpatialForce wrapPointer(long address) {
        return address != 0L ? new PxSpatialForce(address) : null;
    }
    
    public static PxSpatialForce arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxSpatialForce(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

    // Attributes

    /**
     */
    public PxVec3 getForce() {
        checkNotNull();
        return PxVec3.wrapPointer(_getForce(address));
    }
    private static native long _getForce(long address);

    /**
     */
    public void setForce(PxVec3 value) {
        checkNotNull();
        _setForce(address, value.getAddress());
    }
    private static native void _setForce(long address, long value);

    /**
     */
    public PxVec3 getTorque() {
        checkNotNull();
        return PxVec3.wrapPointer(_getTorque(address));
    }
    private static native long _getTorque(long address);

    /**
     */
    public void setTorque(PxVec3 value) {
        checkNotNull();
        _setTorque(address, value.getAddress());
    }
    private static native void _setTorque(long address, long value);

}
