package physx.physics;

import physx.NativeObject;

/**
 * An interface class that the user can implement in order to receive simulation events.
 * <p>
 * With the exception of onAdvance(), the events get sent during the call to either #PxScene::fetchResults() or 
 * #PxScene::flushSimulation() with sendPendingReports=true. onAdvance() gets called while the simulation
 * is running (that is between PxScene::simulate() or PxScene::advance() and PxScene::fetchResults()).
 * <p>
 * <b>Note:</b> SDK state should not be modified from within the callbacks. In particular objects should not
 * be created or destroyed. If state modification is needed then the changes should be stored to a buffer
 * and performed after the simulation step.
 * <p>
 * <b>Threading:</b> With the exception of onAdvance(), it is not necessary to make these callbacks thread safe as 
 * they will only be called in the context of the user thread.
 * @see PxScene#setSimulationEventCallback
 * @see PxScene#getSimulationEventCallback
 */
public class PxSimulationEventCallback extends NativeObject {

    protected PxSimulationEventCallback() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxSimulationEventCallback wrapPointer(long address) {
        return address != 0L ? new PxSimulationEventCallback(address) : null;
    }
    
    public static PxSimulationEventCallback arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxSimulationEventCallback(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

}
