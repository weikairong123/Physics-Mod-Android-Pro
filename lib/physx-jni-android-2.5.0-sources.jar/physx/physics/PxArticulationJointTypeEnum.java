package physx.physics;

public enum PxArticulationJointTypeEnum {

    /**
     * All joint axes, i.e. degrees of freedom (DOFs) locked
     */
    eFIX(geteFIX()),
    /**
     * Single linear DOF, e.g. cart on a rail
     */
    ePRISMATIC(getePRISMATIC()),
    /**
     * Single rotational DOF, e.g. an elbow joint or a rotational motor, position wrapped at 2pi radians
     */
    eREVOLUTE(geteREVOLUTE()),
    /**
     * Ball and socket joint with two or three DOFs
     */
    eSPHERICAL(geteSPHERICAL()),
    eUNDEFINED(geteUNDEFINED());
    public final int value;
    
    PxArticulationJointTypeEnum(int value) {
        this.value = value;
    }

    private static native int _geteFIX();
    private static int geteFIX() {
        de.fabmax.physxjni.Loader.load();
        return _geteFIX();
    }

    private static native int _getePRISMATIC();
    private static int getePRISMATIC() {
        de.fabmax.physxjni.Loader.load();
        return _getePRISMATIC();
    }

    private static native int _geteREVOLUTE();
    private static int geteREVOLUTE() {
        de.fabmax.physxjni.Loader.load();
        return _geteREVOLUTE();
    }

    private static native int _geteSPHERICAL();
    private static int geteSPHERICAL() {
        de.fabmax.physxjni.Loader.load();
        return _geteSPHERICAL();
    }

    private static native int _geteUNDEFINED();
    private static int geteUNDEFINED() {
        de.fabmax.physxjni.Loader.load();
        return _geteUNDEFINED();
    }

    public static PxArticulationJointTypeEnum forValue(int value) {
        for (int i = 0; i < values().length; i++) {
            if (values()[i].value == value) {
                return values()[i];
            }
        }
        throw new IllegalArgumentException("Unknown value for enum PxArticulationJointTypeEnum: " + value);
    }

}
