package physx.physics;


public class PxQueryFilterCallbackImpl extends SimpleQueryFilterCallback {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxQueryFilterCallbackImpl wrapPointer(long address) {
        return address != 0L ? new PxQueryFilterCallbackImpl(address) : null;
    }
    
    public static PxQueryFilterCallbackImpl arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxQueryFilterCallbackImpl(long address) {
        super(address);
    }

    protected PxQueryFilterCallbackImpl() {
        address = _PxQueryFilterCallbackImpl();
    }
    private native long _PxQueryFilterCallbackImpl();
    
    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

    // Functions

    /*
     * Called from native code
     */
    private int _simplePreFilter(long filterData, long shape, long actor, long queryFlags) {
        return simplePreFilter(PxFilterData.wrapPointer(filterData), PxShape.wrapPointer(shape), PxRigidActor.wrapPointer(actor), PxHitFlags.wrapPointer(queryFlags));
    }

    /**
     * @param filterData WebIDL type: {@link PxFilterData} [Const, Ref]
     * @param shape      WebIDL type: {@link PxShape} [Const]
     * @param actor      WebIDL type: {@link PxRigidActor} [Const]
     * @param queryFlags WebIDL type: {@link PxHitFlags} [Ref]
     * @return WebIDL type: unsigned long
     */
    public int simplePreFilter(PxFilterData filterData, PxShape shape, PxRigidActor actor, PxHitFlags queryFlags) {
        return 0;
    }

    /*
     * Called from native code
     */
    private int _simplePostFilter(long filterData, long hit, long shape, long actor) {
        return simplePostFilter(PxFilterData.wrapPointer(filterData), PxQueryHit.wrapPointer(hit), PxShape.wrapPointer(shape), PxRigidActor.wrapPointer(actor));
    }

    /**
     * @param filterData WebIDL type: {@link PxFilterData} [Const, Ref]
     * @param hit        WebIDL type: {@link PxQueryHit} [Const, Ref]
     * @param shape      WebIDL type: {@link PxShape} [Const]
     * @param actor      WebIDL type: {@link PxRigidActor} [Const]
     * @return WebIDL type: unsigned long
     */
    public int simplePostFilter(PxFilterData filterData, PxQueryHit hit, PxShape shape, PxRigidActor actor) {
        return 0;
    }

}
