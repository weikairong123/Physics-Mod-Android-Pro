package physx.character;

public enum PxCapsuleClimbingModeEnum {

    /**
     * Standard mode, let the capsule climb over surfaces according to impact normal
     */
    eEASY(geteEASY()),
    /**
     * Constrained mode, try to limit climbing according to the step offset
     */
    eCONSTRAINED(geteCONSTRAINED());
    public final int value;
    
    PxCapsuleClimbingModeEnum(int value) {
        this.value = value;
    }

    private static native int _geteEASY();
    private static int geteEASY() {
        de.fabmax.physxjni.Loader.load();
        return _geteEASY();
    }

    private static native int _geteCONSTRAINED();
    private static int geteCONSTRAINED() {
        de.fabmax.physxjni.Loader.load();
        return _geteCONSTRAINED();
    }

    public static PxCapsuleClimbingModeEnum forValue(int value) {
        for (int i = 0; i < values().length; i++) {
            if (values()[i].value == value) {
                return values()[i];
            }
        }
        throw new IllegalArgumentException("Unknown value for enum PxCapsuleClimbingModeEnum: " + value);
    }

}
