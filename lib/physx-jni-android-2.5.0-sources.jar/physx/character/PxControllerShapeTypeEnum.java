package physx.character;

/**
 * The type of controller, eg box, sphere or capsule.
 */
public enum PxControllerShapeTypeEnum {

    /**
     * A box controller.
     * <p>
     * <b>See also:</b> PxBoxController PxBoxControllerDesc
     */
    eBOX(geteBOX()),
    /**
     * A capsule controller
     * <p>
     * <b>See also:</b> PxCapsuleController PxCapsuleControllerDesc
     */
    eCAPSULE(geteCAPSULE());
    public final int value;
    
    PxControllerShapeTypeEnum(int value) {
        this.value = value;
    }

    private static native int _geteBOX();
    private static int geteBOX() {
        de.fabmax.physxjni.Loader.load();
        return _geteBOX();
    }

    private static native int _geteCAPSULE();
    private static int geteCAPSULE() {
        de.fabmax.physxjni.Loader.load();
        return _geteCAPSULE();
    }

    public static PxControllerShapeTypeEnum forValue(int value) {
        for (int i = 0; i < values().length; i++) {
            if (values()[i].value == value) {
                return values()[i];
            }
        }
        throw new IllegalArgumentException("Unknown value for enum PxControllerShapeTypeEnum: " + value);
    }

}
