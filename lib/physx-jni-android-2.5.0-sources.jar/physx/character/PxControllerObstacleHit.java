package physx.character;

import physx.NativeObject;

/**
 * Describes a hit between a CCT and a user-defined obstacle. Passed to onObstacleHit().
 * @see PxUserControllerHitReport#onObstacleHit
 * @see PxObstacleContext
 */
public class PxControllerObstacleHit extends PxControllerHit {

    protected PxControllerObstacleHit() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxControllerObstacleHit wrapPointer(long address) {
        return address != 0L ? new PxControllerObstacleHit(address) : null;
    }
    
    public static PxControllerObstacleHit arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxControllerObstacleHit(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

    // Attributes

    /**
     */
    public NativeObject getUserData() {
        checkNotNull();
        return NativeObject.wrapPointer(_getUserData(address));
    }
    private static native long _getUserData(long address);

    /**
     */
    public void setUserData(NativeObject value) {
        checkNotNull();
        _setUserData(address, value.getAddress());
    }
    private static native void _setUserData(long address, long value);

}
