package physx.common;

import physx.NativeObject;

/**
 * default implementation of the allocator interface required by the SDK
 */
public class PxDefaultAllocator extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxDefaultAllocator wrapPointer(long address) {
        return address != 0L ? new PxDefaultAllocator(address) : null;
    }
    
    public static PxDefaultAllocator arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxDefaultAllocator(long address) {
        super(address);
    }

    // Constructors

    public PxDefaultAllocator() {
        address = _PxDefaultAllocator();
    }
    private static native long _PxDefaultAllocator();

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

}
