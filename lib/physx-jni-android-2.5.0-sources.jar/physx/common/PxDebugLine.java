package physx.common;

import physx.NativeObject;

/**
 * Used to store a single line and colour for debug rendering.
 */
public class PxDebugLine extends NativeObject {

    protected PxDebugLine() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxDebugLine wrapPointer(long address) {
        return address != 0L ? new PxDebugLine(address) : null;
    }
    
    public static PxDebugLine arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxDebugLine(long address) {
        super(address);
    }

    // Attributes

    /**
     */
    public PxVec3 getPos0() {
        checkNotNull();
        return PxVec3.wrapPointer(_getPos0(address));
    }
    private static native long _getPos0(long address);

    /**
     */
    public void setPos0(PxVec3 value) {
        checkNotNull();
        _setPos0(address, value.getAddress());
    }
    private static native void _setPos0(long address, long value);

    /**
     */
    public int getColor0() {
        checkNotNull();
        return _getColor0(address);
    }
    private static native int _getColor0(long address);

    /**
     */
    public void setColor0(int value) {
        checkNotNull();
        _setColor0(address, value);
    }
    private static native void _setColor0(long address, int value);

    /**
     */
    public PxVec3 getPos1() {
        checkNotNull();
        return PxVec3.wrapPointer(_getPos1(address));
    }
    private static native long _getPos1(long address);

    /**
     */
    public void setPos1(PxVec3 value) {
        checkNotNull();
        _setPos1(address, value.getAddress());
    }
    private static native void _setPos1(long address, long value);

    /**
     */
    public int getColor1() {
        checkNotNull();
        return _getColor1(address);
    }
    private static native int _getColor1(long address);

    /**
     */
    public void setColor1(int value) {
        checkNotNull();
        _setColor1(address, value);
    }
    private static native void _setColor1(long address, int value);

}
