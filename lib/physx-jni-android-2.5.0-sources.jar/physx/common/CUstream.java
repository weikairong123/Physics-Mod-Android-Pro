package physx.common;

import physx.NativeObject;
import physx.PlatformChecks;

public class CUstream extends NativeObject {

    static {
        PlatformChecks.requirePlatform(3, "physx.common.CUstream");
    }

    protected CUstream() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static CUstream wrapPointer(long address) {
        return address != 0L ? new CUstream(address) : null;
    }
    
    public static CUstream arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected CUstream(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

}
