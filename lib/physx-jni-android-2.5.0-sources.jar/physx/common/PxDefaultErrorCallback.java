package physx.common;


/**
 * default implementation of the error callback
 * <p>
 * This class is provided in order to enable the SDK to be started with the minimum of user code. Typically an application
 * will use its own error callback, and log the error to file or otherwise make it visible. Warnings and error messages from
 * the SDK are usually indicative that changes are required in order for PhysX to function correctly, and should not be ignored.
 */
public class PxDefaultErrorCallback extends PxErrorCallback {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxDefaultErrorCallback wrapPointer(long address) {
        return address != 0L ? new PxDefaultErrorCallback(address) : null;
    }
    
    public static PxDefaultErrorCallback arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxDefaultErrorCallback(long address) {
        super(address);
    }

    // Constructors

    public PxDefaultErrorCallback() {
        address = _PxDefaultErrorCallback();
    }
    private static native long _PxDefaultErrorCallback();

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        _delete_native_instance(address);
        address = 0L;
    }
    private static native long _delete_native_instance(long address);

}
