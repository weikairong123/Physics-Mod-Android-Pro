package physx.vehicle2;

public enum PxVehicleSimulationContextTypeEnum {

    /**
     * The simulation context inherits from PxVehicleSimulationContext
     */
    eDEFAULT(geteDEFAULT()),
    ePHYSX(getePHYSX());
    public final int value;
    
    PxVehicleSimulationContextTypeEnum(int value) {
        this.value = value;
    }

    private static native int _geteDEFAULT();
    private static int geteDEFAULT() {
        de.fabmax.physxjni.Loader.load();
        return _geteDEFAULT();
    }

    private static native int _getePHYSX();
    private static int getePHYSX() {
        de.fabmax.physxjni.Loader.load();
        return _getePHYSX();
    }

    public static PxVehicleSimulationContextTypeEnum forValue(int value) {
        for (int i = 0; i < values().length; i++) {
            if (values()[i].value == value) {
                return values()[i];
            }
        }
        throw new IllegalArgumentException("Unknown value for enum PxVehicleSimulationContextTypeEnum: " + value);
    }

}
