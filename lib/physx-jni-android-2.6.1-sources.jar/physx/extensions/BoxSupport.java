package physx.extensions;

import physx.common.PxVec3;

/**
 * Pre-made support mapping for a box
 */
public class BoxSupport extends Support {

    protected BoxSupport() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static BoxSupport wrapPointer(long address) {
        return address != 0L ? new BoxSupport(address) : null;
    }
    
    public static BoxSupport arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected BoxSupport(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address     Pre-allocated memory, where the object is created.
     * @param halfExtents WebIDL type: {@link PxVec3} [Const, Ref]
     * @return Stack allocated object of BoxSupport
     */
    public static BoxSupport createAt(long address, PxVec3 halfExtents) {
        Raw.BoxSupport_placed(address, halfExtents.getAddress());
        BoxSupport createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>         Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator   Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate    Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param halfExtents WebIDL type: {@link PxVec3} [Const, Ref]
     * @return Stack allocated object of BoxSupport
     */
    public static <T> BoxSupport createAt(T allocator, Allocator<T> allocate, PxVec3 halfExtents) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.BoxSupport_placed(address, halfExtents.getAddress());
        BoxSupport createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address     Pre-allocated memory, where the object is created.
     * @param halfExtents WebIDL type: {@link PxVec3} [Const, Ref]
     * @param margin      WebIDL type: float
     * @return Stack allocated object of BoxSupport
     */
    public static BoxSupport createAt(long address, PxVec3 halfExtents, float margin) {
        Raw.BoxSupport_placed(address, halfExtents.getAddress(), margin);
        BoxSupport createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>         Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator   Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate    Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param halfExtents WebIDL type: {@link PxVec3} [Const, Ref]
     * @param margin      WebIDL type: float
     * @return Stack allocated object of BoxSupport
     */
    public static <T> BoxSupport createAt(T allocator, Allocator<T> allocate, PxVec3 halfExtents, float margin) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.BoxSupport_placed(address, halfExtents.getAddress(), margin);
        BoxSupport createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * Constructs a BoxSupport for a box halfExtents with optional margin
     */
    public BoxSupport(PxVec3 halfExtents) {
        address = Raw.BoxSupport(halfExtents.getAddress());
    }

    /**
     * Constructs a BoxSupport for a box halfExtents with optional margin
     */
    public BoxSupport(PxVec3 halfExtents, float margin) {
        address = Raw.BoxSupport(halfExtents.getAddress(), margin);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     */
    public PxVec3 getHalfExtents() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getHalfExtents(address));
    }

    /**
     */
    public void setHalfExtents(PxVec3 value) {
        checkNotNull();
        Raw.setHalfExtents(address, value.getAddress());
    }

    /**
     */
    public float getMargin() {
        checkNotNull();
        return Raw.getMargin(address);
    }

    /**
     */
    public void setMargin(float value) {
        checkNotNull();
        Raw.setMargin(address, value);
    }

    public static class Raw {
        public static native void BoxSupport_placed(long address, long halfExtents);
        public static native void BoxSupport_placed(long address, long halfExtents, float margin);
        public static native long BoxSupport(long halfExtents);
        public static native long BoxSupport(long halfExtents, float margin);
        public static native void destroy(long address);
        public static native long getHalfExtents(long address);
        public static native void setHalfExtents(long address, long value);
        public static native float getMargin(long address);
        public static native void setMargin(long address, float value);
    }
}
