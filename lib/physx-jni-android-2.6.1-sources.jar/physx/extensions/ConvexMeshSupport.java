package physx.extensions;

import physx.PlatformChecks;
import physx.common.PxQuat;
import physx.common.PxVec3;
import physx.geometry.PxConvexMesh;

/**
 * Pre-made support mapping for a convex mesh
 */
public class ConvexMeshSupport extends Support {

    protected ConvexMeshSupport() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static ConvexMeshSupport wrapPointer(long address) {
        return address != 0L ? new ConvexMeshSupport(address) : null;
    }
    
    public static ConvexMeshSupport arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected ConvexMeshSupport(long address) {
        super(address);
    }

    // Placed Constructors

    /**
     * @param address    Pre-allocated memory, where the object is created.
     * @param convexMesh WebIDL type: {@link PxConvexMesh} [Const, Ref]
     * @return Stack allocated object of ConvexMeshSupport
     */
    public static ConvexMeshSupport createAt(long address, PxConvexMesh convexMesh) {
        Raw.ConvexMeshSupport_placed(address, convexMesh.getAddress());
        ConvexMeshSupport createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>        Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator  Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate   Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param convexMesh WebIDL type: {@link PxConvexMesh} [Const, Ref]
     * @return Stack allocated object of ConvexMeshSupport
     */
    public static <T> ConvexMeshSupport createAt(T allocator, Allocator<T> allocate, PxConvexMesh convexMesh) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.ConvexMeshSupport_placed(address, convexMesh.getAddress());
        ConvexMeshSupport createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address    Pre-allocated memory, where the object is created.
     * @param convexMesh WebIDL type: {@link PxConvexMesh} [Const, Ref]
     * @param scale      WebIDL type: {@link PxVec3} [Const, Ref]
     * @return Stack allocated object of ConvexMeshSupport
     */
    public static ConvexMeshSupport createAt(long address, PxConvexMesh convexMesh, PxVec3 scale) {
        Raw.ConvexMeshSupport_placed(address, convexMesh.getAddress(), scale.getAddress());
        ConvexMeshSupport createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>        Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator  Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate   Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param convexMesh WebIDL type: {@link PxConvexMesh} [Const, Ref]
     * @param scale      WebIDL type: {@link PxVec3} [Const, Ref]
     * @return Stack allocated object of ConvexMeshSupport
     */
    public static <T> ConvexMeshSupport createAt(T allocator, Allocator<T> allocate, PxConvexMesh convexMesh, PxVec3 scale) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.ConvexMeshSupport_placed(address, convexMesh.getAddress(), scale.getAddress());
        ConvexMeshSupport createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address       Pre-allocated memory, where the object is created.
     * @param convexMesh    WebIDL type: {@link PxConvexMesh} [Const, Ref]
     * @param scale         WebIDL type: {@link PxVec3} [Const, Ref]
     * @param scaleRotation WebIDL type: {@link PxQuat} [Const, Ref]
     * @return Stack allocated object of ConvexMeshSupport
     */
    public static ConvexMeshSupport createAt(long address, PxConvexMesh convexMesh, PxVec3 scale, PxQuat scaleRotation) {
        Raw.ConvexMeshSupport_placed(address, convexMesh.getAddress(), scale.getAddress(), scaleRotation.getAddress());
        ConvexMeshSupport createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>           Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator     Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate      Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param convexMesh    WebIDL type: {@link PxConvexMesh} [Const, Ref]
     * @param scale         WebIDL type: {@link PxVec3} [Const, Ref]
     * @param scaleRotation WebIDL type: {@link PxQuat} [Const, Ref]
     * @return Stack allocated object of ConvexMeshSupport
     */
    public static <T> ConvexMeshSupport createAt(T allocator, Allocator<T> allocate, PxConvexMesh convexMesh, PxVec3 scale, PxQuat scaleRotation) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.ConvexMeshSupport_placed(address, convexMesh.getAddress(), scale.getAddress(), scaleRotation.getAddress());
        ConvexMeshSupport createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param address       Pre-allocated memory, where the object is created.
     * @param convexMesh    WebIDL type: {@link PxConvexMesh} [Const, Ref]
     * @param scale         WebIDL type: {@link PxVec3} [Const, Ref]
     * @param scaleRotation WebIDL type: {@link PxQuat} [Const, Ref]
     * @param margin        WebIDL type: float
     * @return Stack allocated object of ConvexMeshSupport
     */
    public static ConvexMeshSupport createAt(long address, PxConvexMesh convexMesh, PxVec3 scale, PxQuat scaleRotation, float margin) {
        Raw.ConvexMeshSupport_placed(address, convexMesh.getAddress(), scale.getAddress(), scaleRotation.getAddress(), margin);
        ConvexMeshSupport createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    /**
     * @param <T>           Allocator class, e.g. LWJGL's MemoryStack.
     * @param allocator     Object to use for allocation, e.g. an instance of LWJGL's MemoryStack.
     * @param allocate      Method to call on allocator to obtain the target address, e.g. MemoryStack::nmalloc.
     * @param convexMesh    WebIDL type: {@link PxConvexMesh} [Const, Ref]
     * @param scale         WebIDL type: {@link PxVec3} [Const, Ref]
     * @param scaleRotation WebIDL type: {@link PxQuat} [Const, Ref]
     * @param margin        WebIDL type: float
     * @return Stack allocated object of ConvexMeshSupport
     */
    public static <T> ConvexMeshSupport createAt(T allocator, Allocator<T> allocate, PxConvexMesh convexMesh, PxVec3 scale, PxQuat scaleRotation, float margin) {
        long address = allocate.on(allocator, ALIGNOF, SIZEOF);
        Raw.ConvexMeshSupport_placed(address, convexMesh.getAddress(), scale.getAddress(), scaleRotation.getAddress(), margin);
        ConvexMeshSupport createdObj = wrapPointer(address);
        createdObj.isExternallyAllocated = true;
        return createdObj;
    }

    // Constructors

    /**
     * Constructs a BoxSupport for a PxConvexMesh
     */
    public ConvexMeshSupport(PxConvexMesh convexMesh) {
        address = Raw.ConvexMeshSupport(convexMesh.getAddress());
    }

    /**
     * Constructs a BoxSupport for a PxConvexMesh
     */
    public ConvexMeshSupport(PxConvexMesh convexMesh, PxVec3 scale) {
        address = Raw.ConvexMeshSupport(convexMesh.getAddress(), scale.getAddress());
    }

    /**
     * Constructs a BoxSupport for a PxConvexMesh
     */
    public ConvexMeshSupport(PxConvexMesh convexMesh, PxVec3 scale, PxQuat scaleRotation) {
        address = Raw.ConvexMeshSupport(convexMesh.getAddress(), scale.getAddress(), scaleRotation.getAddress());
    }

    /**
     * Constructs a BoxSupport for a PxConvexMesh
     */
    public ConvexMeshSupport(PxConvexMesh convexMesh, PxVec3 scale, PxQuat scaleRotation, float margin) {
        address = Raw.ConvexMeshSupport(convexMesh.getAddress(), scale.getAddress(), scaleRotation.getAddress(), margin);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     */
    public PxConvexMesh getConvexMesh() {
        checkNotNull();
        PlatformChecks.requirePlatform(15, "physx.extensions.ConvexMeshSupport");
        return PxConvexMesh.wrapPointer(Raw.getConvexMesh(address));
    }

    /**
     */
    public PxVec3 getScale() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getScale(address));
    }

    /**
     */
    public void setScale(PxVec3 value) {
        checkNotNull();
        Raw.setScale(address, value.getAddress());
    }

    /**
     */
    public PxQuat getScaleRotation() {
        checkNotNull();
        return PxQuat.wrapPointer(Raw.getScaleRotation(address));
    }

    /**
     */
    public void setScaleRotation(PxQuat value) {
        checkNotNull();
        Raw.setScaleRotation(address, value.getAddress());
    }

    /**
     */
    public float getMargin() {
        checkNotNull();
        return Raw.getMargin(address);
    }

    /**
     */
    public void setMargin(float value) {
        checkNotNull();
        Raw.setMargin(address, value);
    }

    public static class Raw {
        public static native void ConvexMeshSupport_placed(long address, long convexMesh);
        public static native void ConvexMeshSupport_placed(long address, long convexMesh, long scale);
        public static native void ConvexMeshSupport_placed(long address, long convexMesh, long scale, long scaleRotation);
        public static native void ConvexMeshSupport_placed(long address, long convexMesh, long scale, long scaleRotation, float margin);
        public static native long ConvexMeshSupport(long convexMesh);
        public static native long ConvexMeshSupport(long convexMesh, long scale);
        public static native long ConvexMeshSupport(long convexMesh, long scale, long scaleRotation);
        public static native long ConvexMeshSupport(long convexMesh, long scale, long scaleRotation, float margin);
        public static native void destroy(long address);
        public static native long getConvexMesh(long address);
        public static native long getScale(long address);
        public static native void setScale(long address, long value);
        public static native long getScaleRotation(long address);
        public static native void setScaleRotation(long address, long value);
        public static native float getMargin(long address);
        public static native void setMargin(long address, float value);
    }
}
