package physx.character;


/**
 * A capsule obstacle.
 * @see PxBoxObstacle
 * @see PxObstacle
 * @see PxObstacleContext
 */
public class PxCapsuleObstacle extends PxObstacle {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxCapsuleObstacle wrapPointer(long address) {
        return address != 0L ? new PxCapsuleObstacle(address) : null;
    }
    
    public static PxCapsuleObstacle arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxCapsuleObstacle(long address) {
        super(address);
    }

    // Constructors

    public PxCapsuleObstacle() {
        address = Raw.PxCapsuleObstacle();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     */
    public float getMHalfHeight() {
        checkNotNull();
        return Raw.getMHalfHeight(address);
    }

    /**
     */
    public void setMHalfHeight(float value) {
        checkNotNull();
        Raw.setMHalfHeight(address, value);
    }

    /**
     */
    public float getMRadius() {
        checkNotNull();
        return Raw.getMRadius(address);
    }

    /**
     */
    public void setMRadius(float value) {
        checkNotNull();
        Raw.setMRadius(address, value);
    }

    public static class Raw {
        public static native long PxCapsuleObstacle();
        public static native void destroy(long address);
        public static native float getMHalfHeight(long address);
        public static native void setMHalfHeight(long address, float value);
        public static native float getMRadius(long address);
        public static native void setMRadius(long address, float value);
    }
}
