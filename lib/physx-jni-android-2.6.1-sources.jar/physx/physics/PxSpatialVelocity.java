package physx.physics;

import physx.NativeObject;
import physx.common.PxVec3;

/**
 * Data structure to represent spatial velocities.
 */
public class PxSpatialVelocity extends NativeObject {

    protected PxSpatialVelocity() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxSpatialVelocity wrapPointer(long address) {
        return address != 0L ? new PxSpatialVelocity(address) : null;
    }
    
    public static PxSpatialVelocity arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxSpatialVelocity(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     */
    public PxVec3 getLinear() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getLinear(address));
    }

    /**
     */
    public void setLinear(PxVec3 value) {
        checkNotNull();
        Raw.setLinear(address, value.getAddress());
    }

    /**
     */
    public PxVec3 getAngular() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getAngular(address));
    }

    /**
     */
    public void setAngular(PxVec3 value) {
        checkNotNull();
        Raw.setAngular(address, value.getAddress());
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native long getLinear(long address);
        public static native void setLinear(long address, long value);
        public static native long getAngular(long address);
        public static native void setAngular(long address, long value);
    }
}
