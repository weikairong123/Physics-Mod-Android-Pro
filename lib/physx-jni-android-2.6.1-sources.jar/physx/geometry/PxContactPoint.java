package physx.geometry;

import physx.NativeObject;
import physx.common.PxVec3;

public class PxContactPoint extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxContactPoint wrapPointer(long address) {
        return address != 0L ? new PxContactPoint(address) : null;
    }
    
    public static PxContactPoint arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxContactPoint(long address) {
        super(address);
    }

    // Constructors

    public PxContactPoint() {
        address = Raw.PxContactPoint();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getNormal() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getNormal(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setNormal(PxVec3 value) {
        checkNotNull();
        Raw.setNormal(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getPoint() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getPoint(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setPoint(PxVec3 value) {
        checkNotNull();
        Raw.setPoint(address, value.getAddress());
    }

    /**
     * @return WebIDL type: {@link PxVec3} [Value]
     */
    public PxVec3 getTargetVel() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getTargetVel(address));
    }

    /**
     * @param value WebIDL type: {@link PxVec3} [Value]
     */
    public void setTargetVel(PxVec3 value) {
        checkNotNull();
        Raw.setTargetVel(address, value.getAddress());
    }

    /**
     * The separation of the shapes at the contact point. A negative separation denotes a penetration.
     */
    public float getSeparation() {
        checkNotNull();
        return Raw.getSeparation(address);
    }

    /**
     * The separation of the shapes at the contact point. A negative separation denotes a penetration.
     */
    public void setSeparation(float value) {
        checkNotNull();
        Raw.setSeparation(address, value);
    }

    /**
     * The max impulse permitted at this point
     */
    public float getMaxImpulse() {
        checkNotNull();
        return Raw.getMaxImpulse(address);
    }

    /**
     * The max impulse permitted at this point
     */
    public void setMaxImpulse(float value) {
        checkNotNull();
        Raw.setMaxImpulse(address, value);
    }

    /**
     * The static friction coefficient
     */
    public float getStaticFriction() {
        checkNotNull();
        return Raw.getStaticFriction(address);
    }

    /**
     * The static friction coefficient
     */
    public void setStaticFriction(float value) {
        checkNotNull();
        Raw.setStaticFriction(address, value);
    }

    /**
     */
    public byte getMaterialFlags() {
        checkNotNull();
        return Raw.getMaterialFlags(address);
    }

    /**
     */
    public void setMaterialFlags(byte value) {
        checkNotNull();
        Raw.setMaterialFlags(address, value);
    }

    /**
     * The surface index of shape 1 at the contact point. This is used to identify the surface material.
     * <p>
     * <b>Note:</b> This field is only supported by triangle meshes and heightfields, else it will be set to PXC_CONTACT_NO_FACE_INDEX.
     */
    public int getInternalFaceIndex1() {
        checkNotNull();
        return Raw.getInternalFaceIndex1(address);
    }

    /**
     * The surface index of shape 1 at the contact point. This is used to identify the surface material.
     * <p>
     * <b>Note:</b> This field is only supported by triangle meshes and heightfields, else it will be set to PXC_CONTACT_NO_FACE_INDEX.
     */
    public void setInternalFaceIndex1(int value) {
        checkNotNull();
        Raw.setInternalFaceIndex1(address, value);
    }

    /**
     * The dynamic friction coefficient
     */
    public float getDynamicFriction() {
        checkNotNull();
        return Raw.getDynamicFriction(address);
    }

    /**
     * The dynamic friction coefficient
     */
    public void setDynamicFriction(float value) {
        checkNotNull();
        Raw.setDynamicFriction(address, value);
    }

    /**
     * The restitution coefficient
     */
    public float getRestitution() {
        checkNotNull();
        return Raw.getRestitution(address);
    }

    /**
     * The restitution coefficient
     */
    public void setRestitution(float value) {
        checkNotNull();
        Raw.setRestitution(address, value);
    }

    /**
     * Damping coefficient (for compliant contacts)
     */
    public float getDamping() {
        checkNotNull();
        return Raw.getDamping(address);
    }

    /**
     * Damping coefficient (for compliant contacts)
     */
    public void setDamping(float value) {
        checkNotNull();
        Raw.setDamping(address, value);
    }

    public static class Raw {
        public static native long PxContactPoint();
        public static native void destroy(long address);
        public static native long getNormal(long address);
        public static native void setNormal(long address, long value);
        public static native long getPoint(long address);
        public static native void setPoint(long address, long value);
        public static native long getTargetVel(long address);
        public static native void setTargetVel(long address, long value);
        public static native float getSeparation(long address);
        public static native void setSeparation(long address, float value);
        public static native float getMaxImpulse(long address);
        public static native void setMaxImpulse(long address, float value);
        public static native float getStaticFriction(long address);
        public static native void setStaticFriction(long address, float value);
        public static native byte getMaterialFlags(long address);
        public static native void setMaterialFlags(long address, byte value);
        public static native int getInternalFaceIndex1(long address);
        public static native void setInternalFaceIndex1(long address, int value);
        public static native float getDynamicFriction(long address);
        public static native void setDynamicFriction(long address, float value);
        public static native float getRestitution(long address);
        public static native void setRestitution(long address, float value);
        public static native float getDamping(long address);
        public static native void setDamping(long address, float value);
    }
}
