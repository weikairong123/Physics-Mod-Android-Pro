package physx.vehicle2;

import physx.NativeObject;

public class PxVehicleClutchCommandResponseState extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleClutchCommandResponseState wrapPointer(long address) {
        return address != 0L ? new PxVehicleClutchCommandResponseState(address) : null;
    }
    
    public static PxVehicleClutchCommandResponseState arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleClutchCommandResponseState(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleClutchCommandResponseState() {
        address = Raw.PxVehicleClutchCommandResponseState();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     */
    public float getNormalisedCommandResponse() {
        checkNotNull();
        return Raw.getNormalisedCommandResponse(address);
    }

    /**
     */
    public void setNormalisedCommandResponse(float value) {
        checkNotNull();
        Raw.setNormalisedCommandResponse(address, value);
    }

    /**
     */
    public float getCommandResponse() {
        checkNotNull();
        return Raw.getCommandResponse(address);
    }

    /**
     */
    public void setCommandResponse(float value) {
        checkNotNull();
        Raw.setCommandResponse(address, value);
    }

    // Functions

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    public static class Raw {
        public static native long PxVehicleClutchCommandResponseState();
        public static native void destroy(long address);
        public static native float getNormalisedCommandResponse(long address);
        public static native void setNormalisedCommandResponse(long address, float value);
        public static native float getCommandResponse(long address);
        public static native void setCommandResponse(long address, float value);
        public static native void setToDefault(long address);
    }
}
