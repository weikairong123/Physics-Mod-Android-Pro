package physx.vehicle2;

import physx.NativeObject;
import physx.common.PxVec3;

public class PxVehicleSimulationContext extends NativeObject {

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehicleSimulationContext wrapPointer(long address) {
        return address != 0L ? new PxVehicleSimulationContext(address) : null;
    }
    
    public static PxVehicleSimulationContext arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehicleSimulationContext(long address) {
        super(address);
    }

    // Constructors

    public PxVehicleSimulationContext() {
        address = Raw.PxVehicleSimulationContext();
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     */
    public PxVec3 getGravity() {
        checkNotNull();
        return PxVec3.wrapPointer(Raw.getGravity(address));
    }

    /**
     */
    public void setGravity(PxVec3 value) {
        checkNotNull();
        Raw.setGravity(address, value.getAddress());
    }

    /**
     */
    public PxVehicleFrame getFrame() {
        checkNotNull();
        return PxVehicleFrame.wrapPointer(Raw.getFrame(address));
    }

    /**
     */
    public void setFrame(PxVehicleFrame value) {
        checkNotNull();
        Raw.setFrame(address, value.getAddress());
    }

    /**
     */
    public PxVehicleScale getScale() {
        checkNotNull();
        return PxVehicleScale.wrapPointer(Raw.getScale(address));
    }

    /**
     */
    public void setScale(PxVehicleScale value) {
        checkNotNull();
        Raw.setScale(address, value.getAddress());
    }

    /**
     */
    public PxVehicleTireSlipParams getTireSlipParams() {
        checkNotNull();
        return PxVehicleTireSlipParams.wrapPointer(Raw.getTireSlipParams(address));
    }

    /**
     */
    public void setTireSlipParams(PxVehicleTireSlipParams value) {
        checkNotNull();
        Raw.setTireSlipParams(address, value.getAddress());
    }

    /**
     */
    public PxVehicleTireStickyParams getTireStickyParams() {
        checkNotNull();
        return PxVehicleTireStickyParams.wrapPointer(Raw.getTireStickyParams(address));
    }

    /**
     */
    public void setTireStickyParams(PxVehicleTireStickyParams value) {
        checkNotNull();
        Raw.setTireStickyParams(address, value.getAddress());
    }

    /**
     * Forward wheel speed below which the wheel rotation speed gets blended with the rolling speed.
     * <p>
     * The blended rotation speed is used to integrate the wheel rotation angle. At low forward wheel speed, 
     * the wheel rotation speed can get unstable (depending on the tire model used) and, for example, oscillate.
     * <p>
     * <b>Note:</b> If brake or throttle is applied, there will be no blending.
     * <p>
     * <b>Unit:</b> velocity = length / time
     */
    public float getThresholdForwardSpeedForWheelAngleIntegration() {
        checkNotNull();
        return Raw.getThresholdForwardSpeedForWheelAngleIntegration(address);
    }

    /**
     * Forward wheel speed below which the wheel rotation speed gets blended with the rolling speed.
     * <p>
     * The blended rotation speed is used to integrate the wheel rotation angle. At low forward wheel speed, 
     * the wheel rotation speed can get unstable (depending on the tire model used) and, for example, oscillate.
     * <p>
     * <b>Note:</b> If brake or throttle is applied, there will be no blending.
     * <p>
     * <b>Unit:</b> velocity = length / time
     */
    public void setThresholdForwardSpeedForWheelAngleIntegration(float value) {
        checkNotNull();
        Raw.setThresholdForwardSpeedForWheelAngleIntegration(address, value);
    }

    /**
     * Structure to support Omni PVD, the PhysX Visual Debugger.
     */
    public PxVehiclePvdContext getPvdContext() {
        checkNotNull();
        return PxVehiclePvdContext.wrapPointer(Raw.getPvdContext(address));
    }

    /**
     * Structure to support Omni PVD, the PhysX Visual Debugger.
     */
    public void setPvdContext(PxVehiclePvdContext value) {
        checkNotNull();
        Raw.setPvdContext(address, value.getAddress());
    }

    // Functions

    /**
     * @return WebIDL type: {@link PxVehicleSimulationContextTypeEnum} [enum]
     */
    public PxVehicleSimulationContextTypeEnum getType() {
        checkNotNull();
        return PxVehicleSimulationContextTypeEnum.forValue(Raw.getType(address));
    }

    public void setToDefault() {
        checkNotNull();
        Raw.setToDefault(address);
    }

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehicleSimulationContext} [Value]
     */
    public PxVehicleSimulationContext transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehicleSimulationContext.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    public static class Raw {
        public static native long PxVehicleSimulationContext();
        public static native void destroy(long address);
        public static native long getGravity(long address);
        public static native void setGravity(long address, long value);
        public static native long getFrame(long address);
        public static native void setFrame(long address, long value);
        public static native long getScale(long address);
        public static native void setScale(long address, long value);
        public static native long getTireSlipParams(long address);
        public static native void setTireSlipParams(long address, long value);
        public static native long getTireStickyParams(long address);
        public static native void setTireStickyParams(long address, long value);
        public static native float getThresholdForwardSpeedForWheelAngleIntegration(long address);
        public static native void setThresholdForwardSpeedForWheelAngleIntegration(long address, float value);
        public static native long getPvdContext(long address);
        public static native void setPvdContext(long address, long value);
        public static native int getType(long address);
        public static native void setToDefault(long address);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
    }
}
