package physx.vehicle2;

import physx.NativeObject;

/**
 * A description of the PhysX models employed to resolve suspension limit constraints.
 * @see PxVehiclePhysXConstraintState
 */
public class PxVehiclePhysXSuspensionLimitConstraintParams extends NativeObject {

    protected PxVehiclePhysXSuspensionLimitConstraintParams() { }

    private static native int __sizeOf();
    public static final int SIZEOF = __sizeOf();
    public static final int ALIGNOF = 8;
    
    public static PxVehiclePhysXSuspensionLimitConstraintParams wrapPointer(long address) {
        return address != 0L ? new PxVehiclePhysXSuspensionLimitConstraintParams(address) : null;
    }
    
    public static PxVehiclePhysXSuspensionLimitConstraintParams arrayGet(long baseAddress, int index) {
        if (baseAddress == 0L) throw new NullPointerException("baseAddress is 0");
        return wrapPointer(baseAddress + (long) SIZEOF * index);
    }
    
    protected PxVehiclePhysXSuspensionLimitConstraintParams(long address) {
        super(address);
    }

    // Destructor

    public void destroy() {
        if (address == 0L) {
            throw new IllegalStateException(this + " is already deleted");
        }
        if (isExternallyAllocated) {
            throw new IllegalStateException(this + " is externally allocated and cannot be manually destroyed");
        }
        Raw.destroy(address);
        address = 0L;
    }

    // Attributes

    /**
     * restitution is used by the restitution model used to generate a target velocity when resolving suspension limit
     * constraints.
     * <b>Note:</b> A value of 0.0 means that the restitution model is not employed.
     * <b>Note:</b> Restitution has no effect if directionForSuspensionLimitConstraint has value Enum::eNONE.
     */
    public float getRestitution() {
        checkNotNull();
        return Raw.getRestitution(address);
    }

    /**
     * restitution is used by the restitution model used to generate a target velocity when resolving suspension limit
     * constraints.
     * <b>Note:</b> A value of 0.0 means that the restitution model is not employed.
     * <b>Note:</b> Restitution has no effect if directionForSuspensionLimitConstraint has value Enum::eNONE.
     */
    public void setRestitution(float value) {
        checkNotNull();
        Raw.setRestitution(address, value);
    }

    /**
     */
    public PxVehiclePhysXSuspensionLimitConstraintParamsDirectionSpecifierEnum getDirectionForSuspensionLimitConstraint() {
        checkNotNull();
        return PxVehiclePhysXSuspensionLimitConstraintParamsDirectionSpecifierEnum.forValue(Raw.getDirectionForSuspensionLimitConstraint(address));
    }

    /**
     */
    public void setDirectionForSuspensionLimitConstraint(PxVehiclePhysXSuspensionLimitConstraintParamsDirectionSpecifierEnum value) {
        checkNotNull();
        Raw.setDirectionForSuspensionLimitConstraint(address, value.value);
    }

    // Functions

    /**
     * @param srcFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param trgFrame WebIDL type: {@link PxVehicleFrame} [Const, Ref]
     * @param srcScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @param trgScale WebIDL type: {@link PxVehicleScale} [Const, Ref]
     * @return WebIDL type: {@link PxVehiclePhysXSuspensionLimitConstraintParams} [Value]
     */
    public PxVehiclePhysXSuspensionLimitConstraintParams transformAndScale(PxVehicleFrame srcFrame, PxVehicleFrame trgFrame, PxVehicleScale srcScale, PxVehicleScale trgScale) {
        checkNotNull();
        return PxVehiclePhysXSuspensionLimitConstraintParams.wrapPointer(Raw.transformAndScale(address, srcFrame.getAddress(), trgFrame.getAddress(), srcScale.getAddress(), trgScale.getAddress()));
    }

    /**
     * @return WebIDL type: boolean
     */
    public boolean isValid() {
        checkNotNull();
        return Raw.isValid(address);
    }

    public static class Raw {
        public static native void destroy(long address);
        public static native float getRestitution(long address);
        public static native void setRestitution(long address, float value);
        public static native int getDirectionForSuspensionLimitConstraint(long address);
        public static native void setDirectionForSuspensionLimitConstraint(long address, int value);
        public static native long transformAndScale(long address, long srcFrame, long trgFrame, long srcScale, long trgScale);
        public static native boolean isValid(long address);
    }
}
